#!/bin/bash
/sbin/route del 100.0.0.2
/sbin/ifconfig cx0 down
/sbin/rmmod cxcisco
