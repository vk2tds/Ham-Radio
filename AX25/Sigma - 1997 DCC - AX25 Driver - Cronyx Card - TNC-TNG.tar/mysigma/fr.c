/*
 * Frame Relay protocol layer for Sigma driver.
 * 
 * Copyright (C) 1997, Serge V.Vakulenko <vak@cronyx.ru>
 * 
 * This program may be redistributed and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 *
 * This source is derived from the implementation of Frame Relay protocol
 * for Linux by Mike McLagan <mike.mclagan@linux.org>.
 *
 * Only one DLCI per channel is implemented at this time.
 */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/socket.h>
#include <linux/ioport.h>
#include <linux/in.h>
#include <linux/tqueue.h>

#include <asm/system.h>
#include <asm/segment.h>
#include <asm/io.h>
#include <asm/bitops.h>

#include <linux/inet.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/timer.h>
#include <linux/fcntl.h>

#include "cx.h"
#include "csigma.h"

#define FR_MTU		1600    /* default Frame Relay MTU (RFC 1490) */

#define FR_UI		0x03	
#define FR_CLNP		0x81
#define FR_IP		0xCC
#define FR_PADDING	0x00
#define FR_Q933		0x08
#define FR_SNAP		0x80

struct fr_data {
	struct enet_statistics stats;
	unsigned short dlci [CX_MAXDLCI];
};

static struct device *port2dev_map [NCX * NCHAN];

char cx_devname[] = "cx";

static int fr_xmit (struct sk_buff *skb, struct device *dev)
{
	struct fr_data *f = dev->priv;
	int port = dev->base_addr;

	if (dev->tbusy)
		return 1;
	if (! skb || ! f->dlci[0])
		return 0;
	if (skb->dev->type != ARPHRD_DLCI) {
		printk (KERN_WARNING "%s: invalid packet type %i tried to send on FRAD module.\n",
			dev->name, skb->dev->type);
		return 0;
	}

	set_bit (0, (void*) &dev->tbusy);

	/* if card is full, return unsuccessful */
	if (cx_hw_write (port, skb) == 0) {
		f->stats.tx_dropped++;
		return 1;
	}

	/* Packet was queued onto card, device not busy. */
	dev_kfree_skb (skb, FREE_WRITE);
	dev->tbusy = 0;
	f->stats.tx_packets++;
	return 0;
}

static int fr_header (struct sk_buff *skb, struct device *dev,
	unsigned short type, void *daddr, void *saddr, unsigned len)
{
	struct fr_data *f = dev->priv;
	unsigned char *hdr;
	unsigned hlen;

	/* Compute the additional header length. */
	switch (type) {
	case ETH_P_IP: hlen = 4; break;
	default:       hlen = 10; break;
	}

	/* Add the space for Frame Relay header. */
	hdr = skb_push (skb, hlen);
	if (! hdr)
		return 0;

	/* Fill the header. */
	hdr[0] = f->dlci[0] << 2;
	hdr[1] = (f->dlci[0] >> 2 & 0x3c0) | 1;
	hdr[2] = FR_UI;
	switch (type) {
	case ETH_P_IP:
		hdr[3] = FR_IP;
		break;
	default:
		hdr[3] = FR_PADDING;
		hdr[4] = FR_SNAP;
		hdr[5] = 0;
		hdr[6] = 0;
		hdr[7] = 0;
		*(short*) (hdr+8) = htons(type);
		break;
	}
	return hlen;
}

static void fr_rxisr (unsigned int port)
{
	struct device *dev = port2dev_map[port];
	struct fr_data *f;
	struct sk_buff *skb;
	unsigned char *hdr;
	int status, dlci, i, hlen;

	if (! dev) {
		cx_hw_read (port, NULL);
		return;
	}
	f = dev->priv;

	/* Get the received packet. */
	status = cx_hw_read (port, &skb);
	if (! status)
		return;

	/* Skip bad frames. */
	if (status < 0) {
		f->stats.rx_errors++;
		return;
	}
	skb->dev = dev;
	hdr = (unsigned char*) skb->data;

	/* Get the DLCI number. */
	dlci = (hdr[0] >> 2 & 0x3f) | (hdr[1] << 2 & 0x3c0);
	for (i=0; i<CX_MAXDLCI; ++i)
		if (dlci == f->dlci[i])
			break;

	if (i >= CX_MAXDLCI) {
		printk (KERN_NOTICE "%s: Received packet from invalid DLCI %i, ignoring.",
			dev->name, dlci);
bad:            f->stats.rx_errors++;
		dev_kfree_skb (skb, FREE_WRITE);
		return;
	}

	/* Process the packet. */
	if (hdr[2] != FR_UI) {
		printk(KERN_NOTICE "%s: Invalid header flag 0x%02X.\n",
			dev->name, hdr[2]);
		goto bad;
	}
	switch (hdr[3]) {
	default:
		printk (KERN_NOTICE "%s: Invalid pad byte 0x%02X.\n",
			dev->name, hdr[3]);
		goto bad;

	case FR_SNAP:
	case FR_Q933:
	case FR_CLNP:
		printk (KERN_NOTICE "%s: Unsupported NLPID 0x%02X.\n",
			dev->name, hdr[3]);
		goto bad;

	case FR_PADDING:
		if (hdr[4] != FR_SNAP) {
			printk (KERN_NOTICE "%s: Unsupported NLPID 0x%02X.\n",
				dev->name, hdr[4]);
			goto bad;
		}
		if (hdr[5] || hdr[6] || hdr[7]) {
			printk (KERN_NOTICE "%s: Unsupported organizationally unique identifier 0x%02X-%02X-%02X.\n",
				dev->name, hdr[5], hdr[6], hdr[7]);
			goto bad;
		}
		skb->protocol = *(short*) (hdr+8);
		hlen = 10;
		break;

	case FR_IP:
		skb->protocol = htons (ETH_P_IP);
		hlen = 4;
		break;
	}

	/* Discard the header. */
	skb->mac.raw = skb->data;
	skb_pull (skb, hlen);

	f->stats.rx_packets++;
	netif_rx (skb);
}

static void fr_txisr (unsigned int port)
{
	struct device *dev = port2dev_map [port];

	/* tell net layers we're clear... */
	if (dev)
		dev->tbusy = 0;
	mark_bh (NET_BH);
}

static int fr_open (struct device *dev)
{
	int port = dev->base_addr;
	int status;

   	/* init hardware */
	status = cx_hw_open (port, fr_rxisr, fr_txisr);
	if (status != 0) {
		printk (KERN_ERR "%s: failed (%d) to open Sigma card %d port %d\n",
		       dev->name, status, port / 16, port % 16);
		return status;
	}
	printk (KERN_DEBUG "%s: Sigma board %d port %d opened\n", dev->name,
	       port / 16, port % 16);

   	port2dev_map[port] = dev;
   	dev->start = 1;

   	MOD_INC_USE_COUNT;

   	return 0;
}

static int fr_close (struct device *dev)
{
	int port = dev->base_addr;

	cx_hw_close (port);
	port2dev_map [port] = 0;
   	dev->start = 0;
	dev->tbusy = 1;

   	MOD_DEC_USE_COUNT;

   	return 0;
}

static struct enet_statistics *fr_stats (struct device *dev)
{
	struct fr_data *f = dev->priv;

	return &f->stats;
}

static int fr_mtu (struct device *dev, int new_mtu)
{
	if (dev->start)
		return -EBUSY;

	/* Cannot change MTU for now. */
	return -EACCES;
}

void cxproto_dlci (struct device *dev, unsigned short *tab, int set)
{
	struct fr_data *f = dev->priv;

	if (! f) {
		memset (tab, 0, sizeof (f->dlci));
		return;
	}
	if (set)
		memcpy (f->dlci, tab, sizeof (f->dlci));
	else
		memcpy (tab, f->dlci, sizeof (f->dlci));
}

int cxproto_init (struct device *dev)
{
	struct fr_data *f;
	int i;

	/*
	 * Allocate the statistics data structure.
	 */
	f = kmalloc (sizeof(*f), GFP_KERNEL);
	if (! f)
		return -ENOMEM;
	memset (f, 0, sizeof(*f));
	dev->priv = f;

	/*
	 * Fill in the driver data structure.
	 */
	dev->open            = fr_open;
	dev->stop            = fr_close;
	dev->hard_start_xmit = fr_xmit;
	dev->hard_header     = fr_header;
	dev->get_stats       = fr_stats;
	dev->change_mtu      = fr_mtu;

	dev->type            = ARPHRD_DLCI;
	dev->family          = AF_INET;
	dev->mtu             = FR_MTU;
	dev->hard_header_len = 8;
	dev->pa_alen         = 4;
	dev->addr_len        = 2;

	for (i=0; i<DEV_NUMBUFFS; ++i)
		skb_queue_head_init (&dev->buffs[i]);
  
	port2dev_map [dev->base_addr] = 0;
	return 0;  
}

int cx_open (struct inode*, struct file*);
void cx_close (struct inode*, struct file*);
int cx_write (struct inode*, struct file*, const char*, int);
int cx_read (struct inode*, struct file*, char*, int);

struct file_operations cxproto_fops = {
	NULL,			/* lseek   */
	cx_read,		/* read    */
	cx_write,		/* write   */
	NULL,			/* readdir */
	NULL,			/* select  */
	cx_ioctl,		/* ioctl   */
	NULL,			/* mmap    */
	cx_open,		/* open    */
	cx_close,		/* release */
	NULL,			/* fsync   */
	NULL,			/* fasync  */
};
