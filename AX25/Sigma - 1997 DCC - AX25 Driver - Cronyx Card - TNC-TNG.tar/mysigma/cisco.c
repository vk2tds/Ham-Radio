/*
 * Cisco/HDLC protocol implementation for Sigma driver.
 * 
 * Copyright (C) 1997, Dmitry Gorodchanin <begemot@bgm.rosprint.net>.
 * 
 * This program may be redistributed and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 * 
 * This source is derived from:
 * 	RISCom/N2 network driver for Linux
 *   	Copyright 1995-1996, SDL Communications, Inc.
 *   	by Mike Natale (mike@ns.sdlcomm.com)
 *
 * Revision history:
 * 	06 Mar 1997 - version 0.02, first public release (bgm)
 */
#include <linux/config.h>
#include <linux/module.h>

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/socket.h>
#include <linux/ioport.h>
#include <linux/in.h>
#include <linux/if_ether.h>     /* For the statistics structure. */
#include <linux/if_arp.h>

#include <linux/tqueue.h>
#include <linux/termios.h>

#include <asm/system.h>
#include <asm/segment.h>
#include <asm/io.h>
#include <asm/bitops.h>

#include <linux/inet.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/timer.h>
#include <linux/fcntl.h>

#include "cx.h"

/*
 * Some cisco HDLC protocol-specific defintions
 */
#define CISCO_ADDR_UNICAST      0x0f
#define CISCO_ADDR_BCAST        0x8f

#define CISCO_CTL               0

#define CISCO_IP                0x0800 
#define CISCO_IPX               0x8137
#define CISCO_SLARP             0x8035

/*
 * Cisco SLARP control packet structure
 */
struct slarp_pkt {
	long    type;               	/* code */
	union {
		u_long	addr;		/* IP addr */
		long	myseq;		/* my sequence number */
	} f1;
	union {
		u_long	mask;		/* IP netmask */
		long	yourseq;	/* your sequence number */
	} f2;
	short	rel;			/* reliability */
	short	t1;			/* time alive (1) */
	short 	t0;			/* time alive (0) */
};

#define	SLARP_SIZE	18	/* sizeof rounds up */

/*
 * SLARP control packet codes
 */
#define SLARP_REQUEST		0
#define SLARP_REPLY		1
#define SLARP_KEEPALIVE		2

#define SLARP_KEEPALIVE_TIME	10 /* 10 sec */

static void cisco_txisr(unsigned int port);
static void cisco_rxisr(unsigned int port);

int init_module(void);
void cleanup_module(void);

static int mtu = 1500;

/* Queues, etc. */
static struct device *port2dev_map[NCX * NCHAN];

/* Slarp control stuff  */
static struct timer_list slarp_timer[NCX * NCHAN];
static int slarp_hisseq[NCX * NCHAN], slarp_ourseq[NCX * NCHAN];

/* Not all places in the high level net code have proper checks
   for availability of this function. So we better will provide it */
static int cisco_rebuild_header(void *eth, struct device *dev, 
				unsigned long raddr, struct sk_buff *skb)
{
	return 0;
}

static int cisco_header(struct sk_buff * skb, struct device *dev, 
			unsigned short type,  void *daddr, 
			void *saddr, unsigned len)
{
	return 0;
}

/*
 * this routine called by network interface with IP packet in skb->data
 */
static int cisco_xmit(struct sk_buff *skb, struct device *dev)
{
	struct enet_statistics *stats = (struct enet_statistics *)dev->priv;
	int port = dev->base_addr;

	/* Net layer thinks we're broken. Restart the channel  */
	if (set_bit(0,&dev->tbusy)) {
		int tickssofar = jiffies - dev->trans_start;
		if (tickssofar < 10 * HZ)
			 return 1;
#if 0
		restart_channel(port);
#else
		printk(KERN_ERR "%s: transmitter timeout\n", dev->name);
#endif
		stats->tx_dropped++;
		dev->tbusy=0;
		dev->trans_start = jiffies;
	}

	/* should never happen, but just in case... */
	if (skb == NULL) {
		printk(KERN_DEBUG "%s: NULL skb in cisco_xmit().\n", dev->name);
		dev_tint(dev);
		return 0;
	}

	skb_push(skb, 4);	/* Must be CISCO_HEADER_LENGHT */
	skb->data[0] = 0x0f;
	skb->data[1] = 0x00;
	*((unsigned short *)&skb->data[2]) = skb->protocol;

	/* if card is full, return unsuccessful */
	if (cx_hw_write(port, skb) == 0) {
		skb_pull(skb, 4);
		return 1;
	}

	/* packet was queued onto card, free skb, device not busy */
	dev->tbusy = 0;
	dev->trans_start = jiffies;

	dev_kfree_skb(skb, FREE_WRITE);
	stats->tx_packets++;

	return 0;
}

static struct enet_statistics * netget_stats(struct device *dev)
{
	return (struct enet_statistics *)dev->priv;
}

static void slarp (struct device *dev, struct sk_buff *skb) 
{
	struct slarp_pkt *slp = (struct slarp_pkt *)(skb->data + 4);

	struct enet_statistics *stats = (struct enet_statistics *)dev->priv;
	int port = dev->base_addr;
	unsigned uptime;

	if (skb->len >= SLARP_SIZE + 4) {
		switch (ntohl(slp->type)) {
	
		case SLARP_REQUEST:
			/* fill in header correctly, just in case.... */
			skb_pull(skb, 4);
			skb->protocol = htons(CISCO_SLARP);
			slp->type = htonl(SLARP_REPLY);
			slp->f1.addr = dev->pa_addr; /* in net order already */ 
			slp->f2.mask = dev->pa_mask; /* in net order already */
			uptime = jiffies * 10;
			/*  are following fields necessary on reply?  */
			slp->rel = 0xffff;
			slp->t1 = htons(uptime >> 16);
			slp->t0 = htons(uptime & 0xffff);
			printk(KERN_DEBUG "%s: Got SLARP request.\n", dev->name);
			skb_queue_head(&dev->buffs[0], skb);
			mark_bh(NET_BH);
			stats->rx_packets++;
			return;
	
		case SLARP_REPLY:
			printk(KERN_NOTICE "%s: Got unexpected SLARP reply.\n", dev->name);
			stats->rx_packets++;
			break;
	
		case SLARP_KEEPALIVE:
			slarp_hisseq[port] = ntohl ( slp->f1.myseq );
			stats->rx_packets++;
			break;
	
		default:
			printk(KERN_NOTICE "%s: Got unrecognized SLARP packet,"
			       " type: 0x%lx\n", dev->name, ntohl(slp->type));
			stats->rx_dropped++;
			break;
		}
	} else {
		printk(KERN_NOTICE "%s: Got short SLARP packet, len: %ld\n",
		       dev->name, skb->len);
		stats->rx_dropped++;
	}
	skb->free = 1;
	kfree_skb(skb, FREE_READ);
}

static void cisco_rxisr(unsigned int port) 
{
	struct device * dev = port2dev_map[port];
	struct enet_statistics *stats;
	struct sk_buff *skb;
	int proto, status;

	if (!dev) {
		cx_hw_read(port, NULL);
		return;
	}

	stats = (struct enet_statistics *)dev->priv;

	if ((status = cx_hw_read(port, &skb))) {
		/* skip bad frames */
		if (status < 0) {
			stats->rx_errors++;
			return;
		}

		proto = ntohs(*((unsigned short *)&skb->data[2]));
		switch (proto) {
		case CISCO_IP: 
                case CISCO_IPX:
			/*  An IP/IPX packet.  Send to net layer.  */
			skb->dev = dev;
			skb->protocol = htons(proto);
			skb_pull(skb, 4);/* Remove CISCO header */
			skb->mac.raw = skb->data;
			netif_rx(skb);
			stats->rx_packets++;
			break;
		case CISCO_SLARP:
			/*  A SLARP packet. Send to slarp routine. */
			slarp (dev, skb);
			break;
		default:
			/* drop it. */
			printk (KERN_DEBUG "%s: received unrecognized packet (proto %04x)\n",
				dev->name, proto);
			skb->free = 1;
			kfree_skb(skb, FREE_READ);
			stats->rx_dropped++;
			break;
		}
	} 
}

static void slarp_keepalive (unsigned long arg)
{
	struct slarp_pkt *slp;
	struct device *dev = (struct device *) arg;
	unsigned uptime;
	int port = dev->base_addr;
	struct sk_buff * skb;
	int delay = HZ;

	skb = dev_alloc_skb(SLARP_SIZE + 4);
	if (skb) {
		skb_reserve(skb, 4);
		skb_put(skb, SLARP_SIZE);
		skb->free = 1;
		skb->protocol = htons(CISCO_SLARP);
		slp = (struct slarp_pkt *)(skb->data);
		slp->type = htonl(SLARP_KEEPALIVE);
		slp->f1.myseq = htonl(++slarp_ourseq[port]);
		slp->f2.yourseq = htonl(slarp_hisseq[port]);
		slp->rel = 0xffff;
		uptime = jiffies * 10;
		slp->t1 = htons(uptime >> 16);
		slp->t0 = htons(uptime & 0xffff);
		skb_queue_head(&dev->buffs[0], skb);
		mark_bh(NET_BH);
		delay = SLARP_KEEPALIVE_TIME * HZ;
	}
	slarp_timer[port].expires = jiffies + delay;   /* 10 sec */
	slarp_timer[port].data = arg;
	slarp_timer[port].function = &slarp_keepalive;
	add_timer(&slarp_timer[port]);
}

static void cisco_txisr (unsigned int port)
{
	struct device *dev = port2dev_map[port];

	/* tell net layers we're clear... */
	if (dev)
		dev->tbusy = 0;
	mark_bh(NET_BH);
}

static int cisco_open(struct device *dev) 
{
	int status;
	int port = dev->base_addr;

   	/* init hardware */
   	if ((status = cx_hw_open (port, cisco_rxisr, cisco_txisr ))) {
		printk(KERN_ERR "%s: failed (%d) to open Cronyx card %d port %d\n", 
		       dev->name, status, port / 16, port % 16);
		return status;
	}
	printk(KERN_DEBUG "%s: Cronyx board %d port %d opened\n", dev->name,
	       port / 16, port % 16);

  	memset(dev->priv, 0, sizeof(struct enet_statistics));
   	port2dev_map[port] = dev;
   	dev->start = 1;
   	MOD_INC_USE_COUNT;

   	slarp_hisseq[port] = 0;
   	slarp_ourseq[port] = jiffies;
   	init_timer(&slarp_timer[port]);

	slarp_keepalive((unsigned long) dev);
   	return 0;
}

static int cisco_close(struct device *dev)
{
	int port = dev->base_addr;

   	cx_hw_close(port);
   	port2dev_map[port] = 0;
   	dev->start = 0;
	del_timer(&slarp_timer[port]);

   	MOD_DEC_USE_COUNT;

   	return 0;
}

int cxproto_init(struct device *dev) 
{
	int i;
	int port = dev->base_addr;

	dev->open            = cisco_open;
	dev->stop            = cisco_close;
	dev->hard_start_xmit = cisco_xmit;
	dev->tbusy           = 0;
	dev->start           = 0;

	/* fill in device generic fields */
	dev->hard_header     = cisco_header;
	dev->rebuild_header  = cisco_rebuild_header;

	dev->type            = ARPHRD_PPP;
	dev->hard_header_len = 4;
	dev->mtu             = mtu; /* eth_mtu */
	dev->addr_len        = 0;

	dev->tx_queue_len    = 100;

	/* New-style flags. */
	dev->flags           = IFF_POINTOPOINT | IFF_NOARP;
	dev->family          = AF_INET;
	dev->pa_addr         = 0;
	dev->pa_brdaddr      = 0;
	dev->pa_mask         = 0;
	dev->pa_alen         = 4;
	dev->priv = kmalloc(sizeof(struct enet_statistics), GFP_KERNEL);
	memset(dev->priv, 0, sizeof(struct enet_statistics));
	dev->get_stats = netget_stats;

	for (i = 0; i < DEV_NUMBUFFS; i++)
		skb_queue_head_init(&dev->buffs[i]);
  
	port2dev_map[port] = 0;
	return 0;  
}

int cxproto_dlci (unsigned long arg, int add)
{
	return EPFNOSUPPORT;
}

int cx_open(struct inode*, struct file*);
void cx_close(struct inode*, struct file*);
int cx_write(struct inode*, struct file*, const char*, int);
int cx_read(struct inode*, struct file*, char*, int);

char cx_devname[] = "cx";

struct file_operations cxproto_fops = {
	NULL,			/* lseek   */
	cx_read,		/* read    */
	cx_write,		/* write   */
	NULL,			/* readdir */
	NULL,			/* select  */
	cx_ioctl,		/* ioctl   */
	NULL,			/* mmap    */
	cx_open,		/* open    */
	cx_close,		/* release */
	NULL,			/* fsync   */
	NULL,			/* fasync  */
};

