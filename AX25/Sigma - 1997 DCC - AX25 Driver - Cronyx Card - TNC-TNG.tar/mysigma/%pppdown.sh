#!/bin/bash
killall pppd
sleep 1
/sbin/rmmod cxppp
