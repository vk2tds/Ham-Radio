/*
 * Cronyx-Sigma adapter driver for Linux.
 * 
 * Copyright (C) 1997, Dmitry Gorodchanin <begemot@bgm.rosprint.net>.
 * 
 * This program may be redistributed  and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 */
#ifndef _LINUX_CX_H
#define _LINUX_CX_H

#ifdef __KERNEL__

#define CX_VERSION	"0.03"

#define NCX 		3
#ifndef NCHAN	
#define NCHAN		16
#endif

#define CX_MAJOR	60	/* For now, need registration though. */
#define CX_UNIT_MINOR	255	/* Control device minor */

typedef void (*isr)(unsigned int port);

/* cx.c */
extern int  cx_hw_init(void);
extern void cx_hw_release(void);
extern int  cx_hw_open(unsigned int chan, isr rxisr, isr txisr);
extern void cx_hw_close(unsigned int chan);
extern int  cx_hw_write(unsigned int chan, const struct sk_buff * skb);
extern int  cx_hw_read(unsigned int chan, struct sk_buff ** skb);
extern int  cx_hw_dcd(unsigned int chan);

extern int  cx_ioctl(struct inode *inode, struct file *file,
		     unsigned int cmd, unsigned long arg);

extern struct file_operations cx_default_fops;

#endif
#endif
