#!/bin/bash
/sbin/insmod cxfr.o port=0x260 irq=12 drq=6
cxconfig cx0 +extclock dlci=16
/sbin/ifconfig cx0 100.0.0.1 pointopoint 100.0.0.2
/sbin/route add 100.0.0.2 dev cx0
