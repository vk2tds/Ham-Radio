#!/bin/bash
/sbin/insmod cxppp.o port=0x260 irq=12 drq=6
cxconfig cx0 +extclock
pppd cx0 -am -vj -ac -pc persist
