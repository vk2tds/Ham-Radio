/*
 * Cronyx-Sigma adapter driver for Linux.
 * 
 * Copyright (C) 1997, Dmitry Gorodchanin <begemot@bgm.rosprint.net>.
 * 
 * This program may be redistributed and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 * 
 * This source is derived from:
 * 1) RISCom/N2 network driver for Linux
 *    Copyright 1995-1996, SDL Communications, Inc.
 *    by Mike Natale (mike@ns.sdlcomm.com)
 * 2) Cronyx-Sigma adapter driver for FreeBSD 
 *    Copyright (C) 1994-1996 Cronyx Engineering Ltd.
 *    by Serge Vakulenko (vak@cronyx.ru)
 *
 * Revision history:
 * 	06 Mar 1997 - version 0.02, first public release (bgm)
 * 	09 Apr 1997 - version 0.03, added frame relay protocol (vak)
 */
#include <linux/config.h>
#define __NO_VERSION__
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/errno.h>
#include <linux/malloc.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <asm/io.h>

#include "csigma.h"
#include "cxreg.h"

#include "cx.h"
#include "cronyxfw.h"
#include "csigmafw.h"

#define CX_IO_RANGE 	0x20
#define CX_DMABUFSIZE   (7 * 256)

#define B_SIGMA_NONE	0xff	/* No board installed */

static cx_board_t  cxboard[NCX] = { 
	{ B_SIGMA_NONE, },
	{ B_SIGMA_NONE, },
	{ B_SIGMA_NONE, },
};

static cx_chan_t * cx_chan[NCX*NCHAN] = { NULL, };

static short irq_valid_values [] = { 3, 5, 7, 10, 11, 12, 15, 0 };
static short drq_valid_values [] = { 5, 6, 7, 0 };
static short port_valid_values [] = {
        0x240, 0x260, 0x280, 0x300, 0x320, 0x380, 0x3a0, 0,
};

static struct sk_buff_head rxdata[NCX* NCHAN];
static struct wait_queue *rxq[NCX * NCHAN] = { NULL, };
static struct wait_queue *txq[NCX * NCHAN] = { NULL, };

static isr cx_rxisr[NCX*NCHAN] = { NULL, };
static isr cx_txisr[NCX*NCHAN] = { NULL, };
static int cx_opens[NCX] = { 0, };
static cx_board_t * irq2dev[16] = { NULL, };
static struct device cx_dev[NCX*NCHAN];

int port[NCX] = { 0, };
int irq[NCX]  = { 0, };
int drq[NCX]  = { 0, };

int dbg = 1;

static void cx_hw_intr(int irq, void * dev_id, struct pt_regs * regs);

extern void cxproto_dlci (struct device *dev, unsigned short *tab, int set);

extern inline cx_board_t * cx_board(int n)
{
	return cxboard + n;
}

static int valid (unsigned short value, unsigned short *list)
{
        while (*list)
                if (value == *list++)
                        return 1;
        return 0;
}

void cx_c_rxisr(unsigned int chan)
{
	int status;
	struct sk_buff * skb;

#if 0
	printk(KERN_DEBUG "cx%d: cx_c_rxisr\n", chan);
#endif
        status = cx_hw_read(chan, &skb);
	/* skip bad frames */
	if (status < 0) {
		printk(KERN_NOTICE "cx(%d): bad input frame status %x\n",
		       chan, -status);
		return;
	}
	
	if (dbg) {
		int len = skb->len, i;
		if (len > 12)
			len = 12;
		printk(KERN_DEBUG "cx(%d): cx_c_rxisr: ", chan);
		for (i = 0; i < len; i++) 
			printk("%02x ", skb->data[i]);
		printk("\n");
	}

	skb->free = 1;
#if 0
	if (!cx_opens[chan]) {
		kfree_skb(skb, FREE_READ);
		return;
	}
#endif
	if (skb_queue_len(&rxdata[chan]) >= 20) {
		kfree_skb(skb, FREE_READ);
		return;
	}
	skb_queue_tail(&rxdata[chan], skb);
	wake_up_interruptible(&rxq[chan]);
}

void cx_c_txisr(unsigned int chan)
{
	wake_up_interruptible(&txq[chan]);
}

int cx_open(struct inode *inode, struct file *file)
{
	unsigned int minor = MINOR(inode->i_rdev);
	int err;

#if 0
	printk(KERN_ERR "cx: cxopen minor %d\n", minor);
#endif
	if (minor == CX_UNIT_MINOR) {
		MOD_INC_USE_COUNT;
		return 0;
	}
	if ((err = cx_hw_open(minor, cx_c_rxisr, cx_c_txisr))) 
		return err;

	skb_queue_head_init(&rxdata[minor]);

	MOD_INC_USE_COUNT;
	return 0;
}

void cx_close(struct inode *inode, struct file *file)
{
	unsigned int minor = MINOR(inode->i_rdev);
	struct sk_buff * skb;

	if (minor == CX_UNIT_MINOR) {
		MOD_DEC_USE_COUNT;
		return;
	}
	cx_hw_close(minor);

	while ((skb = skb_dequeue(&rxdata[minor])))
		kfree_skb(skb, FREE_READ);

	MOD_DEC_USE_COUNT;
}

int cx_write(struct inode *inode, struct file *file, const char *buf, int len)
{
	unsigned int minor = MINOR(inode->i_rdev);
	struct sk_buff * skb = NULL;
	int ret = 0;

	if (minor == CX_UNIT_MINOR) 
		return -EIO;

	do {
                if (!skb) {
                        skb = alloc_skb(len, GFP_KERNEL);
                        skb->free = 1;
                }
                if (skb) {
                        memcpy_fromfs(skb_put(skb, len), buf, len);
                        if ((ret = cx_hw_write(minor, skb))) {
                                if (dbg) {
                                        int i;
                                        
                                        if (len > 12)
                                                len = 12;
                                        printk(KERN_DEBUG "cx(%d): write: ", minor);
                                        for (i = 0; i < len; i++) 
                                                printk("%02x ",skb->data[i]);
                                        printk("\n");
                                }
                                kfree_skb(skb, FREE_READ);
                                return ret;
                        }
                }
                if (file->f_flags & O_NONBLOCK)
                        goto free_and_exit;
                /* sleep */
                interruptible_sleep_on(&txq[minor]); 
                
        } while (!(current->signal & ~current->blocked));

        ret = -ERESTARTNOINTR;
free_and_exit:
	if (skb) 
                kfree_skb(skb, FREE_READ);
        return ret;
}

int cx_read(struct inode *inode, struct file *file, char *buf, int len)
{
        int minor = MINOR(inode->i_rdev);
        struct sk_buff * skb;

	if (minor == CX_UNIT_MINOR) 
		return -EIO;
	
        do {
                if ((skb = skb_dequeue(&rxdata[minor]))) {
                        if (len > skb->len) 
                                len = skb->len;
                        memcpy_tofs(buf, skb->data, len);
                        kfree_skb(skb, FREE_READ);
                        return len;
                }
                /* No data available  */
                if (file->f_flags & O_NONBLOCK) 
                        return -EWOULDBLOCK;
                interruptible_sleep_on(&rxq[minor]); 
        } while (!(current->signal & ~current->blocked));
        
        return -ERESTARTNOINTR;
}

static int cx_setmode(unsigned long arg) 
{
	int error;
	cx_options_t opt;
	cx_chan_t * c;
	int oldmode;

	if ((error = verify_area(VERIFY_READ, (void *)arg, sizeof(opt))))
		return error;
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &cxboard[opt.board].chan[opt.channel];

	if (c->type == T_NONE) 
		return -EINVAL;

	if (c->type == T_ASYNC && opt.mode != M_ASYNC)
		return -EINVAL;
	
	if (opt.mode == M_ASYNC)
		return -EINVAL; /* FIXME: No async support for now */

	oldmode   = c->mode;
	c->mode   = opt.mode;
	c->rxbaud = opt.rxbaud;
	c->txbaud = opt.txbaud;
	c->opt    = opt.opt;
	c->aopt   = opt.aopt;
	c->hopt   = opt.hopt;
	cxproto_dlci (cx_dev+opt.channel, opt.sopt.dlci, 1);

	switch(c->num) {
	case 0: 
		c->board->if0type = opt.iftype;
		break;
	case 8: 
		c->board->if8type = opt.iftype;
		break;
	}
	
	if (oldmode != c->mode) {
		cx_setup_chan(c);
	} else {
		cx_update_chan(c);
	}

	outb(0, IER(c->chip->port));
	return 0;
}

static int cx_getmode(unsigned long arg) 
{
	int error;
	cx_options_t opt;
	cx_chan_t * c;

	if ((error = verify_area(VERIFY_WRITE, (void *)arg, sizeof (opt))))
		return error;
	
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &(cxboard[opt.board].chan[opt.channel]);

	if (c->type == T_NONE) 
		return -EINVAL;

	opt.magic = CX_OPT_MAGIC;
	opt.port = c->board->port;
	opt.irq  = c->board->irq;
	opt.dma  = c->board->dma;
	strcpy (opt.name, c->board->name);
	opt.type   = c->type;
	opt.mode   = c->mode;
	opt.rxbaud = c->rxbaud;
	opt.txbaud = c->txbaud;
	opt.opt    = c->opt;
	opt.aopt   = c->aopt;
	opt.hopt   = c->hopt;
	opt.bopt   = c->board->opt;
	cxproto_dlci (cx_dev+opt.channel, opt.sopt.dlci, 0);

	switch (c->num) {
	case 0:  opt.iftype = c->board->if0type; break;
	case 8:  opt.iftype = c->board->if8type; break;
	default: opt.iftype = 0;                 break;
	}

	memcpy_tofs((void *) arg, &opt, sizeof(opt));
	return 0;
}

static int cx_getstat(unsigned long arg) 
{
	int error;
	cx_stat_t opt;
	cx_chan_t * c;

	if ((error = verify_area(VERIFY_WRITE, (void *)arg, sizeof (opt))))
		return error;
	
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &(cxboard[opt.board].chan[opt.channel]);

	if (c->type == T_NONE) 
		return -EINVAL;

	opt.rintr  = c->stat->rintr;
	opt.tintr  = c->stat->tintr;
	opt.mintr  = c->stat->mintr;
	opt.ibytes = c->stat->ibytes;
	opt.ipkts  = c->stat->ipkts;
	opt.ierrs  = c->stat->ierrs;
	opt.obytes = c->stat->obytes;
	opt.opkts  = c->stat->opkts;
	opt.oerrs  = c->stat->oerrs;

	memcpy_tofs((void *) arg, &opt, sizeof(opt));
	return 0;
}

int cx_ioctl(struct inode *inode, struct file *file,
		    unsigned int cmd, unsigned long arg)
{
	unsigned int minor = MINOR(inode->i_rdev);

	if (minor != CX_UNIT_MINOR)
		return -EINVAL;

	switch(cmd) {
	case CXIOCSETMODE:
		return cx_setmode(arg);
	case CXIOCGETMODE:
		return cx_getmode(arg);
	case CXIOCGETSTAT:
		return cx_getstat(arg);
	default:
		return -EINVAL; 
	}
}

static int cx_probe(int i, short port, short irq, short drq)
{
	cx_board_t * b = cx_board(i);
	int n;
	int ports = 0;

	if (!valid(port, port_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid base address 0x%03x.\n", 
		       i, port);
		return 0;
	}
	if (!valid(irq, irq_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid IRQ %d.\n", i, irq);
		return 0;
	}
	if (!valid(drq, drq_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid DMA %d.\n", i, drq);
		return 0;
	}
	if (check_region(port, CX_IO_RANGE)) {
		printk(KERN_ERR "cx%d: Skipping board with base address 0x%03x,"
		       " I/O space in use.\n", i, port);
		return 0;
	}
	if (!cx_probe_board(port)) {
		printk(KERN_ERR "cx%d: No board found with base address 0x%03x\n",
		       i, port);
		return 0;
	}
	cx_init(b, i, port, irq, drq);
	printk(KERN_INFO "cx%d: <Cronyx-%s> at 0x%03x irq %d drq %d\n", i,
	       b->name, port, irq, drq);

	request_region(port, CX_IO_RANGE, "Cronyx");

	for (n = 0; n < NCHAN; n++) {
                cx_chan_t *c = b->chan + n;

                cx_chan[b->num * NCHAN + n] = c;

		if (c->type == T_NONE)
			continue;
#if 1
		if (c->mode == M_ASYNC)
			c->mode = M_HDLC;
#endif
		ports++;
	}

	if (!ports) {
		printk(KERN_ERR "cx%d: No operational ports on this board\n",
		       i);
		return 0;
	}
	return 1;
}

/****************************************************************************/

int cx_hw_init(void)
{
	int i = 0;
	int n = 0;

	for (i = 0; i < NCX; i++) {
		if (port[i] && cx_probe(i, port[i],irq[i],drq[i]))
			n++;
	}
	if (!n) {
		printk(KERN_ERR "cx: No Cronyx boards detected.\n");
		return -EIO;
	}
	return 0;
}

void cx_hw_release(void)
{
	int i;

	unregister_chrdev(CX_MAJOR, "Cronyx");

	for (i = 0; i < NCX; i++) {
		if (cxboard[i].type != B_SIGMA_NONE) {
			release_region(cxboard[i].port, CX_IO_RANGE);
		}
	}
}

int cx_hw_open(unsigned int chan, isr rxisr, isr txisr)
{
	cx_chan_t * c;
	int board, err;
	unsigned short port;

	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	if (!rxisr || !txisr)
		return -EINVAL;

	if (cx_rxisr[chan])
		return -EBUSY;

	board = c->board->num;
	if (!cx_opens[board]++) {
		long fw_len;
		const char *fw_version, *fw_date, *fw_copyright;
		const cr_dat_tst_t *fw_tvec;
		const unsigned char *fw_data;

		switch (c->board->type) {
		case B_SIGMA_800:
			fw_len       = csigma_fw_len;
			fw_version   = csigma_fw_version;
			fw_date      = csigma_fw_date;
			fw_copyright = csigma_fw_copyright;
			fw_tvec      = csigma_fw_tvec;
			fw_data      = csigma_fw_data;
			break;
		default:
			fw_len       = 0;
			fw_version   = 0;
			fw_date      = 0;
			fw_copyright = 0;
			fw_tvec      = 0;
			fw_data      = 0;
			break;
		}
		if (fw_data) {
			printk(KERN_INFO "cx%d: Firmware version %s (%s)\n",
				board, fw_version, fw_date);
			printk(KERN_INFO "cx%d: %s\n", board, fw_copyright);
		}
		if (! cx_setup_board (c->board, fw_data, fw_len, fw_tvec)) {
			printk(KERN_ERR "cx%d: Error loading firmware\n", 
				board);
			return -ENODEV;
		}
		if ((err = request_irq(c->board->irq, cx_hw_intr,
				       SA_INTERRUPT, "Cronyx", NULL))) {
			printk(KERN_ERR "cx%d: Unable to get IRQ %d"
			       " (error %d).\n", board, c->board->irq, err);
			return -EBUSY;
		}
		irq2dev[c->board->irq] = c->board;
		MOD_INC_USE_COUNT;
		/* enable board */
	}

	if (!(c->arbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto no_memory;
	if (!(c->brbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_arbuf;
	if (!(c->atbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_brbuf;
	if (!(c->btbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_atbuf;
	
	cx_rxisr[chan] = rxisr;
	cx_txisr[chan] = txisr;

	cx_setup_chan(c);	/* port initialization */

	/* Initialize channel, enable receiver and transmitter */
	cx_cmd (port, CCR_INITCH | CCR_ENRX | CCR_ENTX);
	/* Repeat the command, to avoid the rev.H bug */
	cx_cmd (port, CCR_INITCH | CCR_ENRX | CCR_ENTX);

	/* Start receiver */
	outw (CX_DMABUFSIZE,ARBCNT(port));
	outb (BSTS_OWN24,   ARBSTS(port));
	outw (CX_DMABUFSIZE,BRBCNT(port));
	outb (BSTS_OWN24,   BRBSTS(port));

	/* Raise DTR and RTS */
	cx_chan_dtr (c, 1);
	cx_chan_rts (c, 1);

	/* Enable interrupts */
	outb (IER_RXD | IER_TXD, IER(port));
	
	return 0;

free_atbuf:
	kfree(c->atbuf);
	c->atbuf = NULL;
free_brbuf:
	kfree(c->brbuf);
	c->brbuf = NULL;
free_arbuf:
	kfree(c->arbuf);
	c->arbuf = NULL;
no_memory:
	printk(KERN_ERR "cx%d: Can't alloc DMA memory for port %d.",
	       board, chan);
	if (!--cx_opens[board]) {
		irq2dev[c->board->irq] = NULL;
		free_irq(c->board->irq, NULL);
		/* disable board */
		MOD_DEC_USE_COUNT;
	}
	return -ENOMEM;
}

void cx_hw_close(unsigned int chan)
{
	cx_chan_t * c;
	int board;
	unsigned short port;
	
	if (chan >= NCX*NCHAN || !(c = cx_chan[chan]) 
	    || c->type == T_NONE || !cx_rxisr[chan])
		return;

	if (!(port = c->chip->port))
		return;

	board = c->board->num;
	/* Reset the channel */
	outb (c->num & 3, CAR(port));
	outb (STC_ABORTTX | STC_SNDSPC, STCR(port));
	cx_setup_chan (c);

	cx_rxisr[chan] = NULL;
	cx_txisr[chan] = NULL;
	kfree(c->btbuf);
	kfree(c->atbuf);
	kfree(c->brbuf);
	kfree(c->arbuf);
	if (!--cx_opens[board]) {
		/* disable board */
		irq2dev[c->board->irq] = NULL;
		free_irq(c->board->irq, NULL);
		MOD_DEC_USE_COUNT;
	}
}

/*
 * Handle transmit interrupt.
 */
static int cx_hw_tint(cx_chan_t *c)
{
	unsigned short port = c->chip->port;
	unsigned char tisr = inb (TISR(port));
	unsigned char teoir = 0;
	int num = c->board->num * NCHAN + c->num;

	if (tisr & (TIS_BUSERR | TIS_UNDERRUN)) {
		printk(KERN_DEBUG "cx%d.%d: transmit error, tisr=%x,"
		       " atbsts=%x, btbsts=%x\n",
		       c->board->num, c->num, tisr,
		       inb(ATBSTS(port)), inb(BTBSTS(port)));
		++c->stat->oerrs;
		
		/* Terminate the failed buffer. */
		/* teoir = TEOI_TERMBUFF; */
	} else { 
#if 0
		printk(KERN_DEBUG "cx%d.%d: hdlc transmit interrupt,"
		       " tisr=%x, atbsts=%x, btbsts=%x\n",
			c->board->num, c->num, tisr,
			inb(ATBSTS(port)), inb(BTBSTS(port)));
#endif
	}

	if (tisr & TIS_EOFR) {
		++c->stat->opkts;
	}

	if (cx_txisr[num]) 
		(cx_txisr[num])(num);
	
	return teoir;
}

static void cx_hw_intr(int irq, void * dev_id, struct pt_regs * regs)
{
	cx_board_t * b = irq2dev[irq];

	if (!b) 
		return;

	while (!(inw(BSR(b->port)) & BSR_NOINTR)) {
		/* Acknowledge the interrupt to enter the interrupt context. */
		/* Read the local interrupt vector register. */
		unsigned char livr = inb (IACK(b->port, BRD_INTR_LEVEL));
		cx_chan_t *c = b->chan + (livr>>2 & 0xf);
		unsigned short port = c->chip->port;
		unsigned short eoiport = REOIR(port);
		unsigned char eoi = 0;
		int num = b->num * NCHAN + c->num;

		if (c->type == T_NONE) {
			printk (KERN_DEBUG "cx%d.%d: unexpected interrupt, "
				"livr=0x%x\n", c->board->num, c->num, livr);
			continue;       /* incorrect channel number? */
		}

		/* Clear RTS to stop receiver data flow while we are busy
		 * processing the interrupt, thus avoiding underruns. */

		outb (0, MSVR_RTS(port));
		c->rts = 0;

		switch (livr & 3) {
		case LIV_EXCEP:         /* receive exception */
		case LIV_RXDATA:        /* receive interrupt */
			++c->stat->rintr;
			/* Handle incoming packet */
			if (cx_rxisr[num]) 
				(cx_rxisr[num])(num);
			/* Restart receiver. */
			if (!(inb(ARBSTS(port)) & BSTS_OWN24)) {
				outw(CX_DMABUFSIZE, ARBCNT(port));
				outb(BSTS_OWN24,    ARBSTS(port));
			}
			if (!(inb(BRBSTS(port)) & BSTS_OWN24)) {
				outw(CX_DMABUFSIZE, BRBCNT(port));
				outb(BSTS_OWN24,    BRBSTS(port));
			}
			break;
		case LIV_TXDATA:        /* transmit interrupt */
			++c->stat->tintr;
			eoiport = TEOIR(port);
			cx_hw_tint(c);
			break;
		case LIV_MODEM:         /* modem/timer interrupt */
			++c->stat->mintr;
			eoiport = MEOIR(port);
#if 0
			cx_hw_mint (c);
#endif
			break;
		}

		/* Raise RTS for this channel if and only if
		 * both receive buffers are empty. */
		if ((inb(CSR(port)) & CSRA_RXEN) &&
		    (inb(ARBSTS(port)) & BSTS_OWN24) &&
		    (inb(BRBSTS(port)) & BSTS_OWN24)) {
			outb(MSV_RTS, MSVR_RTS(port));
			c->rts = 1;
		}

		/* Exit from interrupt context. */
		outb(eoi, eoiport);
	}
}

/* Shouldn't be executed in the interrupt context */
int cx_hw_write(unsigned int chan, const struct sk_buff * skb)
{
	unsigned short port;
	cx_chan_t * c;
	unsigned long flags;
	int len = skb->len;

	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	if (skb->len > CX_DMABUFSIZE) {
		return -EIO;
	}

	save_flags(flags);
	cli();
	/* Set the current channel number. */
	outb (c->num & 3, CAR(port));

	if ((inb(DMABSTS(port)) & DMABSTS_NTBUF) &&
	    !(inb(BTBSTS(port)) & BSTS_OWN24)) {
#if 0
		printk(KERN_DEBUG "cx: B buf choosen\n");
#endif
		memcpy(c->btbuf, skb->data, skb->len);
		outw(len, BTBCNT(port));
		outb(BSTS_EOFR | BSTS_INTR | BSTS_OWN24, BTBSTS(port));
	} else if (!(inb(ATBSTS(port)) & BSTS_OWN24)) {
#if 0
		printk(KERN_DEBUG "cx: A buf choosen\n");
#endif
		memcpy(c->atbuf, skb->data, skb->len);
		outw(len, ATBCNT(port));
		outb(BSTS_EOFR | BSTS_INTR | BSTS_OWN24, ATBSTS(port));
	} else {
#if 0
		printk(KERN_DEBUG "cx: No buffers free\n");
#endif
		len = 0;
	}

	/*
	 * Enable TXMPTY interrupt,
	 * to catch the case when the second buffer is empty.
	 */
	if ((inb(ATBSTS(port)) & BSTS_OWN24) &&
	    (inb(BTBSTS(port)) & BSTS_OWN24)) {
		outb (IER_RXD | IER_TXD | IER_TXMPTY, IER(port));
	} else
		outb (IER_RXD | IER_TXD, IER(port));

	restore_flags(flags);
	return len;
}

/* Should be executed in the interrupt context */
int cx_hw_read(unsigned int chan, struct sk_buff ** skb)
{
	unsigned short port;
	unsigned short len, risr;
	cx_chan_t * c;

	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	risr = inw(RISR(port));

	/* Receive errors. */
	if (risr & (RIS_BUSERR | RIS_OVERRUN | RISH_CRCERR | RISH_RXABORT)) {
		printk(KERN_DEBUG "cx%d.%d: receive error, risr=%x\n",
		       c->board->num, c->num, risr);
		++c->stat->ierrs;
		return -EIO;

	} else if (risr & RIS_EOBUF) {
#if 0		
		printk(KERN_DEBUG "cx%d.%d: hdlc receive interrupt, risr=%x,"
		       " arbsts=%x, brbsts=%x\n",
		       c->board->num, c->num, risr,
		       inb (ARBSTS(port)), inb (BRBSTS(port)));
#endif
		++c->stat->ipkts;

		/* Handle received data. */
		len = (risr & RIS_BB) ? inw(BRBCNT(port)) : inw(ARBCNT(port));
		c->stat->ibytes += len;
		if (len > CX_DMABUFSIZE) {
			/* Fatal error: actual DMA transfer size
			 * exceeds our buffer size.  It could be caused
			 * by incorrectly programmed DMA register or
			 * hardware fault.  Possibly, should panic here. */
			printk(KERN_ERR "cx%d.%d: panic!"
			       " DMA buffer overflow: %d bytes\n",
			       c->board->num, c->num, len);
			return -EIO;

		} else if (! (risr & RIS_EOFR)) {
			/* The received frame does not fit in the DMA buffer.
			 * It could be caused by serial lie noise,
			 * or if the peer has too big MTU. */
			printk(KERN_ERR "cx%d.%d: received frame length"
			       " exceeds MTU, risr=%x\n",
			       c->board->num, c->num, risr);
			return -EIO;
		} else {
			/* Valid frame received. */
#if 0
			printk(KERN_DEBUG "cx%d.%d: hdlc received %d bytes\n",
			       c->board->num, c->num, len);
#endif
			if (!(*skb = dev_alloc_skb(len)))
				return -ENOMEM;

			skb_put(*skb, len);
			(*skb)->mac.raw = (*skb)->data;
			memcpy((*skb)->data,
			       risr & RIS_BB ? c->brbuf : c->arbuf, len);
			return len;
		}
	} else {
		printk(KERN_DEBUG "cx%d.%d: unknown hdlc receive interrupt,"
		       " risr=%x\n", c->board->num, c->num, risr);
		++c->stat->ierrs;
		return -EIO;
	}
	return 0;
}

int cx_hw_dcd(unsigned int chan) 
{
	cx_chan_t * c;

	if (chan >= NCX*NCHAN)
		return 0;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return 0;

	return cx_chan_cd(c);
}

/*
 * Module initialization.
 */
static int cx_ndev;
static char devname[NCX*NCHAN][6];

extern int cxproto_init (struct device*);
extern struct file_operations cxproto_fops;
extern char cx_devname[];

/* pppd checks for this device */
static struct device dev_ppp0 = { "ppp0", 0x0, 0x0, 0x0, 0x0, 
	CX_UNIT_MINOR - 1, 0, 0, 0, 0, NULL, cxproto_init };

static int ppp0_registered = 0;

int init_module(void)
{ 
	int unit;
	cx_board_t *b;
	cx_chan_t *c;
	struct device *d;

	if (register_chrdev(CX_MAJOR, "Cronyx", &cxproto_fops)) {
		printk(KERN_ERR "cx: Unable to get major %d "
		       "for Cronyx devices.\n", CX_MAJOR);
		return -EIO;
	} 
  
	/* initialize the hardware */
	if (cx_hw_init() != 0) {
		unregister_chrdev(CX_MAJOR, "Cronyx");
		return -EIO;
	}
   
	cx_ndev = 0;
	for (b=cxboard; b<cxboard+NCX; ++b) 
		for (c=b->chan; c<b->chan+NCHAN; ++c) {
			if (c->type == T_NONE)
				continue;
			unit = b->num*NCHAN + c->num;
			d = cx_dev + unit;
			d->name = devname[unit];
			sprintf (d->name, "%s%d", cx_devname, unit);
			d->base_addr = unit;
			d->init = cxproto_init;
			if (register_netdev (d) != 0) {
				printk(KERN_ERR "cx: Unable to register net"
				       " device %s.\n", d->name);
				continue;
			}
			cx_ndev++;
		}

	if (! cx_ndev) {
		printk(KERN_ERR "cx: No devices registered."
		       " Initialization failed.\n");
		cx_hw_release();
		unregister_chrdev(CX_MAJOR, "Cronyx");
		return -EIO;
	}

	if (!dev_get(dev_ppp0.name)) {
		register_netdev (&dev_ppp0);
		ppp0_registered = 1;
	}
	return 0;
}

void cleanup_module(void) 
{
	int i;

	cx_hw_release();

	for (i=0; i<cx_ndev; ++i)
		if (cx_dev[i].name)
			unregister_netdev (&cx_dev[i]);

	if (ppp0_registered)  {
		unregister_netdev(&dev_ppp0);
		ppp0_registered = 0;
	}

	unregister_chrdev(CX_MAJOR, "Cronyx");
}
