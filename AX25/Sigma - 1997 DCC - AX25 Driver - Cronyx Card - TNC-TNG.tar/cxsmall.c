/*
 * Cronyx-Sigma adapter driver for Linux.  
 * 
 * Copyright (C) 1997, Dmitry Gorodchanin <begemot@bgm.rosprint.net>.
 * 
 * This program may be redistributed and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 * 
 * This source is derived from:
 * 1) RISCom/N2 network driver for Linux
 *    Copyright 1995-1996, SDL Communications, Inc.
 *    by Mike Natale (mike@ns.sdlcomm.com)
 * 2) Cronyx-Sigma adapter driver for FreeBSD 
 *    Copyright (C) 1994-1996 Cronyx Engineering Ltd.
 *    by Serge Vakulenko (vak@cronyx.ru)
 *
 * Revision history:
 * 	06 Mar 1997 - version 0.02, first public release (bgm)
 * 	09 Apr 1997 - version 0.03, added frame relay protocol (vak)
 *	24 May 1997 - Version 0.10, Totally hacked by darryl smith for 
 *			packet radio applications.
 */
#include <linux/config.h>
 /* #define __NO_VERSION__ */
#include <linux/version.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/errno.h>
#include <linux/malloc.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <asm/io.h>

#include "csigma.h"
#include "cxreg.h"

#include "cx.h"
#include "cronyxfw.h"
#include "csigmafw.h"

#define CX_IO_RANGE 	0x20
#define CX_DMABUFSIZE   (7 * 256)

#define B_SIGMA_NONE	0xff	/* No board installed */

static cx_board_t  cxboard[NCX] = { 
	{ B_SIGMA_NONE, },
	{ B_SIGMA_NONE, },
	{ B_SIGMA_NONE, },
};

static cx_chan_t * cx_chan[NCX*NCHAN] = { NULL, };

static short irq_valid_values [] = { 3, 5, 7, 10, 11, 12, 15, 0 };
static short drq_valid_values [] = { 5, 6, 7, 0 };
static short port_valid_values [] = {
        0x240, 0x260, 0x280, 0x300, 0x320, 0x380, 0x3a0, 0,
};

static struct sk_buff_head rxdata[NCX* NCHAN];
static struct wait_queue *rxq[NCX * NCHAN] = { NULL, };
static struct wait_queue *txq[NCX * NCHAN] = { NULL, };

static isr cx_rxisr[NCX*NCHAN] = { NULL, };
static isr cx_txisr[NCX*NCHAN] = { NULL, };
static int cx_opens[NCX] = { 0, };
static cx_board_t * irq2dev[16] = { NULL, };
static struct device cx_dev[NCX*NCHAN];

static int TxTail	[NCX*NCHAN] = {0, };
static int TxDelay	[NCX*NCHAN] = {0, };
static int SlotTime	[NCX*NCHAN] = {0, };

static struct sk_buff * cx_rxpend[NCX*NCHAN] = { NULL, };
static int              cx_rxpend_pos[NCX*NCHAN] = {0, };
static struct sk_buff * cx_txpend[NCX*NCHAN] = { NULL, };
static int              cx_txpend_pos[NCX*NCHAN] = {0, };


int port[NCX] = { 0, };
int irq[NCX]  = { 0, };
int drq[NCX]  = { 0, };

int dbg = 1;

static void cx_hw_intr(int irq, void * dev_id, struct pt_regs * regs);


extern inline cx_board_t * cx_board(int n)
{
 	return cxboard + n;
}

static int valid (unsigned short value, unsigned short *list)
{
        while (*list)
                if (value == *list++)
                        return 1;
        return 0;
}

void cx_c_rxisr(unsigned int chan)
{
	int status;
	struct sk_buff * skb;

        status = cx_hw_read(chan, &skb);

	/* skip bad frames */
	if (status < 0) {
		printk(KERN_NOTICE "cx(%d): bad input frame status %x\n",
		       chan, -status);
		return;
	}
	if (dbg) {
		int len = skb->len, i;
		if (len > 128)
			len = 100;
		printk(KERN_DEBUG "cx(%d): cx_c_rxisr: ", chan);
		for (i = 0; i < len; i++) 
			printk("%02x ", skb->data[i]);
		printk("\n");
	}
	

	skb->free = 1;
	if (skb_queue_len(&rxdata[chan]) >= 20) {
		kfree_skb(skb, FREE_READ);
		return;
	}
	skb_queue_tail(&rxdata[chan], skb);
	wake_up_interruptible(&rxq[chan]);
}

void cx_c_txisr(unsigned int chan)
{
	wake_up_interruptible(&txq[chan]);
}

int cx_open(struct inode *inode, struct file *file)
{
	unsigned int minor = MINOR(inode->i_rdev);
	int err;

	if (minor == CX_UNIT_MINOR) {
		MOD_INC_USE_COUNT;
		return 0;
	}
	if ((err = cx_hw_open(minor, cx_c_rxisr, cx_c_txisr))) {
		printk(KERN_DEBUG "CX:HW Open fail\n");
		return err;
		}

	skb_queue_head_init(&rxdata[minor]);

	MOD_INC_USE_COUNT;
	return 0;
}

void cx_close(struct inode *inode, struct file *file)
{
	unsigned int minor = MINOR(inode->i_rdev);
	struct sk_buff * skb;

	if (minor == CX_UNIT_MINOR) {
		MOD_DEC_USE_COUNT;
		return;
	}
	cx_hw_close(minor);

	while ((skb = skb_dequeue(&rxdata[minor])))
		kfree_skb(skb, FREE_READ);
  
	MOD_DEC_USE_COUNT;
}

int cx_write(struct inode *inode, struct file *file, const char *buf, int len)
{
	unsigned int minor = MINOR(inode->i_rdev);
	struct sk_buff * skb = NULL;
	int ret = 0;
int i;
int down;
#ifdef 0


		if ( TXEN(port) & PTT(port)){
			/* if transmitter is enabled and PTT is high
				then we are in TxTail
					Therefore stop Timer */
			TIMER(port) = TxTail[port];
			}
			
		Queue Packet

		if ( !PTT(port)){
			/* if PTT is low
				then we need to power PTT through slot time
					therefore we call SlotTime() */
			SlotTime(port);
			}

#endif

	printk (KERN_DEBUG "Kern len: %d",len);
	if (minor == CX_UNIT_MINOR) 
		return -EIO;

	/* do */
	if (1==1) { /* Do only one return per packet ??? HELP.... ???? */
                if (!skb) {
                        skb = alloc_skb(len, GFP_KERNEL);
                        skb->free = 1;
                }
                if (skb) {
                	printk (KERN_DEBUG "Before memcpy");
                        memcpy_fromfs(skb_put(skb, len), buf, len);
                        if (skb->len > 3) printk (KERN_DEBUG "After Memcpy %x %x %x",skb->data[0], skb->data[1], skb->data[2]);
         		/* Character 0 == FEND */
         		down = 2;
         		for (i=2; i < len; i++){
         			if (skb->data[i] == 0xdb){
         				down++;
         				i++;
         				if (skb->data[i] == 0xdc){
         					skb->data[i-down] = 0xc0;
         				}
         				else if (skb->data[i] == 0xdd){
         					skb->data[i-down] = 0xdb;
         				}
         				else skb->data[i-down]=0xff;
         			}
         			else if (skb->data[i] == 0xc0){
         				skb->len = i-1;
         				i = len+1;
         			}
         			else skb->data[i-down] = skb->data[i];
         		}
         		skb->len = skb->len-down+3;
			if (skb->len < 3) skb->len = 0;
                        if ((ret = cx_hw_write(minor, skb))) {
                                if (1==1) {
                                        int i;
                                        
                                        if (len > 12)
                                                len = 12;
                                        printk(KERN_DEBUG "cx(%d): ret %d write: ", minor, ret);
                                        for (i = 0; i < len; i++) 
                                                printk("%02x ",skb->data[i]);
                                        printk("\n");
                                }
                                kfree_skb(skb, FREE_READ);
                                return ret+1;
                        }
                }
                if (file->f_flags & O_NONBLOCK)
                        goto free_and_exit;
                /* sleep */
                interruptible_sleep_on( &txq[minor]); 
                
        }
        /*  while (!(current->signal & ~current->blocked)); */

        ret = -ERESTARTNOINTR;
free_and_exit:
	if (skb)  
                kfree_skb(skb, FREE_READ);
        return ret;
}

int cx_read(struct inode *inode, struct file *file, char *buf, int len)
{
        int minor = MINOR(inode->i_rdev);
        struct sk_buff * skb;
        int i,off=0;
        unsigned char cha;
	int ret=0;
	int down;
	printk ( KERN_DEBUG "R  Len of packet = %d",len); 

	skb = NULL;
	if (minor == CX_UNIT_MINOR) 
 		return -EIO;

	do{
		if ((skb = skb_dequeue(&rxdata[minor]))){
			printk (KERN_DEBUG "dequeue ok");
			down = 0;

			for (i = 0; i < skb->len; i++){
				if ((skb->data[i] == 0xC0) | (skb->data[i] == 0xdb))
					down++;
			}
			
			printk (KERN_DEBUG "down == %d",down);
	
			for (i = skb->len + down+2; i > 1; i--){
				if (skb->data[i-2-down] == 0xC0){
					down--;
					skb->data[i] = 0xdb;
					i--;
					skb->data[i] = 0xdc;
				}
				else if (skb->data[i-2-down] == 0xDB){
					down --;
					skb->data[i] = 0xdb;
					i--;
					skb->data[i] = 0xdd;
				}			
				else skb->data[i] = skb->data[i-2-down];
			}
			
			skb->data[skb->len - down + 2] = 0xc0;
			skb->data[0] = 0xc0; 
			skb->data[1] = 0x00;	
			printk (KERN_DEBUG "Downer ");
			skb->len = skb->len-down+3;
			len = skb->len;
			memcpy_tofs(buf, skb->data, len);
			kfree_skb(skb, FREE_READ);
			printk ( KERN_DEBUG "Read Len of packet = %d",len); 
			return len;
			}
			if (file->f_flags & O_NONBLOCK)
				return -EWOULDBLOCK;
			interruptible_sleep_on(&rxq[minor]);
	} while (!(current->signal & ~current->blocked));
	
	return -ERESTARTNOINTR;
        
}

static int cx_setmode(unsigned long arg) 
{
	int error;
	cx_options_t opt;
	cx_chan_t * c;
	int oldmode;

	if ((error = verify_area(VERIFY_READ, (void *)arg, sizeof(opt))))
		return error;
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &cxboard[opt.board].chan[opt.channel];

	if (c->type == T_NONE) 
		return -EINVAL;

	if (c->type == T_ASYNC && opt.mode != M_ASYNC)
		return -EINVAL;
	
	if (opt.mode == M_ASYNC)
		return -EINVAL; /* FIXME: No async support for now */

	oldmode   = c->mode;
	c->mode   = opt.mode;
	c->rxbaud = opt.rxbaud;
	c->txbaud = opt.txbaud;
	c->opt    = opt.opt;
	c->aopt   = opt.aopt;
	c->hopt   = opt.hopt;
	/*cxproto_dlci (cx_dev+opt.channel, opt.sopt.dlci, 1);*/

	switch(c->num) {
	case 0: 
		c->board->if0type = opt.iftype;
		break;
	case 8: 
		c->board->if8type = opt.iftype;
		break;
	}
	
	if (oldmode != c->mode) {
		cx_setup_chan(c);
	} else {
		cx_update_chan(c);
	}

	outb(0, IER(c->chip->port));
	return 0;
}

static int cx_getmode(unsigned long arg) 
{
	int error;
	cx_options_t opt;
	cx_chan_t * c;

	if ((error = verify_area(VERIFY_WRITE, (void *)arg, sizeof (opt))))
		return error;
	
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &(cxboard[opt.board].chan[opt.channel]);

	if (c->type == T_NONE) 
		return -EINVAL;

	opt.magic = CX_OPT_MAGIC;
	opt.port = c->board->port;
	opt.irq  = c->board->irq;
	opt.dma  = c->board->dma;
	strcpy (opt.name, c->board->name);
	opt.type   = c->type;
	opt.mode   = c->mode;
	opt.rxbaud = c->rxbaud;
	opt.txbaud = c->txbaud;
	opt.opt    = c->opt;
	opt.aopt   = c->aopt;
	opt.hopt   = c->hopt;
	opt.bopt   = c->board->opt;
	/*cxproto_dlci (cx_dev+opt.channel, opt.sopt.dlci, 0);*/

	switch (c->num) {
	case 0:  opt.iftype = c->board->if0type; break;
	case 8:  opt.iftype = c->board->if8type; break;
	default: opt.iftype = 0;                 break;
	}

	memcpy_tofs((void *) arg, &opt, sizeof(opt));
	return 0;
}

static int cx_getstat(unsigned long arg) 
{
	int error;
	cx_stat_t opt;
	cx_chan_t * c;

	if ((error = verify_area(VERIFY_WRITE, (void *)arg, sizeof (opt))))
		return error;
	
	memcpy_fromfs(&opt, (void *) arg, sizeof(opt));

	if (opt.board >= NCX || opt.channel >= NCHAN)
		return -EINVAL;

	c = &(cxboard[opt.board].chan[opt.channel]);

	if (c->type == T_NONE) 
		return -EINVAL;

	opt.rintr  = c->stat->rintr;
	opt.tintr  = c->stat->tintr;
	opt.mintr  = c->stat->mintr;
	opt.ibytes = c->stat->ibytes;
	opt.ipkts  = c->stat->ipkts;
	opt.ierrs  = c->stat->ierrs;
	opt.obytes = c->stat->obytes;
	opt.opkts  = c->stat->opkts;
	opt.oerrs  = c->stat->oerrs;

	memcpy_tofs((void *) arg, &opt, sizeof(opt));
	return 0;
}

int cx_ioctl(struct inode *inode, struct file *file,
		    unsigned int cmd, unsigned long arg)
{
	unsigned int minor = MINOR(inode->i_rdev);

	if (minor != CX_UNIT_MINOR)
		return -EINVAL;

	switch(cmd) {
	case CXIOCSETMODE:
		return cx_setmode(arg);
	case CXIOCGETMODE:
		return cx_getmode(arg);
	case CXIOCGETSTAT:
		return cx_getstat(arg);
	default:
		return -EINVAL; 
	}
}

static int cx_probe(int i, short port, short irq, short drq)
{
	cx_board_t * b = cx_board(i);
	int n;
	int ports = 0;

	if (!valid(port, port_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid base address 0x%03x.\n", 
		       i, port);
		return 0;
	}
	if (!valid(irq, irq_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid IRQ %d.\n", i, irq);
		return 0;
	}
	if (!valid(drq, drq_valid_values)) {
		printk(KERN_ERR "cx%d: Invalid DMA %d.\n", i, drq);
		return 0;
	}
	if (check_region(port, CX_IO_RANGE)) {
		printk(KERN_ERR "cx%d: Skipping board with base address 0x%03x,"
		       " I/O space in use.\n", i, port);
		return 0;
	}
	if (!cx_probe_board(port)) {
		printk(KERN_ERR "cx%d: No board found with base address 0x%03x\n",
		       i, port);
		return 0;
	}
	cx_init(b, i, port, irq, drq);
	printk(KERN_INFO "cx%d: <Cronyx-%s> at 0x%03x irq %d drq %d\n", i,
	       b->name, port, irq, drq);

	request_region(port, CX_IO_RANGE, "Cronyx");

	for (n = 0; n < NCHAN; n++) {
                cx_chan_t *c = b->chan + n;

                cx_chan[b->num * NCHAN + n] = c;

		if (c->type == T_NONE)
			continue;
#if 1
		if (c->mode == M_ASYNC)
			c->mode = M_HDLC;
#endif
		ports++;
	}

	if (!ports) {
		printk(KERN_ERR "cx%d: No operational ports on this board\n",
		       i);
		return 0;
	}
	return 1;
}

/****************************************************************************/

int cx_hw_init(void)
{
	int i = 0;
	int n = 0;

	for (i = 0; i < NCX; i++) {
		if (port[i] && cx_probe(i, port[i],irq[i],drq[i]))
			n++;
	}
	if (!n) {
		printk(KERN_ERR "cx: No Cronyx boards detected.\n");
		return -EIO;
	}
	return 0;
}

void cx_hw_release(void)
{
	int i;

	unregister_chrdev(CX_MAJOR, "Cronyx");

	for (i = 0; i < NCX; i++) {
		if (cxboard[i].type != B_SIGMA_NONE) {
			release_region(cxboard[i].port, CX_IO_RANGE);
		}
	}
}

int cx_hw_open(unsigned int chan, isr rxisr, isr txisr)
{
	cx_chan_t * c;
	int board, err;
	unsigned short port;

	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	if (!rxisr || !txisr)
		return -EINVAL;

	if (cx_rxisr[chan])
		return -EBUSY;

	board = c->board->num;
	if (!cx_opens[board]++) {
		long fw_len;
		const char *fw_version, *fw_date, *fw_copyright;
		const cr_dat_tst_t *fw_tvec;
		const unsigned char *fw_data;

		switch (c->board->type) {
		case B_SIGMA_800:
			fw_len       = csigma_fw_len;
			fw_version   = csigma_fw_version;
			fw_date      = csigma_fw_date;
			fw_copyright = csigma_fw_copyright;
			fw_tvec      = csigma_fw_tvec;
			fw_data      = csigma_fw_data;
			break;
		default:
			fw_len       = 0;
			fw_version   = 0;
			fw_date      = 0;
			fw_copyright = 0;
			fw_tvec      = 0;
			fw_data      = 0;
			break;
		}
		if (fw_data) {
			printk(KERN_INFO "cx%d: Firmware version %s (%s)\n",
				board, fw_version, fw_date);
			printk(KERN_INFO "cx%d: %s\n", board, fw_copyright);
		}
		if (! cx_setup_board (c->board, fw_data, fw_len, fw_tvec)) {
			printk(KERN_ERR "cx%d: Error loading firmware\n", 
				board);
			return -ENODEV;
		}
		if ((err = request_irq(c->board->irq, cx_hw_intr,
				       SA_INTERRUPT, "Cronyx", NULL))) {
			printk(KERN_ERR "cx%d: Unable to get IRQ %d"
			       " (error %d).\n", board, c->board->irq, err);
			return -EBUSY;
		}
		irq2dev[c->board->irq] = c->board;
		MOD_INC_USE_COUNT;
		/* enable board */
	}

	if (!(c->arbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto no_memory;
	if (!(c->brbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_arbuf;
	if (!(c->atbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_brbuf;
	if (!(c->btbuf = kmalloc(CX_DMABUFSIZE, GFP_KERNEL | GFP_DMA)))
		goto free_atbuf;
	
	cx_rxisr[chan] = rxisr;
	cx_txisr[chan] = txisr;

	cx_setup_chan(c);	/* port initialization */

	/* Initialize channel, enable receiver and transmitter */
	cx_cmd (port, CCR_INITCH | CCR_ENRX | CCR_ENTX);
	/* Repeat the command, to avoid the rev.H bug */
	cx_cmd (port, CCR_INITCH | CCR_ENRX | CCR_ENTX);

	/* Start receiver */
	outw (CX_DMABUFSIZE,ARBCNT(port));
	outb (BSTS_OWN24,   ARBSTS(port));
	outw (CX_DMABUFSIZE,BRBCNT(port));
	outb (BSTS_OWN24,   BRBSTS(port));

	/* Raise DTR and RTS */
#ifdef NEVER
	cx_chan_rts (c, 1);
#endif
	cx_chan_dtr (c, 1);

	/* Enable interrupts */	
	outb (IER_RXD | IER_TXD, IER(port));
	
	printk (KERN_DEBUG "cx:open OK\n:");
	
	return 0;

free_atbuf:
	kfree(c->atbuf);
	c->atbuf = NULL;
free_brbuf:
	kfree(c->brbuf);
	c->brbuf = NULL;
free_arbuf:
	kfree(c->arbuf);
	c->arbuf = NULL;
no_memory:
	printk(KERN_ERR "cx%d: Can't alloc DMA memory for port %d.",board, chan);
	if (!--cx_opens[board]) {
		irq2dev[c->board->irq] = NULL;
		free_irq(c->board->irq, NULL);
		/* disable board */
		MOD_DEC_USE_COUNT;
	}
	return -ENOMEM;
}

void cx_hw_close(unsigned int chan)
{
	cx_chan_t * c;
	int board;
	unsigned short port;
	
	if (chan >= NCX*NCHAN || !(c = cx_chan[chan]) 
	    || c->type == T_NONE || !cx_rxisr[chan])
		return;

	if (!(port = c->chip->port))
		return;

	board = c->board->num;
	/* Reset the channel */
	outb (c->num & 3, CAR(port));
	outb (STC_ABORTTX | STC_SNDSPC, STCR(port));
	cx_setup_chan (c);

	cx_rxisr[chan] = NULL;
	cx_txisr[chan] = NULL;
	kfree(c->btbuf);
	kfree(c->atbuf);
	kfree(c->brbuf);
	kfree(c->arbuf);
	if (!--cx_opens[board]) {
		/* disable board */
		irq2dev[c->board->irq] = NULL;
		free_irq(c->board->irq, NULL);
		MOD_DEC_USE_COUNT;
	}
}



#ifdef 0

void cx_hw_slottime(unsigned int chan)
{
	
	if (FullDuplex[port] != 0){
		/* If in fact we are opertaing in FULL DUPLEX MODE then
		   we do not need to wory about a slot time. We do however
		   need to wory about TxDelay :-) */
		SetPTT(port, 1==1);
		TIMER(port) = TxDelay[port]
		return;
		}
	
	
	
	
	
	if ( ((seed = (((25173 * seed) + 13849)%65536)) >> 8 ) > persist()
		& cx_chan_cd()  ){
		/* if Random()>p and CD is low
			then it is OK to send
				therefore we	
					PTT ON
					Start Timer with TxDelay */

		SetPTT(port, 1==1);
		TIMER(port) = TxDelay[port];
		}
	else {
		/* then it is not OK on this slow
			therefore
				Start Timer with Slot Time */
		TIMER(port) = SlotTime[port];

}
#endif




/*
 * Handle transmit interrupt.
 */
static int cx_hw_tint(cx_chan_t *c)
{
	unsigned short port = c->chip->port;
	unsigned char tisr = inb (TISR(port));
	unsigned char teoir = 0;
	int num = c->board->num * NCHAN + c->num;

	if (tisr & (TIS_BUSERR | TIS_UNDERRUN)) {
		printk(KERN_DEBUG "cx%d.%d: transmit error, tisr=%x,"
		       " atbsts=%x, btbsts=%x\n",
		       c->board->num, c->num, tisr,
		       inb(ATBSTS(port)), inb(BTBSTS(port)));
		++c->stat->oerrs;
		
		/* Terminate the failed buffer. */
		/* teoir = TEOI_TERMBUFF; */
	} else { 
#ifdef 0
		printk(KERN_DEBUG "cx%d.%d: hdlc transmit interrupt,"
		       " tisr=%x, atbsts=%x, btbsts=%x\n",
			c->board->num, c->num, tisr,
			inb(ATBSTS(port)), inb(BTBSTS(port)));
#endif

	}

	if (tisr & TIS_EOFR) {
		++c->stat->opkts;
	}


	
	


	if (cx_txisr[num]) 
		(cx_txisr[num])(num);
	
	return teoir;
}




#ifdef 0



void cx_chan_ptt (cx_chan_t *c, int on)
{
	cx_chan_rts (c, on);
	c->ptt = on;
}

cx_chan_txen (cx_chan_t *c, int on)
{
	unsigned short port = c->chip->port;

	c->txen = on;
	if (on){
		cx_cmd (base, CCR_TXEN);
	else {
		cx_cmd (base, CCR_TXENN);
	}
}

cx_chan_timer (cx_chan_t *c, unsigned int delay)
{
	unsigned short port = c->chip->port;


	/* cx_setup_chip() sets the timer period register to 10 mSec */
	outw (GT1(port), delay);

}


unsigned char TxEN(cx_chan_t *c)
{

	return c->txen;

}


unsigned char PTT (cx_chan_t *c)
{
	
	return c->ptt;

}




#endif







/*
 * Handle modem/timert interrupt.
 */
static int cx_hw_mint(cx_chan_t *c)
{
#ifdef 0
	unsigned short port = c->chip->port;
	unsigned char tisr = inb (TISR(port));
	unsigned char teoir = 0;
	int num = c->board->num * NCHAN + c->num;

	


	if (!TXEN() & !PTT()){
		/* If Transmitter is Disabled and PTT is low
			then we have not yet entered TxDelay
				Therefore we call SlotTime() */
		cx_hw_slottime(num);
		}
	else 
	if (!TXEN() & PTT()){
		/* Else if Transmitter is Disabled and PTT is high
			then we have just finished TxDelay
				Therefore we enable Transmitter */
		cx_chan_txen (num, 1==1);
		}
	else
	if (TXEN()){
		/* Else if Transmitter is Enabled
			then we are in TxTail
				Therefore we set PTT low */
		cx_chan_ptt (num, 1==0);
		}

	
	
	
	return teoir;
#endif
}




static void cx_hw_intr(int irq, void * dev_id, struct pt_regs * regs)
{
	cx_board_t * b = irq2dev[irq];

	if (!b) 
		return;

	while (!(inw(BSR(b->port)) & BSR_NOINTR)) {
		/* Acknowledge the interrupt to enter the interrupt context. */
		/* Read the local interrupt vector register. */
		unsigned char livr = inb (IACK(b->port, BRD_INTR_LEVEL));
		cx_chan_t *c = b->chan + (livr>>2 & 0xf);
		unsigned short port = c->chip->port;
		unsigned short eoiport = REOIR(port);
		unsigned char eoi = 0;
		int num = b->num * NCHAN + c->num;

		if (c->type == T_NONE) {
			printk (KERN_DEBUG "cx%d.%d: unexpected interrupt, "
				"livr=0x%x\n", c->board->num, c->num, livr);
			continue;       /* incorrect channel number? */
		}

		/* Clear RTS to stop receiver data flow while we are busy
		 * processing the interrupt, thus avoiding underruns. */
#ifdef never
		outb (0, MSVR_RTS(port));
		c->rts = 0;
#endif
		switch (livr & 3) {
		case LIV_EXCEP:         /* receive exception */
		case LIV_RXDATA:        /* receive interrupt */
			++c->stat->rintr;
			/* Handle incoming packet */
			if (cx_rxisr[num]) 
				(cx_rxisr[num])(num);
				
			/* Restart receiver. */
			if (!(inb(ARBSTS(port)) & BSTS_OWN24)) {
				outw(CX_DMABUFSIZE, ARBCNT(port));
				outb(BSTS_OWN24,    ARBSTS(port));
			}
			if (!(inb(BRBSTS(port)) & BSTS_OWN24)) {
				outw(CX_DMABUFSIZE, BRBCNT(port));
				outb(BSTS_OWN24,    BRBSTS(port));
			}
			break;
		case LIV_TXDATA:        /* transmit interrupt */
			++c->stat->tintr;
			eoiport = TEOIR(port);
			cx_hw_tint(c);
			break;
		case LIV_MODEM:         /* modem/timer interrupt */
			++c->stat->mintr;
			eoiport = MEOIR(port);
#if 0
			cx_hw_mint (c);
#endif
			break;
		}
#ifdef NEVER
		/* Raise RTS for this channel if and only if
		 * both receive buffers are empty. */
		if ((inb(CSR(port)) & CSRA_RXEN) &&
		    (inb(ARBSTS(port)) & BSTS_OWN24) &&
		    (inb(BRBSTS(port)) & BSTS_OWN24)) {
			outb(MSV_RTS, MSVR_RTS(port));
			c->rts = 1;
		}
#endif

		/* Exit from interrupt context. */
		outb(eoi, eoiport);
	}
}

/* Shouldn't be executed in the interrupt context */
int cx_hw_write(unsigned int chan, const struct sk_buff * skb)
{
	unsigned short port;
	cx_chan_t * c;
	unsigned long flags;
	int len = skb->len;
	printk(KERN_DEBUG "cx: before buf choosen\n");


	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	if (skb->len > CX_DMABUFSIZE) {
		printk(KERN_DEBUG "IO ERROR %ld \n", skb->len);
		return -EIO;

	}

	save_flags(flags);
	cli();
	/* Set the current channel number. */
	outb (c->num & 3, CAR(port));
		printk(KERN_DEBUG "cx: buf choosen\n");

	if ((inb(DMABSTS(port)) & DMABSTS_NTBUF) &&
	    !(inb(BTBSTS(port)) & BSTS_OWN24)) {

		printk(KERN_DEBUG "cx: B buf choosen\n");

		memcpy(c->btbuf, skb->data, skb->len);
		outw(len, BTBCNT(port));
		outb(BSTS_EOFR | BSTS_INTR | BSTS_OWN24, BTBSTS(port));
	} else if (!(inb(ATBSTS(port)) & BSTS_OWN24)) {

		printk(KERN_DEBUG "cx: A buf choosen\n");

		memcpy(c->atbuf, skb->data, skb->len);
		outw(len, ATBCNT(port));
		outb(BSTS_EOFR | BSTS_INTR | BSTS_OWN24, ATBSTS(port));
	} else {

		printk(KERN_DEBUG "cx: No buffers free\n");

		len = 0;
	}
	c->stat->obytes += len;
	/*
	 * Enable TXMPTY interrupt,
	 * to catch the case when the second buffer is empty.
	 */
	if ((inb(ATBSTS(port)) & BSTS_OWN24) &&
	    (inb(BTBSTS(port)) & BSTS_OWN24)) {
		outb (IER_RXD | IER_TXD | IER_TXMPTY, IER(port));
	} else
		outb (IER_RXD | IER_TXD, IER(port));
	restore_flags(flags);
	return len;
}

/* Should be executed in the interrupt context */
int cx_hw_read(unsigned int chan, struct sk_buff ** skb)
{
	unsigned short port;
	unsigned short len, risr;
	cx_chan_t * c;

	if (chan >= NCX*NCHAN)
		return -ENODEV;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return -ENODEV;

	if (!(port = c->chip->port))
		return -ENODEV;

	risr = inw(RISR(port));

	/* Receive errors. */
	if (risr & (RIS_BUSERR | RIS_OVERRUN | RISH_CRCERR | RISH_RXABORT)) {
		printk(KERN_DEBUG "cx%d.%d: receive error, risr=%x\n",
		       c->board->num, c->num, risr);
		++c->stat->ierrs;
		return -EIO;

	} else if (risr & RIS_EOBUF) {

		printk(KERN_DEBUG "cx%d.%d: hdlc receive interrupt, risr=%x,"
		       " arbsts=%x, brbsts=%x\n",
		       c->board->num, c->num, risr,
		       inb (ARBSTS(port)), inb (BRBSTS(port)));

		/* Handle received data. */
		len = (risr & RIS_BB) ? inw(BRBCNT(port)) : inw(ARBCNT(port));
		c->stat->ibytes += len;
		if (len > CX_DMABUFSIZE) {
			/* Fatal error: actual DMA transfer size
			 * exceeds our buffer size.  It could be caused
			 * by incorrectly programmed DMA register or
			 * hardware fault.  Possibly, should panic here. */
			printk(KERN_ERR "cx%d.%d: panic!"
			       " DMA buffer overflow: %d bytes\n",
			       c->board->num, c->num, len);
			return -EIO;

		} else if (! (risr & RIS_EOFR)) {
			/* The received frame does not fit in the DMA buffer.
			 * It could be caused by serial lie noise,
			 * or if the peer has too big MTU. */
			printk(KERN_ERR "cx%d.%d: received frame length"
			       " exceeds MTU, risr=%x\n",
			       c->board->num, c->num, risr);
			return -EIO;
		} else {
			/* Valid frame received. */
			++c->stat->ipkts;
			printk(KERN_DEBUG "cx%d.%d: hdlc received %d bytes\n",
			       c->board->num, c->num, len);

			if (!(*skb = dev_alloc_skb(len)))
				return -ENOMEM;

			skb_put(*skb, len);
			(*skb)->mac.raw = (*skb)->data;
			memcpy((*skb)->data,
			       risr & RIS_BB ? c->brbuf : c->arbuf, len);
			return len;
		}
	} else {
		printk(KERN_DEBUG "cx%d.%d: unknown hdlc receive interrupt,"
		       " risr=%x\n", c->board->num, c->num, risr);
		++c->stat->ierrs;
		return -EIO;
	}
	return 0;
}

int cx_hw_dcd(unsigned int chan) 
{
	cx_chan_t * c;

	if (chan >= NCX*NCHAN)
		return 0;

	if (!(c = cx_chan[chan]) || c->type == T_NONE)
		return 0;

	return cx_chan_cd(c);
}

/*
 * Module initialization.
 */


extern int cxproto_init (struct device*);
extern struct file_operations cxproto_fops;


int init_module(void)
{ 

	if (register_chrdev(CX_MAJOR, "Cronyx", &cxproto_fops)) {
		printk(KERN_ERR "cx: Unable to get major %d "
		       "for Cronyx devices.\n", CX_MAJOR);
		return -EIO;
	} 
  
	/* initialize the hardware */
	if (cx_hw_init() != 0) {
		unregister_chrdev(CX_MAJOR, "Cronyx");
		return -EIO;
	}
   
	return 0;
}

void cleanup_module(void) 
{
	cx_hw_release();
	unregister_chrdev(CX_MAJOR, "Cronyx");
}
/* ********************************************************************** */




struct file_operations cxproto_fops = {
	NULL,			/* seek */
	cx_read,		/* read */
	cx_write,		/* write */
	NULL,			/* readdir */
	NULL,			/* select  */
	cx_ioctl,		/* ioctl   */
	NULL,			/* mmap    */
	cx_open,		/* open    */
	cx_close,		/* release */
	NULL,			/* fsync */
	NULL			/* async */
};   




	