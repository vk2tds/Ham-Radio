#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <net/bpf.h>

#define DEFDATALEN      256             /* default data length */
#define MAXPACKET       65535           /* max packet size */
#define	MAXWAIT		10		/* max seconds to wait for response */

/* various options */
int options;
#define	F_FLOOD		0x001
#define	F_INTERVAL	0x002
#define	F_PINGFILLED	0x008

int datalen = DEFDATALEN;
int s;				/* socket file descriptor */
char outpack [MAXPACKET];
char packet [MAXPACKET];
char *target;                   /* interface name to ping */
int ident;			/* process id to identify our packets */

/* counters */
long npackets;			/* max packets to transmit */
long nreceived;			/* # of packets we got back */
long nrepeats;			/* number of duplicates */
long ntransmitted;		/* sequence # for outbound packets = #sent */
int interval = 1;		/* interval between packets */

/* timing */
int timing;			/* flag to do timing */
double tmin = 999999999.0;	/* minimum round trip time */
double tmax = 0.0;		/* maximum round trip time */
double tsum = 0.0;		/* sum of all times, for doing average */

/*
 * MAX_DUP_CHK is the number of bits in received table, i.e. the maximum
 * number of received sequence numbers we can keep track of.  Change 128
 * to 8192 for complete accuracy...
 */
#define MAX_DUP_CHK     (8 * 128)
int mx_dup_ck = MAX_DUP_CHK;
char rcvd_tbl [MAX_DUP_CHK / 8];

#define	A(bit)		rcvd_tbl[(bit)>>3]	/* identify byte in array */
#define	B(bit)		(1 << ((bit) & 0x07))	/* identify bit in byte */
#define	SET(bit)	(A(bit) |= B(bit))
#define	CLR(bit)	(A(bit) &= (~B(bit)))
#define	TST(bit)	(A(bit) & B(bit))

void usage ()
{
	fprintf (stderr, "Usage:\n"
		"\tifping [-f] [-c count] [-i wait] [-l preload]\n"
		"\t\t[-p pattern] [-s packetsize] interface\n");
	exit (1);
}

char *dltname (int dlt)
{
	static char buf[8];

	switch (dlt) {
	case DLT_NULL:    return "NULL";
	case DLT_EN10MB:  return "Ethernet";
	case DLT_EN3MB:   return "Experimental Ethernet";
	case DLT_AX25:    return "AX.25";
	case DLT_PRONET:  return "Token Ring";
	case DLT_CHAOS:   return "Chaos";
	case DLT_IEEE802: return "IEEE-802";
	case DLT_ARCNET:  return "Arcnet";
	case DLT_SLIP:    return "SLIP";
	case DLT_PPP:     return "PPP";
	case DLT_FDDI:    return "FDDI";
	default:          sprintf (buf, "%d", dlt); return buf;
	}
}

void fill (char *bp, char *patp)
{
	int ii, jj, kk, pat [16];
	char *cp;

	for (cp=patp; *cp; cp++)
		if (! isxdigit(*cp)) {
			fprintf (stderr, "ifping: patterns must be specified as hex digits.\n");
			exit (1);
		}
	ii = sscanf (patp, "%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x",
	    &pat[0], &pat[1], &pat[2], &pat[3], &pat[4], &pat[5], &pat[6],
	    &pat[7], &pat[8], &pat[9], &pat[10], &pat[11], &pat[12],
	    &pat[13], &pat[14], &pat[15]);
	if (ii > 0)
		for (kk = 0;
		    kk <= MAXPACKET - (8 + sizeof(struct timeval) + ii);
		    kk += ii)
			for (jj = 0; jj < ii; ++jj)
				bp[jj + kk] = pat[jj];
	printf ("PATTERN: 0x");
	for (jj = 0; jj < ii; ++jj)
		printf ("%02x", bp[jj] & 0xFF);
	printf ("\n");
}

/*
 * Print out statistics when SIGINFO is received.
 */
void status ()
{
	double temp_min = nreceived ? tmin : 0;

	fprintf (stderr, "%ld/%ld packets received (%d%%) "
		"%.3f min / %.3f avg / %.3f max\n",
		nreceived, ntransmitted, (ntransmitted ?
		100 - (int) ((ntransmitted - nreceived) * 100 / ntransmitted)
		: 0), temp_min, (nreceived + nrepeats) ?
		(tsum / (nreceived + nrepeats)) /1000.0 : tsum,
		tmax / 1000.0);
}

/*
 * Print out statistics, and give up.
 */
void finish ()
{
	int i;

	signal (SIGINT, SIG_IGN);
	putchar ('\n');
	fflush (stdout);
	printf ("--- %s ping statistics ---\n", target);
	printf ("%ld packets transmitted, ", ntransmitted);
	printf ("%ld packets received, ", nreceived);
	if (nrepeats)
		printf ("+%ld duplicates, ", nrepeats);
	if (ntransmitted)
		if (nreceived > ntransmitted)
			printf ("-- somebody's printing up packets!");
		else
			printf ("%d%% packet loss", (int) (((ntransmitted -
				nreceived) * 100) / ntransmitted));
	putchar ('\n');
	if (nreceived && timing) {
		/* Only display average to microseconds */
		i = 1000.0 * tsum / (nreceived + nrepeats);
		printf ("round-trip min/avg/max = %.3f/%.3f/%.3f ms\n",
			tmin, (double) i / 1000.0, tmax);
	}
	exit (nreceived ? 0 : 2);
}

int openbpf ()
{
	int s;
	char *nametab[] = { "/dev/bpf0", "/dev/bpf1", "/dev/bpf2",
		"/dev/bpf3", "/dev/bpf4", "/dev/bpf5", 0 };
	char **p;

	for (p=nametab; *p; ++p) {
		s = open (*p, 2);
		if (s >= 0)
			return s;
	}
	fprintf (stderr, "Cannot open /dev/bpf\n");
	exit (1);
}

/*
 * Compose and transmit a packet.  The first 8 bytes
 * of the data portion are used to hold a UNIX "timeval" struct in VAX
 * byte-order, to compute the round-trip time.
 */
void pinger ()
{
	int i;

	CLR (ntransmitted % mx_dup_ck);
	*(long*) outpack = ntransmitted++;
	*(long*) (outpack+4) = ident;
	if (timing)
		gettimeofday ((struct timeval*) (outpack+8), 0);

	i = write (s, outpack, datalen);
	if (i < 0 || i != datalen)  {
		if (i < 0)
			perror ("ifping: bpfwrite");
		printf ("ifping: wrote %s %d chars, ret=%d\n",
			target, datalen, i);
	}
	if (options & F_FLOOD)
		write (1, ".", 1);
}

/*
 * This routine causes another PING to be transmitted, and then
 * schedules another SIGALRM for 1 second from now.
 *
 * bug --
 *	Our sense of time will slowly skew (i.e., packets will not be
 * launched exactly at 1-second intervals).  This does not affect the
 * quality of the delay and loss statistics.
 */
void catcher ()
{
	int waittime;

	pinger ();
	signal (SIGALRM, catcher);
	if (!npackets || ntransmitted < npackets)
		alarm (interval);
	else {
		if (nreceived) {
			waittime = 2 * tmax / 1000;
			if (! waittime)
				waittime = 1;
		} else
			waittime = MAXWAIT;
		signal (SIGALRM, finish);
		alarm (waittime);
	}
}

/*
 * Subtract 2 timeval structs:  out = out - in.  Out is assumed to be >= in.
 */
void tvsub (struct timeval *out, struct timeval *in)
{
	out->tv_usec -= in->tv_usec;
	if (out->tv_usec < 0) {
		--out->tv_sec;
		out->tv_usec += 1000000;
	}
	out->tv_sec -= in->tv_sec;
}

/*
 * Print out the packet, if it came from us.  This logic is necessary
 * because ALL readers of the ICMP socket get a copy of ALL ICMP packets
 * which arrive ('tis only fair).  This permits multiple copies of this
 * program to be run without having intermingled output (or statistics!).
 */
void pr_pack (char *buf, int cc)
{
	int i, seq;
	u_char *cp, *dp;
	struct timeval tv;
	double triptime = 0;

	gettimeofday (&tv, 0);
	if (cc >= 8 && *(long*) (buf+4) != ident)
		return;                 /* 'Twas not our ECHO */

	seq = *(long*) buf;
	if (! TST(seq % mx_dup_ck)) {
		SET (seq % mx_dup_ck);
		return;
	}
	++nreceived;

	if (timing) {
		tvsub (&tv, (struct timeval*) (buf+8));
		triptime = ((double)tv.tv_sec) * 1000.0 +
			((double)tv.tv_usec) / 1000.0;
		if (triptime < 100000) {
			tsum += triptime;
			if (triptime < tmin)
				tmin = triptime;
			if (triptime > tmax)
				tmax = triptime;
		}
	}

	if (options & F_FLOOD)
		write (1, "\b", 1);
	else {
		printf ("%d bytes from %s: seq=%u", cc, target, seq);
		if (timing)
			printf (" time=%.3f ms", triptime);
		/* check the data */
		cp = buf + 8 + sizeof(struct timeval);
		dp = outpack + 8 + sizeof(struct timeval);
		for (i=8+sizeof(struct timeval); i<datalen; ++i, ++cp, ++dp) {
			if (*cp != *dp) {
				printf("\nwrong data byte #%d should be 0x%x but was 0x%x",
				    i, *dp, *cp);
				cp = buf;
				for (i=8+sizeof(struct timeval); i<datalen; ++i, ++cp) {
					if ((i % 32) == 8)
						printf("\n\t");
					printf("%x ", *cp);
				}
				break;
			}
		}
	}

	if (! (options & F_FLOOD)) {
		putchar ('\n');
		fflush (stdout);
	}
}

int main (int argc, char **argv)
{
	int i, cc, packlen, iftype, preload = 0;
	struct ifreq ifreq;
	char *datap;
	struct timeval timeout;
	struct bpf_hdr *h = (struct bpf_hdr*) packet;

	datap = 8 + &outpack[sizeof(struct timeval)];
	while ((cc = getopt(argc, argv, "c:fi:l:p:s:")) != EOF)
		switch(cc) {
		case 'c':
			npackets = atoi(optarg);
			if (npackets <= 0) {
				fprintf(stderr,
				    "ping: bad number of packets to transmit.\n");
				exit(1);
			}
			break;
		case 'f':
			options |= F_FLOOD;
			setbuf(stdout, (char *)NULL);
			break;
		case 'i':		/* wait between sending packets */
			interval = atoi(optarg);
			if (interval <= 0) {
				fprintf(stderr,
				    "ping: bad timing interval.\n");
				exit(1);
			}
			options |= F_INTERVAL;
			break;
		case 'l':
			preload = atoi(optarg);
			if (preload < 0) {
				fprintf(stderr,
				    "ping: bad preload value.\n");
				exit(1);
			}
			break;
		case 'p':		/* fill buffer with user pattern */
			options |= F_PINGFILLED;
			fill (datap, optarg);
			break;
		case 's':		/* size of packet to send */
			datalen = atoi(optarg);
			if (datalen > MAXPACKET) {
				fprintf(stderr,
				    "ping: packet size too large.\n");
				exit(1);
			}
			if (datalen <= 0) {
				fprintf(stderr,
				    "ping: illegal packet size.\n");
				exit(1);
			}
			break;
		default:
			usage();
		}
	argc -= optind;
	argv += optind;

	if (argc != 1)
		usage();
	target = *argv;

	if (options & F_FLOOD && options & F_INTERVAL) {
		fprintf(stderr,
		    "ping: -f and -i incompatible options.\n");
		exit(1);
	}

	if (datalen >= 8+sizeof(struct timeval))  /* can we time transfer */
		timing = 1;
	if (! (options & F_PINGFILLED))
		for (i=0; i<datalen; ++i)
			outpack[i] = i;
	ident = getpid ();

	s = openbpf ();
	if (ioctl (s, BIOCGBLEN, &packlen) < 0) {
		perror ("BIOCGBLEN");
		exit (1);
	}
	strcpy (ifreq.ifr_name, target);
	if (ioctl (s, BIOCSETIF, &ifreq) < 0) {
		perror (target);
		exit (1);
	}
	if (ioctl (s, BIOCGDLT, &iftype) < 0) {
		perror ("BIOCGDLT");
		exit (1);
	}
	timeout.tv_sec = 0;
	timeout.tv_usec = 10000;
	if (ioctl (s, BIOCSRTIMEOUT, &timeout) < 0) {
		perror ("BIOCSRTIMEOUT");
		exit (1);
	}

	printf ("PING interface %s (type %s): %d data bytes\n",
		target, dltname (iftype), datalen);

	signal (SIGINT, finish);
	signal (SIGALRM, catcher);
	signal (SIGINFO, status);

	while (preload--)		/* fire off them quickies */
		pinger ();

	if ((options & F_FLOOD) == 0)
		catcher ();             /* start things going */

	for (;;) {
		cc = read (s, packet, packlen);
		if (cc <= 0) {
			if (errno != EINTR && errno != 2) {
				perror ("ifping: bpfread");
				fprintf (stderr, "errno=%d\n", errno);
			}
			if (options & F_FLOOD)
				pinger ();
			continue;
		}
		for (datap=packet; cc>0; ) {
			pr_pack (datap + h->bh_hdrlen, h->bh_caplen);
			datap += BPF_WORDALIGN (h->bh_hdrlen + h->bh_caplen);
			cc -= BPF_WORDALIGN (h->bh_hdrlen + h->bh_caplen);
		}
		if (npackets && nreceived >= npackets)
			break;
	}
	finish();
	return 0;
}
