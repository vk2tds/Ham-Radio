:
rm -rf TMP
mkdir TMP

echo Copying...
tar cf - [a-z]* %* | (cd TMP; tar xf -)
echo Converting...

find TMP -type f ! -name \*.bat ! -name \*.exe ! -name \*.bmp \
	! -name \*.doc ! -name \*.prj ! -name \*.tc |\
	xargs todos

d=`pwd`
n=`basename $d`
echo Zipping $n.zip...
(cd TMP; zip -r -q ../$n.zip *)

echo Clearing...
rm -rf TMP
echo Done.
