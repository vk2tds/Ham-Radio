/*
 * Defines for Cronyx-Sigma adapter driver.
 *
 * Copyright (C) 1994 Cronyx Ltd.
 * Author: Serge Vakulenko, <vak@zebub.msk.su>
 *
 * This software is distributed with NO WARRANTIES, not even the implied
 * warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Authors grant any other persons or organisations permission to use
 * or modify this software as long as this message is kept with the software,
 * all derivative works or modified versions.
 *
 * Version 2.1, Thu Jun  6 23:27:53 MSD 1996
 */

#ifndef port_t
#   ifdef _M_ALPHA                      /* port address on Alpha under */
#      define port_t unsigned long      /* Windows NT is 32 bit long */
#   else
#      define port_t unsigned short     /* all other architectures */
#   endif                               /* have 16-bit port addresses */
#endif

/*
 * Asynchronous channel mode -------------------------------------------------
 */

/* Parity */
#define	PAR_EVEN	0	/* even parity */
#define	PAR_ODD		1	/* odd parity */

/* Parity mode */
#define	PARM_NOPAR	0	/* no parity */
#define	PARM_FORCE	1	/* force parity (odd = force 1, even = 0) */
#define	PARM_NORMAL	2	/* normal parity */

/* Flow control transparency mode */
#define	FLOWCC_PASS	0	/* pass flow ctl chars as exceptions */
#define FLOWCC_NOTPASS  1       /* don't pass flow ctl chars to the host */

/* Stop bit length */
#define	STOPB_1		2	/* 1 stop bit */
#define	STOPB_15	3	/* 1.5 stop bits */
#define	STOPB_2		4	/* 2 stop bits */

/* Action on break condition */
#define	BRK_INTR	0	/* generate an exception interrupt */
#define	BRK_NULL	1	/* translate to a NULL character */
#define	BRK_RESERVED	2	/* reserved */
#define	BRK_DISCARD	3	/* discard character */

/* Parity/framing error actions */
#define	PERR_INTR	0	/* generate an exception interrupt */
#define	PERR_NULL	1	/* translate to a NULL character */
#define	PERR_IGNORE	2	/* ignore error; char passed as good data */
#define	PERR_DISCARD	3	/* discard error character */
#define	PERR_FFNULL	5	/* translate to FF NULL char */

typedef struct {		/* async channel option register 1 */
	unsigned charlen : 4;	/* character length, 5..8 */
	unsigned ignpar : 1;	/* ignore parity */
	unsigned parmode : 2;	/* parity mode */
	unsigned parity : 1;	/* parity */
} cx_cor1_async_t;

typedef struct {		/* async channel option register 2 */
	unsigned dsrae : 1;	/* DSR automatic enable */
	unsigned ctsae : 1;	/* CTS automatic enable */
	unsigned rtsao : 1;	/* RTS automatic output enable */
	unsigned rlm : 1;	/* remote loopback mode enable */
	unsigned zero : 1;
	unsigned etc : 1;	/* embedded transmitter cmd enable */
	unsigned ixon : 1;	/* in-band XON/XOFF enable */
	unsigned ixany : 1;	/* XON on any character */
} cx_cor2_async_t;

typedef struct {		/* async channel option register 3 */
	unsigned stopb : 3;	/* stop bit length */
	unsigned zero : 1;
	unsigned scde : 1;	/* special char detection enable */
	unsigned flowct : 1;	/* flow control transparency mode */
	unsigned rngde : 1;	/* range detect enable */
	unsigned escde : 1;	/* extended spec. char detect enable */
} cx_cor3_async_t;

typedef struct {		/* async channel option register 6 */
	unsigned parerr : 3;	/* parity/framing error actions */
	unsigned brk : 2;	/* action on break condition */
	unsigned inlcr : 1;	/* translate NL to CR on input */
	unsigned icrnl : 1;	/* translate CR to NL on input */
	unsigned igncr : 1;	/* discard CR on input */
} cx_cor6_async_t;
		
typedef struct {		/* async channel option register 7 */
	unsigned ocrnl : 1;	/* translate CR to NL on output */
	unsigned onlcr : 1;	/* translate NL to CR on output */
	unsigned zero : 3;
	unsigned fcerr : 1;	/* process flow ctl err chars enable */
	unsigned lnext : 1;	/* LNext option enable */
	unsigned istrip : 1;	/* strip 8-bit on input */
} cx_cor7_async_t;

typedef struct {		/* async channel options */
	cx_cor1_async_t cor1;   /* channel option register 1 */
	cx_cor2_async_t cor2;   /* channel option register 2 */
	cx_cor3_async_t cor3;   /* option register 3 */
	cx_cor6_async_t cor6;   /* channel option register 6 */
	cx_cor7_async_t cor7;   /* channel option register 7 */
	unsigned char schr1;	/* special character register 1 (XON) */
	unsigned char schr2;	/* special character register 2 (XOFF) */
	unsigned char schr3;	/* special character register 3 */
	unsigned char schr4;	/* special character register 4 */
	unsigned char scrl;	/* special character range low */
	unsigned char scrh;	/* special character range high */
	unsigned char lnxt;	/* LNext character */
} cx_opt_async_t;

/*
 * HDLC channel mode ---------------------------------------------------------
 */
/* Address field length option */
#define	AFLO_1OCT	0	/* address field is 1 octet in length */
#define	AFLO_2OCT	1	/* address field is 2 octet in length */

/* Clear detect for X.21 data transfer phase */
#define	CLRDET_DISABLE	0	/* clear detect disabled */
#define	CLRDET_ENABLE	1	/* clear detect enabled */

/* Addressing mode */
#define	ADMODE_NOADDR	0	/* no address */
#define	ADMODE_4_1	1	/* 4 * 1 byte */
#define	ADMODE_2_2	2	/* 2 * 2 byte */

/* FCS append */
#define	FCS_NOTPASS	0	/* receive CRC is not passed to the host */
#define	FCS_PASS	1	/* receive CRC is passed to the host */

/* CRC modes */
#define	CRC_INVERT	0	/* CRC is transmitted inverted (CRC V.41) */
#define	CRC_DONT_INVERT	1	/* CRC is not transmitted inverted (CRC-16) */

/* Send sync pattern */
#define	SYNC_00		0	/* send 00h as pad char (NRZI encoding) */
#define	SYNC_AA		1	/* send AAh (Manchester/NRZ encoding) */

/* FCS preset */
#define	FCSP_ONES	0	/* FCS is preset to all ones (CRC V.41) */
#define	FCSP_ZEROS	1	/* FCS is preset to all zeros (CRC-16) */

/* idle mode */
#define	IDLE_FLAG	0	/* idle in flag */
#define	IDLE_MARK	1	/* idle in mark */

/* CRC polynomial select */
#define	POLY_V41	0	/* x^16+x^12+x^5+1 (HDLC, preset to 1) */
#define	POLY_16		1	/* x^16+x^15+x^2+1 (bisync, preset to 0) */

typedef struct {		/* hdlc channel option register 1 */
	unsigned ifflags : 4;	/* number of inter-frame flags sent */
	unsigned admode : 2;	/* addressing mode */
	unsigned clrdet : 1;	/* clear detect for X.21 data transfer phase */
	unsigned aflo : 1;	/* address field length option */
} cx_cor1_hdlc_t;

typedef struct {		/* hdlc channel option register 2 */
	unsigned dsrae : 1;	/* DSR automatic enable */
	unsigned ctsae : 1;	/* CTS automatic enable */
	unsigned rtsao : 1;	/* RTS automatic output enable */
	unsigned zero1 : 1;
	unsigned crcninv : 1;	/* CRC invertion option */
	unsigned zero2 : 1;
	unsigned fcsapd : 1;	/* FCS append */
	unsigned zero3 : 1;
} cx_cor2_hdlc_t;

typedef struct {		/* hdlc channel option register 3 */
	unsigned padcnt : 3;	/* pad character count */
	unsigned idle : 1;	/* idle mode */
	unsigned nofcs : 1;	/* FCS disable */
	unsigned fcspre : 1;	/* FCS preset */
	unsigned syncpat : 1;	/* send sync pattern */
	unsigned sndpad : 1;	/* send pad characters before flag enable */
} cx_cor3_hdlc_t;

typedef struct {		/* hdlc channel options */
	cx_cor1_hdlc_t cor1;    /* hdlc channel option register 1 */
	cx_cor2_hdlc_t cor2;    /* hdlc channel option register 2 */
	cx_cor3_hdlc_t cor3;    /* hdlc channel option register 3 */
	unsigned char rfar1;	/* receive frame address register 1 */
	unsigned char rfar2;	/* receive frame address register 2 */
	unsigned char rfar3;	/* receive frame address register 3 */
	unsigned char rfar4;	/* receive frame address register 4 */
	unsigned char cpsr;	/* CRC polynomial select */
} cx_opt_hdlc_t;

/*
 * CD2400 channel state structure --------------------------------------------
 */

/* Signal encoding */
#define ENCOD_NRZ        0      /* NRZ mode */
#define ENCOD_NRZI       1      /* NRZI mode */
#define ENCOD_MANCHESTER 2      /* Manchester mode */

/* Clock source */
#define CLK_0           0      /* clock 0 */
#define CLK_1           1      /* clock 1 */
#define CLK_2           2      /* clock 2 */
#define CLK_3           3      /* clock 3 */
#define CLK_4           4      /* clock 4 */
#define CLK_EXT         6      /* external clock */
#define CLK_RCV         7      /* receive clock */

/* Board type */
#define B_SIGMA_XXX     0       /* old Sigmas */
#define B_SIGMA_2X      1       /* Sigma-22 */
#define B_SIGMA_800     2       /* Sigma-800 */

/* Channel type */
#define T_NONE          0       /* no channel */
#define T_ASYNC         1       /* pure asynchronous RS-232 channel */
#define T_SYNC_RS232    2       /* pure synchronous RS-232 channel */
#define T_SYNC_V35      3       /* pure synchronous V.35 channel */
#define T_SYNC_RS449    4       /* pure synchronous RS-449 channel */
#define T_UNIV_RS232    5       /* sync/async RS-232 channel */
#define T_UNIV_RS449    6       /* sync/async RS-232/RS-449 channel */
#define T_UNIV_V35      7       /* sync/async RS-232/V.35 channel */

#define M_ASYNC 0               /* asynchronous mode */
#define M_HDLC  1               /* HDLC mode */

typedef struct {		/* channel option register 4 */
	unsigned thr : 4;	/* FIFO threshold */
	unsigned zero : 1;
	unsigned cts_zd : 1;	/* detect 1 to 0 transition on the CTS */
	unsigned cd_zd : 1;	/* detect 1 to 0 transition on the CD */
	unsigned dsr_zd : 1;	/* detect 1 to 0 transition on the DSR */
} cx_cor4_t;

typedef struct {		/* channel option register 5 */
	unsigned rx_thr : 4;	/* receive flow control FIFO threshold */
	unsigned zero : 1;
	unsigned cts_od : 1;	/* detect 0 to 1 transition on the CTS */
	unsigned cd_od : 1;	/* detect 0 to 1 transition on the CD */
	unsigned dsr_od : 1;	/* detect 0 to 1 transition on the DSR */
} cx_cor5_t;

typedef struct {		/* receive clock option register */
	unsigned clk : 3;	/* receive clock source */
	unsigned encod : 2;     /* signal encoding NRZ/NRZI/Manchester */
	unsigned dpll : 1;      /* DPLL enable */
	unsigned zero : 1;
	unsigned tlval : 1;	/* transmit line value */
} cx_rcor_t;

typedef struct {		/* transmit clock option register */
	unsigned zero1 : 1;
	unsigned llm : 1;	/* local loopback mode */
	unsigned zero2 : 1;
	unsigned ext1x : 1;	/* external 1x clock mode */
	unsigned zero3 : 1;
	unsigned clk : 3;	/* transmit clock source */
} cx_tcor_t;

typedef struct {
	cx_cor4_t cor4;         /* channel option register 4 */
	cx_cor5_t cor5;         /* channel option register 5 */
	cx_rcor_t rcor;         /* receive clock option register */
	cx_tcor_t tcor;         /* transmit clock option register */
} cx_chan_opt_t;

typedef enum {                  /* line break mode */
	BRK_IDLE,               /* normal line mode */
	BRK_SEND,               /* start sending break */
	BRK_STOP,               /* stop sending break */
} cx_break_t;

#define CX_MAXDLCI 16           /* max DLCIs per channel */

typedef struct {
	unsigned cisco : 1;             /* cisco mode */
	unsigned keepalive : 1;         /* keepalive enable */
	unsigned ext : 1;               /* use external ppp implementation */
	unsigned norts : 1;             /* disable automatic RTS control */
	unsigned callout : 1;           /* callout device opened */
	unsigned dtroff : 1;            /* DTR off timeout active */
	unsigned auth : 2;		/* authentication mode off/pap/chap/chap-ms */
	unsigned lock;                  /* channel locked for use by driver */
	unsigned dtrwait;               /* DTR off timeout in ticks */
	unsigned short dlci [CX_MAXDLCI]; /* list of DLCIs (for Frame Relay) */
	char master [16];               /* master interface name or \0 */
	unsigned char name [32];	/* PAP/CHAP identification name */
	unsigned char passwd [16];	/* PAP/CHAP password */
} cx_soft_opt_t;

#define BUS_NORMAL	0	/* normal bus timing */
#define BUS_FAST	1	/* fast bus timing (Sigma-22 and -800) */
#define BUS_FAST2	2	/* fast bus timing (Sigma-800) */
#define BUS_FAST3	3	/* fast bus timing (Sigma-800) */

typedef struct {                /* board options */
	unsigned char fast;	/* bus master timing (Sigma-22 and -800) */
} cx_board_opt_t;

#define NCHIP    4		/* the number of controllers per board */
#define NCHAN    16		/* the number of channels on the board */

#define CX_OPT_MAGIC	0x43534947

typedef struct {
	unsigned long magic;		/* magic number */
	unsigned char board;            /* adapter number, 0..2 */
	unsigned char channel;          /* channel number, 0..15 */

	/* Adapter data */
	port_t port;                    /* base board port, 0..3f0 */
	unsigned char irq;              /* irq {3 5 7 10 11 12 15} */
	unsigned char dma;              /* DMA request {5 6 7} */
	unsigned long anum;             /* NT adapter number */
	char name[16];                  /* board version name */
	cx_board_opt_t bopt;            /* board options */
	
	/* Channel data */
	unsigned char type;             /* channel type (read only) */
	unsigned char iftype;           /* chan0 interface RS-232/RS-449/V.35 */
	unsigned long rxbaud;		/* receiver speed */
	unsigned long txbaud;		/* transmitter speed */
	unsigned char mode;             /* channel mode */
	cx_chan_opt_t opt;              /* common channel options */
	cx_opt_async_t aopt;            /* async mode options */
	cx_opt_hdlc_t hopt;             /* hdlc mode options */
	cx_soft_opt_t sopt;             /* software options and state flags */
} cx_options_t;                         /* user settable options */

#ifdef NDIS_MINIPORT_DRIVER
typedef struct _cx_queue_t {            /* packet queue */
	PNDIS_WAN_PACKET	head;	/* first packet in queue */
	PNDIS_WAN_PACKET	tail;	/* last packet in queue */
} cx_queue_t;				
#endif

typedef struct _cx_chan_t {
	unsigned char type;             /* channel type */
	unsigned char num;              /* channel number, 0..15 */
	struct _cx_board_t *board;      /* board pointer */
	struct _cx_chip_t *chip;        /* controller pointer */
	struct _cx_stat_t *stat;        /* statistics */
	unsigned long rxbaud;		/* receiver speed */
	unsigned long txbaud;		/* transmitter speed */
	unsigned char mode;             /* channel mode */
	cx_chan_opt_t opt;              /* common channel options */
	cx_opt_async_t aopt;            /* async mode options */
	cx_opt_hdlc_t hopt;             /* hdlc mode options */
	unsigned char *arbuf;           /* receiver A dma buffer */
	unsigned char *brbuf;           /* receiver B dma buffer */
	unsigned char *atbuf;           /* transmitter A dma buffer */
	unsigned char *btbuf;           /* transmitter B dma buffer */
	unsigned long arphys;           /* receiver A phys address */
	unsigned long brphys;           /* receiver B phys address */
	unsigned long atphys;           /* transmitter A phys address */
	unsigned long btphys;           /* transmitter B phys address */
	unsigned char dtr;              /* DTR signal value */
	unsigned char rts;              /* RTS signal value */
	unsigned char ptt;		/* PTT Status */
	unsigned char txen;		/* TxEN Status */

#if defined(__linux__) && defined(__KERNEL__)
	/* Linux specific fields */
#else
	/* FreeBSD & BSDI specific fields */
#ifdef KERNEL
	struct tty *ttyp;               /* tty structure pointer */
	struct ifnet *ifp;              /* network interface data */
	struct ifnet *master;           /* master interface, or ==ifp */
	struct _cx_chan_t *slaveq;      /* slave queue pointer, or NULL */
	caddr_t bpf;                    /* packet filter data */
	cx_soft_opt_t sopt;             /* software options and state flags */
	cx_break_t brk;                 /* line break mode */
#ifdef __bsdi__
	struct ttydevice_tmp *ttydev;   /* tty statistics structure */
#endif
#endif
#endif
#ifdef NDIS_MINIPORT_DRIVER
	HTAPI_LINE		htline;	/* TAPI line descriptor */
	HTAPI_CALL		htcall;	/* TAPI call descriptor */
	NDIS_HANDLE             connect; /* WAN connection context */
	cx_queue_t		sendq;	/* packets to transmit queue */
	cx_queue_t		busyq;	/* transmit busy queue */
	UINT			state;	/* line state mask */
	int			timo;	/* state timeout counter */
#endif
} cx_chan_t;

typedef struct _cx_chip_t {
	port_t port;                    /* base port address, or 0 if no chip */
	unsigned char num;              /* controller number, 0..3 */
	struct _cx_board_t *board;      /* board pointer */
	unsigned long oscfreq;		/* oscillator frequency in Hz */
} cx_chip_t;

typedef struct _cx_stat_t {
	unsigned char board;            /* adapter number, 0..2 */
	unsigned char channel;          /* channel number, 0..15 */
	unsigned long rintr;            /* receive interrupts */
	unsigned long tintr;            /* transmit interrupts */
	unsigned long mintr;            /* modem interrupts */
	unsigned long ibytes;           /* input bytes */
	unsigned long ipkts;            /* input packets */
	unsigned long ierrs;            /* input errors */
	unsigned long obytes;           /* output bytes */
	unsigned long opkts;            /* output packets */
	unsigned long oerrs;            /* output errors */
} cx_stat_t;

typedef struct _cx_board_t {
	unsigned char type;             /* board type */
	unsigned char num;		/* board number, 0..2 */
	unsigned char irq;              /* irq {3 5 7 10 11 12 15} */
	unsigned char dma;              /* DMA request {5 6 7} */
	port_t port;                    /* base board port, 0..3f0 */
	unsigned char if0type;          /* chan0 interface RS-232/RS-449/V.35 */
	unsigned char if8type;          /* chan8 interface RS-232/RS-449/V.35 */
	unsigned short bcr0;            /* BCR0 image */
	unsigned short bcr0b;           /* BCR0b image */
	unsigned short bcr1;            /* BCR1 image */
	unsigned short bcr1b;           /* BCR1b image */
	cx_board_opt_t opt;             /* board options */
	cx_chip_t chip[NCHIP];          /* controller structures */
	cx_chan_t chan[NCHAN];          /* channel structures */
	cx_stat_t stat[NCHAN];          /* channel statistics */
	char name[16];                  /* board version name */
	unsigned char nuniv;            /* number of universal channels */
	unsigned char nsync;            /* number of sync. channels */
	unsigned char nasync;           /* number of async. channels */
#ifdef NDIS_MINIPORT_DRIVER
	PVOID           	ioaddr; /* mapped i/o port address */
	NDIS_HANDLE     	mh;     /* miniport adapter handler */
	NDIS_MINIPORT_INTERRUPT	irqh;   /* interrupt handler */
	NDIS_HANDLE     	dmah;   /* dma channel handler */
	ULONG			bufsz;	/* size of shared memory buffer */
	PVOID           	buf;    /* shared memory for adapter */
	NDIS_PHYSICAL_ADDRESS	bphys;  /* shared memory phys address */
	NDIS_SPIN_LOCK  	lock;   /* lock descriptor */
	ULONG           	debug;  /* debug flags */
	ULONG           	idbase; /* TAPI device identifier base number */
	ULONG           	anum; 	/* adapter number, from inf setup script */
	NDIS_MINIPORT_TIMER     timer;  /* periodic timer structure */
#endif
} cx_board_t;

#define CX_SPEED_DFLT	9600

extern long cx_rxbaud, cx_txbaud;
extern int cx_univ_mode, cx_sync_mode, cx_iftype;

extern cx_chan_opt_t chan_opt_dflt;     /* default mode-independent options */
extern cx_opt_async_t opt_async_dflt;   /* default async options */
extern cx_opt_hdlc_t opt_hdlc_dflt;     /* default hdlc options */
extern cx_board_opt_t board_opt_dflt;   /* default board options */

struct _cr_dat_tst;
int cx_probe_board (port_t port);
void cx_init (cx_board_t *b, int num, port_t port, int irq, int dma);
void cx_init_board (cx_board_t *b, int num, port_t port, int irq, int dma,
	int chain, int rev, int osc, int mod, int rev2, int osc2, int mod2);
void cx_init_2x (cx_board_t *b, int num, port_t port, int irq, int dma,
	int rev, int osc);
void cx_init_800 (cx_board_t *b, int num, port_t port, int irq, int dma,
	int chain);
int cx_setup_board (cx_board_t *b, const unsigned char *firmware,
	long bits, const struct _cr_dat_tst *tst);
void cx_setup_chan (cx_chan_t *c);
void cx_update_chan (cx_chan_t *c);
void cx_chan_dtr (cx_chan_t *c, int on);
void cx_chan_rts (cx_chan_t *c, int on);
void cx_cmd (port_t base, int cmd);
void cx_disable_dma (cx_board_t *b);
void cx_reinit_board (cx_board_t *b);
int cx_chan_dsr (cx_chan_t *c);
int cx_chan_cd (cx_chan_t *c);
void cx_clock (long hz, long ba, int *clk, int *div);

#define CXIOCGETMODE _IOWR('x', 1, cx_options_t)   /* get channel options */
#define CXIOCSETMODE _IOW('x',  2, cx_options_t)   /* set channel options */
#define CXIOCGETSTAT _IOWR('x', 3, cx_stat_t)      /* get channel stats */

#ifdef KERNEL
#ifdef __bsdi__
#include <sys/types.h>
#include <sys/device.h>
#include <i386/isa/isavar.h>
struct cxsoftc {
	struct device dev;      /* base device */
	struct isadev isadev;   /* ISA device */
	struct intrhand intr;   /* interrupt vectoring */
#ifdef BSDI2
	cx_board_t brd;         /* adapter structure */
#endif
};
#endif /* __bsdi__ */
#endif /* KERNEL */
