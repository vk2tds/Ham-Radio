/*
 * Declarations of port i/o routines.
 *
 * Copyright (C) 1994 Cronyx Ltd.
 * Author: Serge Vakulenko, <vak@zebub.msk.su>
 *
 * This software is distributed with NO WARRANTIES, not even the implied
 * warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Authors grant any other persons or organisations permission to use
 * or modify this software as long as this message is kept with the software,
 * all derivative works or modified versions.
 */
#if defined (MSDOS) || defined (__MSDOS__)
#   include <dos.h>
#   define inb(port)    inportb(port)
#   define inw(port)    inport(port)
#   define outb(port,b) outportb(port,b)
#   define outw(port,w)	outport(port,w)
#else
    extern unsigned char inb (unsigned short port);
    extern unsigned short inw (unsigned short port);
    extern void outb (unsigned short port, unsigned char val);
    extern void outw (unsigned short port, unsigned short val);
#endif
