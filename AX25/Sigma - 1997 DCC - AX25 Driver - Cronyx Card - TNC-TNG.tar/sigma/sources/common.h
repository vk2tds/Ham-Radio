//
// Declarations of common variables for DIAG utility.
//
// Copyright (C) 1994 Cronyx Ltd.
// Author: Serge Vakulenko, <vak@zebub.msk.su>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.8, Thu Jun  8 20:22:06 MSD 1995
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timeb.h>
#include <dos.h>
#include <bios.h>
#include <conio.h>
extern "C" {
	#include "csigma.h"
	#include "cxreg.h"
	#include "udelay.h"
	extern void Message (char *str, ...);
};
#include "Screen.h"
#include "Menu.h"
#include "Popup.h"

#if defined (MSDOS) || defined (__MSDOS__)
#   include <dos.h>
#   define inb(port)    inportb(port)
#   define inw(port)    inport(port)
#   define outb(port,b) outportb(port,b)
#   define outw(port,w)	outport(port,w)
#else
    extern unsigned char inb (unsigned short port);
    extern unsigned short inw (unsigned short port);
    extern void outb (unsigned short port, unsigned char val);
    extern void outw (unsigned short port, unsigned short val);
#endif

#define Msg(eng,rus)	(LanguageEnglish ? (eng) : (rus))
#define IOSZ		256

typedef struct {
	unsigned long sendbus;		// send bus error count
	unsigned long recvbus;		// recv bus error count
	unsigned long underrun;		// underrun error count
	unsigned long overrun;		// overrun error count
	unsigned long parity;		// parity error count
	unsigned long frame;		// frame error count
	unsigned long crc;		// CRC error count
	unsigned long data;		// data error count
	unsigned char recvbyte;		// invalid received byte
	unsigned char sentbyte;		// byte as it should be
	unsigned long bytenum;		// its order number
	unsigned char board;		// its adapter number
	unsigned char channel;		// its channel number
} errcnt_t;

typedef struct {
	unsigned long offset;		// received data byte count
	unsigned char sendoff;		// transmitted data byte count
	unsigned long data;		// data error count
	unsigned char recvbyte;		// invalid received byte
	unsigned char sentbyte;		// byte as it should be
	unsigned long bytenum;		// its order number
} errchan_t;

extern errcnt_t errcnt;
extern errchan_t errchan[NBRD][NCHAN];

extern unsigned long bytecount, rbytecount;
extern unsigned long framecount, rframecount;
extern unsigned long gigacount, rgigacount;
extern unsigned long intrcount;
extern struct timeb time0;

extern unsigned char TestPattern[256];
extern int TestPatternDisabled;
extern int TestPatternNumber;
extern unsigned char TestPatternCustom;

typedef enum {
	ER_DATA,
	ER_SENDBUS,
	ER_RECVBUS,
	ER_UNDERRUN,
	ER_OVERRUN,
	ER_PARITY,
	ER_FRAME,
	ER_CRC,
} log_type_t;

typedef struct {
	long sec;			// seconds since test start
	unsigned char board;		// adapter number
	unsigned char channel;		// channel number
	log_type_t type;		// error type
	unsigned long bytenum;		// byte number
	unsigned char recvbyte;		// invalid received byte
	unsigned char sentbyte;		// byte as it should be
} log_t;

extern log_t logtab[256];		// circular buffer
extern unsigned char lnext;		// next free slot
extern unsigned char lfirst;		// first busy slot
extern unsigned long ovf;		// log buffer overflow counter
extern unsigned long lastovf;		// last saved overflow counter

extern void InitLog (cx_board_t *b0, cx_chan_t *c0, char *name);
extern void FlushLog (void);
extern void CloseLog (void);
extern void Log (unsigned char bn, unsigned char cn, log_type_t type,
	unsigned char errb=0, unsigned char goodb=0);

extern Screen V;
extern Menu M;
extern void PromptQuit (void);
extern void Hint (char *str);
extern void Help (int key);
extern void Help (char *str);
extern void NotImplementedYet (void);

extern int TextColor;
extern int LightTextColor;
extern int InverseTextColor;
extern int InverseLightTextColor;
extern int DimTextColor;
extern int InverseDimTextColor;
extern int OptionColor;
extern int LightOptionColor;
extern int ErrorColor;
extern int HelpColor;

extern int PaletteChanged;
extern int LanguageEnglish;

extern char *HelpItem;

extern cx_board_t board[NBRD];
extern int nbrd;

extern int dmatab[NBRD];
extern int irqtab[NBRD];

extern cx_chan_opt_t chan_opt_save;
extern cx_opt_async_t opt_async_save;
extern cx_opt_hdlc_t opt_hdlc_save;

extern void interrupt (*PortHandlerTable []) ();
extern void interrupt (*DMAHandlerTable []) ();

extern void irq_enable (int irq);
extern void irq_disable (int irq);
extern void irq_eoi (int irq);

extern void DisplaySetup (int transmit, int receive, char *title, char *name);
extern void DisplayRefresh (int transmit, int receive);
extern void DisplayRestore (void);

extern int AskByte (char *prompt);
extern long AskWord (char *prompt);

extern void SetDefaultPattern (void);
extern void DisplayOptions (void);
extern char *PatternName ();
extern void TestAutoconfigure (void);
extern void TestManualConfigure (void);
extern void LoadFirmware (char *name);
extern void ScanIRQs (void);

extern void ViewFile (char *name, int top, int rows);
extern void PrintScreen (char *filename);
extern void Quit (void);

extern int getstr (FILE *fd, char *buf);
