//
// Diagnose utility for Cronyx-Sigma adapter:
// Help routines.
//
// Copyright (C) 1995 Cronyx Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.3, Tue Oct 20 17:01:36 MSD 1994
//
#include "common.h"

#define MAXLINES	2048	// max. number of lines in text file

struct {
	short menu;
	short submenu;
	char *subject;
} HelpTab [] = {
	// Test
	0,  0,	"test-general",
	0,  1,	"test-show-protocol",
	0,  2,	"test-auto-configure",
	0,  3,	"test-manual-configure",
	0,  4,  "",
	0,  5,	"test-about",
	0,  6,	"test-escape-to-shell",
	0,  7,	"test-quit",

	// General
	1,  0,	"general-transmit-port",
	1,  1,	"general-receive-port",
	1,  2,	"general-intloop-port",
	1,  3,	"general-extloop-port",
	1,  4,  "",
	1,  5,	"general-transmit-dma",
	1,  6,	"general-receive-dma",
	1,  7,	"general-intloop-dma",
	1,  8,	"general-extloop-dma",

	// Adapter
	2,  0,	"adapter-select",
	2,  1,	"adapter-reset",
	2,  2,	"",
	2,  3,	"adapter-check-data-path",
	2,  4,	"adapter-check-data-loop",
	2,  5,	"adapter-read-registers",
	2,  6,	"adapter-write-registers",
	2,  7,	"",
	2,  8,	"adapter-transmit-port",
	2,  9,	"adapter-receive-port",
	2, 10,	"adapter-intloop-port",
	2, 11,	"adapter-extloop-port",
	2, 12,  "",
	2, 13,	"adapter-transmit-dma",
	2, 14,	"adapter-receive-dma",
	2, 15,	"adapter-intloop-dma",
	2, 16,	"adapter-extloop-dma",

	// Channel
	3,  0,	"channel-select",
	3,  1,	"channel-baud-rate",
	3,  2,	"",
	3,  3,	"channel-transmit-port",
	3,  4,	"channel-receive-port",
	3,  5,	"channel-intloop-port",
	3,  6,	"channel-extloop-port",
	3,  7,  "",
	3,  8,	"channel-transmit-dma",
	3,  9,	"channel-receive-dma",
	3, 10,	"channel-intloop-dma",
	3, 11,	"channel-extloop-dma",

	// Setup
	4,  0,	"setup-mode",
	4,  1,	"setup-irq-dma-channels",
	4,  2,	"setup-code-pattern",
	4,  3,	"",
	4,  4,	"setup-save",
	4,  5,	"setup-restore",
	4,  6,	"setup-restore-defaults",

	0,  0,	0,
};

struct helptab {
	char *item;
	char *einfo;
	char *rinfo;
} helpTab [] = {
#include "help.h"
{0} };

void Help (char *item)
{
	// ������ ������� �� ��������� ����.
	for (struct helptab *p=helpTab; p->item; ++p)
		if (! strcmp (item, p->item))
			break;
	V.PopupString (Msg (" Help ", " ������� "),
		p->item ? Msg (p->einfo, p->rinfo) :
		    Msg ("No information\n", "��� ����������\n"),
		Msg (" OK ", " ������ "), HelpColor, TextColor);
}

void Help (int key)
{
	// ��� ������� ���������� ��� ������� F1 � ����� �� ����� ������.
	// ���������� ����������� ����������� ����� Help ������� Help.
	// ������ ���, ��������� ����������� ���������� insideHelp.
	static insideHelp = 0;
	int i, j;

	if (insideHelp)
		V.Beep ();
	else {
		i = M.Current (&j);
		for (int n=0; HelpTab[n].subject; ++n)
			if (HelpTab[n].menu == i &&
			    HelpTab[n].submenu == j) {
				insideHelp = 1;
				Help (HelpTab[n].subject);
				insideHelp = 0;
			}
	}
	V.Sync ();
}

static void ViewLine (char *line, int y)
{
	V.Move (y, 0);
	if (line)
		for (; *line; ++line) {
			unsigned char c = *line;
			V.Put (c, (c>=0xb0 && c<0xe0) ?
				DimTextColor : TextColor);
		}
	V.ClearLine (TextColor);
}

static void View (char **line, int nlin, int y, int ny)
{
	// Save image under the window.
	// Box box (V, y, 0, ny, V.Columns);

	// The line at the top of the screen.
	int cline = 0;
	for (;;) {
		for (int i=0; i<ny; ++i)
			ViewLine (cline+i<nlin ? line[cline+i] : 0, y+i);
		for (;;) {
			V.HideCursor ();
			V.Sync ();
			switch (V.GetKey ()) {
			default:
				V.Beep ();
				continue;
			case cntrl ('['):       // Escape - exit
			case cntrl ('C'):       // ^C - exit
				// V.Put (box);
				return;
			case cntrl ('M'):       // ^M - down
			case cntrl ('J'):       // ^J - down
			case meta ('d'):        // down
				if (cline+ny >= nlin)
					continue;
				++cline;
				V.DelLine (y, TextColor);
				V.InsLine (y + ny - 1, TextColor);
				ViewLine (line[cline+ny-1], y+ny-1);
				continue;
			case meta ('u'):        // up
				if (cline <= 0)
					continue;
				--cline;
				V.DelLine (y + ny - 1, TextColor);
				V.InsLine (y, TextColor);
				ViewLine (line[cline], y);
				continue;
			case meta ('n'):        // next page
			case ' ':		// space - next page
				if (cline+ny >= nlin)
					continue;
				cline += ny - 1;
				break;
			case meta ('p'):        // prev page
			case 'b':		// 'b' - prev page
				if (cline <= 0)
					continue;
				if (cline < ny-1)
					cline = 0;
				else
					cline -= ny - 1;
				break;
			case meta ('h'):        // home
				if (cline == 0)
					continue;
				cline = 0;
				break;
			case meta ('e'):        // end
				if (cline+ny >= nlin)
					// ��� �� ��������� ��������.
					continue;
				cline = nlin - ny;
				break;
			}
			break;
		}
	}
}

void ViewFile (char *name, int top, int nrows)
{
	// Open the file.
	FILE *fd = fopen (name, "r");
	if (! fd) {
		V.Error (InverseLightTextColor, TextColor,
			Msg (" Help ", " ������� "), Msg (" Ok ", " ������ "),
			Msg ("Cannot open file `%s'", "��� ����� `%s'"), name);
		return;
	}

	// Read the contents into memory.
	static char *line[MAXLINES];
	for (int len=0; len<MAXLINES; ++len) {
		char buf[256];
		if (! getstr (fd, buf))
			break;
		buf[V.Columns] = 0;
		line[len] = strdup (buf);
		if (! line[len])
			break;
	}
	fclose (fd);

	// Display the text.
	Hint (Msg ("\1PgDn\2-Next page  \1PgUp\2-Previous page  \1Esc\2-Return to Test",
		"\1PgDn\2-����.��������  \1PgUp\2-������.��������  \1Esc\2-������� � ����"));
	View (line, len, top, nrows);

	// Free allocated memory.
	while (--len >= 0)
		free (line[len]);

	// Restore options window.
	DisplayOptions ();
}
