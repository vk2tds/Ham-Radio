//
// Diagnose utility for Cronyx-Sigma adapter:
// Single channel test routines.
//
// Copyright (C) 1995 Cronyx Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.9, Wed Oct  4 21:37:55 MSK 1995
//
#include "common.h"

#define BYTE		*(unsigned char*)&
#define NOERROR		(~0L)
#define GIGA		010000000000L
#define GIGASHIFT	30
#define GIGAMASK	07777777777L

extern int cbrd;			// current board, 0..6
extern cx_board_t *bp;			// current board pointer
int cchan;				// current channel, 0..15

int inside_test;			// flag: test is running
static int giveup;			// flag: halting the test
static int use_dma;			// flag: using DMA

unsigned long transmit_displays_per_10_sec;	// transmit display rate
unsigned long loop_displays_per_10_sec;		// loopback display rate

static void TestChan (cx_chan_t *c, int transmit, int receive,
	int dma, int intloop);
static void TestModemSignals (cx_chan_t *c);

//
// Issue End of Interrupt command to PC interrupt controller.
//
void irq_eoi (int irq)
{
	if (irq >= 8)
		outb (0xa0, 0x20);			// slave EOI
	outb (0x20, 0x20);				// master EOI
}

//
// Unmask (enable) the given interrupt request number
// on the PC interrupt controller.
//
void irq_enable (int irq)
{
	irq_eoi (irq);
	if (irq >= 8) {
		outb (0xa1, inb(0xa1) & ~(1 << (irq&7))); // unmask slave
		outb (0x21, inb(0x21) & ~(1 << 2));	// unmask master #2
	} else
		outb (0x21, inb(0x21) & ~(1 << irq));	// unmask master
}

//
// Mask (disable) the given interrupt request number
// on the PC interrupt controller.
//
void irq_disable (int irq)
{
	irq_eoi (irq);
	if (irq >= 8)
		outb (0xa1, inb(0xa1) | 1 << (irq&7));	// mask slave
	else
		outb (0x21, inb(0x21) | 1 << irq);	// mask master
}

inline void CheckTransmitErrors (cx_chan_t *c, int isr)
{
	if (isr & TIS_BUSERR) {		// Transmit bus error
		++errcnt.sendbus;
		Log (c->board->num, c->num, ER_SENDBUS);
	}
	if (isr & TIS_UNDERRUN)	{	// Transmit underrun error
		++errcnt.underrun;
		Log (c->board->num, c->num, ER_UNDERRUN);
	}
}

inline void CheckReceiveErrors (cx_chan_t *c, int isr, int mode)
{
	if (isr & RIS_BUSERR) {		// Receive bus error
		++errcnt.recvbus;
		Log (c->board->num, c->num, ER_RECVBUS);
	}
	if (isr & RIS_OVERRUN) {	// Receive overrun error
		++errcnt.overrun;
		Log (c->board->num, c->num, ER_OVERRUN);
	}
	switch (mode) {
	case M_ASYNC:
		if (isr & RISA_PARERR) {	// Receive parity error
			++errcnt.parity;
			Log (c->board->num, c->num, ER_PARITY);
		}
		if (isr & RISA_FRERR) {		// Receive frame error
			++errcnt.frame;
			Log (c->board->num, c->num, ER_FRAME);
		}
		break;
	case M_HDLC:
		if (isr & RISH_CRCERR) {	// Receive CRC error
			++errcnt.crc;
			Log (c->board->num, c->num, ER_CRC);
		}
		break;
	}
}

inline void CheckReceivedData (unsigned char *data, unsigned short len,
	int board, int channel)
{
	errchan_t *e = &errchan[board][channel];

	// Fast check.
	unsigned char off = (char) e->offset;
	unsigned char plen = IOSZ - off;
	if (len <= plen) {
		if (memcmp (data, TestPattern+off, len) == 0) {
			e->offset += len;
			rbytecount += len;
			return;
		}
	} else if (memcmp (data, TestPattern+off, plen) == 0 &&
	    memcmp (data+plen, TestPattern, len-plen) == 0) {
		e->offset += len;
		rbytecount += len;
		return;
	}

	// Sequential check.
	for (; len-->0; ++data, ++off) {
		unsigned char as_it_should_be = TestPattern[off];
		if (*data != as_it_should_be) {
			++e->data;
			++errcnt.data;
			Log (board, channel, ER_DATA, *data, as_it_should_be);
			e->recvbyte = errcnt.recvbyte = *data;
			e->sentbyte = errcnt.sentbyte = as_it_should_be;
			e->bytenum = errcnt.bytenum = e->offset;
			errcnt.board = board;
			errcnt.channel = channel;
			return;
		}
		++e->offset;
		++rbytecount;
	}
}

static void PortInterrupt (cx_chan_t *c, unsigned char livr)
{
	unsigned char n;
	unsigned short port = c->chip->port;

	switch (livr & 3) {
	case LIV_MODEM:			// cannot happen
		Message ("Unexpected modem interrupt, misr=%xh", inb(MISR(port)));
		outb (MEOIR(port), 0);
		break;
	case LIV_EXCEP:			// receive exception
	case LIV_RXDATA:		// receive interrupt
		unsigned short risr = inw (RISR(port));
		CheckReceiveErrors (c, risr, c->mode);

		// Increment frame counter.
		if (c->mode==M_HDLC && (risr & RISH_EOFR)) {
			++rframecount;
			// ����������� ������� �������� ������ �� �������
			// ������.  � ���� ������ ��� ������ �� ����������
			// ��������������� ��� ��������� ���������
			// � ����������� �������.
			errchan[c->board->num][c->num].offset &= ~255;
		}

		n = inb (RFOC(port));
		if (TestPatternDisabled) {
			rbytecount += n;
			for (int i=0; i<n; ++i)
				inb (RDR(port));
		} else {
			unsigned char data[16];
			for (int i=0; i<n; ++i)
				data[i] = inb (RDR(port));
			CheckReceivedData (data, n, c->board->num, c->num);
		}

		if (rbytecount >= GIGA) {
			rgigacount += rbytecount >> GIGASHIFT;
			rbytecount &= GIGAMASK;
		}
		/* End of interrupt. */
		outb (REOIR(port), 0);
		break;
	case LIV_TXDATA:		// transmit interrupt
		unsigned char tisr = inb (TISR(port));
		if (c->board->type == B_SIGMA_2X)	// turn LED off
			outb (BCR0(c->board->port),
				c->board->bcr0 & ~BCR02X_LED);

		CheckTransmitErrors (c, tisr);

		errchan_t *e = &errchan[c->board->num][c->num];
		unsigned char teoir = 0;
		n = inb (TFTC(port));
		for (int i=0; i<n; ++i) {
			outb (TDR(port), TestPattern[e->sendoff++]);
			++bytecount;
			if (c->mode != M_ASYNC && ! e->sendoff) {
				// End of frame.
				++framecount;
				teoir |= TEOI_EOFR;
				break;
			}
		}
		if (n && c->board->type == B_SIGMA_2X)	// turn LED on
			outb (BCR0(c->board->port),
				c->board->bcr0 | BCR02X_LED);

		if (n && bytecount >= GIGA) {
			gigacount += bytecount >> GIGASHIFT;
			bytecount &= GIGAMASK;
		}

		/* End of interrupt, set end of frame for synchronous modes. */
		outb (TEOIR(port), teoir);
		break;
	}
}

static void HandleReceiveDMATimeout (cx_chan_t *c)
{
	unsigned short port = c->chip->port;
	unsigned long rcbadr = (unsigned short) inw (RCBADRL(port)) |
		(long) inw (RCBADRU(port)) << 16;

	unsigned char *buf;
	unsigned long phys;
	unsigned short cnt_port, sts_port;
	if (rcbadr >= c->brphys && rcbadr < c->brphys+IOSZ) {
		buf = c->brbuf;
		phys = c->brphys;
		cnt_port = BRBCNT(port);
		sts_port = BRBSTS(port);
	} else if (rcbadr >= c->arphys && rcbadr < c->arphys+IOSZ) {
		buf = c->arbuf;
		phys = c->arphys;
		cnt_port = ARBCNT(port);
		sts_port = ARBSTS(port);
	} else
		Message ("Invalid buffer address");

	if (TestPatternDisabled)
		rbytecount += rcbadr - phys;
	else
		CheckReceivedData (buf, rcbadr-phys, c->board->num, c->num);

	// Restart receiver.
	if (! TestPatternDisabled)
		memset (buf, 0, IOSZ);
	outw (cnt_port, IOSZ);
	outb (sts_port, BSTS_OWN24);
}

static void HandleReceiveDMAData (cx_chan_t *c)
{
	unsigned short port = c->chip->port;

	unsigned char *buf1, *buf2;
	unsigned short cnt_port1, sts_port1;
	unsigned short cnt_port2, sts_port2;

	if (inb (DMABSTS(port)) & DMABSTS_NRBUF) {
		buf1      = c->brbuf;	  buf2      = c->arbuf;
		cnt_port1 = BRBCNT(port); cnt_port2 = ARBCNT(port);
		sts_port1 = BRBSTS(port); sts_port2 = ARBSTS(port);
	} else {
		buf1      = c->arbuf;	  buf2      = c->brbuf;
		cnt_port1 = ARBCNT(port); cnt_port2 = BRBCNT(port);
		sts_port1 = ARBSTS(port); sts_port2 = BRBSTS(port);
	}

	// Restart receiver.
	if (! (inb (sts_port1) & BSTS_OWN24)) {
		if (! TestPatternDisabled)
			memset (buf1, 0, IOSZ);
		outw (cnt_port1, IOSZ);
		outb (sts_port1, BSTS_OWN24);
	}
	if (! (inb (sts_port2) & BSTS_OWN24)) {
		if (! TestPatternDisabled)
			memset (buf2, 0, IOSZ);
		outw (cnt_port2, IOSZ);
		outb (sts_port2, BSTS_OWN24);
	}
}

static void HandleTransmitDMAData (cx_chan_t *c)
{
	unsigned short port = c->chip->port;

	unsigned short cnt_port1, sts_port1;
	unsigned short cnt_port2, sts_port2;
	if (inb (DMABSTS(port)) & DMABSTS_NTBUF) {
		cnt_port1 = BTBCNT(port); cnt_port2 = ATBCNT(port);
		sts_port1 = BTBSTS(port); sts_port2 = ATBSTS(port);
	} else {
		cnt_port1 = ATBCNT(port); cnt_port2 = BTBCNT(port);
		sts_port1 = ATBSTS(port); sts_port2 = BTBSTS(port);
	}

	// Fill buffers with data and restart transmitting them.
	if (! (inb (sts_port1) & BSTS_OWN24)) {
		outw (cnt_port1, IOSZ);
		outb (sts_port1, BSTS_EOFR | BSTS_INTR | BSTS_OWN24);
	} else if (! (inb (sts_port2) & BSTS_OWN24)) {
		outw (cnt_port2, IOSZ);
		outb (sts_port2, BSTS_EOFR | BSTS_INTR | BSTS_OWN24);
	} else
		return;

	bytecount += IOSZ;
	if (c->mode != M_ASYNC)
		++framecount;
	if (c->board->type == B_SIGMA_2X)	// turn LED on
		outb (BCR0(c->board->port), c->board->bcr0 | BCR02X_LED);
}

static void DMAInterrupt (cx_chan_t *c, unsigned char livr)
{
	unsigned short port = c->chip->port;

	switch (livr & 3) {
	case LIV_MODEM:			// cannot happen
		Message ("Unexpected modem interrupt, misr=%xh", inb(MISR(port)));
		outb (MEOIR(port), 0);
		break;
	case LIV_EXCEP:			// receive exception
	case LIV_RXDATA:		// receive interrupt
		unsigned short risr = inw (RISR(port));
		CheckReceiveErrors (c, risr, c->mode);

		// Increment frame counter.
		if (c->mode==M_HDLC && (risr & RISH_EOFR))
			++rframecount;

		// Handle received data.
		unsigned char reoi = 0;
		if (c->mode==M_ASYNC && (risr & RISA_TIMEOUT)) {
			HandleReceiveDMATimeout (c);
			reoi |= REOI_TERMBUFF;
		} else if (risr & RIS_EOBUF) {
			unsigned short len = (risr & RIS_BB) ?
				inw(BRBCNT(port)) : inw(ARBCNT(port));

			if (TestPatternDisabled)
				rbytecount += len;
			else
				CheckReceivedData ((risr & RIS_BB) ?
					c->brbuf : c->arbuf, len,
					c->board->num, c->num);

			HandleReceiveDMAData (c);

			// ����������� ������� �������� ������ �� �������
			// ������.  � ���� ������ ��� ������ �� ����������
			// ��������������� ��� ��������� ���������
			// � ����������� �������.
			errchan[c->board->num][c->num].offset &= ~255;
		}
		if (rbytecount >= GIGA) {
			rgigacount += rbytecount >> GIGASHIFT;
			rbytecount &= GIGAMASK;
		}
		outb (REOIR(port), reoi);
		break;
	case LIV_TXDATA:		// transmit interrupt
		unsigned char tisr = inb (TISR(port));

		if (c->board->type == B_SIGMA_2X)	// turn LED off
			outb (BCR0(c->board->port),
				c->board->bcr0 & ~BCR02X_LED);

		CheckTransmitErrors (c, tisr);

		// Fill buffers with data.
		if (tisr & (TIS_EOBUF | TIS_TXEMPTY | TIS_TXDATA))
			HandleTransmitDMAData (c);

		if (bytecount >= GIGA) {
			gigacount += bytecount >> GIGASHIFT;
			bytecount &= GIGAMASK;
		}

		// End of interrupt.
		outb (TEOIR(port), 0);
		break;
	}
}

static void InterruptHandler (cx_board_t *b)
{
	int loopcount = 0;
	unsigned short bsr;
	// Cursor csav (V);

	++intrcount;
	while (! (bsr = inw (BSR(b->port)) & BSR_NOINTR)) {
		// Enter the interrupt context, using IACK bus cycle.
		// Read the local interrupt vector register. */
		unsigned char livr = inb (IACK(b->port, BRD_INTR_LEVEL));
		cx_chan_t *c = b->chan + (livr>>2 & 0xf);

		if (c->type == T_NONE)
			Message ("Invalid channel %d, board %d", c->num, b->num);
		else if (use_dma)
			DMAInterrupt (c, livr);
		else
			PortInterrupt (c, livr);

		// Stop the test if the interrupt rate is too high,
		// and we could never leave the interrupt handler.
		if (++loopcount > 1000)
			giveup = 1;

		// Stop the transmitter if any key pressed.
		if (giveup) {
			cx_setup_board (b, 0, 0, 0);
			break;
		}
	}
	if (loopcount == 0)
		Message ("Stray interrupt, bsr at %xh => %xh", b->port, bsr);

	// Aknowledge the end of interrupt.
	// V.SetCursor (csav);
	irq_eoi (b->irq);
}

static void interrupt intr0 (void) { InterruptHandler (board+0); }
static void interrupt intr1 (void) { InterruptHandler (board+1); }
static void interrupt intr2 (void) { InterruptHandler (board+2); }
static void interrupt (*intrtab []) () = { intr0, intr1, intr2 };

static void Test (cx_board_t *b0, cx_chan_t *c0,
	int transmit, int receive, int dma, int intloop)
{
	if (c0)
		b0 = c0->board;

	char *title;
	if (receive && transmit) title = Msg (" Loop ",     " ������� ");
	else if (transmit)       title = Msg (" Transmit ", " �������� ");
	else		         title = Msg (" Receive ",  " ����� ");

	if (! nbrd) {
		V.Error (ErrorColor, TextColor, title,
			Msg (" Ok ", " ������ "),
			Msg ("No adapters configured", "�������� �� �����������"));
		return;
	}

	char *name;
	if (!dma && transmit && !receive)
		name = Msg ("Transmit test via port", "���� �������� ����� ����");
	else if (dma && transmit && !receive)
		name = Msg ("Transmit test via DMA", "���� �������� ����� ���");
	else if (!dma && !transmit && receive)
		name = Msg ("Receive test via port", "���� ������ ����� ����");
	else if (dma && !transmit && receive)
		name = Msg ("Receive test via DMA", "���� ������ ����� ���");
	else if (!dma && transmit && receive && intloop)
		name = Msg ("Internal loopback test via port", "���������� ���� ����� ����");
	else if (!dma && transmit && receive && !intloop)
		name = Msg ("External loopback test via port", "������� ���� � ��������� ����� ����");
	else if (dma && transmit && receive && intloop)
		name = Msg ("Internal loopback test via DMA", "���������� ���� ����� ���");
	else if (dma && transmit && receive && !intloop)
		name = Msg ("External loopback test via DMA", "������� ���� � ��������� ����� ���");
	else
		return;

	char buf[80];
	cx_board_t *b;
	int nc;
	if (c0)
		nc = 1;
	else if (b0)
		nc = b0->nuniv + b0->nsync + b0->nasync;
	else for (nc=0, b=board; b<board+nbrd; ++b)
		nc += b->nuniv + b->nsync + b->nasync;
	sprintf (buf, "%s: %d %s", name, nc, Msg ("channel", "�����"));
	if (nc > 1)
		strcat (buf, nc < 5 ? Msg ("s", "�") : Msg ("s", "��"));
	giveup = 0;
	InitLog (b0, c0, buf);
	DisplaySetup (transmit, receive, title, buf);

	void interrupt (*old_handler[NBRD]) (void);
	int vect[NBRD];
	inside_test = 1;
	use_dma = dma;
	for (b=board; b<board+nbrd; ++b) {
		if (b0 && b != b0)
			continue;

		// Disable interrupts.
		disable ();

		// Initialize the adapter.
		cx_setup_board (b, 0, 0, 0);

		// Set new interrupt vector.
		vect[b->num] = b->irq + 8;
		if (b->irq >= 8)
			vect[b->num] += 0x60;
		old_handler[b->num] = getvect (vect[b->num]);
		setvect (vect[b->num], intrtab[b->num]);

		// Unmask an interrupt.
		irq_enable (b->irq);
		enable ();

		for (cx_chan_t *c=b->chan; c<b->chan+NCHAN; ++c) {
			if (c->type == T_NONE || (c0 && c != c0))
				continue;
			TestChan (c, transmit, receive, dma, intloop);
		}
	}
	if (c0 && ! intloop) {
		int dsrx = 13, cdx = 36, ctsx = 58;
		V.Put (0, 0, Msg (" Signals: ", " �������: "), InverseTextColor);
		V.ClearLine (InverseTextColor);
		V.Put (0, dsrx, "Data Set Ready: ", InverseTextColor);
		V.Put (0, cdx,  "Carrier Detect: ", InverseTextColor);
		V.Put (0, ctsx, " Clear To Send: ", InverseTextColor);
	}

	// Disable hot keys.
	V.DelHotKey (meta ('J'));
	V.DelHotKey (alt ('x'));
	V.DelHotKey (alt ('q'));
	V.DelHotKey (cntrl ('Q'));

	// The main test loop.
	while (! giveup) {
		if (kbhit ()) {
			int k = V.GetKey ();
			if (k != alt ('p')) {
				V.UngetKey (k);
				break;
			}
			PrintScreen (Msg ("diag.scr", "diag-r.scr"));
		}
		DisplayRefresh (transmit, receive);
		if (c0 && ! intloop)
			TestModemSignals (c0);
		FlushLog ();
	}

	// Enable hot keys.
	V.AddHotKey (meta ('J'), (void(*)(int)) PromptQuit);
	V.AddHotKey (alt ('x'), (void(*)(int)) PromptQuit);
	V.AddHotKey (alt ('q'), (void(*)(int)) PromptQuit);
	V.AddHotKey (cntrl ('Q'), (void(*)(int)) PromptQuit);
	if (giveup)
		V.PopupString (Msg (" Abort ", " ������� "),
			Msg ("Data rate is too high,\nadapter overloaded\n",
			     "������� ������� ���� ������,\n������� ����������\n"),
			Msg (" OK ", " ��� "), ErrorColor, TextColor);
	giveup = 1;
	DisplayRestore ();
	CloseLog ();

	Flash reset (&V, Msg (" Reset ", " ����� "),
		Msg ("Reset...", "�����..."), InverseLightTextColor);

	for (b=board; b<board+nbrd; ++b) {
		if (b0 && b != b0)
			continue;
		disable ();

		for (cx_chan_t *c=b->chan; c<b->chan+NCHAN; ++c) {
			if (c->type == T_NONE || (c0 && c != c0))
				continue;

			// Reset the channel.
			outb (CAR(c->chip->port), c->num & 3);
			if (c->mode != M_ASYNC)
				outb (STCR(c->chip->port),
					STC_ABORTTX | STC_SNDSPC);
			cx_cmd (c->chip->port, CCR_CLRCH);

			/* Clear DTR and RTS. */
			cx_chan_dtr (c, 0);
			cx_chan_rts (c, 0);
		}

		// Mask an interrupt.
		irq_disable (b->irq);
		irq_eoi (b->irq);

		// Disable DMA channel.
		cx_disable_dma (b);

		// Turn LED off.
		if (b->type == B_SIGMA_2X)
			outb (BCR0(b->port), b->bcr0 & ~BCR02X_LED);
		enable ();

		// Restore old interrupt vector.
		setvect (vect[b->num], old_handler[b->num]);
	}
	inside_test = 0;
}

static void TestChan (cx_chan_t *c, int transmit, int receive,
	int dma, int intloop)
{
	unsigned short port = c->chip->port;
	int command = 0;
	int mode = 0;
	int ier = 0;
	if (receive) {
		command |= CCR_ENRX;
		ier |= IER_RXD;
		if (dma) {
			mode |= CMR_RXDMA;
			ier |= IER_RET;
		}
	}
	if (transmit) {
		command |= CCR_ENTX;
		ier |= IER_TXD | IER_TXMPTY;
		if (dma)
			mode |= CMR_TXDMA;
	}

	memset (c->arbuf, 0, IOSZ);
	memset (c->brbuf, 0, IOSZ);
	memcpy (c->atbuf, TestPattern, IOSZ);
	memcpy (c->btbuf, TestPattern, IOSZ);

	// Disable interrupts.
	disable ();

	// Set current channel number
	outb (CAR(port), c->num & 3);

	// Set loopback mode
	if (intloop) {
		// Set up receiver clock values
		int clock, period;
		cx_clock (c->chip->oscfreq, c->rxbaud, &clock, &period);
		c->opt.rcor.clk = clock;
		outb (RCOR(port), BYTE c->opt.rcor);
		outb (RBPR(port), period);

		cx_tcor_t tcor = c->opt.tcor;
		cx_clock (c->chip->oscfreq, c->txbaud, &clock, &period);
		tcor.clk = clock;
		tcor.llm = 1;
		tcor.ext1x = 0;
		outb (TCOR(port), BYTE tcor);
		outb (TBPR(port), period);

		// Disable CTS and DSR check
		switch (c->mode) {
		case M_ASYNC:
			outb (COR2(port), (BYTE c->aopt.cor2) & ~3);
			break;
		case M_HDLC:
			outb (COR2(port), (BYTE c->hopt.cor2) & ~3);
			break;
		}
	}
	// Set channel mode
	switch (c->mode) {
	case M_ASYNC:  outb (CMR(port), CMR_ASYNC | mode);  break;
	case M_HDLC:   outb (CMR(port), CMR_HDLC | mode);   break;
	}

	// Clear and initialize channel, enable receiver and/or transmitter
	cx_cmd (port, CCR_INITCH | command);
	cx_cmd (port, CCR_INITCH | command);	// Rev. H bug?

	// Start receiver.
	outw (ARBCNT(port), IOSZ);
	outw (BRBCNT(port), IOSZ);
	outw (ARBSTS(port), BSTS_OWN24);
	outw (BRBSTS(port), BSTS_OWN24);

	// Raise DTR and RTS.
	cx_chan_dtr (c, 1);
	cx_chan_rts (c, 1);

	// Enable interrupts
	outb (IER(port), ier);
	enable ();
}

static void TestModemSignals (cx_chan_t *c)
{
	// Check CTS, DSR, CD.
	int dsrx = 13, cdx = 36, ctsx = 58;
	int cts, dsr, cd;

	disable ();
	outb (CAR(c->chip->port), c->num & 3);
	cts = inb (MSVR(c->chip->port)) & MSV_CTS;
	dsr = cx_chan_dsr (c);
	cd = cx_chan_cd (c);
	if (c->board->type == B_SIGMA_2X ||
	    c->board->type == B_SIGMA_800 || c->mode == M_ASYNC) {
		V.Move (0, dsrx+15);
		if (dsr) V.Put (" OK  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
		V.Move (0, cdx+15);
		if (cd)  V.Put (" OK  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
		V.Move (0, ctsx+15);
		if (cts) V.Put (" ON  ", InverseTextColor);
		else     V.Put (" OFF ", InverseTextColor);
	} else if ((c->num & 7) >= 4 || (c->num && c->type == T_UNIV_RS232)) {
		V.Put (0, dsrx+15, " N/A ", InverseTextColor);
		V.Put (0, cdx+15,  " N/A ", InverseTextColor);
		V.Move (0, ctsx+15);
		if (cts) V.Put (" ON  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
	} else {
		V.Move (0, dsrx+15);
		if (dsr) V.Put (" OK  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
		V.Move (0, cdx+15);
		if (cd)  V.Put (" OK  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
		V.Move (0, ctsx+15);
		if (cts) V.Put (" ON  ", InverseTextColor);
		else     V.Put (" Err ", ErrorColor);
	}
	enable ();
}

void GeneralTransmitIntr () { Test (0, 0, 1, 0, 0, 0); }
void GeneralReceiveIntr ()  { Test (0, 0, 0, 1, 0, 0); }
void GeneralIntloopIntr ()  { Test (0, 0, 1, 1, 0, 1); }
void GeneralExtloopIntr ()  { Test (0, 0, 1, 1, 0, 0); }
void GeneralTransmitDMA ()  { Test (0, 0, 1, 0, 1, 0); }
void GeneralReceiveDMA ()   { Test (0, 0, 0, 1, 1, 0); }
void GeneralIntloopDMA ()   { Test (0, 0, 1, 1, 1, 1); }
void GeneralExtloopDMA ()   { Test (0, 0, 1, 1, 1, 0); }

void AdapterTransmitIntr () { Test (bp, 0, 1, 0, 0, 0); }
void AdapterReceiveIntr ()  { Test (bp, 0, 0, 1, 0, 0); }
void AdapterIntloopIntr ()  { Test (bp, 0, 1, 1, 0, 1); }
void AdapterExtloopIntr ()  { Test (bp, 0, 1, 1, 0, 0); }
void AdapterTransmitDMA ()  { Test (bp, 0, 1, 0, 1, 0); }
void AdapterReceiveDMA ()   { Test (bp, 0, 0, 1, 1, 0); }
void AdapterIntloopDMA ()   { Test (bp, 0, 1, 1, 1, 1); }
void AdapterExtloopDMA ()   { Test (bp, 0, 1, 1, 1, 0); }

void ChannelTransmitIntr () { Test (0, bp->chan+cchan, 1, 0, 0, 0); }
void ChannelReceiveIntr ()  { Test (0, bp->chan+cchan, 0, 1, 0, 0); }
void ChannelIntloopIntr ()  { Test (0, bp->chan+cchan, 1, 1, 0, 1); }
void ChannelExtloopIntr ()  { Test (0, bp->chan+cchan, 1, 1, 0, 0); }
void ChannelTransmitDMA ()  { Test (0, bp->chan+cchan, 1, 0, 1, 0); }
void ChannelReceiveDMA ()   { Test (0, bp->chan+cchan, 0, 1, 1, 0); }
void ChannelIntloopDMA ()   { Test (0, bp->chan+cchan, 1, 1, 1, 1); }
void ChannelExtloopDMA ()   { Test (0, bp->chan+cchan, 1, 1, 1, 0); }
