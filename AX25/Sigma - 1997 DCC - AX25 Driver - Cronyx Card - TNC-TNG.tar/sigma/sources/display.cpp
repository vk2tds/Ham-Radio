//
// Diagnose utility for Cronyx-Tau adapter:
// Single channel test routines.
//
// Copyright (C) 1995 Cronyx Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 2.1, Wed Oct  4 21:37:55 MSK 1995
//
#include "common.h"

#define NOERROR		(~0L)
#define GIGA		010000000000L
#define GIGASHIFT	30
#define GIGAMASK	07777777777L

unsigned long bytecount, rbytecount;	// transmitted, received bytes
unsigned long framecount, rframecount;	// transmitted, received frames
unsigned long gigacount, rgigacount;    // transmitted, received gigabytes
unsigned long intrcount;		// number of interrupts
struct timeb time0;			// test start time
struct timeb time1;			// test current time
unsigned long delta_t;			// test running time in milliseconds
unsigned long display_cnt;		// displays count
unsigned long delta_t0;			// base count
unsigned long delta_t_old, display_cnt_old;	// temporary count value
int filter_value;			// mean filter value

errcnt_t errcnt;			// generic errors
errchan_t errchan[NBRD][NCHAN];		// errors per channel

extern unsigned long transmit_displays_per_10_sec; // transmit display rate
extern unsigned long loop_displays_per_10_sec; // loopback display rate

static char *cvt (unsigned long v)
{
	static char buf[32];
	memset (buf+13, ' ', 12);

	char *p = buf + 12;
	*p   = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '\'';
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '\'';
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '0' + v % 10; if (! (v /= 10)) goto done;
	*--p = '\'';
	*--p = '0' + v % 10;
done:	p[13] = 0;
	return (p);
}

static Box *DisplayBox;
static int DisplayRow, DisplayCol, DisplayWid;

static void PrintTime (int row, int col, unsigned long t)
{
	V.Move (row, col);
	V.Print (InverseTextColor, "%02d", t / 60 / 60);
	V.Put (':', InverseDimTextColor);
	V.Print (InverseTextColor, "%02d", t / 60 % 60);
	V.Put (':', InverseDimTextColor);
	V.Print (InverseTextColor, "%02d", t % 60);
}

void DisplaySetup (int sendflag, int recvflag, char *title, char *head)
{
	int h = 2 + 9 + 2 + 2 + 3;
	int w = 65;
	int len = strlen (head);
	if (len > w)
		w = len;
	len = strlen (title);
	if (len > w)
		w = len;
	w += 4;
	int r = V.Lines/2 - h/2 - 1;
	int c = V.Columns/2 - w/2;
	DisplayWid = w;
	DisplayRow = r;
	DisplayCol = c;

	DisplayBox = new Box (V, r, c, h+1, w+1);			// save box
	V.Clear (r, c, h, w, InverseLightTextColor, ' ');
	V.DrawFrame (r, c, h, w, InverseLightTextColor);
	V.Put (r, c + (w-strlen(title)) / 2, title, InverseLightTextColor);	// head
	V.Put (r+1, c + (w-strlen(head)) / 2, head, InverseLightTextColor);

	// Draw shadow.
	for (int i=0; i<w; ++i)
		V.AttrLow (r+h, c+i+1);
	for (i=0; i<h-1; ++i)
		V.AttrLow (r+i+1, c+w);

	int c1 = c+1 + (w/2-1)/2 + 3;
	int c2 = c1 + w/2;

	if (recvflag) {
		V.Put (r+ 3, c2-1-12, Msg ("     Errors:",
					   "     ������:"), InverseDimTextColor);
		V.Put (r+ 8, c1-1-15, Msg ("Received bytes:",
					   "  ������� ����:"), InverseDimTextColor);
		V.Put (r+ 9, c1-1-11, Msg ("per second:",
					   " � �������:"), InverseDimTextColor);
		V.Put (r+10, c1-1-7,  Msg ("frames:",
					   "������:"), InverseDimTextColor);
		V.Put (r+11, c1-1-10, Msg ("gigabytes:",
					   " ��������:"), InverseDimTextColor);
		V.Put (r+ 4, c2-1-15, Msg ("          data:",
					   "        ������:"), InverseDimTextColor);
		V.Put (r+ 5, c2-1-15, Msg ("       overrun:",
					   "  ������������:"), InverseDimTextColor);
		V.Put (r+ 6, c2-1-15, Msg ("        parity:",
					   "      ��������:"), InverseDimTextColor);
		V.Put (r+ 7, c2-1-15, Msg ("         frame:",
					   "        ������:"), InverseDimTextColor);
		V.Put (r+ 8, c2-1-15, Msg ("           crc:",
					   "   �����.�����:"), InverseDimTextColor);
		V.Put (r+ 9, c2-1-15, Msg ("   receive bus:",
					   "���� ���������:"), InverseDimTextColor);
		V.Put (r+10, c1, '-', InverseTextColor);
		V.Put (r+11, c1, '-', InverseTextColor);
		V.Put (r+ 4, c2, '-', InverseTextColor);
		V.Put (r+ 5, c2, '-', InverseTextColor);
		V.Put (r+ 6, c2, '-', InverseTextColor);
		V.Put (r+ 7, c2, '-', InverseTextColor);
		V.Put (r+ 8, c2, '-', InverseTextColor);
		V.Put (r+ 9, c2, '-', InverseTextColor);
	} else
		V.Put (r+ 9, c2-1-12, Msg ("     Errors:",
					   "     ������:"), InverseDimTextColor);
	if (sendflag) {
		V.Put (r+ 3, c1-1-18, Msg ("Transmitted bytes:",
					   "    �������� ����:"), InverseDimTextColor);
		V.Put (r+ 4, c1-1-11, Msg ("per second:",
					   " � �������:"), InverseDimTextColor);
		V.Put (r+ 5, c1-1-7,  Msg ("frames:",
					   "������:"), InverseDimTextColor);
		V.Put (r+ 6, c1-1-10, Msg ("gigabytes:",
					   " ��������:"), InverseDimTextColor);
		V.Put (r+10, c2-1-17, Msg ("        send bus:",
					   "���� �����������:"), InverseDimTextColor);
		V.Put (r+11, c2-1-17, Msg ("        underrun:",
					   "     �����������:"), InverseDimTextColor);
		V.Put (r+ 5, c1, '-', InverseTextColor);
		V.Put (r+ 6, c1, '-', InverseTextColor);
		V.Put (r+10, c2, '-', InverseTextColor);
		V.Put (r+11, c2, '-', InverseTextColor);
	}
	V.Put (r+13, c1-1-11, Msg ("Interrupts:",
				   "����������:"), InverseDimTextColor);
	V.Put (r+14, c1-1-11, Msg ("per second:",
				   " � �������:"), InverseDimTextColor);
	V.Put (r+14, c2-1-12, Msg ("  Test time:",
				   "����� �����:"), InverseDimTextColor);

	bytecount = rbytecount = 0;
	framecount = rframecount = 0;
	gigacount = rgigacount = 0;
	intrcount = 0;
	memset (&errcnt, 0, sizeof (errcnt));
	memset (errchan, 0, sizeof (errchan));
	errcnt.bytenum = NOERROR;
	delta_t = 0;
	display_cnt = display_cnt_old = 0;
	delta_t0 = delta_t_old = 0;
	filter_value = 0;
	ftime (&time0);
	time1 = time0;
}

static int filter (int v)
{
	if (v < 0) v = 0;
	filter_value = (v + 19L * filter_value) / 20;
	return (filter_value);
}

void DisplayRefresh (int sendflag, int recvflag)
{
	int r = DisplayRow;
	int c = DisplayCol;
	int w = DisplayWid;
	int c1 = c+1 + (w/2-1)/2 + 3;
	int c2 = c1 + w/2;

	ftime (&time1);
	delta_t = (time1.time - time0.time) * 1000 +
		(time1.millitm - time0.millitm);

	if (sendflag) {
		// Bytes.
		V.Put (r+3, c1, cvt (bytecount), InverseTextColor);
		if (delta_t)
			V.Put (r+4, c1, cvt ((long) (((float) gigacount *
				GIGA + bytecount) * 1000 / delta_t)),
				InverseTextColor);
		else
			V.Put (r+4, c1, '0', InverseTextColor);

		// Gigabytes.
		if (gigacount)
			V.Put (r+6, c1, cvt (gigacount), InverseTextColor);

		// Displays.
		if (framecount)
			V.Put (r+5, c1, cvt (framecount), InverseTextColor);

		if (errcnt.sendbus)
			V.Put (r+10, c2, cvt (errcnt.sendbus), InverseTextColor);
		if (errcnt.underrun)
			V.Put (r+11, c2, cvt (errcnt.underrun), InverseTextColor);

		unsigned long dp10s = recvflag ? loop_displays_per_10_sec :
			transmit_displays_per_10_sec;
		if (delta_t && dp10s) {
			// Display the rate from t0 to now.
			++display_cnt;
			int v = filter ((int) (1e4 - 1e8 * display_cnt /
				(delta_t - delta_t0) / dp10s));
			V.Print (r+13, c2, InverseTextColor, "%d.%02d",
				v/100, v%100);
			V.Put ("% ", InverseDimTextColor);

			// Every 20 seconds shift the count window.
			// Use t_old as the new value of t0.
			if (delta_t > delta_t_old + 20000) {
				delta_t0 = delta_t_old;
				delta_t_old = delta_t;
				display_cnt -= display_cnt_old;
				display_cnt_old = display_cnt;
			}
		}
	}
	if (recvflag) {
		// Bytes.
		V.Put (r+8, c1, cvt (rbytecount), InverseTextColor);
		if (delta_t)
			V.Put (r+9, c1, cvt ((long) (((float) rgigacount *
				GIGA + rbytecount) * 1000 / delta_t)),
				InverseTextColor);
		else
			V.Put (r+9, c1, '0', InverseTextColor);

		// Gigabytes.
		if (rgigacount)
			V.Put (r+11, c1, cvt (rgigacount), InverseTextColor);

		// Displays.
		if (rframecount)
			V.Put (r+10, c1, cvt (rframecount), InverseTextColor);

		if (errcnt.data)
			V.Put (r+ 4, c2, cvt (errcnt.data), InverseTextColor);
		if (errcnt.overrun)
			V.Put (r+ 5, c2, cvt (errcnt.overrun), InverseTextColor);
		if (errcnt.parity)
			V.Put (r+ 6, c2, cvt (errcnt.parity), InverseTextColor);
		if (errcnt.frame)
			V.Put (r+ 7, c2, cvt (errcnt.frame), InverseTextColor);
		if (errcnt.crc)
			V.Put (r+ 8, c2, cvt (errcnt.crc), InverseTextColor);
		if (errcnt.recvbus)
			V.Put (r+ 9, c2, cvt (errcnt.recvbus), InverseTextColor);
	}
	V.Put (r+13, c1, cvt (intrcount), InverseTextColor);
	V.Put (r+14, c1, cvt (delta_t ? intrcount * 1000.0 / delta_t : 0L),
		InverseTextColor);
	PrintTime (r+14, c2, delta_t/1000);

	if (errcnt.bytenum != NOERROR) {
		char *errmsg = Msg ("Adapter %d channel %d byte #%ld received %xh should be %xh   ",
				    "������� %d ����� %d ���� #%ld ������� %xh ������ %xh   ");

		V.Print (r+16, c+(w-strlen(errmsg)-3)/2, InverseLightTextColor,
			errmsg, errcnt.board, errcnt.channel,
			errcnt.bytenum, errcnt.recvbyte, errcnt.sentbyte);
		errcnt.bytenum = NOERROR;
	}

	V.HideCursor ();
	V.Sync ();
}

void DisplayRestore ()
{
	if (DisplayBox) {
		V.Put (*DisplayBox);
		delete DisplayBox;
	}
	DisplayBox = 0;
}
