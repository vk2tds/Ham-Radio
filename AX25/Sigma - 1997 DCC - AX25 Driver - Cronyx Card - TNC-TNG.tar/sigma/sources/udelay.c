/*
 * General microsecond delay routine.
 *
 * Copyright (C) 1995 Cronyx Ltd.
 * Author: Serge Vakulenko, <vak@cronyx.ru>
 *
 * This software is distributed with NO WARRANTIES, not even the implied
 * warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Authors grant any other persons or organisations permission to use
 * or modify this software as long as this message is kept with the software,
 * all derivative works or modified versions.
 *
 * Version 1.0, Fri Oct  7 19:34:06 MSD 1994
 */
#ifdef unix

#include <unistd.h>

void udelay (unsigned long usec)
{
	usleep (usec);
}

void udelay_init ()
{
}

#else

#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include "udelay.h"

unsigned short udelay_scale;

static void fastdelay (register unsigned short d)
{
	while (--d > 0)
		inportb (0x64);		/* keyboard status port */
}

void udelay (unsigned long usec)
{
	long count;
	unsigned short u, m;

	for (; usec>=1000000L; usec-=1000000L)
		sleep (1);

	count = (udelay_scale * usec) >> 6;
	u = count;
	m = count >> 16;
	while (m--)
		fastdelay (0);
	if (u)
		fastdelay (u);
}

void udelay_init ()
{
	long t0 = biostime (0, 0L);
	long dt = 0;
	long u;
	for (u=1; dt<18; u+=u) {
		long i = u;
		while (i--)
			fastdelay (0);
		dt = biostime (0, 0L) - t0;
	}
	udelay_scale = (u << 22) / dt / 55000;
}

#ifdef UDELAY_TEST
long udelay_calibr (long usec)
{
	long t1, t2;

	t1 = biostime (0, 0L);
	udelay (usec);
	t2 = biostime (0, 0L);
	return ((t2 - t1) * 55000);
}

long udelay_test (long usec)
{
	long t1, t2;
	unsigned short x = usec / 1000;
	usec = 1000;

	t1 = biostime (0, 0L);
	while (x--)
		udelay (usec);
	t2 = biostime (0, 0L);
	return ((t2 - t1) * 55000);
}

int main ()
{
	udelay_init ();
	printf ("delay = %ld/64 * usec\n", udelay_scale);

	printf ("udelay (1000000) = %ld\n", udelay_calibr (1000000L));
	printf ("udelay (2000000) = %ld\n", udelay_calibr (2000000L));
	printf ("udelay (4000000) = %ld\n", udelay_calibr (4000000L));
	printf ("udelayt(1000000) = %ld\n", udelay_test (1000000L));
	printf ("udelayt(2000000) = %ld\n", udelay_test (2000000L));
	printf ("udelayt(4000000) = %ld\n", udelay_test (4000000L));
	return (0);
}
#endif /* UDELAY_TEST */

#endif /* unix */
