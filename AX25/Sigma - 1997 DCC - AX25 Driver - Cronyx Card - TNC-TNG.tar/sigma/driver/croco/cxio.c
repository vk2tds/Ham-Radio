#include <sys/ioctl.h>

#ifdef HAVE_SIGMA
#   include <csigma.h>
#   undef NCHAN
#endif
#ifdef HAVE_TAU
#   include <ctau.h>
#   undef NCHAN
#endif

#ifdef HAVE_SIGMA
int cxget (int fd, cx_options_t *arg)
{
	return ioctl (fd, CXIOCGETMODE, arg);
}

int cxset (int fd, cx_options_t *arg)
{
	return ioctl (fd, CXIOCSETMODE, arg);
}
#endif

#ifdef HAVE_TAU
int ctget (int fd, ct_options_t *arg)
{
	return ioctl (fd, CTIOCGETMODE, arg);
}

int ctset (int fd, ct_options_t *arg)
{
	return ioctl (fd, CTIOCSETMODE, arg);
}
#endif
