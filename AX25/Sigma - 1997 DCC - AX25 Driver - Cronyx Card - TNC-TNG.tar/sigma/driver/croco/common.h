//
// Declarations of common variables for CCFG utility.
//
// Copyright (C) 1996 Cronyx Engineering Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.0, Fri Nov  8 21:14:45 MSK 1996
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include "Screen.h"
#include "Popup.h"

#ifdef HAVE_SIGMA
#   include <csigma.h>
#   undef NCHAN
#else
#   define cx_soft_opt_t ct_soft_opt_t
    typedef int cx_options_t;
#endif
#ifdef HAVE_TAU
#   include <ctau.h>
#   undef NCHAN
#else
    typedef int ct_options_t;
#endif

#define Msg(eng,rus)	(LanguageEnglish ? (eng) : (rus))

typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned long  ulong;

typedef enum { SIGMA, TAU } chan_t;

union options_t {
	cx_options_t s;                 // Sigma channel options
	ct_options_t t;                 // Tau channel options
};

typedef struct {
	chan_t type;                    // channel type, Tau or Sigma
	union options_t o;              // channel options
	struct termios a;               // async mode options
} channel_t;

#define MAXCHAN (48 + 6)                // max number of channels

extern char *InitFileName;              // init file
extern channel_t chan [MAXCHAN];        // the table of channels
extern int nchan;                       // the number of channels

extern Screen V;
extern void Quit (void);
extern void PromptQuit (void);

extern int TextColor;
extern int LightTextColor;
extern int InverseTextColor;
extern int InverseLightTextColor;
extern int DimTextColor;
extern int InverseDimTextColor;
extern int ErrorColor;
extern int FrameColor;
extern unsigned char DialogPalette[];

extern int LanguageEnglish;

extern "C" {
	void iflist (void (*) (char*));
	extern int cxget (int fd, cx_options_t *arg);
	extern int cxset (int fd, cx_options_t *arg);
	extern int ctget (int fd, ct_options_t *arg);
	extern int ctset (int fd, ct_options_t *arg);
};
extern int getstr (FILE *fd, char *buf);
extern channel_t *opt_to_chan (options_t *o);
extern void ChanInit (void);
extern void SaveConfig (void);
extern void ChanDialog (void);
extern int SigmaDialog (cx_options_t *o);
extern int TauDialog (ct_options_t *o);
extern void ProtoDialog (cx_soft_opt_t *o, chan_t type, int cnum);
extern int AsyncDialog (channel_t *c);
extern int SigmaSetup (cx_options_t *o);
extern int TauSetup (ct_options_t *o);
