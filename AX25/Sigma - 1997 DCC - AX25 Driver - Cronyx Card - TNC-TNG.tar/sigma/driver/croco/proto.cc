//
// Run protocol dialog.
//
// Copyright (C) 1996 Cronyx Engineering Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.0, Fri Nov  8 21:12:14 MSK 1996
//
#include "common.h"
#include "Dialog.h"

void ProtoDialog (cx_soft_opt_t *o, chan_t type, int cnum)
{
#ifndef linux
	char title [80];

	sprintf (title, Msg (" Channel c%c%d ", " ����� c%c%d "),
		type==SIGMA ? 'x' : 't', cnum);

	int proto;
	if (o->cisco)
		proto = 2;
	else
		proto = o->keepalive;
	int auth = o->auth;

	char name [32+1], passwd [16+1], master [16+1];
	memset (name, 0, sizeof (name));
	memset (passwd, 0, sizeof (passwd));
	memset (master, 0, sizeof (master));

	strncpy (name, (char*) o->name, sizeof (name));
	strncpy (passwd, (char*) o->passwd, sizeof (passwd));
	strncpy (master, (char*) o->master, sizeof (master));

	Dialog dlg (title, DialogPalette, Msg (
		"( {Protocol} [ R :0{PPP} :1{PPP+keepalive} :2{Cisco/HDLC} ]"
		"+++ {Master interface} S:16:16 ) {}"
		"{Authentication} [ R :0{Disabled} :1{PAP} :2{CHAP} +"
		"{    Name} | S:16:32 {}"
		"{Password} | S:16:32 ]"
		,
		"( {��������} [ R :0{PPP} :1{PPP+keepalive} :2{Cisco/HDLC} ]"
		"++ {������� ���������} S:16:16 ) {}"
		"{��������������} [ R :0{���������} :1{PAP} :2{CHAP} +"
		"{   ���} | S:16:32 {}"
		"{������} | S:16:32 ]"
		), &proto, master, &auth, name, passwd);
	if (dlg.Run (&V) <= 0)
		return;

	o->cisco = (proto == 2);
	o->keepalive = (proto != 0);
	o->auth = auth;
	strncpy ((char*) o->name, name, sizeof (o->name));
	strncpy ((char*) o->passwd, passwd, sizeof (o->passwd));
	strncpy ((char*) o->master, master, sizeof (o->master));
#endif
}
