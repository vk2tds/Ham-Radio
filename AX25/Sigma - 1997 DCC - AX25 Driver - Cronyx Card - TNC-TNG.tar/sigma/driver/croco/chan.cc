//
// Read/save Cronyx-Sigma and Cronyx-Tau channel options.
// Run channel list dialog.
//
// Copyright (C) 1996 Cronyx Engineering Ltd.
// Author: Serge Vakulenko, <vak@cronyx.ru>
//
// This software is distributed with NO WARRANTIES, not even the implied
// warranties for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Authors grant any other persons or organisations permission to use
// or modify this software as long as this message is kept with the software,
// all derivative works or modified versions.
//
// Version 1.0, Fri Nov  8 21:12:14 MSK 1996
//
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "common.h"
#include "Dialog.h"

#ifdef HAVE_TAU
#   include <ctaureg.h>
#   include <ic/hdc64570.h>
#endif

#define CTAUDEV         "/dev/ctau"
#define CSIGMADEV       "/dev/csigma"

channel_t chan [MAXCHAN];       // the table of channels
int nchan;                      // the number of channels

#ifdef HAVE_SIGMA
    static int sigmafd = -1;    // /dev/csigma descriptor
#endif
#ifdef HAVE_TAU
    static int taufd = -1;      // /dev/ctau descriptor
#endif

static char FMT[] = "c%c%-2d     %-11s %-9s %-14s %-10s";

channel_t *opt_to_chan (options_t *o)
{
	for (channel_t *c=chan; c<chan+nchan; ++c)
		if (&c->o == o)
			return c;
	return 0;
}

static void AsyncInit (channel_t *c)
{
	char tty[60];

	tty[0] = 0;
#ifdef HAVE_SIGMA
	if (c->type == SIGMA)
		sprintf (tty, "/dev/tty%c%x", 'x' + c->o.s.board, c->o.s.channel);
#endif
#ifdef HAVE_TAU
	if (c->type == TAU)
		sprintf (tty, "/dev/ttyt%d", c->o.t.channel + c->o.t.board * 2);
#endif
	int fd = open (tty, O_NDELAY);
	if (fd < 0)
		return;
	tcgetattr (fd, &c->a);
	close (fd);
}

static void SigmaInit (int n)
{
#ifdef HAVE_SIGMA
	if (sigmafd < 0) {
		sigmafd = open (CSIGMADEV, 0);
		if (sigmafd < 0)
			return;
	}

	channel_t *c = chan + nchan;
	c->o.s.board = n / 16;
	c->o.s.channel = n % 16;
	if (cxget (sigmafd, &c->o.s) < 0)
		return;
	c->type = SIGMA;
	if (c->o.s.mode == M_ASYNC)
		AsyncInit (c);
	++nchan;
#endif
}

static void TauInit (int n)
{
#ifdef HAVE_TAU
	if (taufd < 0) {
		taufd = open (CTAUDEV, 0);
		if (taufd < 0)
			return;
	}

	channel_t *c = chan + nchan;
	c->o.t.board = n / 2;
	c->o.t.channel = n % 2;
	if (ctget (taufd, &c->o.t) < 0)
		return;
	c->type = TAU;
	if (c->o.t.mode == M_ASYNC)
		AsyncInit (c);
	++nchan;
#endif
}

static void InterfaceInit (char *name)
{
	if (strncmp (name, "cx", 2) == 0)
		SigmaInit (atoi (name + 2));
	else if (strncmp (name, "ct", 2) == 0)
		TauInit (atoi (name + 2));
}

//
// Get the list if all network interfaces,
// and for every Sigma or Tau interface,
// call SigmaInit() or TauInit().
//
void ChanInit (void)
{
	int i;

	for (i=0; i<48; ++i)
		SigmaInit (i);
	for (i=0; i<6; ++i)
		TauInit (i);
}

int SigmaSetup (cx_options_t *o)
{
	int ok = 1;
#ifdef HAVE_SIGMA
	if (cxset (sigmafd, o) < 0)
		ok = 0;
	cxget (sigmafd, o);
	SaveConfig ();
#endif
	return ok;
}

int TauSetup (ct_options_t *o)
{
	int ok = 1;
#ifdef HAVE_TAU
	if (ctset (taufd, o) < 0)
		ok = 0;
	ctget (taufd, o);

	// ��������� ������� ������ ������
	// ����� ��������� � ��������� ������� ���������
	// ������� ��������.
	// ������� ����� ��������� ������ ������ ������
	// ���������� ������ ��������� ��������� ��������� �������.
	// ���� ��� ��������� ������ � Tau/E1 � Tau/G703.
	channel_t *c = opt_to_chan ((options_t*) o);
	c = c + (c->o.t.channel ? -1 : 1);
	ctget (taufd, &c->o.t);

	SaveConfig ();
#endif
	return ok;
}

static void AsyncPrint (channel_t *c, int color)
{
	char baud[40], encod[40];
	int csize = 8;
	long ospeed;

	ospeed = cfgetospeed (&c->a);
	if (ospeed >= 1000)
		sprintf (baud, "%ld,%03ld", ospeed / 1000, ospeed % 1000);
	else
		sprintf (baud, "%ld", ospeed);

	switch (c->a.c_cflag & CSIZE) {
	case CS8: csize = 8; break;
	case CS7: csize = 7; break;
	case CS6: csize = 6; break;
	case CS5: csize = 5; break;
	}
	sprintf (encod, "%d-%c-%c", csize,
		! (c->a.c_cflag & PARENB) ? 'N' :
		(c->a.c_cflag & PARODD) ? 'O' : 'E',
		(c->a.c_cflag & CSTOPB) ? '2' : '1');

	int cnum = 0;
#ifdef HAVE_SIGMA
	if (c->type == SIGMA)
		cnum = c->o.s.channel + c->o.s.board * 16;
#endif
#ifdef HAVE_TAU
	if (c->type == TAU)
		cnum = c->o.t.channel + c->o.t.board * 2,
#endif
	V.Print (color, FMT, c->type == SIGMA ? 'x' : 't', cnum,
		Msg ("Async", "������"), "--", baud, encod);
}

static void SigmaPrint (cx_options_t *o, int color)
{
#ifdef HAVE_SIGMA
	char baud[40], *type;

	if (o->mode == M_ASYNC) {
		AsyncPrint (opt_to_chan ((options_t*) o), color);
		return;
	}
	switch (o->type) {
	default:
	case T_SYNC_RS232:	/* pure synchronous RS-232 channel */
	case T_UNIV_RS232:	/* sync/async RS-232 channel */
		type = "HDLC RS-232";
		break;	
	case T_SYNC_V35:	/* pure synchronous V.35 channel */
		type = "HDLC V.35";
		break;
	case T_SYNC_RS449:	/* pure synchronous RS-449 channel */
		type = "HDLC RS-530";
		break;
	case T_UNIV_RS449:	/* sync/async RS-232/RS-449 channel */
		type = o->iftype ? "HDLC RS-530" : "HDLC RS-232";
		break;
	case T_UNIV_V35:	/* sync/async RS-232/V.35 channel */
		type = o->iftype ? "HDLC V.35" : "HDLC RS-232";
		break;
	}

	if (o->txbaud >= 1000)
		sprintf (baud, "%ld,%03ld%s", o->txbaud / 1000, o->txbaud % 1000,
			o->opt.rcor.dpll ? " DPLL" : "");
	else
		sprintf (baud, "%ld%s", o->txbaud,
			o->opt.rcor.dpll ? " DPLL" : "");

	static char *sigmaencod[] = { "NRZ", "NRZI", "Manchester" };

	V.Print (color, FMT, 'x', o->channel + o->board * 16, type,
#ifdef linux
		"--",
#else
		o->sopt.cisco ? "Cisco" :
		o->sopt.keepalive ? "PPP+" : "PPP",
#endif
		o->opt.tcor.ext1x ? Msg ("External", "�������") : baud,
		sigmaencod [o->opt.rcor.encod]);
#endif
}

static void TauPrint (ct_options_t *o, int color)
{
#ifdef HAVE_TAU
	char baud[40], *type = "???";

	switch (o->mode) {
	case M_ASYNC:
		AsyncPrint (opt_to_chan ((options_t*) o), color);
		return;
	case M_HDLC:
		type = o->v35 ? "HDLC V35/RS530" : "HDLC RS232";
		break;
	case M_HDLC_E1:
		type = (o->channel & 1) && o->bopt.cfg==GCFG_K ? "E1/0" : "E1";
		break;
	case M_HDLC_G703:
		type = "G.703";
		break;
	case M_RAW_E1:
		type = (o->channel & 1) && o->bopt.cfg==GCFG_K ?
			"Raw E1/0" : "Raw E1";
		break;
	case M_RAW_G703:
		type = "Raw G.703";
		break;
	}

	int dpll = (o->mode != M_ASYNC && o->hopt.rxs == CLK_RXS_DPLL_INT);
	int extclk = (o->mode == M_HDLC && o->hopt.txs == CLK_LINE);
	if (o->baud >= 1000000)
		sprintf (baud, "%ld,%03ld,%03ld%s", o->baud / 1000000,
			o->baud / 1000 % 1000, o->baud % 1000,
			dpll ? " DPLL" : "");
	else if (o->baud >= 1000)
		sprintf (baud, "%ld,%03ld%s", o->baud / 1000, o->baud % 1000,
			dpll ? " DPLL" : "");
	else
		sprintf (baud, "%ld%s", o->baud,
			dpll ? " DPLL" : "");

	static char *tauencod[] = {
		"NRZ", "NRZI", "??", "???", "Manchester", "Fm0", "Fm1", };

	V.Print (color, FMT, 't', o->channel + o->board * 2, type,
		o->sopt.cisco ? "Cisco" :
		o->sopt.keepalive ? "PPP+" : "PPP",
		extclk ? Msg ("External", "�������") : baud,
		tauencod [o->opt.md2.encod]);
#endif
}

void ChanDialog (void)
{
	int w = 57;
	int h = 2 + nchan;
	int color = InverseTextColor;
	int inverse = TextColor;
	char *reply = Msg ("Ok", "������");
	char *title = Msg (" Cronyx ", " ������� ");

	// ��������, ��� ��������� � ������ ����������.
	int r = strlen (title);
	if (r > w)
		w = r;
	r = strlen (reply);
	if (r > w)
		w = r;

	// ������� ����� ����� ��� �����, ������ � ������.
	h += 2;
	w += 4;

	// ��������� ����� ������� ���� (���� � ������ ������).
	r = V.Lines/2 - h/2;
	int c = V.Columns/2 - w/2;

	Box box (V, r, c, h+1, w+1);
	channel_t *ch = chan;
again:
	V.Clear (r, c, h, w, color, ' ');               // ��������� ����
	V.DrawFrame (r, c, h, w, FrameColor);           // �����
	int i;
	for (i=0; i<w; ++i)
		V.AttrLow (r+h, c+i+1);                 // ���� �����
	for (i=0; i<h-1; ++i)
		V.AttrLow (r+i+1, c+w);			// ���� ������

	// ������ ���������.
	V.Put (r, c + (w-strlen(title)) / 2, title, FrameColor);

	// ������ ������������.
	V.Put (r+1, c+2, Msg ("Channel  Mode        Protocol  Data Rate      Encoding",
			      "�����    �����       ��������  ��������       �����������"),
		InverseDimTextColor);
	V.HorLine (r+2, c+2, w-4, InverseDimTextColor);
	for (i=0; i<nchan; ++i) {
		V.Move (r+3+i, c+2);
		switch (chan[i].type) {
		case SIGMA:
			SigmaPrint (&chan[i].o.s, color);
			break;
		case TAU:
			TauPrint (&chan[i].o.t, color);
			break;
		}
	}

	for (;;) {
		Box *curbox = new Box (V, r+3 + (ch - chan), c+2, 1, w-4);
		V.Put (*curbox, inverse);
		V.HideCursor ();
		V.Sync ();
		int n = V.GetKey ();
		V.Put (*curbox);
		delete (curbox);
		switch (n) {
		default:
			V.Beep ();
			continue;
		case cntrl (']'):		// redraw screen
			V.Redraw ();
			continue;
		case cntrl ('J'):
		case cntrl ('M'):
			V.Put (box);
			switch (ch->type) {
			case SIGMA:
#ifdef HAVE_SIGMA
				if (SigmaDialog (&ch->o.s)) {
					if (ch->o.s.mode == M_HDLC)
						ProtoDialog (&ch->o.s.sopt,
							ch->type,
							ch->o.s.channel +
							ch->o.s.board * 16);
					SigmaSetup (&ch->o.s);
				}
#endif
				break;
			case TAU:
#ifdef HAVE_TAU
				if (TauDialog (&ch->o.t)) {
					if (ch->o.t.mode & M_HDLC)
						ProtoDialog ((cx_soft_opt_t*)
							&ch->o.t.sopt,
							ch->type,
							ch->o.t.channel +
							ch->o.t.board * 2);
					TauSetup (&ch->o.t);
				}
#endif
				break;
			}
			goto again;
		case cntrl ('C'):
		case cntrl ('['):
		case meta ('J'):		// f0
			PromptQuit ();
			continue;
		case meta ('u'):		// up
			if (--ch < chan)
				ch = chan+nchan-1;
			continue;
		case meta ('d'):		// down
			if (++ch >= chan+nchan)
				ch = chan;
			continue;
		case meta ('h'):		// home
			ch = chan;
			continue;
		case meta ('e'):		// end
			ch = chan+nchan-1;
			continue;
		}
	}
}

#ifdef HAVE_TAU
static char *ts (unsigned long s)
{
	static char buf [100];
	char *p = buf;
	int i;

	for (i=1; i<32; ++i)
		if ((s >> i) & 1) {
			int prev = i>1  & (s >> (i-1));
			int next = i<31 & (s >> (i+1));

			if (prev) {
				if (next)
					continue;
				*p++ = '-';
			} else if (p > buf)
				*p++ = ',';

			if (i >= 10)
				*p++ = '0' + i / 10;
			*p++ = '0' + i % 10;
		}
	*p = 0;
	return buf;
}
#endif

void SaveAsync (FILE *fd, channel_t *c)
{
#ifndef linux
	struct termios *t = &c->a;

#ifdef HAVE_SIGMA
	if (c->type == SIGMA)
		fprintf (fd, "stty < /dev/tty%c%x", 'x' + c->o.s.board,
			c->o.s.channel);
#endif
#ifdef HAVE_TAU
	if (c->type == TAU)
		fprintf (fd, "stty < /dev/ttyt%d", c->o.t.channel +
			c->o.t.board * 2);
#endif
	fprintf (fd, " %ld", (long) cfgetospeed (t));
	switch (c->a.c_cflag & CSIZE) {
	case CS8: fprintf (fd, " cs8"); break;
	case CS7: fprintf (fd, " cs7"); break;
	case CS6: fprintf (fd, " cs6"); break;
	case CS5: fprintf (fd, " cs5"); break;
	}
	fprintf (fd, (c->a.c_cflag & CSTOPB) ? " cstopb" : " -cstopb");

	if (! (c->a.c_cflag & PARENB))
		fprintf (fd, " -parenb -inpck");
	else if (c->a.c_cflag & PARODD)
		fprintf (fd, " parenb inpck -parodd");
	else
		fprintf (fd, " parenb inpck parodd");
	fprintf (fd, " \\\n\t");

	fprintf (fd, (c->a.c_cflag & CRTSCTS) ? " crtscts" : " -crtscts");
	fprintf (fd, (c->a.c_iflag & (IXON | IXOFF)) ?
		" ixon ixoff -ixany" : " -ixon -ixoff -ixany");
	fprintf (fd, (c->a.c_iflag & IGNPAR) ? " ignpar" : " -ignpar");
	fprintf (fd, (c->a.c_iflag & ISTRIP) ? " istrip" : " -istrip");
	fprintf (fd, "\n");
#endif
}

void SaveConfig ()
{
	char line [256];
	static int firsttime = 1;

	if (firsttime) {
		strcpy (line, InitFileName);
		strcat (line, "~");
		unlink (line);
		rename (InitFileName, line);
	}
	FILE *fd = fopen (InitFileName, "w");
	if (! fd) {
		if (firsttime)
			V.Error (ErrorColor, TextColor,
				Msg (" Error ", " ������ "), Msg (" Ok ", " ������ "),
				Msg ("Cannot create %s", "��� ����� ������ � ���� %s"),
				InitFileName);
		firsttime = 0;
		return;
	}
	firsttime = 0;
	Flash alert (&V, " Save ", Msg ("Saving setup...",
		"��������� ���������..."), InverseLightTextColor);

	fprintf (fd, ":\n");
	fprintf (fd, "# This file was generated by Cronyx configuration utility.\n");
	fprintf (fd, "# DON'T EDIT IT FILE MANUALLY, USE croco!\n");
	fprintf (fd, "#\n");
	fprintf (fd, "# To run this file at the system startup,\n");
	fprintf (fd, "# add the following line to your /etc/rc file,\n");
	fprintf (fd, "# just before running /etc/netstart:\n");
	fprintf (fd, "#\n");
	fprintf (fd, "#       [ -f /etc/rc.cronyx ] && sh /etc/rc.cronyx\n");
	fprintf (fd, "#\n");

	for (channel_t *c=chan; c<chan+nchan; ++c) {
		cx_soft_opt_t *sopt;
		int mode;

		switch (c->type) {
		default:
			continue;

#ifdef HAVE_SIGMA
		case SIGMA: {
			cx_options_t *so = &c->o.s;
			sopt = &c->o.s.sopt;
			mode = so->mode;
			fprintf (fd, "\n# Channel %d (%s) of Cronyx-Sigma-%s at port 0x%x\n",
				so->channel, mode == M_ASYNC ?
				"Async" : "HDLC", so->name, so->port);
#ifdef linux
			if (mode == M_ASYNC)
				break;
#endif
			fprintf (fd, "cxconfig cx%d", so->channel +
				so->board * 16);

			if (mode == M_ASYNC) {
				fprintf (fd, " async");
				break;
			}

			fprintf (fd, " hdlc");
			if (so->channel == 0 || so->channel == 8)
				fprintf (fd, " port=%s", so->iftype ?
					"v35" : "rs232");
			if (so->opt.tcor.ext1x)
				fprintf (fd, " +extclock");
			else
				fprintf (fd, " %ld", so->txbaud);
			if (so->opt.rcor.dpll)
				fprintf (fd, " +dpll");
			if (so->opt.rcor.encod == 2)
				fprintf (fd, " manchester");
			else if (so->opt.rcor.encod == 1)
				fprintf (fd, " nrzi");
			break;
		}
#endif
#ifdef HAVE_TAU
		case TAU:
			ct_options_t *to = &c->o.t;
			sopt = (cx_soft_opt_t*) &c->o.t.sopt;
			mode = to->mode;
			fprintf (fd, "\n# Channel %d (%s) of Cronyx-%s at port 0x%x\n",
				to->channel, mode == M_ASYNC ? "Async" :
				(mode & M_E1) ? "E1" :
				(mode & M_G703) ? "G.703" : "HDLC",
				to->name, to->port);
#ifdef linux
			if (mode == M_ASYNC)
				break;
#endif
			fprintf (fd, "ctconfig ct%d", to->channel +
				to->board * 2);

			if (mode == M_ASYNC) {
				fprintf (fd, " async");
				break;
			}

			fprintf (fd, " hdlc");
			if (to->type & (T_E1 | T_G703))
				fprintf (fd, " cfg=%s",
					to->bopt.cfg == GCFG_II ? "II" :
					to->bopt.cfg == GCFG_HI ? "HI" : "K");
			if (mode == M_HDLC)
				if (to->hopt.txs == CLK_LINE)
					fprintf (fd, " baud=ext");
				else
					fprintf (fd, " %ld", to->baud);

			if (to->bopt.bcr2 & ((to->channel & 1) ?
			    BCR2_INVCLK1 : BCR2_INVCLK0))
				fprintf (fd, " +invclk");
			if (to->hopt.rxs == CLK_RXS_DPLL_INT)
				fprintf (fd, " +dpll");
			if (to->opt.md2.encod == MD2_ENCOD_MANCHESTER)
				fprintf (fd, " manchester");
			else if (to->opt.md2.encod == MD2_ENCOD_NRZI)
				fprintf (fd, " nrzi");

			if (! (mode & (M_E1 | M_G703)))
				break;

			// E1/G.703 options.
			int clk = (to->channel & 1) ?
				to->bopt.clk1 : to->bopt.clk0;
			fprintf (fd, " txclk=%s", clk==GCLK_INT ? "int":
				clk==GCLK_RCV ? "rcv" : "chan");
			if (! to->gopt.hdb3)
				fprintf (fd, " -hdb3");

			if (mode & M_G703) {
				if (to->gopt.pce)
					fprintf (fd, " +pce");
				if (to->gopt.rate != 2048)
					fprintf (fd, " kbps=%ld",
						to->gopt.rate);
				break;
			}

			// E1-specific options.
			if (to->gopt.cas)
				fprintf (fd, " +cas");
			if (to->gopt.crc4)
				fprintf (fd, " +crc4");
			if (to->gopt.higain)
				fprintf (fd, " +higain");

			long s = (to->channel & 1) ?
				to->bopt.s1 : to->bopt.s0;
			fprintf (fd, " ts=%s", ts (s));

			if (! (to->channel & 1) &&
			    (to->bopt.cfg == GCFG_K ||
			    to->bopt.cfg == GCFG_HI))
				fprintf (fd, " pass=%s", ts (to->bopt.s2));
			break;
#endif
		}
#ifndef linux
		// Adapter-independent software options.
		if (mode != M_ASYNC) {
			fprintf (fd, " \\\n\t%s", sopt->cisco ? "cisco" : "ppp");
			if (! sopt->cisco)
				fprintf (fd, " %ckeepalive", sopt->keepalive ? '+' : '-');
			if (*sopt->master)
				fprintf (fd, " master='%.16s'", sopt->master);
			if (sopt->auth) {
				fprintf (fd, " auth=%s", sopt->auth>1 ? "chap" : "pap");
				fprintf (fd, " name='%s'", sopt->name);
				fprintf (fd, " passwd='%s'", sopt->passwd);
			} else
				fprintf (fd, " auth=off");
		}
#endif
		fprintf (fd, "\n");
		if (mode == M_ASYNC)
			SaveAsync (fd, c);
	}
	fclose (fd);
}
