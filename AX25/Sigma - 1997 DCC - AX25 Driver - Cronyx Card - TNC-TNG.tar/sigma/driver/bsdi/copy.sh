:
#
# Copy the Tau driver sources into the BSD/OS kernel sources directory
#
src=../..
sys=/usr/src/sys
[ -d $sys ] || mkdir $sys
[ -d $sys/net ] || mkdir $sys/net
[ -d $sys/i386 ] || mkdir $sys/i386
[ -d $sys/i386/include ] || mkdir $sys/i386/include
[ -d $sys/i386/isa ] || mkdir $sys/i386/isa
[ -d $sys/i386/isa/ic ] || mkdir $sys/i386/isa/ic
[ -d $sys/i386/isa/cronyx ] || mkdir $sys/i386/isa/cronyx

set -x
cp $src/driver/if_sppps.c            /usr/src/sys/net/if_spppsubr.c
cp $src/driver/if_sppp.h             /usr/src/sys/net/
cp $src/driver/cx.c                  /usr/src/sys/i386/isa/
cp $src/driver/if_cx.c               /usr/src/sys/i386/isa/
cp $src/driver/csigmafw.h            /usr/src/sys/i386/isa/cronyx/
cp $src/sources/csigma.c             /usr/src/sys/i386/isa/cronyx/
cp $src/sources/cronyxfw.h           /usr/src/sys/i386/isa/cronyx/
cp $src/sources/cxreg.h              /usr/src/sys/i386/isa/
cp $src/sources/csigma.h             /usr/src/sys/i386/include/
