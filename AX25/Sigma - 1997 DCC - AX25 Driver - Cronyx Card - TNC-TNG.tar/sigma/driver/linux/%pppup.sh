#!/bin/bash
/sbin/insmod cxppp.o port=0x320 irq=5 drq=6
cxconfig cx0 +extclock
pppd cx0 -am -vj -ac -pc persist
