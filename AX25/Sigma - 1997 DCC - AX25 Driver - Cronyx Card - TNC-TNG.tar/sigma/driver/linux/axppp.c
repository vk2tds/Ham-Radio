/*
 * Point-to-Point protocol layer for Sigma driver.
 * 
 * Copyright (C) 1997, Dmitry Gorodchanin <begemot@bgm.rosprint.net>.
 * 
 * This program may be redistributed and/or
 * modified under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version
 * 2 of the License, or (at your option) any later version.
 * 
 * This source is derived from:
 * 	RISCom/N2 network driver for Linux
 *   	Copyright 1995-1996, SDL Communications, Inc.
 *   	by Mike Natale (mike@ns.sdlcomm.com)
 *
 * Revision history:
 * 	06 Mar 1997 - version 0.02, first public release (bgm)
 */
/* These comments are made by darryl smith, VK2TDS 1997
 * Eack SKB only has one buffer!
 * Timers are not relevant to this code in that they are dealth
 * with on a different level. But this code must pass initialisation 
 * paramaters to the code, and report back the status if required!
 * Ports are sent to cxppp_read and _write from the minor number of the 
 * device. 
 *
 *
 *
 */








#include <linux/config.h>
#include <linux/version.h>
#include <linux/module.h>

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/interrupt.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/socket.h>
#include <linux/ioport.h>
#include <linux/in.h>
#include <linux/if_ether.h>     /* For the statistics structure. */
#include <linux/if_arp.h>

#include <linux/tqueue.h>
#include <linux/termios.h>
#include <linux/ppp.h>

#include <asm/system.h>
#include <asm/segment.h>
#include <asm/io.h>

#include <linux/inet.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/timer.h>

#include <linux/fcntl.h>

#include "cx.h"

#define MAXPORTS (NCX * NCHAN)

static void ppp_txisr(unsigned int port);
static void ppp_rxisr(unsigned int port);

int init_module(void);
void cleanup_module(void);

static int opens[MAXPORTS] = { 0, };
static int mtu = 1500;

/* character driver disciplines */
#define RAW 0
#define PPP 1
static int char_mode[MAXPORTS];
#define MAX_READ_QUEUE 10
static struct sk_buff_head rxdata[MAXPORTS];
static struct wait_queue *rxq[MAXPORTS] = { NULL, };
static struct wait_queue *txq[MAXPORTS] = { NULL, };
static struct device *port2dev_map[MAXPORTS] = { NULL, };
static struct fasync_struct *fasync[MAXPORTS] = { NULL, };
static int owner[MAXPORTS] = { 0, };

/* Initialization */
int debug = 0;


/*
 * This routine called by network interface with IP packet in skb->data
 */
static int ppp_xmit(struct sk_buff *skb, struct device *dev) 
{
	struct enet_statistics *stats = (struct enet_statistics *)dev->priv;
	unsigned int port = dev->base_addr;

	
	/* should never happen, but just in case... */
	if (!skb) {
		printk(KERN_DEBUG "%s: NULL skb in ppp_xmit().\n", dev->name);
		dev_tint(dev);
		return 0;
	}

	if (cx_hw_write(port, skb) == 0) {
		return 1;
	}
	
	/* packet was queued onto card, free skb, device not busy */
	dev->tbusy = 0;
	dev->trans_start = jiffies;
	dev_kfree_skb(skb, FREE_WRITE);
	stats->tx_packets++;
	return 0;
}

static struct enet_statistics * netget_stats(struct device *dev) 
{
	return (struct enet_statistics *)dev->priv;
}

static void ppp_rxisr (unsigned int port)
{
	struct device *dev = port2dev_map[port];
	struct enet_statistics *stats = NULL;
	struct sk_buff *skb;
	int status;
	
	if (dev) 
		stats = (struct enet_statistics *) dev->priv;

	if ((status = cx_hw_read(port, &skb))) {
		if (debug) {
			int len = skb->len, i;
			if (len > 12)
				len = 12;
			printk(KERN_DEBUG "%s: ppp_rxisr: ", dev->name);
			for (i = 0; i < len; i++) 
				printk("%02x ", skb->data[i]);
			printk("\n");
		}

		if (dev) {
				skb->dev = dev;
				skb->mac.raw = skb->data; /* Is this correct? It does not make any harm TDS */
				netif_rx(skb);
				stats->rx_packets++;
				return;
		}
		skb->free = 1;
		kfree_skb(skb, FREE_READ);
		return;

	} 

}

static void ppp_txisr(unsigned int port)
{
	struct device *dev = port2dev_map[port];

	/*  tell net layers we're clear... */
	if (dev) 
		dev->tbusy = 0;
	mark_bh(NET_BH);
	/*  ... and wake up any char processes if necessary */
	wake_up_interruptible(&txq[port]);
}

static int ppp_open(struct device *dev)
{
	int port = dev->base_addr;

	printk(KERN_DEBUG "%s: network open, CX card %d port %d\n",
	       dev->name, port / 16, port % 16);
	memset(dev->priv, 0, sizeof(struct enet_statistics));
	dev->start = 1;
	MOD_INC_USE_COUNT;
	port2dev_map[port] = dev;
	return 0;
}

static int ppp_close(struct device *dev) 
{
	int port = dev->base_addr;
	
	dev->start = 0;
	MOD_DEC_USE_COUNT;
	printk(KERN_DEBUG "%s: network close, CX card %d port %d\n",
	       dev->name, port / 16, port % 16);
	port2dev_map[port] = 0;
	return 0;
}


static int ppp_ioctl (struct device *dev, struct ifreq *ifr, int cmd)
{
        int error = 0;
	int len;
	/*
	 * Process the requests
	 */
        switch (cmd) {
        case SIOCGPPPSTATS:
		break;

        case SIOCGPPPCSTATS:
		break;

        case SIOCGPPPVER:
	        len = strlen(PPP_VERSION) + 1;
                memcpy_tofs(ifr->ifr_ifru.ifru_data, PPP_VERSION, len);
                break;

        default:
                error = -EINVAL;
                break;
	}
	return error;
}

int cxproto_init(struct device *dev) 
{
	int port = dev->base_addr;
	int i;

	dev->open            = ppp_open;
	dev->stop            = ppp_close;
	dev->hard_start_xmit = ppp_xmit;
	dev->tbusy           = 0;
	dev->start           = 0;
	dev->do_ioctl        = ppp_ioctl; 

	/* fill in device generic fields */
	dev->hard_header     = 0; /* 0 ? TDS */
	dev->rebuild_header  = 0; /* 0 ? TDS */

	dev->type            = ARPHRD_PPP;
	dev->hard_header_len = 0;
	dev->mtu             = mtu; /* eth_mtu = ??? TDS */
	dev->addr_len        = 0;

	/* New-style flags. */
	dev->flags           = IFF_POINTOPOINT | IFF_NOARP; /* ? TDS */
	dev->family          = AF_INET;
	dev->pa_addr         = 0;
	dev->pa_brdaddr      = 0;
	dev->pa_mask         = 0;
	dev->pa_alen         = 0;
	dev->priv = kmalloc(sizeof(struct enet_statistics), GFP_KERNEL);
	memset (dev->priv, 0, sizeof (struct enet_statistics) );
	dev->get_stats = netget_stats;
	for (i = 0; i < DEV_NUMBUFFS; i++)
		skb_queue_head_init(&dev->buffs[i]);
  
	port2dev_map[port] = 0;
   
	return 0;
}

int cxppp_open(struct inode *inode, struct file *filp)
{
	int port = MINOR(inode->i_rdev);
	int err;

	if (port == CX_UNIT_MINOR) {
		MOD_INC_USE_COUNT;
		return 0;
		
	}
	/* already opened */
	if (opens[port]) 
		return -EBUSY;

	if ((err = cx_hw_open(port, ppp_rxisr, ppp_txisr)))
		return err;
	
	/* HW opened. Finish open  */
	MOD_INC_USE_COUNT;
	owner[port] = current->pid;
	skb_queue_head_init(&rxdata[port]);

	opens[port]++;
	char_mode[port] = RAW;

	return 0;
}

static int cxppp_fasync(struct inode *inode, struct file *filp, int on)
{
   	int port = MINOR(inode->i_rdev);
	int ret;

        ret = fasync_helper(inode, filp, on, &fasync[port]);
	
	return ret < 0 ? ret : 0;
}

static void cxppp_close(struct inode *inode, struct file *filp) 
{
	int port = MINOR(inode->i_rdev);
	struct sk_buff * skb;

	if (port == CX_UNIT_MINOR) {
		MOD_DEC_USE_COUNT;
		return;
	}

	if (--opens[port] <= 0) {
		opens[port] = 0;
		
		while ((skb = skb_dequeue(&rxdata[port])))
			kfree_skb(skb, FREE_READ);
		
		cx_hw_close(port);
		char_mode[port] = RAW;
		owner[port] = 0;
		cxppp_fasync(inode, filp, 0);
		MOD_DEC_USE_COUNT;
	}
}

static int cxppp_write(struct inode *inode, struct file *filp,
			const char *buf, int len)
{
	int ret  = 0;
	int port = MINOR(inode->i_rdev);
	struct sk_buff * skb = NULL;
	
	do {
		if (skb) {
			memcpy_fromfs(skb_put(skb, len), buf, len);

			if ((skb->data[0] != 0xc0) | (len <= 3)){
				printk (KERN_NOTICE "Bad formatting of the KISS pkt. \n");
				goto free_and_exit;
				}
			switch (skb->data[1] & 0x0f){
				case 0x01: /* Set TX Delay on skb->data[2] */
				case 0x02: /* Set Persistence on skb->data[2] */
				case 0x03: /* Set the Slot Time on skb->data[2] */
				case 0x04: /* Set the TxTail on skb->data[2] */
				case 0x05: /* Set Full/Half Duplex on skb->data[2] */
				case 0x06: /* Set hardware (modem speed) on skb->data[2] */
						printk ("KISS TNC: SET: %x %x \n",skb->data[1], skb->data[2]);
						


						break;
				default: 		
				
					skb->protocol = htons(ETH_P_WAN_PPP);
					if (!port2dev_map[port] || char_mode[port] == RAW) {
						if (cx_hw_write(port, skb)) {
							kfree_skb(skb, FREE_READ);
							return len;
						}
					} else {
						struct device * dev = port2dev_map[port];
						skb_queue_head(&dev->buffs[0], skb);
						mark_bh(NET_BH);
						return len;
						}
				} /* Switch */ 
		}/* SKB */
		if (filp->f_flags & O_NONBLOCK)
			goto free_and_exit;
		/* sleep */
		interruptible_sleep_on(&txq[port]); 
		
	} while (!(current->signal & ~current->blocked));

	ret = -ERESTARTNOINTR;
free_and_exit:
	if (skb) 
		kfree_skb(skb, FREE_READ);
	return ret;
}

static int cxppp_read(struct inode *inode, struct file *filp, 
		       char *buf, int len)
{
	int port = MINOR(inode->i_rdev);
	struct sk_buff * skb;
	
	do {
		if ((skb = skb_dequeue(&rxdata[port]))) {
			if (len > skb->len) 
				len = skb->len;
			memcpy_tofs(buf, skb->data, len);
			kfree_skb(skb, FREE_READ);
			return len;
		}
		/* No data available  */
		if (filp->f_flags & O_NONBLOCK) 
			return -EWOULDBLOCK;
		interruptible_sleep_on(&rxq[port]); 
	} while (!(current->signal & ~current->blocked));
	
	return -ERESTARTNOINTR;
}

static int cxppp_ioctl(struct inode *inode, struct file *filp,
			unsigned int cmd, unsigned long arg) 
{
	int retv = 0;
	int port = MINOR(inode->i_rdev);

	if (port == CX_UNIT_MINOR) {
		return cx_ioctl(inode, filp, cmd, arg);
	}

  	switch(cmd) {
			

	case TIOCGETD:
		break;

	case TIOCSETD:
		/* set to PPP mode */
	 	char_mode[port] = PPP;
	 	break;

	case PPPIOCGUNIT:
	 	put_fs_long (-port - 1,(int *)arg); 
	 	break;

	} 
  	return retv;
}               

static int cxppp_select(struct inode *inode, struct file *filp,
			 int type, select_table * st)
{
   	int port = MINOR(inode->i_rdev);

	switch (type) {
	case SEL_IN:
		if (!skb_queue_empty(&rxdata[port]))
			return 1;
	case SEL_EX:
		select_wait(&rxq[port], st);	
		break;
		
	case SEL_OUT:
		return 1; 	
	}
	return 0;
}

int cxproto_dlci (unsigned long arg, int add)
{
	return EPFNOSUPPORT;
}

char cx_devname[] = "ppp-";

struct file_operations cxproto_fops = {
	NULL,			/* seek */
	cxppp_read,		/* read */
	cxppp_write,		/* write */
	NULL,			/* readdir */
	cxppp_select,		/* select  */
	cxppp_ioctl,		/* ioctl   */
	NULL,			/* mmap    */
	cxppp_open,		/* open    */
	cxppp_close,		/* release */
	NULL,			/* fsync */
	cxppp_fasync		/* async */
};   
