:
find . -type f ! -name \*.bat ! -name \*.exe ! -name \*.bmp ! -name \*.cpl \
	! -name \*.doc ! -name \*.prj ! -name \*.tc ! -name \*.sys \
	! -name \*.zip ! -name \*.dat |\
xargs fromdos

