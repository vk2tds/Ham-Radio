
//#ifndef __PCM__
//	/*
//#endif
#include <16F628.h>
#use DELAY (clock=10000000)
#use rs232 (BAUD=4800, xmit=PIN_B2, rcv=PIN_B1, ERRORS)
#fuses HS, NOWDT
#BIT TRMT = 0x98.1

#BYTE TRISA = 0x85


//#ifndef __PCM__
//	*/
//#endif
#ifndef __PCM__
#include <stdio.h>
#endif


char CallsignPos;
char Callsign[10];


char CallsignToPos;
char CallsignTo[10];

char PayloadPos;
char Payload[60];
/* char Buffer [40]; */
/* Mode =

	0 = CallSign Ack
	1 = Callsign to
	2 = Callsign Digi
	3 = Payload
	4 = Process Data
	5 = Payload Processed - waiting for CRLF

	20 = Bad something - waiting for new line
	*/

unsigned char mode;

void NewMode (char NewMode)
{

#ifndef __PCM__
	printf ("Changing MODE from %d to %d\n",mode, NewMode);
#else
	while (!TRMT);
/*	putc ('0' + NewMode); */
#endif
	mode = NewMode;

}


void main (void)
{
	unsigned char c;
	char Buffer[40];
	char i,j;
	char Offset;

	while (!TRMT);
	puts ("AntiTracker: Copyright 2002 Darryl Smith VK2TDS\n");
	while (!TRMT);
	puts ("16F84 IC Copyright Mike Berg N0QBH\n");


/*	setup_comparator(NC_NC_NC_NC);
	setup_ccp1(CCP_OFF);
	setup_vref(FALSE);
	disable_interrupts(GLOBAL);
	TRISA = 0x00;

	output_bit (PIN_A0, 1);
  */

init:
	Buffer[0] = '$';
	Buffer[1] = 'G';
	Buffer[2] = 'P';
	Buffer[3] = 'W';
	Buffer[4] = 'P';
	Buffer[5] = 'L';
	Buffer[6] = ',';
	Buffer[7] = '0';
	Buffer[8] = '0';
	Buffer[9] = '0';
	Buffer[10] = '0';
	Buffer[11] = '.';
	Buffer[12] = '0';
	Buffer[13] = '0';
	Buffer[14] = ',';
	Buffer[15] = 'N';
	Buffer[16] = ',';
	Buffer[17] = '0';
	Buffer[18] = '0';
	Buffer[19] = '0';
	Buffer[20] = '0';
	Buffer[21] = '0';
	Buffer[22] = '.';
	Buffer[23] = '0';
	Buffer[24] = '0';
	Buffer[25] = ',';
	Buffer[26] = 'W';
	Buffer[27] = ',';
	Buffer[28] = 'X';
	Buffer[29] = 'X';
	Buffer[30] = 'X';
	Buffer[31] = 'X';
	Buffer[32] = 'X';
	Buffer[33] = 'X';
	Buffer[34] = 'X';
	Buffer[35] = 'X';
	Buffer[36] = 'X';
	Buffer[37] = 'X';
	Buffer[38] = 0x00;



	PayloadPos = 0;
	CallsignPos = 0;
	CallsignToPos = 0;
	NewMode (0);
  while (1 == 1){
	while (1 == 1){ /* was kbhit() */
	c = getch();
	while (!TRMT);
/*	printf ("%x",c); */
/*	putc (mode + '0'); */




	if (c == 0x0a | c == 0x0d | c == 0x00 ){
		switch (mode){
		case 5:
			NewMode (0);
			goto init;
		case 4:
			break;
		case 3:
			NewMode (4);
			break;
		default:
			NewMode (0);
			goto init;
			break;

		}
	}


	if (mode == 4){
		if ( Payload[0] == '}'){
			for ( i = 1; (Payload[i] != '*' & Payload[i] != ',' & Payload[i] != '>' & Payload[i] != ':' ) & ( i < 11) ; i++ ){
				Callsign[i-1] = Payload[i];
			}
			Callsign[i] = 0;
			for ( ; Payload[i] != ':'; i++){
//				while (!TRMT);
//				putc (Payload[i]);
			};
			i++;
			while (!TRMT);
			putc ('\n');

			for ( j = 0; j < 59-i; j++)
			{
				Payload[j] = Payload[j+i];
//				while (!TRMT);
//				putc (Payload[j]);
			}
		}

		if (
			((Payload[0] == '!' | Payload[0] == '=' )& Payload[13] != 'T') |
			((Payload[0] == '/' | Payload[0] == '@' )& Payload[20] != 'T') |
			((Payload[0] == ';' & Payload[18] != '/')) |
			((Payload[0] == ')' | Payload[0] == '\'' | Payload[0] == '`' ))

			 )
			{
			Offset = 0; /* Offset for POS format without TIME */
			switch (Payload[0]){
				case ';':
					Offset = 17;
					for (i = 0; i < 9; i++)
						Buffer[i+28] = Payload[i+1];
					break;
				case ')':

					for (i = 4; (i < 10) & (Payload[i] != '!') & (Payload[i] != '_'); i++){
						;
					}
					for (j = 0; j < i-1; j++)
						Buffer[j+28] = Payload[j+1];
					Offset = i;
					break;

				case '/':
				case '@':
					Offset = 7;

				case '!':
				case '=':
					for (i = 0; i < CallsignPos; i++)
						Buffer[i+28] = Callsign[i];
					break;
				case '\'':
				case '`':
					for (i = 0; i < CallsignPos; i++)
						Buffer[i+28] = Callsign[i];
					Offset = 20;
					break;

				}
				Buffer[CallsignPos + 28] = 0;


			if (Offset != 20){

				for (i = 0; i < 7; i++)
					Buffer[i+7] = Payload[i+1+Offset];
				Buffer[15] = Payload[8+Offset];
				for (i = 0; i < 8; i++)
					Buffer[i+17] = Payload[i+10+Offset];
				Buffer[26] = Payload[18+Offset];

			} else {
				if (CallsignTo[3] < 'P') Buffer[15] = 'S'; else Buffer[15] = 'N';
				if (CallsignTo[5] < 'P') Buffer[26] = 'E'; else Buffer[26] = 'W';
				if (CallsignTo[4] < 'P') Buffer[17] = '0'; else Buffer[17] = '1';
				for (i = 0; i < 6; i++){
					if (CallsignTo[i] >= 'P') CallsignTo[i] -= 0x20;
					if (CallsignTo[i] >= 'A') CallsignTo[i] -= 0x11;
					if (i >= 4)
						Buffer[i+8] = CallsignTo[i];
					else
						Buffer[i+7] = CallsignTo[i];
				}
				buffer[11] = '.';

				Buffer[18] = ((Payload[1] - 28) / 10 ) + '0';
				Buffer[19] = ((Payload[1] - 28) % 10 ) + '0';
				Buffer[20] = ((Payload[2] - 28) / 10 ) + '0';
				Buffer[21] = ((Payload[2] - 28) % 10 ) + '0';
				Buffer[22] = '.';
				Buffer[23] = ((Payload[3] - 28) / 10 ) + '0';
				Buffer[24] = ((Payload[3] - 28) % 10 ) + '0';

			}


			c = 0;
			for (i = 0; Buffer[i] != 0; i++){
				if (i != 0) c = c ^ Buffer[i];
				while (!TRMT);
				putc (Buffer[i]);
			}

				while (!TRMT);
			   /*	printf ("*%X\r\n",c); */
				printf ("\r\n");
		}
		if (c == 0x0a | c == 0x0d | c == 0x00){
			NewMode (0);
			goto init;
		} else {
			NewMode (5);
		}

	}
	if (mode == 0){
		if (c == '>'){
			NewMode (1);
			goto dontprocess;
		}
		if (mode == 0 & CallsignPos == 9){
			NewMode (20);
			goto dontprocess;
		}
		if ( c == '-' | (c >= '0' & c <= '9') | (c >= 'A' & c <= 'Z') )
		{
			Callsign[CallsignPos] = c;
			CallsignPos ++;
		} else {
			NewMode (20);
			goto dontprocess;
		}

	}
	if (mode == 1){
		if (c == ':'){
			NewMode (3);
			goto dontprocess;
		}
		if (c == ','){
			NewMode (2);
			goto dontprocess;
		}

		if (mode == 1 & CallsignToPos == 9){
			NewMode (20);
		}
		CallsignTo[CallsignToPos] = c;
		CallsignToPos ++;

	}

	if (mode == 2){
		if (c == ':'){
			NewMode (3);
			goto dontprocess;
		}
		if (c == ','){
			NewMode (2);
			goto dontprocess;
		}

		if (mode == 2 & c != ',' & CallsignToPos == 9){
			NewMode (20);
		}
	}


	if (mode == 3){
		if (PayloadPos == 59){
			NewMode (4);
		}
		Payload[PayloadPos] = c;
		PayloadPos ++;

	}


dontprocess:

       mode = mode;
	}
  }


}
