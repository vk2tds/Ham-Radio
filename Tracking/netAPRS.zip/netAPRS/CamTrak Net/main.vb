Imports Microsoft.visualbasic
Imports System.Xml
Imports StormSource.Gps


Public Class frmmain
    Inherits System.Windows.Forms.Form

    Dim WithEvents CommTNC As SerialNET.Port




#Region " Windows Form Designer generated code "

    Public Sub New()
 
            MyBase.New()
        Try

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents FpTCPAPRSServerSpread As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpTCPAPRSServerSpread_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents tcpAPRSServer As Dart.PowerTCP.Sockets.Server
    Friend WithEvents cron As System.Windows.Forms.Timer
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents tcpAPRS As Dart.PowerTCP.Sockets.Tcp
    Friend WithEvents devMonitor As System.Windows.Forms.ListBox
    Friend WithEvents PortsList As System.Windows.Forms.ListBox
    Friend WithEvents FpPortsCrosspoint As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpPortsCrosspoint_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpDevGuiMaster As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpDevGuiMaster_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents mnuInterfacesOziSync As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInterfacesOziClear As System.Windows.Forms.MenuItem
    Friend WithEvents WebServer80 As Dart.PowerTCP.Sockets.Server
    Friend WithEvents mnuServAPRSServ As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServHub As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServGPRS As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServNetGPS As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServTNC As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServAGWPE As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServGPS As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServLog As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServDatabase As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServMapPoint As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServOzi As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServUIView As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInterfaceOziDecay As System.Windows.Forms.MenuItem
    Friend WithEvents tcpAGWPE As Dart.PowerTCP.Sockets.Tcp
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPopup As System.Windows.Forms.ContextMenu
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents mnuPopupAddStation As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopup As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem20 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopupQRZ As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopupFindU As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopupDynamic As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopupCancel As System.Windows.Forms.MenuItem
    Friend WithEvents txtPopupCallsign As System.Windows.Forms.TextBox
    Friend WithEvents mnuPopupFilter1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPopupMove As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem32 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInterfaceOziAutoTrail As System.Windows.Forms.MenuItem
    Friend WithEvents tcpGPRSserver As Dart.PowerTCP.Sockets.Server
    Friend WithEvents FpSpreadMessages As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpSpreadMessages_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents mnuServWx As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServRINO As System.Windows.Forms.MenuItem
    Friend WithEvents AxeWaypoint1 As AxEWAYPOINTLib.AxeWaypoint
    Friend WithEvents MenuItem34 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGUIdatabase As System.Windows.Forms.MenuItem
    Friend WithEvents FpCallsignTranslation As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpCallsignTranslation_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents mnuGuiTranslate As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiGeo As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileSetup As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServices As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGui As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiMonitored As System.Windows.Forms.MenuItem
    Friend WithEvents tabDisplayPositions As System.Windows.Forms.TabPage
    Friend WithEvents tabAllPositions As System.Windows.Forms.TabPage
    Friend WithEvents tabMessages As System.Windows.Forms.TabPage
    Friend WithEvents tabAPRSserver As System.Windows.Forms.TabPage
    Friend WithEvents tabMonitor As System.Windows.Forms.TabPage
    Friend WithEvents tabDevices As System.Windows.Forms.TabPage
    Friend WithEvents tabCallsignTranslation As System.Windows.Forms.TabPage
    Friend WithEvents mnuGuiState As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiStateSave As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiStateSaveFilename As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiStateLoad As System.Windows.Forms.MenuItem
    Friend WithEvents mnuGuiStateLoadFilename As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInterfaces As System.Windows.Forms.MenuItem
    Friend WithEvents mnuInterfacesOziExplorer As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpRegister As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPollNearby As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPopupAdd As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPopupCancel As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPopupMessage As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsign As System.Windows.Forms.MenuItem
    Friend WithEvents tabLanguages As System.Windows.Forms.TabPage
    Friend WithEvents FpLanguages As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpLanguages_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents mnuPopupFilter2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCallsignPoll As System.Windows.Forms.MenuItem
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents FpDevGuiDisplay As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpDevGuiDisplay_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents mnuServRealTrack As System.Windows.Forms.MenuItem
    Friend WithEvents tcpRealTrack As Dart.PowerTCP.Sockets.Server
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents mnuInterfaceOziGetGPS As System.Windows.Forms.MenuItem
    Friend WithEvents NMEAline As System.Windows.Forms.TextBox
    Friend WithEvents SatelliteViewer1 As StormSource.Gps.Controls.SatelliteViewer
    Friend WithEvents txtOziLon As System.Windows.Forms.TextBox
    Friend WithEvents txtOziLat As System.Windows.Forms.TextBox
    Friend WithEvents txtLon As System.Windows.Forms.TextBox
    Friend WithEvents txtLat As System.Windows.Forms.TextBox
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMapAtCursor As System.Windows.Forms.MenuItem
    Friend WithEvents mnuBestMapAtCursor As System.Windows.Forms.MenuItem
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents VideoPanel As System.Windows.Forms.Panel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProductBasic As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProductLive As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProductPro As System.Windows.Forms.MenuItem
    Friend WithEvents frmModeLive As System.Windows.Forms.MenuItem
    Friend WithEvents frmModePlayback As System.Windows.Forms.MenuItem
    Friend WithEvents frmModeRecording As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileLoad As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFilesave As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuServerAGWPE As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTNCcom As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTNCconnect As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTNCkiss As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem19 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTestClear As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Group As System.Windows.Forms.GroupBox
    Public WithEvents Command5 As System.Windows.Forms.Button
    Public WithEvents Command1 As System.Windows.Forms.Button
    Public WithEvents Command4 As System.Windows.Forms.Button
    Friend WithEvents Text2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmmain))
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim CheckBoxCellType1 As FarPoint.Win.Spread.CellType.CheckBoxCellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-15", "DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-16")
        Dim ComplexBorder1 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-17")
        Dim ComplexBorder2 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-18")
        Dim ComplexBorder3 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-19")
        Dim ComplexBorder4 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-20")
        Dim ComplexBorder5 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType6 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-21")
        Dim ComplexBorder6 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType7 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-22")
        Dim ComplexBorder7 As FarPoint.Win.ComplexBorder = New FarPoint.Win.ComplexBorder(New FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None, System.Drawing.Color.Black))
        Dim GeneralCellType8 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("Excel-0-23")
        Dim GeneralCellType9 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Me.tcpAPRSServer = New Dart.PowerTCP.Sockets.Server(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tabDisplayPositions = New System.Windows.Forms.TabPage
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.FpDevGuiDisplay = New FarPoint.Win.Spread.FpSpread
        Me.FpDevGuiDisplay_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.AxeWaypoint1 = New AxEWAYPOINTLib.AxeWaypoint
        Me.VideoPanel = New System.Windows.Forms.Panel
        Me.Group = New System.Windows.Forms.GroupBox
        Me.Command5 = New System.Windows.Forms.Button
        Me.Command1 = New System.Windows.Forms.Button
        Me.Command4 = New System.Windows.Forms.Button
        Me.Text2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.tabMessages = New System.Windows.Forms.TabPage
        Me.FpSpreadMessages = New FarPoint.Win.Spread.FpSpread
        Me.FpSpreadMessages_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.tabAllPositions = New System.Windows.Forms.TabPage
        Me.FpDevGuiMaster = New FarPoint.Win.Spread.FpSpread
        Me.FpDevGuiMaster_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.tabCallsignTranslation = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.FpCallsignTranslation = New FarPoint.Win.Spread.FpSpread
        Me.FpCallsignTranslation_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.tabAPRSserver = New System.Windows.Forms.TabPage
        Me.FpTCPAPRSServerSpread = New FarPoint.Win.Spread.FpSpread
        Me.FpTCPAPRSServerSpread_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.tabMonitor = New System.Windows.Forms.TabPage
        Me.devMonitor = New System.Windows.Forms.ListBox
        Me.tabDevices = New System.Windows.Forms.TabPage
        Me.FpPortsCrosspoint = New FarPoint.Win.Spread.FpSpread
        Me.FpPortsCrosspoint_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.PortsList = New System.Windows.Forms.ListBox
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.txtLat = New System.Windows.Forms.TextBox
        Me.txtLon = New System.Windows.Forms.TextBox
        Me.SatelliteViewer1 = New StormSource.Gps.Controls.SatelliteViewer
        Me.NMEAline = New System.Windows.Forms.TextBox
        Me.txtPopupCallsign = New System.Windows.Forms.TextBox
        Me.txtOziLon = New System.Windows.Forms.TextBox
        Me.txtOziLat = New System.Windows.Forms.TextBox
        Me.tabLanguages = New System.Windows.Forms.TabPage
        Me.FpLanguages = New FarPoint.Win.Spread.FpSpread
        Me.FpLanguages_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.cron = New System.Windows.Forms.Timer(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.mnuFile = New System.Windows.Forms.MenuItem
        Me.mnuFileSetup = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.mnuFileLoad = New System.Windows.Forms.MenuItem
        Me.mnuFilesave = New System.Windows.Forms.MenuItem
        Me.mnuServices = New System.Windows.Forms.MenuItem
        Me.mnuServAPRSServ = New System.Windows.Forms.MenuItem
        Me.mnuServAGWPE = New System.Windows.Forms.MenuItem
        Me.mnuServTNC = New System.Windows.Forms.MenuItem
        Me.mnuServGPS = New System.Windows.Forms.MenuItem
        Me.mnuServWx = New System.Windows.Forms.MenuItem
        Me.mnuServRINO = New System.Windows.Forms.MenuItem
        Me.mnuServDatabase = New System.Windows.Forms.MenuItem
        Me.mnuServUIView = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.mnuServOzi = New System.Windows.Forms.MenuItem
        Me.mnuServMapPoint = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.mnuServHub = New System.Windows.Forms.MenuItem
        Me.mnuServGPRS = New System.Windows.Forms.MenuItem
        Me.mnuServNetGPS = New System.Windows.Forms.MenuItem
        Me.mnuServRealTrack = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.mnuServLog = New System.Windows.Forms.MenuItem
        Me.mnuInterfaces = New System.Windows.Forms.MenuItem
        Me.mnuInterfacesOziExplorer = New System.Windows.Forms.MenuItem
        Me.mnuInterfacesOziSync = New System.Windows.Forms.MenuItem
        Me.mnuInterfacesOziClear = New System.Windows.Forms.MenuItem
        Me.mnuInterfaceOziDecay = New System.Windows.Forms.MenuItem
        Me.mnuInterfaceOziAutoTrail = New System.Windows.Forms.MenuItem
        Me.mnuInterfaceOziGetGPS = New System.Windows.Forms.MenuItem
        Me.mnuGui = New System.Windows.Forms.MenuItem
        Me.mnuGuiGeo = New System.Windows.Forms.MenuItem
        Me.mnuGuiMonitored = New System.Windows.Forms.MenuItem
        Me.mnuGuiTranslate = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.mnuGuiState = New System.Windows.Forms.MenuItem
        Me.mnuGuiStateSave = New System.Windows.Forms.MenuItem
        Me.mnuGuiStateSaveFilename = New System.Windows.Forms.MenuItem
        Me.mnuGuiStateLoad = New System.Windows.Forms.MenuItem
        Me.mnuGuiStateLoadFilename = New System.Windows.Forms.MenuItem
        Me.MenuItem34 = New System.Windows.Forms.MenuItem
        Me.mnuGUIdatabase = New System.Windows.Forms.MenuItem
        Me.mnuHelp = New System.Windows.Forms.MenuItem
        Me.mnuHelpRegister = New System.Windows.Forms.MenuItem
        Me.mnuHelpAbout = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.mnuProductBasic = New System.Windows.Forms.MenuItem
        Me.mnuProductLive = New System.Windows.Forms.MenuItem
        Me.mnuProductPro = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.frmModeLive = New System.Windows.Forms.MenuItem
        Me.frmModePlayback = New System.Windows.Forms.MenuItem
        Me.frmModeRecording = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.mnuServerAGWPE = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.mnuTNCcom = New System.Windows.Forms.MenuItem
        Me.mnuTNCconnect = New System.Windows.Forms.MenuItem
        Me.mnuTNCkiss = New System.Windows.Forms.MenuItem
        Me.MenuItem19 = New System.Windows.Forms.MenuItem
        Me.mnuTestClear = New System.Windows.Forms.MenuItem
        Me.tcpAPRS = New Dart.PowerTCP.Sockets.Tcp(Me.components)
        Me.WebServer80 = New Dart.PowerTCP.Sockets.Server(Me.components)
        Me.tcpAGWPE = New Dart.PowerTCP.Sockets.Tcp(Me.components)
        Me.mnuPopup = New System.Windows.Forms.ContextMenu
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.mnuMapAtCursor = New System.Windows.Forms.MenuItem
        Me.mnuBestMapAtCursor = New System.Windows.Forms.MenuItem
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.mnuPollNearby = New System.Windows.Forms.MenuItem
        Me.mnuPopupAdd = New System.Windows.Forms.MenuItem
        Me.mnuPopupAddStation = New System.Windows.Forms.MenuItem
        Me.mnuPopupMove = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.mnuPopupFilter1 = New System.Windows.Forms.MenuItem
        Me.mnuPopupFilter2 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.mnuPopupCancel = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopup = New System.Windows.Forms.ContextMenu
        Me.mnuCallsign = New System.Windows.Forms.MenuItem
        Me.MenuItem20 = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPoll = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopupQRZ = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopupFindU = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopupDynamic = New System.Windows.Forms.MenuItem
        Me.MenuItem32 = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopupMessage = New System.Windows.Forms.MenuItem
        Me.MenuItem24 = New System.Windows.Forms.MenuItem
        Me.mnuCallsignPopupCancel = New System.Windows.Forms.MenuItem
        Me.tcpGPRSserver = New Dart.PowerTCP.Sockets.Server(Me.components)
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog
        Me.tcpRealTrack = New Dart.PowerTCP.Sockets.Server(Me.components)
        Me.FontDialog1 = New System.Windows.Forms.FontDialog
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.TabControl1.SuspendLayout()
        Me.tabDisplayPositions.SuspendLayout()
        CType(Me.FpDevGuiDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpDevGuiDisplay_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxeWaypoint1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VideoPanel.SuspendLayout()
        Me.Group.SuspendLayout()
        Me.tabMessages.SuspendLayout()
        CType(Me.FpSpreadMessages, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpreadMessages_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAllPositions.SuspendLayout()
        CType(Me.FpDevGuiMaster, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpDevGuiMaster_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabCallsignTranslation.SuspendLayout()
        CType(Me.FpCallsignTranslation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpCallsignTranslation_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAPRSserver.SuspendLayout()
        CType(Me.FpTCPAPRSServerSpread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpTCPAPRSServerSpread_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabMonitor.SuspendLayout()
        Me.tabDevices.SuspendLayout()
        CType(Me.FpPortsCrosspoint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpPortsCrosspoint_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.tabLanguages.SuspendLayout()
        CType(Me.FpLanguages, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpLanguages_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tcpAPRSServer
        '
        Me.tcpAPRSServer.Editor = Me.tcpAPRSServer
        '
        'TabControl1
        '
        Me.TabControl1.AccessibleDescription = resources.GetString("TabControl1.AccessibleDescription")
        Me.TabControl1.AccessibleName = resources.GetString("TabControl1.AccessibleName")
        Me.TabControl1.Alignment = CType(resources.GetObject("TabControl1.Alignment"), System.Windows.Forms.TabAlignment)
        Me.TabControl1.Anchor = CType(resources.GetObject("TabControl1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Appearance = CType(resources.GetObject("TabControl1.Appearance"), System.Windows.Forms.TabAppearance)
        Me.TabControl1.BackgroundImage = CType(resources.GetObject("TabControl1.BackgroundImage"), System.Drawing.Image)
        Me.TabControl1.Controls.Add(Me.tabDisplayPositions)
        Me.TabControl1.Controls.Add(Me.tabMessages)
        Me.TabControl1.Controls.Add(Me.tabAllPositions)
        Me.TabControl1.Controls.Add(Me.tabCallsignTranslation)
        Me.TabControl1.Controls.Add(Me.tabAPRSserver)
        Me.TabControl1.Controls.Add(Me.tabMonitor)
        Me.TabControl1.Controls.Add(Me.tabDevices)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.tabLanguages)
        Me.TabControl1.Dock = CType(resources.GetObject("TabControl1.Dock"), System.Windows.Forms.DockStyle)
        Me.TabControl1.Enabled = CType(resources.GetObject("TabControl1.Enabled"), Boolean)
        Me.TabControl1.Font = CType(resources.GetObject("TabControl1.Font"), System.Drawing.Font)
        Me.TabControl1.ImeMode = CType(resources.GetObject("TabControl1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.TabControl1.ItemSize = CType(resources.GetObject("TabControl1.ItemSize"), System.Drawing.Size)
        Me.TabControl1.Location = CType(resources.GetObject("TabControl1.Location"), System.Drawing.Point)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = CType(resources.GetObject("TabControl1.Padding"), System.Drawing.Point)
        Me.TabControl1.RightToLeft = CType(resources.GetObject("TabControl1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = CType(resources.GetObject("TabControl1.ShowToolTips"), Boolean)
        Me.TabControl1.Size = CType(resources.GetObject("TabControl1.Size"), System.Drawing.Size)
        Me.TabControl1.TabIndex = CType(resources.GetObject("TabControl1.TabIndex"), Integer)
        Me.TabControl1.Text = resources.GetString("TabControl1.Text")
        Me.TabControl1.Visible = CType(resources.GetObject("TabControl1.Visible"), Boolean)
        '
        'tabDisplayPositions
        '
        Me.tabDisplayPositions.AccessibleDescription = resources.GetString("tabDisplayPositions.AccessibleDescription")
        Me.tabDisplayPositions.AccessibleName = resources.GetString("tabDisplayPositions.AccessibleName")
        Me.tabDisplayPositions.Anchor = CType(resources.GetObject("tabDisplayPositions.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabDisplayPositions.AutoScroll = CType(resources.GetObject("tabDisplayPositions.AutoScroll"), Boolean)
        Me.tabDisplayPositions.AutoScrollMargin = CType(resources.GetObject("tabDisplayPositions.AutoScrollMargin"), System.Drawing.Size)
        Me.tabDisplayPositions.AutoScrollMinSize = CType(resources.GetObject("tabDisplayPositions.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabDisplayPositions.BackgroundImage = CType(resources.GetObject("tabDisplayPositions.BackgroundImage"), System.Drawing.Image)
        Me.tabDisplayPositions.Controls.Add(Me.StatusBar1)
        Me.tabDisplayPositions.Controls.Add(Me.FpDevGuiDisplay)
        Me.tabDisplayPositions.Controls.Add(Me.AxeWaypoint1)
        Me.tabDisplayPositions.Controls.Add(Me.VideoPanel)
        Me.tabDisplayPositions.Dock = CType(resources.GetObject("tabDisplayPositions.Dock"), System.Windows.Forms.DockStyle)
        Me.tabDisplayPositions.Enabled = CType(resources.GetObject("tabDisplayPositions.Enabled"), Boolean)
        Me.tabDisplayPositions.Font = CType(resources.GetObject("tabDisplayPositions.Font"), System.Drawing.Font)
        Me.tabDisplayPositions.ImageIndex = CType(resources.GetObject("tabDisplayPositions.ImageIndex"), Integer)
        Me.tabDisplayPositions.ImeMode = CType(resources.GetObject("tabDisplayPositions.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabDisplayPositions.Location = CType(resources.GetObject("tabDisplayPositions.Location"), System.Drawing.Point)
        Me.tabDisplayPositions.Name = "tabDisplayPositions"
        Me.tabDisplayPositions.RightToLeft = CType(resources.GetObject("tabDisplayPositions.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabDisplayPositions.Size = CType(resources.GetObject("tabDisplayPositions.Size"), System.Drawing.Size)
        Me.tabDisplayPositions.TabIndex = CType(resources.GetObject("tabDisplayPositions.TabIndex"), Integer)
        Me.tabDisplayPositions.Text = resources.GetString("tabDisplayPositions.Text")
        Me.tabDisplayPositions.ToolTipText = resources.GetString("tabDisplayPositions.ToolTipText")
        Me.tabDisplayPositions.Visible = CType(resources.GetObject("tabDisplayPositions.Visible"), Boolean)
        '
        'StatusBar1
        '
        Me.StatusBar1.AccessibleDescription = resources.GetString("StatusBar1.AccessibleDescription")
        Me.StatusBar1.AccessibleName = resources.GetString("StatusBar1.AccessibleName")
        Me.StatusBar1.Anchor = CType(resources.GetObject("StatusBar1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.StatusBar1.BackgroundImage = CType(resources.GetObject("StatusBar1.BackgroundImage"), System.Drawing.Image)
        Me.StatusBar1.Dock = CType(resources.GetObject("StatusBar1.Dock"), System.Windows.Forms.DockStyle)
        Me.StatusBar1.Enabled = CType(resources.GetObject("StatusBar1.Enabled"), Boolean)
        Me.StatusBar1.Font = CType(resources.GetObject("StatusBar1.Font"), System.Drawing.Font)
        Me.StatusBar1.ImeMode = CType(resources.GetObject("StatusBar1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.StatusBar1.Location = CType(resources.GetObject("StatusBar1.Location"), System.Drawing.Point)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.RightToLeft = CType(resources.GetObject("StatusBar1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StatusBar1.Size = CType(resources.GetObject("StatusBar1.Size"), System.Drawing.Size)
        Me.StatusBar1.TabIndex = CType(resources.GetObject("StatusBar1.TabIndex"), Integer)
        Me.StatusBar1.Text = resources.GetString("StatusBar1.Text")
        Me.StatusBar1.Visible = CType(resources.GetObject("StatusBar1.Visible"), Boolean)
        '
        'FpDevGuiDisplay
        '
        Me.FpDevGuiDisplay.AccessibleDescription = resources.GetString("FpDevGuiDisplay.AccessibleDescription")
        Me.FpDevGuiDisplay.AccessibleName = resources.GetString("FpDevGuiDisplay.AccessibleName")
        Me.FpDevGuiDisplay.Anchor = CType(resources.GetObject("FpDevGuiDisplay.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpDevGuiDisplay.BackgroundImage = CType(resources.GetObject("FpDevGuiDisplay.BackgroundImage"), System.Drawing.Image)
        Me.FpDevGuiDisplay.Dock = CType(resources.GetObject("FpDevGuiDisplay.Dock"), System.Windows.Forms.DockStyle)
        Me.FpDevGuiDisplay.Enabled = CType(resources.GetObject("FpDevGuiDisplay.Enabled"), Boolean)
        Me.FpDevGuiDisplay.Font = CType(resources.GetObject("FpDevGuiDisplay.Font"), System.Drawing.Font)
        Me.FpDevGuiDisplay.ImeMode = CType(resources.GetObject("FpDevGuiDisplay.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpDevGuiDisplay.Location = CType(resources.GetObject("FpDevGuiDisplay.Location"), System.Drawing.Point)
        Me.FpDevGuiDisplay.Name = "FpDevGuiDisplay"
        Me.FpDevGuiDisplay.RightToLeft = CType(resources.GetObject("FpDevGuiDisplay.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpDevGuiDisplay.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpDevGuiDisplay_Sheet1})
        Me.FpDevGuiDisplay.Size = CType(resources.GetObject("FpDevGuiDisplay.Size"), System.Drawing.Size)
        Me.FpDevGuiDisplay.TabIndex = CType(resources.GetObject("FpDevGuiDisplay.TabIndex"), Integer)
        Me.FpDevGuiDisplay.Visible = CType(resources.GetObject("FpDevGuiDisplay.Visible"), Boolean)
        '
        'FpDevGuiDisplay_Sheet1
        '
        Me.FpDevGuiDisplay_Sheet1.Reset()
        Me.FpDevGuiDisplay_Sheet1.DefaultStyle.CellType = TextCellType1
        Me.FpDevGuiDisplay_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpDevGuiDisplay_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpDevGuiDisplay_Sheet1.SheetName = "Sheet1"
        '
        'AxeWaypoint1
        '
        Me.AxeWaypoint1.AccessibleDescription = resources.GetString("AxeWaypoint1.AccessibleDescription")
        Me.AxeWaypoint1.AccessibleName = resources.GetString("AxeWaypoint1.AccessibleName")
        Me.AxeWaypoint1.Anchor = CType(resources.GetObject("AxeWaypoint1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.AxeWaypoint1.BackgroundImage = CType(resources.GetObject("AxeWaypoint1.BackgroundImage"), System.Drawing.Image)
        Me.AxeWaypoint1.ContainingControl = Me
        Me.AxeWaypoint1.Dock = CType(resources.GetObject("AxeWaypoint1.Dock"), System.Windows.Forms.DockStyle)
        Me.AxeWaypoint1.Enabled = CType(resources.GetObject("AxeWaypoint1.Enabled"), Boolean)
        Me.AxeWaypoint1.Font = CType(resources.GetObject("AxeWaypoint1.Font"), System.Drawing.Font)
        Me.AxeWaypoint1.ImeMode = CType(resources.GetObject("AxeWaypoint1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.AxeWaypoint1.Location = CType(resources.GetObject("AxeWaypoint1.Location"), System.Drawing.Point)
        Me.AxeWaypoint1.Name = "AxeWaypoint1"
        Me.AxeWaypoint1.OcxState = CType(resources.GetObject("AxeWaypoint1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxeWaypoint1.RightToLeft = CType(resources.GetObject("AxeWaypoint1.RightToLeft"), Boolean)
        Me.AxeWaypoint1.Size = CType(resources.GetObject("AxeWaypoint1.Size"), System.Drawing.Size)
        Me.AxeWaypoint1.TabIndex = CType(resources.GetObject("AxeWaypoint1.TabIndex"), Integer)
        Me.AxeWaypoint1.Text = resources.GetString("AxeWaypoint1.Text")
        Me.AxeWaypoint1.Visible = CType(resources.GetObject("AxeWaypoint1.Visible"), Boolean)
        '
        'VideoPanel
        '
        Me.VideoPanel.AccessibleDescription = resources.GetString("VideoPanel.AccessibleDescription")
        Me.VideoPanel.AccessibleName = resources.GetString("VideoPanel.AccessibleName")
        Me.VideoPanel.Anchor = CType(resources.GetObject("VideoPanel.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.VideoPanel.AutoScroll = CType(resources.GetObject("VideoPanel.AutoScroll"), Boolean)
        Me.VideoPanel.AutoScrollMargin = CType(resources.GetObject("VideoPanel.AutoScrollMargin"), System.Drawing.Size)
        Me.VideoPanel.AutoScrollMinSize = CType(resources.GetObject("VideoPanel.AutoScrollMinSize"), System.Drawing.Size)
        Me.VideoPanel.BackgroundImage = CType(resources.GetObject("VideoPanel.BackgroundImage"), System.Drawing.Image)
        Me.VideoPanel.Controls.Add(Me.Group)
        Me.VideoPanel.Dock = CType(resources.GetObject("VideoPanel.Dock"), System.Windows.Forms.DockStyle)
        Me.VideoPanel.Enabled = CType(resources.GetObject("VideoPanel.Enabled"), Boolean)
        Me.VideoPanel.Font = CType(resources.GetObject("VideoPanel.Font"), System.Drawing.Font)
        Me.VideoPanel.ImeMode = CType(resources.GetObject("VideoPanel.ImeMode"), System.Windows.Forms.ImeMode)
        Me.VideoPanel.Location = CType(resources.GetObject("VideoPanel.Location"), System.Drawing.Point)
        Me.VideoPanel.Name = "VideoPanel"
        Me.VideoPanel.RightToLeft = CType(resources.GetObject("VideoPanel.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.VideoPanel.Size = CType(resources.GetObject("VideoPanel.Size"), System.Drawing.Size)
        Me.VideoPanel.TabIndex = CType(resources.GetObject("VideoPanel.TabIndex"), Integer)
        Me.VideoPanel.Text = resources.GetString("VideoPanel.Text")
        Me.VideoPanel.Visible = CType(resources.GetObject("VideoPanel.Visible"), Boolean)
        '
        'Group
        '
        Me.Group.AccessibleDescription = resources.GetString("Group.AccessibleDescription")
        Me.Group.AccessibleName = resources.GetString("Group.AccessibleName")
        Me.Group.Anchor = CType(resources.GetObject("Group.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Group.BackgroundImage = CType(resources.GetObject("Group.BackgroundImage"), System.Drawing.Image)
        Me.Group.Controls.Add(Me.Command5)
        Me.Group.Controls.Add(Me.Command1)
        Me.Group.Controls.Add(Me.Command4)
        Me.Group.Controls.Add(Me.Text2)
        Me.Group.Controls.Add(Me.Label1)
        Me.Group.Dock = CType(resources.GetObject("Group.Dock"), System.Windows.Forms.DockStyle)
        Me.Group.Enabled = CType(resources.GetObject("Group.Enabled"), Boolean)
        Me.Group.Font = CType(resources.GetObject("Group.Font"), System.Drawing.Font)
        Me.Group.ImeMode = CType(resources.GetObject("Group.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Group.Location = CType(resources.GetObject("Group.Location"), System.Drawing.Point)
        Me.Group.Name = "Group"
        Me.Group.RightToLeft = CType(resources.GetObject("Group.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Group.Size = CType(resources.GetObject("Group.Size"), System.Drawing.Size)
        Me.Group.TabIndex = CType(resources.GetObject("Group.TabIndex"), Integer)
        Me.Group.TabStop = False
        Me.Group.Text = resources.GetString("Group.Text")
        Me.Group.Visible = CType(resources.GetObject("Group.Visible"), Boolean)
        '
        'Command5
        '
        Me.Command5.AccessibleDescription = resources.GetString("Command5.AccessibleDescription")
        Me.Command5.AccessibleName = resources.GetString("Command5.AccessibleName")
        Me.Command5.Anchor = CType(resources.GetObject("Command5.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Command5.BackColor = System.Drawing.SystemColors.Control
        Me.Command5.BackgroundImage = CType(resources.GetObject("Command5.BackgroundImage"), System.Drawing.Image)
        Me.Command5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command5.Dock = CType(resources.GetObject("Command5.Dock"), System.Windows.Forms.DockStyle)
        Me.Command5.Enabled = CType(resources.GetObject("Command5.Enabled"), Boolean)
        Me.Command5.FlatStyle = CType(resources.GetObject("Command5.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.Command5.Font = CType(resources.GetObject("Command5.Font"), System.Drawing.Font)
        Me.Command5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command5.Image = CType(resources.GetObject("Command5.Image"), System.Drawing.Image)
        Me.Command5.ImageAlign = CType(resources.GetObject("Command5.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Command5.ImageIndex = CType(resources.GetObject("Command5.ImageIndex"), Integer)
        Me.Command5.ImeMode = CType(resources.GetObject("Command5.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Command5.Location = CType(resources.GetObject("Command5.Location"), System.Drawing.Point)
        Me.Command5.Name = "Command5"
        Me.Command5.RightToLeft = CType(resources.GetObject("Command5.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Command5.Size = CType(resources.GetObject("Command5.Size"), System.Drawing.Size)
        Me.Command5.TabIndex = CType(resources.GetObject("Command5.TabIndex"), Integer)
        Me.Command5.Text = resources.GetString("Command5.Text")
        Me.Command5.TextAlign = CType(resources.GetObject("Command5.TextAlign"), System.Drawing.ContentAlignment)
        Me.Command5.Visible = CType(resources.GetObject("Command5.Visible"), Boolean)
        '
        'Command1
        '
        Me.Command1.AccessibleDescription = resources.GetString("Command1.AccessibleDescription")
        Me.Command1.AccessibleName = resources.GetString("Command1.AccessibleName")
        Me.Command1.Anchor = CType(resources.GetObject("Command1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.BackgroundImage = CType(resources.GetObject("Command1.BackgroundImage"), System.Drawing.Image)
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Dock = CType(resources.GetObject("Command1.Dock"), System.Windows.Forms.DockStyle)
        Me.Command1.Enabled = CType(resources.GetObject("Command1.Enabled"), Boolean)
        Me.Command1.FlatStyle = CType(resources.GetObject("Command1.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.Command1.Font = CType(resources.GetObject("Command1.Font"), System.Drawing.Font)
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Image = CType(resources.GetObject("Command1.Image"), System.Drawing.Image)
        Me.Command1.ImageAlign = CType(resources.GetObject("Command1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Command1.ImageIndex = CType(resources.GetObject("Command1.ImageIndex"), Integer)
        Me.Command1.ImeMode = CType(resources.GetObject("Command1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Command1.Location = CType(resources.GetObject("Command1.Location"), System.Drawing.Point)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = CType(resources.GetObject("Command1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Command1.Size = CType(resources.GetObject("Command1.Size"), System.Drawing.Size)
        Me.Command1.TabIndex = CType(resources.GetObject("Command1.TabIndex"), Integer)
        Me.Command1.Text = resources.GetString("Command1.Text")
        Me.Command1.TextAlign = CType(resources.GetObject("Command1.TextAlign"), System.Drawing.ContentAlignment)
        Me.Command1.Visible = CType(resources.GetObject("Command1.Visible"), Boolean)
        '
        'Command4
        '
        Me.Command4.AccessibleDescription = resources.GetString("Command4.AccessibleDescription")
        Me.Command4.AccessibleName = resources.GetString("Command4.AccessibleName")
        Me.Command4.Anchor = CType(resources.GetObject("Command4.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Command4.BackColor = System.Drawing.SystemColors.Control
        Me.Command4.BackgroundImage = CType(resources.GetObject("Command4.BackgroundImage"), System.Drawing.Image)
        Me.Command4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command4.Dock = CType(resources.GetObject("Command4.Dock"), System.Windows.Forms.DockStyle)
        Me.Command4.Enabled = CType(resources.GetObject("Command4.Enabled"), Boolean)
        Me.Command4.FlatStyle = CType(resources.GetObject("Command4.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.Command4.Font = CType(resources.GetObject("Command4.Font"), System.Drawing.Font)
        Me.Command4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command4.Image = CType(resources.GetObject("Command4.Image"), System.Drawing.Image)
        Me.Command4.ImageAlign = CType(resources.GetObject("Command4.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Command4.ImageIndex = CType(resources.GetObject("Command4.ImageIndex"), Integer)
        Me.Command4.ImeMode = CType(resources.GetObject("Command4.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Command4.Location = CType(resources.GetObject("Command4.Location"), System.Drawing.Point)
        Me.Command4.Name = "Command4"
        Me.Command4.RightToLeft = CType(resources.GetObject("Command4.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Command4.Size = CType(resources.GetObject("Command4.Size"), System.Drawing.Size)
        Me.Command4.TabIndex = CType(resources.GetObject("Command4.TabIndex"), Integer)
        Me.Command4.Text = resources.GetString("Command4.Text")
        Me.Command4.TextAlign = CType(resources.GetObject("Command4.TextAlign"), System.Drawing.ContentAlignment)
        Me.Command4.Visible = CType(resources.GetObject("Command4.Visible"), Boolean)
        '
        'Text2
        '
        Me.Text2.AccessibleDescription = resources.GetString("Text2.AccessibleDescription")
        Me.Text2.AccessibleName = resources.GetString("Text2.AccessibleName")
        Me.Text2.Anchor = CType(resources.GetObject("Text2.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Text2.AutoSize = CType(resources.GetObject("Text2.AutoSize"), Boolean)
        Me.Text2.Dock = CType(resources.GetObject("Text2.Dock"), System.Windows.Forms.DockStyle)
        Me.Text2.Enabled = CType(resources.GetObject("Text2.Enabled"), Boolean)
        Me.Text2.Font = CType(resources.GetObject("Text2.Font"), System.Drawing.Font)
        Me.Text2.Image = CType(resources.GetObject("Text2.Image"), System.Drawing.Image)
        Me.Text2.ImageAlign = CType(resources.GetObject("Text2.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Text2.ImageIndex = CType(resources.GetObject("Text2.ImageIndex"), Integer)
        Me.Text2.ImeMode = CType(resources.GetObject("Text2.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Text2.Location = CType(resources.GetObject("Text2.Location"), System.Drawing.Point)
        Me.Text2.Name = "Text2"
        Me.Text2.RightToLeft = CType(resources.GetObject("Text2.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Text2.Size = CType(resources.GetObject("Text2.Size"), System.Drawing.Size)
        Me.Text2.TabIndex = CType(resources.GetObject("Text2.TabIndex"), Integer)
        Me.Text2.Text = resources.GetString("Text2.Text")
        Me.Text2.TextAlign = CType(resources.GetObject("Text2.TextAlign"), System.Drawing.ContentAlignment)
        Me.Text2.Visible = CType(resources.GetObject("Text2.Visible"), Boolean)
        '
        'Label1
        '
        Me.Label1.AccessibleDescription = resources.GetString("Label1.AccessibleDescription")
        Me.Label1.AccessibleName = resources.GetString("Label1.AccessibleName")
        Me.Label1.Anchor = CType(resources.GetObject("Label1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = CType(resources.GetObject("Label1.AutoSize"), Boolean)
        Me.Label1.Dock = CType(resources.GetObject("Label1.Dock"), System.Windows.Forms.DockStyle)
        Me.Label1.Enabled = CType(resources.GetObject("Label1.Enabled"), Boolean)
        Me.Label1.Font = CType(resources.GetObject("Label1.Font"), System.Drawing.Font)
        Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
        Me.Label1.ImageAlign = CType(resources.GetObject("Label1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Label1.ImageIndex = CType(resources.GetObject("Label1.ImageIndex"), Integer)
        Me.Label1.ImeMode = CType(resources.GetObject("Label1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Label1.Location = CType(resources.GetObject("Label1.Location"), System.Drawing.Point)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = CType(resources.GetObject("Label1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Label1.Size = CType(resources.GetObject("Label1.Size"), System.Drawing.Size)
        Me.Label1.TabIndex = CType(resources.GetObject("Label1.TabIndex"), Integer)
        Me.Label1.Text = resources.GetString("Label1.Text")
        Me.Label1.TextAlign = CType(resources.GetObject("Label1.TextAlign"), System.Drawing.ContentAlignment)
        Me.Label1.Visible = CType(resources.GetObject("Label1.Visible"), Boolean)
        '
        'tabMessages
        '
        Me.tabMessages.AccessibleDescription = resources.GetString("tabMessages.AccessibleDescription")
        Me.tabMessages.AccessibleName = resources.GetString("tabMessages.AccessibleName")
        Me.tabMessages.Anchor = CType(resources.GetObject("tabMessages.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabMessages.AutoScroll = CType(resources.GetObject("tabMessages.AutoScroll"), Boolean)
        Me.tabMessages.AutoScrollMargin = CType(resources.GetObject("tabMessages.AutoScrollMargin"), System.Drawing.Size)
        Me.tabMessages.AutoScrollMinSize = CType(resources.GetObject("tabMessages.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabMessages.BackgroundImage = CType(resources.GetObject("tabMessages.BackgroundImage"), System.Drawing.Image)
        Me.tabMessages.Controls.Add(Me.FpSpreadMessages)
        Me.tabMessages.Dock = CType(resources.GetObject("tabMessages.Dock"), System.Windows.Forms.DockStyle)
        Me.tabMessages.Enabled = CType(resources.GetObject("tabMessages.Enabled"), Boolean)
        Me.tabMessages.Font = CType(resources.GetObject("tabMessages.Font"), System.Drawing.Font)
        Me.tabMessages.ImageIndex = CType(resources.GetObject("tabMessages.ImageIndex"), Integer)
        Me.tabMessages.ImeMode = CType(resources.GetObject("tabMessages.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabMessages.Location = CType(resources.GetObject("tabMessages.Location"), System.Drawing.Point)
        Me.tabMessages.Name = "tabMessages"
        Me.tabMessages.RightToLeft = CType(resources.GetObject("tabMessages.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabMessages.Size = CType(resources.GetObject("tabMessages.Size"), System.Drawing.Size)
        Me.tabMessages.TabIndex = CType(resources.GetObject("tabMessages.TabIndex"), Integer)
        Me.tabMessages.Text = resources.GetString("tabMessages.Text")
        Me.tabMessages.ToolTipText = resources.GetString("tabMessages.ToolTipText")
        Me.tabMessages.Visible = CType(resources.GetObject("tabMessages.Visible"), Boolean)
        '
        'FpSpreadMessages
        '
        Me.FpSpreadMessages.AccessibleDescription = resources.GetString("FpSpreadMessages.AccessibleDescription")
        Me.FpSpreadMessages.AccessibleName = resources.GetString("FpSpreadMessages.AccessibleName")
        Me.FpSpreadMessages.Anchor = CType(resources.GetObject("FpSpreadMessages.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpSpreadMessages.BackgroundImage = CType(resources.GetObject("FpSpreadMessages.BackgroundImage"), System.Drawing.Image)
        Me.FpSpreadMessages.Dock = CType(resources.GetObject("FpSpreadMessages.Dock"), System.Windows.Forms.DockStyle)
        Me.FpSpreadMessages.Enabled = CType(resources.GetObject("FpSpreadMessages.Enabled"), Boolean)
        Me.FpSpreadMessages.Font = CType(resources.GetObject("FpSpreadMessages.Font"), System.Drawing.Font)
        Me.FpSpreadMessages.ImeMode = CType(resources.GetObject("FpSpreadMessages.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpSpreadMessages.Location = CType(resources.GetObject("FpSpreadMessages.Location"), System.Drawing.Point)
        Me.FpSpreadMessages.Name = "FpSpreadMessages"
        Me.FpSpreadMessages.RightToLeft = CType(resources.GetObject("FpSpreadMessages.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpSpreadMessages.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpSpreadMessages_Sheet1})
        Me.FpSpreadMessages.Size = CType(resources.GetObject("FpSpreadMessages.Size"), System.Drawing.Size)
        Me.FpSpreadMessages.TabIndex = CType(resources.GetObject("FpSpreadMessages.TabIndex"), Integer)
        Me.FpSpreadMessages.Visible = CType(resources.GetObject("FpSpreadMessages.Visible"), Boolean)
        '
        'FpSpreadMessages_Sheet1
        '
        Me.FpSpreadMessages_Sheet1.Reset()
        Me.FpSpreadMessages_Sheet1.SheetName = "Sheet1"
        '
        'tabAllPositions
        '
        Me.tabAllPositions.AccessibleDescription = resources.GetString("tabAllPositions.AccessibleDescription")
        Me.tabAllPositions.AccessibleName = resources.GetString("tabAllPositions.AccessibleName")
        Me.tabAllPositions.Anchor = CType(resources.GetObject("tabAllPositions.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabAllPositions.AutoScroll = CType(resources.GetObject("tabAllPositions.AutoScroll"), Boolean)
        Me.tabAllPositions.AutoScrollMargin = CType(resources.GetObject("tabAllPositions.AutoScrollMargin"), System.Drawing.Size)
        Me.tabAllPositions.AutoScrollMinSize = CType(resources.GetObject("tabAllPositions.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabAllPositions.BackgroundImage = CType(resources.GetObject("tabAllPositions.BackgroundImage"), System.Drawing.Image)
        Me.tabAllPositions.Controls.Add(Me.FpDevGuiMaster)
        Me.tabAllPositions.Dock = CType(resources.GetObject("tabAllPositions.Dock"), System.Windows.Forms.DockStyle)
        Me.tabAllPositions.Enabled = CType(resources.GetObject("tabAllPositions.Enabled"), Boolean)
        Me.tabAllPositions.Font = CType(resources.GetObject("tabAllPositions.Font"), System.Drawing.Font)
        Me.tabAllPositions.ImageIndex = CType(resources.GetObject("tabAllPositions.ImageIndex"), Integer)
        Me.tabAllPositions.ImeMode = CType(resources.GetObject("tabAllPositions.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabAllPositions.Location = CType(resources.GetObject("tabAllPositions.Location"), System.Drawing.Point)
        Me.tabAllPositions.Name = "tabAllPositions"
        Me.tabAllPositions.RightToLeft = CType(resources.GetObject("tabAllPositions.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabAllPositions.Size = CType(resources.GetObject("tabAllPositions.Size"), System.Drawing.Size)
        Me.tabAllPositions.TabIndex = CType(resources.GetObject("tabAllPositions.TabIndex"), Integer)
        Me.tabAllPositions.Text = resources.GetString("tabAllPositions.Text")
        Me.tabAllPositions.ToolTipText = resources.GetString("tabAllPositions.ToolTipText")
        Me.tabAllPositions.Visible = CType(resources.GetObject("tabAllPositions.Visible"), Boolean)
        '
        'FpDevGuiMaster
        '
        Me.FpDevGuiMaster.AccessibleDescription = resources.GetString("FpDevGuiMaster.AccessibleDescription")
        Me.FpDevGuiMaster.AccessibleName = resources.GetString("FpDevGuiMaster.AccessibleName")
        Me.FpDevGuiMaster.Anchor = CType(resources.GetObject("FpDevGuiMaster.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpDevGuiMaster.BackgroundImage = CType(resources.GetObject("FpDevGuiMaster.BackgroundImage"), System.Drawing.Image)
        Me.FpDevGuiMaster.Dock = CType(resources.GetObject("FpDevGuiMaster.Dock"), System.Windows.Forms.DockStyle)
        Me.FpDevGuiMaster.Enabled = CType(resources.GetObject("FpDevGuiMaster.Enabled"), Boolean)
        Me.FpDevGuiMaster.Font = CType(resources.GetObject("FpDevGuiMaster.Font"), System.Drawing.Font)
        Me.FpDevGuiMaster.ImeMode = CType(resources.GetObject("FpDevGuiMaster.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpDevGuiMaster.Location = CType(resources.GetObject("FpDevGuiMaster.Location"), System.Drawing.Point)
        Me.FpDevGuiMaster.Name = "FpDevGuiMaster"
        Me.FpDevGuiMaster.RightToLeft = CType(resources.GetObject("FpDevGuiMaster.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpDevGuiMaster.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpDevGuiMaster_Sheet1})
        Me.FpDevGuiMaster.Size = CType(resources.GetObject("FpDevGuiMaster.Size"), System.Drawing.Size)
        Me.FpDevGuiMaster.TabIndex = CType(resources.GetObject("FpDevGuiMaster.TabIndex"), Integer)
        Me.FpDevGuiMaster.Visible = CType(resources.GetObject("FpDevGuiMaster.Visible"), Boolean)
        '
        'FpDevGuiMaster_Sheet1
        '
        Me.FpDevGuiMaster_Sheet1.Reset()
        TextCellType2.AcceptsArrowKeys = FarPoint.Win.SuperEdit.AcceptsArrowKeys.Arrows
        Me.FpDevGuiMaster_Sheet1.DefaultStyle.CellType = TextCellType2
        Me.FpDevGuiMaster_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpDevGuiMaster_Sheet1.SheetName = "Sheet1"
        '
        'tabCallsignTranslation
        '
        Me.tabCallsignTranslation.AccessibleDescription = resources.GetString("tabCallsignTranslation.AccessibleDescription")
        Me.tabCallsignTranslation.AccessibleName = resources.GetString("tabCallsignTranslation.AccessibleName")
        Me.tabCallsignTranslation.Anchor = CType(resources.GetObject("tabCallsignTranslation.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabCallsignTranslation.AutoScroll = CType(resources.GetObject("tabCallsignTranslation.AutoScroll"), Boolean)
        Me.tabCallsignTranslation.AutoScrollMargin = CType(resources.GetObject("tabCallsignTranslation.AutoScrollMargin"), System.Drawing.Size)
        Me.tabCallsignTranslation.AutoScrollMinSize = CType(resources.GetObject("tabCallsignTranslation.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabCallsignTranslation.BackgroundImage = CType(resources.GetObject("tabCallsignTranslation.BackgroundImage"), System.Drawing.Image)
        Me.tabCallsignTranslation.Controls.Add(Me.Button1)
        Me.tabCallsignTranslation.Controls.Add(Me.FpCallsignTranslation)
        Me.tabCallsignTranslation.Dock = CType(resources.GetObject("tabCallsignTranslation.Dock"), System.Windows.Forms.DockStyle)
        Me.tabCallsignTranslation.Enabled = CType(resources.GetObject("tabCallsignTranslation.Enabled"), Boolean)
        Me.tabCallsignTranslation.Font = CType(resources.GetObject("tabCallsignTranslation.Font"), System.Drawing.Font)
        Me.tabCallsignTranslation.ImageIndex = CType(resources.GetObject("tabCallsignTranslation.ImageIndex"), Integer)
        Me.tabCallsignTranslation.ImeMode = CType(resources.GetObject("tabCallsignTranslation.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabCallsignTranslation.Location = CType(resources.GetObject("tabCallsignTranslation.Location"), System.Drawing.Point)
        Me.tabCallsignTranslation.Name = "tabCallsignTranslation"
        Me.tabCallsignTranslation.RightToLeft = CType(resources.GetObject("tabCallsignTranslation.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabCallsignTranslation.Size = CType(resources.GetObject("tabCallsignTranslation.Size"), System.Drawing.Size)
        Me.tabCallsignTranslation.TabIndex = CType(resources.GetObject("tabCallsignTranslation.TabIndex"), Integer)
        Me.tabCallsignTranslation.Text = resources.GetString("tabCallsignTranslation.Text")
        Me.tabCallsignTranslation.ToolTipText = resources.GetString("tabCallsignTranslation.ToolTipText")
        Me.tabCallsignTranslation.Visible = CType(resources.GetObject("tabCallsignTranslation.Visible"), Boolean)
        '
        'Button1
        '
        Me.Button1.AccessibleDescription = resources.GetString("Button1.AccessibleDescription")
        Me.Button1.AccessibleName = resources.GetString("Button1.AccessibleName")
        Me.Button1.Anchor = CType(resources.GetObject("Button1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.Dock = CType(resources.GetObject("Button1.Dock"), System.Windows.Forms.DockStyle)
        Me.Button1.Enabled = CType(resources.GetObject("Button1.Enabled"), Boolean)
        Me.Button1.FlatStyle = CType(resources.GetObject("Button1.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.Button1.Font = CType(resources.GetObject("Button1.Font"), System.Drawing.Font)
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = CType(resources.GetObject("Button1.ImageAlign"), System.Drawing.ContentAlignment)
        Me.Button1.ImageIndex = CType(resources.GetObject("Button1.ImageIndex"), Integer)
        Me.Button1.ImeMode = CType(resources.GetObject("Button1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Button1.Location = CType(resources.GetObject("Button1.Location"), System.Drawing.Point)
        Me.Button1.Name = "Button1"
        Me.Button1.RightToLeft = CType(resources.GetObject("Button1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Button1.Size = CType(resources.GetObject("Button1.Size"), System.Drawing.Size)
        Me.Button1.TabIndex = CType(resources.GetObject("Button1.TabIndex"), Integer)
        Me.Button1.Text = resources.GetString("Button1.Text")
        Me.Button1.TextAlign = CType(resources.GetObject("Button1.TextAlign"), System.Drawing.ContentAlignment)
        Me.Button1.Visible = CType(resources.GetObject("Button1.Visible"), Boolean)
        '
        'FpCallsignTranslation
        '
        Me.FpCallsignTranslation.AccessibleDescription = resources.GetString("FpCallsignTranslation.AccessibleDescription")
        Me.FpCallsignTranslation.AccessibleName = resources.GetString("FpCallsignTranslation.AccessibleName")
        Me.FpCallsignTranslation.Anchor = CType(resources.GetObject("FpCallsignTranslation.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpCallsignTranslation.BackgroundImage = CType(resources.GetObject("FpCallsignTranslation.BackgroundImage"), System.Drawing.Image)
        Me.FpCallsignTranslation.Dock = CType(resources.GetObject("FpCallsignTranslation.Dock"), System.Windows.Forms.DockStyle)
        Me.FpCallsignTranslation.Enabled = CType(resources.GetObject("FpCallsignTranslation.Enabled"), Boolean)
        Me.FpCallsignTranslation.Font = CType(resources.GetObject("FpCallsignTranslation.Font"), System.Drawing.Font)
        Me.FpCallsignTranslation.ImeMode = CType(resources.GetObject("FpCallsignTranslation.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpCallsignTranslation.Location = CType(resources.GetObject("FpCallsignTranslation.Location"), System.Drawing.Point)
        Me.FpCallsignTranslation.Name = "FpCallsignTranslation"
        Me.FpCallsignTranslation.RightToLeft = CType(resources.GetObject("FpCallsignTranslation.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpCallsignTranslation.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpCallsignTranslation_Sheet1})
        Me.FpCallsignTranslation.Size = CType(resources.GetObject("FpCallsignTranslation.Size"), System.Drawing.Size)
        Me.FpCallsignTranslation.TabIndex = CType(resources.GetObject("FpCallsignTranslation.TabIndex"), Integer)
        Me.FpCallsignTranslation.Visible = CType(resources.GetObject("FpCallsignTranslation.Visible"), Boolean)
        '
        'FpCallsignTranslation_Sheet1
        '
        Me.FpCallsignTranslation_Sheet1.Reset()
        TextCellType3.AcceptsArrowKeys = FarPoint.Win.SuperEdit.AcceptsArrowKeys.Arrows
        Me.FpCallsignTranslation_Sheet1.DefaultStyle.CellType = TextCellType3
        Me.FpCallsignTranslation_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpCallsignTranslation_Sheet1.SheetName = "Sheet1"
        '
        'tabAPRSserver
        '
        Me.tabAPRSserver.AccessibleDescription = resources.GetString("tabAPRSserver.AccessibleDescription")
        Me.tabAPRSserver.AccessibleName = resources.GetString("tabAPRSserver.AccessibleName")
        Me.tabAPRSserver.Anchor = CType(resources.GetObject("tabAPRSserver.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabAPRSserver.AutoScroll = CType(resources.GetObject("tabAPRSserver.AutoScroll"), Boolean)
        Me.tabAPRSserver.AutoScrollMargin = CType(resources.GetObject("tabAPRSserver.AutoScrollMargin"), System.Drawing.Size)
        Me.tabAPRSserver.AutoScrollMinSize = CType(resources.GetObject("tabAPRSserver.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabAPRSserver.BackgroundImage = CType(resources.GetObject("tabAPRSserver.BackgroundImage"), System.Drawing.Image)
        Me.tabAPRSserver.Controls.Add(Me.FpTCPAPRSServerSpread)
        Me.tabAPRSserver.Dock = CType(resources.GetObject("tabAPRSserver.Dock"), System.Windows.Forms.DockStyle)
        Me.tabAPRSserver.Enabled = CType(resources.GetObject("tabAPRSserver.Enabled"), Boolean)
        Me.tabAPRSserver.Font = CType(resources.GetObject("tabAPRSserver.Font"), System.Drawing.Font)
        Me.tabAPRSserver.ImageIndex = CType(resources.GetObject("tabAPRSserver.ImageIndex"), Integer)
        Me.tabAPRSserver.ImeMode = CType(resources.GetObject("tabAPRSserver.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabAPRSserver.Location = CType(resources.GetObject("tabAPRSserver.Location"), System.Drawing.Point)
        Me.tabAPRSserver.Name = "tabAPRSserver"
        Me.tabAPRSserver.RightToLeft = CType(resources.GetObject("tabAPRSserver.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabAPRSserver.Size = CType(resources.GetObject("tabAPRSserver.Size"), System.Drawing.Size)
        Me.tabAPRSserver.TabIndex = CType(resources.GetObject("tabAPRSserver.TabIndex"), Integer)
        Me.tabAPRSserver.Text = resources.GetString("tabAPRSserver.Text")
        Me.tabAPRSserver.ToolTipText = resources.GetString("tabAPRSserver.ToolTipText")
        Me.tabAPRSserver.Visible = CType(resources.GetObject("tabAPRSserver.Visible"), Boolean)
        '
        'FpTCPAPRSServerSpread
        '
        Me.FpTCPAPRSServerSpread.AccessibleDescription = resources.GetString("FpTCPAPRSServerSpread.AccessibleDescription")
        Me.FpTCPAPRSServerSpread.AccessibleName = resources.GetString("FpTCPAPRSServerSpread.AccessibleName")
        Me.FpTCPAPRSServerSpread.Anchor = CType(resources.GetObject("FpTCPAPRSServerSpread.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpTCPAPRSServerSpread.BackgroundImage = CType(resources.GetObject("FpTCPAPRSServerSpread.BackgroundImage"), System.Drawing.Image)
        Me.FpTCPAPRSServerSpread.Dock = CType(resources.GetObject("FpTCPAPRSServerSpread.Dock"), System.Windows.Forms.DockStyle)
        Me.FpTCPAPRSServerSpread.Enabled = CType(resources.GetObject("FpTCPAPRSServerSpread.Enabled"), Boolean)
        Me.FpTCPAPRSServerSpread.Font = CType(resources.GetObject("FpTCPAPRSServerSpread.Font"), System.Drawing.Font)
        Me.FpTCPAPRSServerSpread.ImeMode = CType(resources.GetObject("FpTCPAPRSServerSpread.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpTCPAPRSServerSpread.Location = CType(resources.GetObject("FpTCPAPRSServerSpread.Location"), System.Drawing.Point)
        Me.FpTCPAPRSServerSpread.Name = "FpTCPAPRSServerSpread"
        Me.FpTCPAPRSServerSpread.RightToLeft = CType(resources.GetObject("FpTCPAPRSServerSpread.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpTCPAPRSServerSpread.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpTCPAPRSServerSpread_Sheet1})
        Me.FpTCPAPRSServerSpread.Size = CType(resources.GetObject("FpTCPAPRSServerSpread.Size"), System.Drawing.Size)
        Me.FpTCPAPRSServerSpread.TabIndex = CType(resources.GetObject("FpTCPAPRSServerSpread.TabIndex"), Integer)
        Me.FpTCPAPRSServerSpread.Visible = CType(resources.GetObject("FpTCPAPRSServerSpread.Visible"), Boolean)
        '
        'FpTCPAPRSServerSpread_Sheet1
        '
        Me.FpTCPAPRSServerSpread_Sheet1.Reset()
        TextCellType4.AcceptsArrowKeys = FarPoint.Win.SuperEdit.AcceptsArrowKeys.Arrows
        Me.FpTCPAPRSServerSpread_Sheet1.DefaultStyle.CellType = TextCellType4
        Me.FpTCPAPRSServerSpread_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpTCPAPRSServerSpread_Sheet1.SheetName = "Sheet1"
        '
        'tabMonitor
        '
        Me.tabMonitor.AccessibleDescription = resources.GetString("tabMonitor.AccessibleDescription")
        Me.tabMonitor.AccessibleName = resources.GetString("tabMonitor.AccessibleName")
        Me.tabMonitor.Anchor = CType(resources.GetObject("tabMonitor.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabMonitor.AutoScroll = CType(resources.GetObject("tabMonitor.AutoScroll"), Boolean)
        Me.tabMonitor.AutoScrollMargin = CType(resources.GetObject("tabMonitor.AutoScrollMargin"), System.Drawing.Size)
        Me.tabMonitor.AutoScrollMinSize = CType(resources.GetObject("tabMonitor.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabMonitor.BackgroundImage = CType(resources.GetObject("tabMonitor.BackgroundImage"), System.Drawing.Image)
        Me.tabMonitor.Controls.Add(Me.devMonitor)
        Me.tabMonitor.Dock = CType(resources.GetObject("tabMonitor.Dock"), System.Windows.Forms.DockStyle)
        Me.tabMonitor.Enabled = CType(resources.GetObject("tabMonitor.Enabled"), Boolean)
        Me.tabMonitor.Font = CType(resources.GetObject("tabMonitor.Font"), System.Drawing.Font)
        Me.tabMonitor.ImageIndex = CType(resources.GetObject("tabMonitor.ImageIndex"), Integer)
        Me.tabMonitor.ImeMode = CType(resources.GetObject("tabMonitor.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabMonitor.Location = CType(resources.GetObject("tabMonitor.Location"), System.Drawing.Point)
        Me.tabMonitor.Name = "tabMonitor"
        Me.tabMonitor.RightToLeft = CType(resources.GetObject("tabMonitor.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabMonitor.Size = CType(resources.GetObject("tabMonitor.Size"), System.Drawing.Size)
        Me.tabMonitor.TabIndex = CType(resources.GetObject("tabMonitor.TabIndex"), Integer)
        Me.tabMonitor.Text = resources.GetString("tabMonitor.Text")
        Me.tabMonitor.ToolTipText = resources.GetString("tabMonitor.ToolTipText")
        Me.tabMonitor.Visible = CType(resources.GetObject("tabMonitor.Visible"), Boolean)
        '
        'devMonitor
        '
        Me.devMonitor.AccessibleDescription = resources.GetString("devMonitor.AccessibleDescription")
        Me.devMonitor.AccessibleName = resources.GetString("devMonitor.AccessibleName")
        Me.devMonitor.Anchor = CType(resources.GetObject("devMonitor.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.devMonitor.BackgroundImage = CType(resources.GetObject("devMonitor.BackgroundImage"), System.Drawing.Image)
        Me.devMonitor.ColumnWidth = CType(resources.GetObject("devMonitor.ColumnWidth"), Integer)
        Me.devMonitor.Dock = CType(resources.GetObject("devMonitor.Dock"), System.Windows.Forms.DockStyle)
        Me.devMonitor.Enabled = CType(resources.GetObject("devMonitor.Enabled"), Boolean)
        Me.devMonitor.Font = CType(resources.GetObject("devMonitor.Font"), System.Drawing.Font)
        Me.devMonitor.HorizontalExtent = CType(resources.GetObject("devMonitor.HorizontalExtent"), Integer)
        Me.devMonitor.HorizontalScrollbar = CType(resources.GetObject("devMonitor.HorizontalScrollbar"), Boolean)
        Me.devMonitor.ImeMode = CType(resources.GetObject("devMonitor.ImeMode"), System.Windows.Forms.ImeMode)
        Me.devMonitor.IntegralHeight = CType(resources.GetObject("devMonitor.IntegralHeight"), Boolean)
        Me.devMonitor.ItemHeight = CType(resources.GetObject("devMonitor.ItemHeight"), Integer)
        Me.devMonitor.Location = CType(resources.GetObject("devMonitor.Location"), System.Drawing.Point)
        Me.devMonitor.Name = "devMonitor"
        Me.devMonitor.RightToLeft = CType(resources.GetObject("devMonitor.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.devMonitor.ScrollAlwaysVisible = CType(resources.GetObject("devMonitor.ScrollAlwaysVisible"), Boolean)
        Me.devMonitor.Size = CType(resources.GetObject("devMonitor.Size"), System.Drawing.Size)
        Me.devMonitor.TabIndex = CType(resources.GetObject("devMonitor.TabIndex"), Integer)
        Me.devMonitor.Visible = CType(resources.GetObject("devMonitor.Visible"), Boolean)
        '
        'tabDevices
        '
        Me.tabDevices.AccessibleDescription = resources.GetString("tabDevices.AccessibleDescription")
        Me.tabDevices.AccessibleName = resources.GetString("tabDevices.AccessibleName")
        Me.tabDevices.Anchor = CType(resources.GetObject("tabDevices.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabDevices.AutoScroll = CType(resources.GetObject("tabDevices.AutoScroll"), Boolean)
        Me.tabDevices.AutoScrollMargin = CType(resources.GetObject("tabDevices.AutoScrollMargin"), System.Drawing.Size)
        Me.tabDevices.AutoScrollMinSize = CType(resources.GetObject("tabDevices.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabDevices.BackgroundImage = CType(resources.GetObject("tabDevices.BackgroundImage"), System.Drawing.Image)
        Me.tabDevices.Controls.Add(Me.FpPortsCrosspoint)
        Me.tabDevices.Controls.Add(Me.PortsList)
        Me.tabDevices.Dock = CType(resources.GetObject("tabDevices.Dock"), System.Windows.Forms.DockStyle)
        Me.tabDevices.Enabled = CType(resources.GetObject("tabDevices.Enabled"), Boolean)
        Me.tabDevices.Font = CType(resources.GetObject("tabDevices.Font"), System.Drawing.Font)
        Me.tabDevices.ImageIndex = CType(resources.GetObject("tabDevices.ImageIndex"), Integer)
        Me.tabDevices.ImeMode = CType(resources.GetObject("tabDevices.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabDevices.Location = CType(resources.GetObject("tabDevices.Location"), System.Drawing.Point)
        Me.tabDevices.Name = "tabDevices"
        Me.tabDevices.RightToLeft = CType(resources.GetObject("tabDevices.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabDevices.Size = CType(resources.GetObject("tabDevices.Size"), System.Drawing.Size)
        Me.tabDevices.TabIndex = CType(resources.GetObject("tabDevices.TabIndex"), Integer)
        Me.tabDevices.Text = resources.GetString("tabDevices.Text")
        Me.tabDevices.ToolTipText = resources.GetString("tabDevices.ToolTipText")
        Me.tabDevices.Visible = CType(resources.GetObject("tabDevices.Visible"), Boolean)
        '
        'FpPortsCrosspoint
        '
        Me.FpPortsCrosspoint.AccessibleDescription = resources.GetString("FpPortsCrosspoint.AccessibleDescription")
        Me.FpPortsCrosspoint.AccessibleName = resources.GetString("FpPortsCrosspoint.AccessibleName")
        Me.FpPortsCrosspoint.Anchor = CType(resources.GetObject("FpPortsCrosspoint.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpPortsCrosspoint.BackgroundImage = CType(resources.GetObject("FpPortsCrosspoint.BackgroundImage"), System.Drawing.Image)
        Me.FpPortsCrosspoint.Dock = CType(resources.GetObject("FpPortsCrosspoint.Dock"), System.Windows.Forms.DockStyle)
        Me.FpPortsCrosspoint.Enabled = CType(resources.GetObject("FpPortsCrosspoint.Enabled"), Boolean)
        Me.FpPortsCrosspoint.Font = CType(resources.GetObject("FpPortsCrosspoint.Font"), System.Drawing.Font)
        Me.FpPortsCrosspoint.ImeMode = CType(resources.GetObject("FpPortsCrosspoint.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpPortsCrosspoint.Location = CType(resources.GetObject("FpPortsCrosspoint.Location"), System.Drawing.Point)
        Me.FpPortsCrosspoint.Name = "FpPortsCrosspoint"
        Me.FpPortsCrosspoint.RightToLeft = CType(resources.GetObject("FpPortsCrosspoint.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpPortsCrosspoint.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpPortsCrosspoint_Sheet1})
        Me.FpPortsCrosspoint.Size = CType(resources.GetObject("FpPortsCrosspoint.Size"), System.Drawing.Size)
        Me.FpPortsCrosspoint.TabIndex = CType(resources.GetObject("FpPortsCrosspoint.TabIndex"), Integer)
        Me.FpPortsCrosspoint.Visible = CType(resources.GetObject("FpPortsCrosspoint.Visible"), Boolean)
        '
        'FpPortsCrosspoint_Sheet1
        '
        Me.FpPortsCrosspoint_Sheet1.Reset()
        Me.FpPortsCrosspoint_Sheet1.ColumnHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Numbers
        Me.FpPortsCrosspoint_Sheet1.DefaultStyle.CellType = CheckBoxCellType1
        Me.FpPortsCrosspoint_Sheet1.DefaultStyle.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.FpPortsCrosspoint_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.FpPortsCrosspoint_Sheet1.SheetName = "Sheet1"
        '
        'PortsList
        '
        Me.PortsList.AccessibleDescription = resources.GetString("PortsList.AccessibleDescription")
        Me.PortsList.AccessibleName = resources.GetString("PortsList.AccessibleName")
        Me.PortsList.Anchor = CType(resources.GetObject("PortsList.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.PortsList.BackgroundImage = CType(resources.GetObject("PortsList.BackgroundImage"), System.Drawing.Image)
        Me.PortsList.ColumnWidth = CType(resources.GetObject("PortsList.ColumnWidth"), Integer)
        Me.PortsList.Dock = CType(resources.GetObject("PortsList.Dock"), System.Windows.Forms.DockStyle)
        Me.PortsList.Enabled = CType(resources.GetObject("PortsList.Enabled"), Boolean)
        Me.PortsList.Font = CType(resources.GetObject("PortsList.Font"), System.Drawing.Font)
        Me.PortsList.HorizontalExtent = CType(resources.GetObject("PortsList.HorizontalExtent"), Integer)
        Me.PortsList.HorizontalScrollbar = CType(resources.GetObject("PortsList.HorizontalScrollbar"), Boolean)
        Me.PortsList.ImeMode = CType(resources.GetObject("PortsList.ImeMode"), System.Windows.Forms.ImeMode)
        Me.PortsList.IntegralHeight = CType(resources.GetObject("PortsList.IntegralHeight"), Boolean)
        Me.PortsList.ItemHeight = CType(resources.GetObject("PortsList.ItemHeight"), Integer)
        Me.PortsList.Location = CType(resources.GetObject("PortsList.Location"), System.Drawing.Point)
        Me.PortsList.Name = "PortsList"
        Me.PortsList.RightToLeft = CType(resources.GetObject("PortsList.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.PortsList.ScrollAlwaysVisible = CType(resources.GetObject("PortsList.ScrollAlwaysVisible"), Boolean)
        Me.PortsList.Size = CType(resources.GetObject("PortsList.Size"), System.Drawing.Size)
        Me.PortsList.TabIndex = CType(resources.GetObject("PortsList.TabIndex"), Integer)
        Me.PortsList.Visible = CType(resources.GetObject("PortsList.Visible"), Boolean)
        '
        'TabPage6
        '
        Me.TabPage6.AccessibleDescription = resources.GetString("TabPage6.AccessibleDescription")
        Me.TabPage6.AccessibleName = resources.GetString("TabPage6.AccessibleName")
        Me.TabPage6.Anchor = CType(resources.GetObject("TabPage6.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.TabPage6.AutoScroll = CType(resources.GetObject("TabPage6.AutoScroll"), Boolean)
        Me.TabPage6.AutoScrollMargin = CType(resources.GetObject("TabPage6.AutoScrollMargin"), System.Drawing.Size)
        Me.TabPage6.AutoScrollMinSize = CType(resources.GetObject("TabPage6.AutoScrollMinSize"), System.Drawing.Size)
        Me.TabPage6.BackgroundImage = CType(resources.GetObject("TabPage6.BackgroundImage"), System.Drawing.Image)
        Me.TabPage6.Controls.Add(Me.txtLat)
        Me.TabPage6.Controls.Add(Me.txtLon)
        Me.TabPage6.Controls.Add(Me.SatelliteViewer1)
        Me.TabPage6.Controls.Add(Me.NMEAline)
        Me.TabPage6.Controls.Add(Me.txtPopupCallsign)
        Me.TabPage6.Controls.Add(Me.txtOziLon)
        Me.TabPage6.Controls.Add(Me.txtOziLat)
        Me.TabPage6.Dock = CType(resources.GetObject("TabPage6.Dock"), System.Windows.Forms.DockStyle)
        Me.TabPage6.Enabled = CType(resources.GetObject("TabPage6.Enabled"), Boolean)
        Me.TabPage6.Font = CType(resources.GetObject("TabPage6.Font"), System.Drawing.Font)
        Me.TabPage6.ImageIndex = CType(resources.GetObject("TabPage6.ImageIndex"), Integer)
        Me.TabPage6.ImeMode = CType(resources.GetObject("TabPage6.ImeMode"), System.Windows.Forms.ImeMode)
        Me.TabPage6.Location = CType(resources.GetObject("TabPage6.Location"), System.Drawing.Point)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.RightToLeft = CType(resources.GetObject("TabPage6.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.TabPage6.Size = CType(resources.GetObject("TabPage6.Size"), System.Drawing.Size)
        Me.TabPage6.TabIndex = CType(resources.GetObject("TabPage6.TabIndex"), Integer)
        Me.TabPage6.Text = resources.GetString("TabPage6.Text")
        Me.TabPage6.ToolTipText = resources.GetString("TabPage6.ToolTipText")
        Me.TabPage6.Visible = CType(resources.GetObject("TabPage6.Visible"), Boolean)
        '
        'txtLat
        '
        Me.txtLat.AccessibleDescription = resources.GetString("txtLat.AccessibleDescription")
        Me.txtLat.AccessibleName = resources.GetString("txtLat.AccessibleName")
        Me.txtLat.Anchor = CType(resources.GetObject("txtLat.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.txtLat.AutoSize = CType(resources.GetObject("txtLat.AutoSize"), Boolean)
        Me.txtLat.BackgroundImage = CType(resources.GetObject("txtLat.BackgroundImage"), System.Drawing.Image)
        Me.txtLat.Dock = CType(resources.GetObject("txtLat.Dock"), System.Windows.Forms.DockStyle)
        Me.txtLat.Enabled = CType(resources.GetObject("txtLat.Enabled"), Boolean)
        Me.txtLat.Font = CType(resources.GetObject("txtLat.Font"), System.Drawing.Font)
        Me.txtLat.ImeMode = CType(resources.GetObject("txtLat.ImeMode"), System.Windows.Forms.ImeMode)
        Me.txtLat.Location = CType(resources.GetObject("txtLat.Location"), System.Drawing.Point)
        Me.txtLat.MaxLength = CType(resources.GetObject("txtLat.MaxLength"), Integer)
        Me.txtLat.Multiline = CType(resources.GetObject("txtLat.Multiline"), Boolean)
        Me.txtLat.Name = "txtLat"
        Me.txtLat.PasswordChar = CType(resources.GetObject("txtLat.PasswordChar"), Char)
        Me.txtLat.RightToLeft = CType(resources.GetObject("txtLat.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.txtLat.ScrollBars = CType(resources.GetObject("txtLat.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.txtLat.Size = CType(resources.GetObject("txtLat.Size"), System.Drawing.Size)
        Me.txtLat.TabIndex = CType(resources.GetObject("txtLat.TabIndex"), Integer)
        Me.txtLat.Text = resources.GetString("txtLat.Text")
        Me.txtLat.TextAlign = CType(resources.GetObject("txtLat.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.txtLat.Visible = CType(resources.GetObject("txtLat.Visible"), Boolean)
        Me.txtLat.WordWrap = CType(resources.GetObject("txtLat.WordWrap"), Boolean)
        '
        'txtLon
        '
        Me.txtLon.AccessibleDescription = resources.GetString("txtLon.AccessibleDescription")
        Me.txtLon.AccessibleName = resources.GetString("txtLon.AccessibleName")
        Me.txtLon.Anchor = CType(resources.GetObject("txtLon.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.txtLon.AutoSize = CType(resources.GetObject("txtLon.AutoSize"), Boolean)
        Me.txtLon.BackgroundImage = CType(resources.GetObject("txtLon.BackgroundImage"), System.Drawing.Image)
        Me.txtLon.Dock = CType(resources.GetObject("txtLon.Dock"), System.Windows.Forms.DockStyle)
        Me.txtLon.Enabled = CType(resources.GetObject("txtLon.Enabled"), Boolean)
        Me.txtLon.Font = CType(resources.GetObject("txtLon.Font"), System.Drawing.Font)
        Me.txtLon.ImeMode = CType(resources.GetObject("txtLon.ImeMode"), System.Windows.Forms.ImeMode)
        Me.txtLon.Location = CType(resources.GetObject("txtLon.Location"), System.Drawing.Point)
        Me.txtLon.MaxLength = CType(resources.GetObject("txtLon.MaxLength"), Integer)
        Me.txtLon.Multiline = CType(resources.GetObject("txtLon.Multiline"), Boolean)
        Me.txtLon.Name = "txtLon"
        Me.txtLon.PasswordChar = CType(resources.GetObject("txtLon.PasswordChar"), Char)
        Me.txtLon.RightToLeft = CType(resources.GetObject("txtLon.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.txtLon.ScrollBars = CType(resources.GetObject("txtLon.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.txtLon.Size = CType(resources.GetObject("txtLon.Size"), System.Drawing.Size)
        Me.txtLon.TabIndex = CType(resources.GetObject("txtLon.TabIndex"), Integer)
        Me.txtLon.Text = resources.GetString("txtLon.Text")
        Me.txtLon.TextAlign = CType(resources.GetObject("txtLon.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.txtLon.Visible = CType(resources.GetObject("txtLon.Visible"), Boolean)
        Me.txtLon.WordWrap = CType(resources.GetObject("txtLon.WordWrap"), Boolean)
        '
        'SatelliteViewer1
        '
        Me.SatelliteViewer1.AccessibleDescription = resources.GetString("SatelliteViewer1.AccessibleDescription")
        Me.SatelliteViewer1.AccessibleName = resources.GetString("SatelliteViewer1.AccessibleName")
        Me.SatelliteViewer1.Anchor = CType(resources.GetObject("SatelliteViewer1.Anchor"), System.Windows.Forms.AnchorStyles)
        'Me.SatelliteViewer1.AutoScroll = CType(resources.GetObject("SatelliteViewer1.AutoScroll"), Boolean)
        'Me.SatelliteViewer1.AutoScrollMargin = CType(resources.GetObject("SatelliteViewer1.AutoScrollMargin"), System.Drawing.Size)
        'Me.SatelliteViewer1.AutoScrollMinSize = CType(resources.GetObject("SatelliteViewer1.AutoScrollMinSize"), System.Drawing.Size)
        Me.SatelliteViewer1.BackgroundImage = CType(resources.GetObject("SatelliteViewer1.BackgroundImage"), System.Drawing.Image)
        Me.SatelliteViewer1.CompassFont = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SatelliteViewer1.Dock = CType(resources.GetObject("SatelliteViewer1.Dock"), System.Windows.Forms.DockStyle)
        Me.SatelliteViewer1.Enabled = CType(resources.GetObject("SatelliteViewer1.Enabled"), Boolean)
        Me.SatelliteViewer1.Font = CType(resources.GetObject("SatelliteViewer1.Font"), System.Drawing.Font)
        Me.SatelliteViewer1.ImeMode = CType(resources.GetObject("SatelliteViewer1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.SatelliteViewer1.Location = CType(resources.GetObject("SatelliteViewer1.Location"), System.Drawing.Point)
        Me.SatelliteViewer1.Name = "SatelliteViewer1"
        'Me.SatelliteViewer1.PrcFont = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SatelliteViewer1.Receiver = Nothing
        Me.SatelliteViewer1.RightToLeft = CType(resources.GetObject("SatelliteViewer1.RightToLeft"), System.Windows.Forms.RightToLeft)
        'Me.SatelliteViewer1.RotationMode = StormSource.Gps.Controls.RotationMode.RotateBearingArrow
        Me.SatelliteViewer1.Size = CType(resources.GetObject("SatelliteViewer1.Size"), System.Drawing.Size)
        Me.SatelliteViewer1.TabIndex = CType(resources.GetObject("SatelliteViewer1.TabIndex"), Integer)
        Me.SatelliteViewer1.Visible = CType(resources.GetObject("SatelliteViewer1.Visible"), Boolean)
        '
        'NMEAline
        '
        Me.NMEAline.AccessibleDescription = resources.GetString("NMEAline.AccessibleDescription")
        Me.NMEAline.AccessibleName = resources.GetString("NMEAline.AccessibleName")
        Me.NMEAline.Anchor = CType(resources.GetObject("NMEAline.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.NMEAline.AutoSize = CType(resources.GetObject("NMEAline.AutoSize"), Boolean)
        Me.NMEAline.BackgroundImage = CType(resources.GetObject("NMEAline.BackgroundImage"), System.Drawing.Image)
        Me.NMEAline.Dock = CType(resources.GetObject("NMEAline.Dock"), System.Windows.Forms.DockStyle)
        Me.NMEAline.Enabled = CType(resources.GetObject("NMEAline.Enabled"), Boolean)
        Me.NMEAline.Font = CType(resources.GetObject("NMEAline.Font"), System.Drawing.Font)
        Me.NMEAline.ImeMode = CType(resources.GetObject("NMEAline.ImeMode"), System.Windows.Forms.ImeMode)
        Me.NMEAline.Location = CType(resources.GetObject("NMEAline.Location"), System.Drawing.Point)
        Me.NMEAline.MaxLength = CType(resources.GetObject("NMEAline.MaxLength"), Integer)
        Me.NMEAline.Multiline = CType(resources.GetObject("NMEAline.Multiline"), Boolean)
        Me.NMEAline.Name = "NMEAline"
        Me.NMEAline.PasswordChar = CType(resources.GetObject("NMEAline.PasswordChar"), Char)
        Me.NMEAline.RightToLeft = CType(resources.GetObject("NMEAline.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.NMEAline.ScrollBars = CType(resources.GetObject("NMEAline.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.NMEAline.Size = CType(resources.GetObject("NMEAline.Size"), System.Drawing.Size)
        Me.NMEAline.TabIndex = CType(resources.GetObject("NMEAline.TabIndex"), Integer)
        Me.NMEAline.Text = resources.GetString("NMEAline.Text")
        Me.NMEAline.TextAlign = CType(resources.GetObject("NMEAline.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.NMEAline.Visible = CType(resources.GetObject("NMEAline.Visible"), Boolean)
        Me.NMEAline.WordWrap = CType(resources.GetObject("NMEAline.WordWrap"), Boolean)
        '
        'txtPopupCallsign
        '
        Me.txtPopupCallsign.AccessibleDescription = resources.GetString("txtPopupCallsign.AccessibleDescription")
        Me.txtPopupCallsign.AccessibleName = resources.GetString("txtPopupCallsign.AccessibleName")
        Me.txtPopupCallsign.Anchor = CType(resources.GetObject("txtPopupCallsign.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.txtPopupCallsign.AutoSize = CType(resources.GetObject("txtPopupCallsign.AutoSize"), Boolean)
        Me.txtPopupCallsign.BackgroundImage = CType(resources.GetObject("txtPopupCallsign.BackgroundImage"), System.Drawing.Image)
        Me.txtPopupCallsign.Dock = CType(resources.GetObject("txtPopupCallsign.Dock"), System.Windows.Forms.DockStyle)
        Me.txtPopupCallsign.Enabled = CType(resources.GetObject("txtPopupCallsign.Enabled"), Boolean)
        Me.txtPopupCallsign.Font = CType(resources.GetObject("txtPopupCallsign.Font"), System.Drawing.Font)
        Me.txtPopupCallsign.ImeMode = CType(resources.GetObject("txtPopupCallsign.ImeMode"), System.Windows.Forms.ImeMode)
        Me.txtPopupCallsign.Location = CType(resources.GetObject("txtPopupCallsign.Location"), System.Drawing.Point)
        Me.txtPopupCallsign.MaxLength = CType(resources.GetObject("txtPopupCallsign.MaxLength"), Integer)
        Me.txtPopupCallsign.Multiline = CType(resources.GetObject("txtPopupCallsign.Multiline"), Boolean)
        Me.txtPopupCallsign.Name = "txtPopupCallsign"
        Me.txtPopupCallsign.PasswordChar = CType(resources.GetObject("txtPopupCallsign.PasswordChar"), Char)
        Me.txtPopupCallsign.RightToLeft = CType(resources.GetObject("txtPopupCallsign.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.txtPopupCallsign.ScrollBars = CType(resources.GetObject("txtPopupCallsign.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.txtPopupCallsign.Size = CType(resources.GetObject("txtPopupCallsign.Size"), System.Drawing.Size)
        Me.txtPopupCallsign.TabIndex = CType(resources.GetObject("txtPopupCallsign.TabIndex"), Integer)
        Me.txtPopupCallsign.Text = resources.GetString("txtPopupCallsign.Text")
        Me.txtPopupCallsign.TextAlign = CType(resources.GetObject("txtPopupCallsign.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.txtPopupCallsign.Visible = CType(resources.GetObject("txtPopupCallsign.Visible"), Boolean)
        Me.txtPopupCallsign.WordWrap = CType(resources.GetObject("txtPopupCallsign.WordWrap"), Boolean)
        '
        'txtOziLon
        '
        Me.txtOziLon.AccessibleDescription = resources.GetString("txtOziLon.AccessibleDescription")
        Me.txtOziLon.AccessibleName = resources.GetString("txtOziLon.AccessibleName")
        Me.txtOziLon.Anchor = CType(resources.GetObject("txtOziLon.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.txtOziLon.AutoSize = CType(resources.GetObject("txtOziLon.AutoSize"), Boolean)
        Me.txtOziLon.BackgroundImage = CType(resources.GetObject("txtOziLon.BackgroundImage"), System.Drawing.Image)
        Me.txtOziLon.Dock = CType(resources.GetObject("txtOziLon.Dock"), System.Windows.Forms.DockStyle)
        Me.txtOziLon.Enabled = CType(resources.GetObject("txtOziLon.Enabled"), Boolean)
        Me.txtOziLon.Font = CType(resources.GetObject("txtOziLon.Font"), System.Drawing.Font)
        Me.txtOziLon.ImeMode = CType(resources.GetObject("txtOziLon.ImeMode"), System.Windows.Forms.ImeMode)
        Me.txtOziLon.Location = CType(resources.GetObject("txtOziLon.Location"), System.Drawing.Point)
        Me.txtOziLon.MaxLength = CType(resources.GetObject("txtOziLon.MaxLength"), Integer)
        Me.txtOziLon.Multiline = CType(resources.GetObject("txtOziLon.Multiline"), Boolean)
        Me.txtOziLon.Name = "txtOziLon"
        Me.txtOziLon.PasswordChar = CType(resources.GetObject("txtOziLon.PasswordChar"), Char)
        Me.txtOziLon.RightToLeft = CType(resources.GetObject("txtOziLon.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.txtOziLon.ScrollBars = CType(resources.GetObject("txtOziLon.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.txtOziLon.Size = CType(resources.GetObject("txtOziLon.Size"), System.Drawing.Size)
        Me.txtOziLon.TabIndex = CType(resources.GetObject("txtOziLon.TabIndex"), Integer)
        Me.txtOziLon.Text = resources.GetString("txtOziLon.Text")
        Me.txtOziLon.TextAlign = CType(resources.GetObject("txtOziLon.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.txtOziLon.Visible = CType(resources.GetObject("txtOziLon.Visible"), Boolean)
        Me.txtOziLon.WordWrap = CType(resources.GetObject("txtOziLon.WordWrap"), Boolean)
        '
        'txtOziLat
        '
        Me.txtOziLat.AccessibleDescription = resources.GetString("txtOziLat.AccessibleDescription")
        Me.txtOziLat.AccessibleName = resources.GetString("txtOziLat.AccessibleName")
        Me.txtOziLat.Anchor = CType(resources.GetObject("txtOziLat.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.txtOziLat.AutoSize = CType(resources.GetObject("txtOziLat.AutoSize"), Boolean)
        Me.txtOziLat.BackgroundImage = CType(resources.GetObject("txtOziLat.BackgroundImage"), System.Drawing.Image)
        Me.txtOziLat.Dock = CType(resources.GetObject("txtOziLat.Dock"), System.Windows.Forms.DockStyle)
        Me.txtOziLat.Enabled = CType(resources.GetObject("txtOziLat.Enabled"), Boolean)
        Me.txtOziLat.Font = CType(resources.GetObject("txtOziLat.Font"), System.Drawing.Font)
        Me.txtOziLat.ImeMode = CType(resources.GetObject("txtOziLat.ImeMode"), System.Windows.Forms.ImeMode)
        Me.txtOziLat.Location = CType(resources.GetObject("txtOziLat.Location"), System.Drawing.Point)
        Me.txtOziLat.MaxLength = CType(resources.GetObject("txtOziLat.MaxLength"), Integer)
        Me.txtOziLat.Multiline = CType(resources.GetObject("txtOziLat.Multiline"), Boolean)
        Me.txtOziLat.Name = "txtOziLat"
        Me.txtOziLat.PasswordChar = CType(resources.GetObject("txtOziLat.PasswordChar"), Char)
        Me.txtOziLat.RightToLeft = CType(resources.GetObject("txtOziLat.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.txtOziLat.ScrollBars = CType(resources.GetObject("txtOziLat.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.txtOziLat.Size = CType(resources.GetObject("txtOziLat.Size"), System.Drawing.Size)
        Me.txtOziLat.TabIndex = CType(resources.GetObject("txtOziLat.TabIndex"), Integer)
        Me.txtOziLat.Text = resources.GetString("txtOziLat.Text")
        Me.txtOziLat.TextAlign = CType(resources.GetObject("txtOziLat.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.txtOziLat.Visible = CType(resources.GetObject("txtOziLat.Visible"), Boolean)
        Me.txtOziLat.WordWrap = CType(resources.GetObject("txtOziLat.WordWrap"), Boolean)
        '
        'tabLanguages
        '
        Me.tabLanguages.AccessibleDescription = resources.GetString("tabLanguages.AccessibleDescription")
        Me.tabLanguages.AccessibleName = resources.GetString("tabLanguages.AccessibleName")
        Me.tabLanguages.Anchor = CType(resources.GetObject("tabLanguages.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.tabLanguages.AutoScroll = CType(resources.GetObject("tabLanguages.AutoScroll"), Boolean)
        Me.tabLanguages.AutoScrollMargin = CType(resources.GetObject("tabLanguages.AutoScrollMargin"), System.Drawing.Size)
        Me.tabLanguages.AutoScrollMinSize = CType(resources.GetObject("tabLanguages.AutoScrollMinSize"), System.Drawing.Size)
        Me.tabLanguages.BackgroundImage = CType(resources.GetObject("tabLanguages.BackgroundImage"), System.Drawing.Image)
        Me.tabLanguages.Controls.Add(Me.FpLanguages)
        Me.tabLanguages.Dock = CType(resources.GetObject("tabLanguages.Dock"), System.Windows.Forms.DockStyle)
        Me.tabLanguages.Enabled = CType(resources.GetObject("tabLanguages.Enabled"), Boolean)
        Me.tabLanguages.Font = CType(resources.GetObject("tabLanguages.Font"), System.Drawing.Font)
        Me.tabLanguages.ImageIndex = CType(resources.GetObject("tabLanguages.ImageIndex"), Integer)
        Me.tabLanguages.ImeMode = CType(resources.GetObject("tabLanguages.ImeMode"), System.Windows.Forms.ImeMode)
        Me.tabLanguages.Location = CType(resources.GetObject("tabLanguages.Location"), System.Drawing.Point)
        Me.tabLanguages.Name = "tabLanguages"
        Me.tabLanguages.RightToLeft = CType(resources.GetObject("tabLanguages.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.tabLanguages.Size = CType(resources.GetObject("tabLanguages.Size"), System.Drawing.Size)
        Me.tabLanguages.TabIndex = CType(resources.GetObject("tabLanguages.TabIndex"), Integer)
        Me.tabLanguages.Text = resources.GetString("tabLanguages.Text")
        Me.tabLanguages.ToolTipText = resources.GetString("tabLanguages.ToolTipText")
        Me.tabLanguages.Visible = CType(resources.GetObject("tabLanguages.Visible"), Boolean)
        '
        'FpLanguages
        '
        Me.FpLanguages.AccessibleDescription = resources.GetString("FpLanguages.AccessibleDescription")
        Me.FpLanguages.AccessibleName = resources.GetString("FpLanguages.AccessibleName")
        Me.FpLanguages.AllowCellOverflow = True
        Me.FpLanguages.AllowUserFormulas = True
        Me.FpLanguages.Anchor = CType(resources.GetObject("FpLanguages.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.FpLanguages.BackgroundImage = CType(resources.GetObject("FpLanguages.BackgroundImage"), System.Drawing.Image)
        Me.FpLanguages.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse
        Me.FpLanguages.Dock = CType(resources.GetObject("FpLanguages.Dock"), System.Windows.Forms.DockStyle)
        Me.FpLanguages.Enabled = CType(resources.GetObject("FpLanguages.Enabled"), Boolean)
        Me.FpLanguages.Font = CType(resources.GetObject("FpLanguages.Font"), System.Drawing.Font)
        Me.FpLanguages.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded
        Me.FpLanguages.ImeMode = CType(resources.GetObject("FpLanguages.ImeMode"), System.Windows.Forms.ImeMode)
        Me.FpLanguages.Location = CType(resources.GetObject("FpLanguages.Location"), System.Drawing.Point)
        Me.FpLanguages.Name = "FpLanguages"
        NamedStyle1.CellType = GeneralCellType1
        NamedStyle1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle1.Locked = True
        NamedStyle1.Parent = "DataAreaDefault"
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle2.Border = ComplexBorder1
        GeneralCellType2.FormatString = "#,##0.00;(#,##0.00);-  "
        GeneralCellType2.NumberFormat = CType(New System.Globalization.CultureInfo("en-AU", False).NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        GeneralCellType2.NumberFormat.CurrencyDecimalDigits = 2
        GeneralCellType2.NumberFormat.CurrencyDecimalSeparator = "."
        GeneralCellType2.NumberFormat.CurrencyGroupSeparator = ","
        GeneralCellType2.NumberFormat.CurrencyGroupSizes = New Integer() {3}
        GeneralCellType2.NumberFormat.CurrencyNegativePattern = 1
        GeneralCellType2.NumberFormat.CurrencyPositivePattern = 0
        GeneralCellType2.NumberFormat.CurrencySymbol = "$"
        GeneralCellType2.NumberFormat.NaNSymbol = "NaN"
        GeneralCellType2.NumberFormat.NegativeInfinitySymbol = "-Infinity"
        GeneralCellType2.NumberFormat.NegativeSign = "-"
        GeneralCellType2.NumberFormat.NumberDecimalDigits = 2
        GeneralCellType2.NumberFormat.NumberDecimalSeparator = "."
        GeneralCellType2.NumberFormat.NumberGroupSeparator = ","
        GeneralCellType2.NumberFormat.NumberGroupSizes = New Integer() {3}
        GeneralCellType2.NumberFormat.NumberNegativePattern = 1
        GeneralCellType2.NumberFormat.PercentDecimalDigits = 2
        GeneralCellType2.NumberFormat.PercentDecimalSeparator = "."
        GeneralCellType2.NumberFormat.PercentGroupSeparator = ","
        GeneralCellType2.NumberFormat.PercentGroupSizes = New Integer() {3}
        GeneralCellType2.NumberFormat.PercentNegativePattern = 0
        GeneralCellType2.NumberFormat.PercentPositivePattern = 0
        GeneralCellType2.NumberFormat.PercentSymbol = "%"
        GeneralCellType2.NumberFormat.PerMilleSymbol = "�"
        GeneralCellType2.NumberFormat.PositiveInfinitySymbol = "Infinity"
        GeneralCellType2.NumberFormat.PositiveSign = "+"
        NamedStyle2.CellType = GeneralCellType2
        NamedStyle2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle2.Locked = True
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle3.Border = ComplexBorder2
        GeneralCellType3.FormatString = "#,##0;(#,##0);-"
        GeneralCellType3.NumberFormat = CType(New System.Globalization.CultureInfo("en-AU", False).NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        GeneralCellType3.NumberFormat.CurrencyDecimalDigits = 2
        GeneralCellType3.NumberFormat.CurrencyDecimalSeparator = "."
        GeneralCellType3.NumberFormat.CurrencyGroupSeparator = ","
        GeneralCellType3.NumberFormat.CurrencyGroupSizes = New Integer() {3}
        GeneralCellType3.NumberFormat.CurrencyNegativePattern = 1
        GeneralCellType3.NumberFormat.CurrencyPositivePattern = 0
        GeneralCellType3.NumberFormat.CurrencySymbol = "$"
        GeneralCellType3.NumberFormat.NaNSymbol = "NaN"
        GeneralCellType3.NumberFormat.NegativeInfinitySymbol = "-Infinity"
        GeneralCellType3.NumberFormat.NegativeSign = "-"
        GeneralCellType3.NumberFormat.NumberDecimalDigits = 2
        GeneralCellType3.NumberFormat.NumberDecimalSeparator = "."
        GeneralCellType3.NumberFormat.NumberGroupSeparator = ","
        GeneralCellType3.NumberFormat.NumberGroupSizes = New Integer() {3}
        GeneralCellType3.NumberFormat.NumberNegativePattern = 1
        GeneralCellType3.NumberFormat.PercentDecimalDigits = 2
        GeneralCellType3.NumberFormat.PercentDecimalSeparator = "."
        GeneralCellType3.NumberFormat.PercentGroupSeparator = ","
        GeneralCellType3.NumberFormat.PercentGroupSizes = New Integer() {3}
        GeneralCellType3.NumberFormat.PercentNegativePattern = 0
        GeneralCellType3.NumberFormat.PercentPositivePattern = 0
        GeneralCellType3.NumberFormat.PercentSymbol = "%"
        GeneralCellType3.NumberFormat.PerMilleSymbol = "�"
        GeneralCellType3.NumberFormat.PositiveInfinitySymbol = "Infinity"
        GeneralCellType3.NumberFormat.PositiveSign = "+"
        NamedStyle3.CellType = GeneralCellType3
        NamedStyle3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle3.Locked = True
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle4.Border = ComplexBorder3
        GeneralCellType4.FormatString = "$ #,##0.00;$ (#,##0.00);$ -"
        GeneralCellType4.NumberFormat = CType(New System.Globalization.CultureInfo("en-AU", False).NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        GeneralCellType4.NumberFormat.CurrencyDecimalDigits = 2
        GeneralCellType4.NumberFormat.CurrencyDecimalSeparator = "."
        GeneralCellType4.NumberFormat.CurrencyGroupSeparator = ","
        GeneralCellType4.NumberFormat.CurrencyGroupSizes = New Integer() {3}
        GeneralCellType4.NumberFormat.CurrencyNegativePattern = 1
        GeneralCellType4.NumberFormat.CurrencyPositivePattern = 0
        GeneralCellType4.NumberFormat.CurrencySymbol = "$"
        GeneralCellType4.NumberFormat.NaNSymbol = "NaN"
        GeneralCellType4.NumberFormat.NegativeInfinitySymbol = "-Infinity"
        GeneralCellType4.NumberFormat.NegativeSign = "-"
        GeneralCellType4.NumberFormat.NumberDecimalDigits = 2
        GeneralCellType4.NumberFormat.NumberDecimalSeparator = "."
        GeneralCellType4.NumberFormat.NumberGroupSeparator = ","
        GeneralCellType4.NumberFormat.NumberGroupSizes = New Integer() {3}
        GeneralCellType4.NumberFormat.NumberNegativePattern = 1
        GeneralCellType4.NumberFormat.PercentDecimalDigits = 2
        GeneralCellType4.NumberFormat.PercentDecimalSeparator = "."
        GeneralCellType4.NumberFormat.PercentGroupSeparator = ","
        GeneralCellType4.NumberFormat.PercentGroupSizes = New Integer() {3}
        GeneralCellType4.NumberFormat.PercentNegativePattern = 0
        GeneralCellType4.NumberFormat.PercentPositivePattern = 0
        GeneralCellType4.NumberFormat.PercentSymbol = "%"
        GeneralCellType4.NumberFormat.PerMilleSymbol = "�"
        GeneralCellType4.NumberFormat.PositiveInfinitySymbol = "Infinity"
        GeneralCellType4.NumberFormat.PositiveSign = "+"
        NamedStyle4.CellType = GeneralCellType4
        NamedStyle4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle4.Locked = True
        NamedStyle4.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle5.Border = ComplexBorder4
        GeneralCellType5.FormatString = "$ #,##0;$ (#,##0);$ -"
        GeneralCellType5.NumberFormat = CType(New System.Globalization.CultureInfo("en-AU", False).NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        GeneralCellType5.NumberFormat.CurrencyDecimalDigits = 2
        GeneralCellType5.NumberFormat.CurrencyDecimalSeparator = "."
        GeneralCellType5.NumberFormat.CurrencyGroupSeparator = ","
        GeneralCellType5.NumberFormat.CurrencyGroupSizes = New Integer() {3}
        GeneralCellType5.NumberFormat.CurrencyNegativePattern = 1
        GeneralCellType5.NumberFormat.CurrencyPositivePattern = 0
        GeneralCellType5.NumberFormat.CurrencySymbol = "$"
        GeneralCellType5.NumberFormat.NaNSymbol = "NaN"
        GeneralCellType5.NumberFormat.NegativeInfinitySymbol = "-Infinity"
        GeneralCellType5.NumberFormat.NegativeSign = "-"
        GeneralCellType5.NumberFormat.NumberDecimalDigits = 2
        GeneralCellType5.NumberFormat.NumberDecimalSeparator = "."
        GeneralCellType5.NumberFormat.NumberGroupSeparator = ","
        GeneralCellType5.NumberFormat.NumberGroupSizes = New Integer() {3}
        GeneralCellType5.NumberFormat.NumberNegativePattern = 1
        GeneralCellType5.NumberFormat.PercentDecimalDigits = 2
        GeneralCellType5.NumberFormat.PercentDecimalSeparator = "."
        GeneralCellType5.NumberFormat.PercentGroupSeparator = ","
        GeneralCellType5.NumberFormat.PercentGroupSizes = New Integer() {3}
        GeneralCellType5.NumberFormat.PercentNegativePattern = 0
        GeneralCellType5.NumberFormat.PercentPositivePattern = 0
        GeneralCellType5.NumberFormat.PercentSymbol = "%"
        GeneralCellType5.NumberFormat.PerMilleSymbol = "�"
        GeneralCellType5.NumberFormat.PositiveInfinitySymbol = "Infinity"
        GeneralCellType5.NumberFormat.PositiveSign = "+"
        NamedStyle5.CellType = GeneralCellType5
        NamedStyle5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle5.Locked = True
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle6.Border = ComplexBorder5
        NamedStyle6.CellType = GeneralCellType6
        NamedStyle6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(0, Byte), CType(128, Byte))
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top
        NamedStyle7.Border = ComplexBorder6
        NamedStyle7.CellType = GeneralCellType7
        NamedStyle7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle7.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(255, Byte))
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top
        NamedStyle8.Border = ComplexBorder7
        GeneralCellType8.FormatString = "0%"
        NamedStyle8.CellType = GeneralCellType8
        NamedStyle8.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle8.Locked = True
        NamedStyle8.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        NamedStyle9.CellType = GeneralCellType9
        NamedStyle9.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NamedStyle9.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(255, Byte))
        NamedStyle9.Locked = True
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Bottom
        Me.FpLanguages.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4, NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8, NamedStyle9})
        Me.FpLanguages.RightToLeft = CType(resources.GetObject("FpLanguages.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.FpLanguages.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.FpLanguages_Sheet1})
        Me.FpLanguages.Size = CType(resources.GetObject("FpLanguages.Size"), System.Drawing.Size)
        Me.FpLanguages.TabIndex = CType(resources.GetObject("FpLanguages.TabIndex"), Integer)
        Me.FpLanguages.TabStrip.ActiveSheetTab.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.FpLanguages.TabStrip.DefaultSheetTab.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.FpLanguages.TabStripPolicy = FarPoint.Win.Spread.TabStripPolicy.Always
        Me.FpLanguages.TabStripRatio = 0.6
        Me.FpLanguages.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded
        Me.FpLanguages.Visible = CType(resources.GetObject("FpLanguages.Visible"), Boolean)
        '
        'FpLanguages_Sheet1
        '
        Me.FpLanguages_Sheet1.Reset()
        Me.FpLanguages_Sheet1.ColumnCount = 256
        Me.FpLanguages_Sheet1.RowCount = 65536
        Me.FpLanguages_Sheet1.Cells.Get(0, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 0).Text = "Context"
        Me.FpLanguages_Sheet1.Cells.Get(0, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 1).Text = "object"
        Me.FpLanguages_Sheet1.Cells.Get(0, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 2).Text = "English"
        Me.FpLanguages_Sheet1.Cells.Get(0, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 3).Text = "Aussie"
        Me.FpLanguages_Sheet1.Cells.Get(0, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 4).Text = "Italian"
        Me.FpLanguages_Sheet1.Cells.Get(0, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 5).Text = "French"
        Me.FpLanguages_Sheet1.Cells.Get(0, 6).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(0, 6).Text = "Polish"
        Me.FpLanguages_Sheet1.Cells.Get(1, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(1, 1).Text = "Email"
        Me.FpLanguages_Sheet1.Cells.Get(1, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(1, 2).StyleName = "Excel-0-23"
        Me.FpLanguages_Sheet1.Cells.Get(1, 2).Text = "Darryl@radio-active.net.au"
        Me.FpLanguages_Sheet1.Cells.Get(1, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(1, 3).StyleName = "Excel-0-23"
        Me.FpLanguages_Sheet1.Cells.Get(1, 3).Text = "Darryl@radio-active.net.au"
        Me.FpLanguages_Sheet1.Cells.Get(2, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(2, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 1).Text = "mnuFile"
        Me.FpLanguages_Sheet1.Cells.Get(2, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 2).Text = "&File"
        Me.FpLanguages_Sheet1.Cells.Get(2, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 3).Text = "Paperwork"
        Me.FpLanguages_Sheet1.Cells.Get(2, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 4).Text = "&File"
        Me.FpLanguages_Sheet1.Cells.Get(2, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(2, 5).Text = "&Fichier"
        Me.FpLanguages_Sheet1.Cells.Get(3, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(3, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 1).Text = "mnuFileSetup"
        Me.FpLanguages_Sheet1.Cells.Get(3, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 2).Text = "&Setup"
        Me.FpLanguages_Sheet1.Cells.Get(3, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 3).Text = "Writing Pad"
        Me.FpLanguages_Sheet1.Cells.Get(3, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 4).Text = "&Configurazione"
        Me.FpLanguages_Sheet1.Cells.Get(3, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(3, 5).Text = "&Config"
        Me.FpLanguages_Sheet1.Cells.Get(4, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(4, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 1).Text = "mnuServices"
        Me.FpLanguages_Sheet1.Cells.Get(4, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 2).Text = "&Services"
        Me.FpLanguages_Sheet1.Cells.Get(4, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 3).Text = "Stuff for us"
        Me.FpLanguages_Sheet1.Cells.Get(4, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 4).Text = "&Servizi"
        Me.FpLanguages_Sheet1.Cells.Get(4, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(4, 5).Text = "&Services"
        Me.FpLanguages_Sheet1.Cells.Get(5, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(5, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 1).Text = "mnuServAPRSserv"
        Me.FpLanguages_Sheet1.Cells.Get(5, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 2).Text = "Connect to APRS Server"
        Me.FpLanguages_Sheet1.Cells.Get(5, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 3).Text = "Grab Positions"
        Me.FpLanguages_Sheet1.Cells.Get(5, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 4).Text = "Connetti ad un Server APRS"
        Me.FpLanguages_Sheet1.Cells.Get(5, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(5, 5).Text = "Connecter Serveur APRS"
        Me.FpLanguages_Sheet1.Cells.Get(6, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(6, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 1).Text = "mnuServAGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(6, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 2).Text = "Connect to AGWPE "
        Me.FpLanguages_Sheet1.Cells.Get(6, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 3).Text = "Use AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(6, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 4).Text = "Connetti alla AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(6, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(6, 5).Text = "Connecter AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(7, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(7, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 1).Text = "mnuServTNC"
        Me.FpLanguages_Sheet1.Cells.Get(7, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 2).Text = "Connect to TNC"
        Me.FpLanguages_Sheet1.Cells.Get(7, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 3).Text = "Use the TNC"
        Me.FpLanguages_Sheet1.Cells.Get(7, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 4).Text = "Connetti al Modem TNC"
        Me.FpLanguages_Sheet1.Cells.Get(7, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(7, 5).Text = "Connecter TNC"
        Me.FpLanguages_Sheet1.Cells.Get(8, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(8, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 1).Text = "mnuServGPS"
        Me.FpLanguages_Sheet1.Cells.Get(8, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 2).Text = "Connect to GPS"
        Me.FpLanguages_Sheet1.Cells.Get(8, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 3).Text = "Plug in the GPS"
        Me.FpLanguages_Sheet1.Cells.Get(8, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 4).Text = "Connetti al GPS"
        Me.FpLanguages_Sheet1.Cells.Get(8, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(8, 5).Text = "Connecter GPS"
        Me.FpLanguages_Sheet1.Cells.Get(9, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(9, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 1).Text = "mnuServWx"
        Me.FpLanguages_Sheet1.Cells.Get(9, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 2).Text = "Connect to Weather Station"
        Me.FpLanguages_Sheet1.Cells.Get(9, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 3).Text = "Check the weather"
        Me.FpLanguages_Sheet1.Cells.Get(9, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 4).Text = "Connetti ad una Stazione Meteo"
        Me.FpLanguages_Sheet1.Cells.Get(9, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(9, 5).Text = "Connecter Station Meteo"
        Me.FpLanguages_Sheet1.Cells.Get(10, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(10, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 1).Text = "mnuServRINO"
        Me.FpLanguages_Sheet1.Cells.Get(10, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 2).Text = "Connect to Garmin RINO"
        Me.FpLanguages_Sheet1.Cells.Get(10, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 3).Text = "Use my GARMIN Rino"
        Me.FpLanguages_Sheet1.Cells.Get(10, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 4).Text = "Connetti al Garmin RINO"
        Me.FpLanguages_Sheet1.Cells.Get(10, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(10, 5).Text = "Connecter Garmin RINO"
        Me.FpLanguages_Sheet1.Cells.Get(11, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(11, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 1).Text = "mnuServData"
        Me.FpLanguages_Sheet1.Cells.Get(11, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 2).Text = "Connect to Database"
        Me.FpLanguages_Sheet1.Cells.Get(11, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 3).Text = "Connect to the Database"
        Me.FpLanguages_Sheet1.Cells.Get(11, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 4).Text = "Connetti al Database"
        Me.FpLanguages_Sheet1.Cells.Get(11, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(11, 5).Text = "Connecter Base Donn�es"
        Me.FpLanguages_Sheet1.Cells.Get(12, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(12, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 1).Text = "mnuServUIView"
        Me.FpLanguages_Sheet1.Cells.Get(12, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 2).Text = "Connect to UI-View"
        Me.FpLanguages_Sheet1.Cells.Get(12, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 3).Text = "Grab from UI-View"
        Me.FpLanguages_Sheet1.Cells.Get(12, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 4).Text = "Connetti ad UI-View"
        Me.FpLanguages_Sheet1.Cells.Get(12, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(12, 5).Text = "Connecter UI-View"
        Me.FpLanguages_Sheet1.Cells.Get(13, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(13, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 1).Text = "mnuServOzi"
        Me.FpLanguages_Sheet1.Cells.Get(13, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 2).Text = "Connect to OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(13, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 3).Text = "Send stuff to OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(13, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 4).Text = "Connetti ad OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(13, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(13, 5).Text = "Connecter OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(14, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(14, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 1).Text = "mnuServMapPoint"
        Me.FpLanguages_Sheet1.Cells.Get(14, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 2).Text = "Connect to Microsoft MapPoint"
        Me.FpLanguages_Sheet1.Cells.Get(14, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 3).Text = "Send stuff to MapPoint"
        Me.FpLanguages_Sheet1.Cells.Get(14, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 4).Text = "Connetti a Microsoft MapPoint"
        Me.FpLanguages_Sheet1.Cells.Get(14, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(14, 5).Text = "Connecter Map Point Microsoft"
        Me.FpLanguages_Sheet1.Cells.Get(15, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(15, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 1).Text = "mnuServHub"
        Me.FpLanguages_Sheet1.Cells.Get(15, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 2).Text = "Hub Listening"
        Me.FpLanguages_Sheet1.Cells.Get(15, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 3).Text = "Hub listening for stuff"
        Me.FpLanguages_Sheet1.Cells.Get(15, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 4).Text = "Ascolta l'Hub"
        Me.FpLanguages_Sheet1.Cells.Get(15, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(15, 5).Text = "Ecoute du Hub"
        Me.FpLanguages_Sheet1.Cells.Get(16, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(16, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 1).Text = "mnuServGPRS"
        Me.FpLanguages_Sheet1.Cells.Get(16, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 2).Text = "GPRS Listening"
        Me.FpLanguages_Sheet1.Cells.Get(16, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 3).Text = "Accept GPRS connections"
        Me.FpLanguages_Sheet1.Cells.Get(16, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 4).Text = "Ascolta il GPRS"
        Me.FpLanguages_Sheet1.Cells.Get(16, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(16, 5).Text = "Ecoute GPRS"
        Me.FpLanguages_Sheet1.Cells.Get(17, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(17, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 1).Text = "mnuServNetGPS"
        Me.FpLanguages_Sheet1.Cells.Get(17, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 2).Text = "NetGPS Listening"
        Me.FpLanguages_Sheet1.Cells.Get(17, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 3).Text = "Accept NetGPS connections"
        Me.FpLanguages_Sheet1.Cells.Get(17, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 4).Text = "Ascolta NetGPS"
        Me.FpLanguages_Sheet1.Cells.Get(17, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(17, 5).Text = "Ecoute NetGPS"
        Me.FpLanguages_Sheet1.Cells.Get(18, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(18, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 1).Text = "mnuServLog"
        Me.FpLanguages_Sheet1.Cells.Get(18, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 2).Text = "Log to File"
        Me.FpLanguages_Sheet1.Cells.Get(18, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 3).Text = "Record everything in a file"
        Me.FpLanguages_Sheet1.Cells.Get(18, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 4).Text = "Log su File"
        Me.FpLanguages_Sheet1.Cells.Get(18, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(18, 5).Text = "Fichier mouchard"
        Me.FpLanguages_Sheet1.Cells.Get(19, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(19, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 1).Text = "mnuGui"
        Me.FpLanguages_Sheet1.Cells.Get(19, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 2).Text = "GUI"
        Me.FpLanguages_Sheet1.Cells.Get(19, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 3).Text = "Look and Feel Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(19, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 4).Text = "GUI"
        Me.FpLanguages_Sheet1.Cells.Get(19, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(19, 5).Text = "GUI"
        Me.FpLanguages_Sheet1.Cells.Get(20, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(20, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 1).Text = "mnuGuiGeo"
        Me.FpLanguages_Sheet1.Cells.Get(20, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 2).Text = "Enable GeoFiltering"
        Me.FpLanguages_Sheet1.Cells.Get(20, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 3).Text = "I am only interested in local stuff"
        Me.FpLanguages_Sheet1.Cells.Get(20, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 4).Text = "Consenti GeoFiltering"
        Me.FpLanguages_Sheet1.Cells.Get(20, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(20, 5).Text = "Geofiltrage"
        Me.FpLanguages_Sheet1.Cells.Get(21, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(21, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 1).Text = "mnuGuiMonitored"
        Me.FpLanguages_Sheet1.Cells.Get(21, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 2).Text = "Upload Only Monitored Positions"
        Me.FpLanguages_Sheet1.Cells.Get(21, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 3).Text = "I am only interested in some stuff"
        Me.FpLanguages_Sheet1.Cells.Get(21, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 4).Text = "Scarica solo le Posizioni Monitorate"
        Me.FpLanguages_Sheet1.Cells.Get(21, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(21, 5).Text = "Charger seul. Positions monitor."
        Me.FpLanguages_Sheet1.Cells.Get(22, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(22, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 1).Text = "mnuGuiTranslate"
        Me.FpLanguages_Sheet1.Cells.Get(22, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 2).Text = "Translate Callsigns"
        Me.FpLanguages_Sheet1.Cells.Get(22, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 3).Text = "Translate callsigns to something nice"
        Me.FpLanguages_Sheet1.Cells.Get(22, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 4).Text = "Traduci i Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(22, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(22, 5).Text = "Traduire les indicatifs"
        Me.FpLanguages_Sheet1.Cells.Get(23, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(23, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 1).Text = "mnuGuiState"
        Me.FpLanguages_Sheet1.Cells.Get(23, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 2).Text = "State"
        Me.FpLanguages_Sheet1.Cells.Get(23, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 3).Text = "Remember things"
        Me.FpLanguages_Sheet1.Cells.Get(23, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 4).Text = "Stato"
        Me.FpLanguages_Sheet1.Cells.Get(23, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(23, 5).Text = "Etat"
        Me.FpLanguages_Sheet1.Cells.Get(24, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(24, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 1).Text = "mnuGuiStateLoad"
        Me.FpLanguages_Sheet1.Cells.Get(24, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 2).Text = "Load State"
        Me.FpLanguages_Sheet1.Cells.Get(24, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 3).Text = "Load remembered things"
        Me.FpLanguages_Sheet1.Cells.Get(24, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 4).Text = "Carica Stato"
        Me.FpLanguages_Sheet1.Cells.Get(24, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(24, 5).Text = "Charger Etat"
        Me.FpLanguages_Sheet1.Cells.Get(25, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(25, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 1).Text = "mnuGuiStateLoadFilename"
        Me.FpLanguages_Sheet1.Cells.Get(25, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 2).Text = "Load State from Filename"
        Me.FpLanguages_Sheet1.Cells.Get(25, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 3).Text = "load remembered things from Filename"
        Me.FpLanguages_Sheet1.Cells.Get(25, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 4).Text = "Carica Stato da File"
        Me.FpLanguages_Sheet1.Cells.Get(25, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(25, 5).Text = "Charger Etat de Fichier �"
        Me.FpLanguages_Sheet1.Cells.Get(26, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(26, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 1).Text = "mnuGuiStateSave"
        Me.FpLanguages_Sheet1.Cells.Get(26, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 2).Text = "Save State"
        Me.FpLanguages_Sheet1.Cells.Get(26, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 3).Text = "Save stuff for remembering"
        Me.FpLanguages_Sheet1.Cells.Get(26, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 4).Text = "Salva Stato"
        Me.FpLanguages_Sheet1.Cells.Get(26, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(26, 5).Text = "Sauver Etat"
        Me.FpLanguages_Sheet1.Cells.Get(27, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(27, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 1).Text = "mnuGuiStateSaveFilename"
        Me.FpLanguages_Sheet1.Cells.Get(27, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 2).Text = "Save State to Filename"
        Me.FpLanguages_Sheet1.Cells.Get(27, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 3).Text = "Save stuff for remembering from Filename"
        Me.FpLanguages_Sheet1.Cells.Get(27, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 4).Text = "Salva Stato su File"
        Me.FpLanguages_Sheet1.Cells.Get(27, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(27, 5).Text = "Sauver Etat sur fichier �"
        Me.FpLanguages_Sheet1.Cells.Get(28, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(28, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 1).Text = "mnuGuiDatabase"
        Me.FpLanguages_Sheet1.Cells.Get(28, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 2).Text = "Database Playback"
        Me.FpLanguages_Sheet1.Cells.Get(28, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 3).Text = "Playback stuff stored in database"
        Me.FpLanguages_Sheet1.Cells.Get(28, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 4).Text = "Playback del Database"
        Me.FpLanguages_Sheet1.Cells.Get(28, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(28, 5).Text = "RELECTURE base donn�es"
        Me.FpLanguages_Sheet1.Cells.Get(29, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(29, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 1).Text = "mnuInterfaces"
        Me.FpLanguages_Sheet1.Cells.Get(29, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 2).Text = "Interfaces"
        Me.FpLanguages_Sheet1.Cells.Get(29, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 3).Text = "External stuff"
        Me.FpLanguages_Sheet1.Cells.Get(29, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 4).Text = "Interfacce"
        Me.FpLanguages_Sheet1.Cells.Get(29, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(29, 5).Text = "Interfaces"
        Me.FpLanguages_Sheet1.Cells.Get(30, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(30, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 1).Text = "mnuInterfacesOziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(30, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 2).Text = "OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(30, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 3).Text = "Ozi Ozi Ozi� Oi Oi Oi"
        Me.FpLanguages_Sheet1.Cells.Get(30, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 4).Text = "OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(30, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(30, 5).Text = "OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(31, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(31, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 1).Text = "mnuInterfacesOziSync"
        Me.FpLanguages_Sheet1.Cells.Get(31, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 2).Text = "Sync"
        Me.FpLanguages_Sheet1.Cells.Get(31, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 3).Text = "Make the two the same"
        Me.FpLanguages_Sheet1.Cells.Get(31, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 4).Text = "Sincronizza"
        Me.FpLanguages_Sheet1.Cells.Get(31, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(31, 5).Text = "Sync"
        Me.FpLanguages_Sheet1.Cells.Get(32, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(32, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 1).Text = "mnuInterfacesOziClear"
        Me.FpLanguages_Sheet1.Cells.Get(32, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 2).Text = "Clear"
        Me.FpLanguages_Sheet1.Cells.Get(32, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 3).Text = "Clear Out Ozi."
        Me.FpLanguages_Sheet1.Cells.Get(32, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 4).Text = "Pulisci"
        Me.FpLanguages_Sheet1.Cells.Get(32, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(32, 5).Text = "RAZ"
        Me.FpLanguages_Sheet1.Cells.Get(33, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(33, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 1).Text = "mnuInterfacesOziDecay"
        Me.FpLanguages_Sheet1.Cells.Get(33, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 2).Text = "Decaying Icons"
        Me.FpLanguages_Sheet1.Cells.Get(33, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 3).Text = "Icons go dark over time"
        Me.FpLanguages_Sheet1.Cells.Get(33, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 4).Text = "Icone che Decadono"
        Me.FpLanguages_Sheet1.Cells.Get(33, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(33, 5).Text = "Icons ag�es"
        Me.FpLanguages_Sheet1.Cells.Get(34, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(34, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 1).Text = "mnuInterfacesOziAutoTrail"
        Me.FpLanguages_Sheet1.Cells.Get(34, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 2).Text = "AutoTrail Moving Stations"
        Me.FpLanguages_Sheet1.Cells.Get(34, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 3).Text = "Draw Snail Trails"
        Me.FpLanguages_Sheet1.Cells.Get(34, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 4).Text = "Crea il Percorso delle Stazioni in Movimento"
        Me.FpLanguages_Sheet1.Cells.Get(34, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(34, 5).Text = "Trace Auto stations mobiles"
        Me.FpLanguages_Sheet1.Cells.Get(35, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(35, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 1).Text = "mnuHelp"
        Me.FpLanguages_Sheet1.Cells.Get(35, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 2).Text = "Help"
        Me.FpLanguages_Sheet1.Cells.Get(35, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 3).Text = "We are here to help you mate"
        Me.FpLanguages_Sheet1.Cells.Get(35, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 4).Text = "Aiuto"
        Me.FpLanguages_Sheet1.Cells.Get(35, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(35, 5).Text = "Aide"
        Me.FpLanguages_Sheet1.Cells.Get(36, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(36, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 1).Text = "mnuHelpRegister"
        Me.FpLanguages_Sheet1.Cells.Get(36, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 2).Text = "Register"
        Me.FpLanguages_Sheet1.Cells.Get(36, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 3).Text = "Pay up or else I will rip your bloody arms off"
        Me.FpLanguages_Sheet1.Cells.Get(36, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 4).Text = "Registrazione"
        Me.FpLanguages_Sheet1.Cells.Get(36, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(36, 5).Text = "Inscription"
        Me.FpLanguages_Sheet1.Cells.Get(37, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 0).Text = "main"
        Me.FpLanguages_Sheet1.Cells.Get(37, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 1).Text = "mnuHelpAbout"
        Me.FpLanguages_Sheet1.Cells.Get(37, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 2).Text = "About"
        Me.FpLanguages_Sheet1.Cells.Get(37, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 3).Text = "Find out about stuff"
        Me.FpLanguages_Sheet1.Cells.Get(37, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 4).Text = "Crediti"
        Me.FpLanguages_Sheet1.Cells.Get(37, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(37, 5).Text = "Au sujet de"
        Me.FpLanguages_Sheet1.Cells.Get(38, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(38, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 1).Text = "tabDisplayPositions"
        Me.FpLanguages_Sheet1.Cells.Get(38, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 2).Text = "Display Positions"
        Me.FpLanguages_Sheet1.Cells.Get(38, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 3).Text = "Pozzies"
        Me.FpLanguages_Sheet1.Cells.Get(38, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 4).Text = "Mostra Posizioni"
        Me.FpLanguages_Sheet1.Cells.Get(38, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(38, 5).Text = "Affichage positions"
        Me.FpLanguages_Sheet1.Cells.Get(39, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(39, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 1).Text = "tabAllPositions"
        Me.FpLanguages_Sheet1.Cells.Get(39, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 2).Text = "All Positions"
        Me.FpLanguages_Sheet1.Cells.Get(39, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 3).Text = "All Possies"
        Me.FpLanguages_Sheet1.Cells.Get(39, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 4).Text = "Tutte le Posizioni"
        Me.FpLanguages_Sheet1.Cells.Get(39, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(39, 5).Text = "Toutes positions"
        Me.FpLanguages_Sheet1.Cells.Get(40, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(40, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 1).Text = "tabMessages"
        Me.FpLanguages_Sheet1.Cells.Get(40, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 2).Text = "Messages"
        Me.FpLanguages_Sheet1.Cells.Get(40, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 3).Text = "Messages and Mail"
        Me.FpLanguages_Sheet1.Cells.Get(40, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 4).Text = "Messaggi"
        Me.FpLanguages_Sheet1.Cells.Get(40, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(40, 5).Text = "Messages"
        Me.FpLanguages_Sheet1.Cells.Get(41, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(41, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 1).Text = "tabAPRSserver"
        Me.FpLanguages_Sheet1.Cells.Get(41, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 2).Text = "APRSserver"
        Me.FpLanguages_Sheet1.Cells.Get(41, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 3).Text = "Network Connections"
        Me.FpLanguages_Sheet1.Cells.Get(41, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 4).Text = "Server APRS"
        Me.FpLanguages_Sheet1.Cells.Get(41, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(41, 5).Text = "Setrveur APRS"
        Me.FpLanguages_Sheet1.Cells.Get(42, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(42, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 1).Text = "tabMonitor"
        Me.FpLanguages_Sheet1.Cells.Get(42, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 2).Text = "Monitor"
        Me.FpLanguages_Sheet1.Cells.Get(42, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 3).Text = "Monitoring Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(42, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 4).Text = "Monitor"
        Me.FpLanguages_Sheet1.Cells.Get(42, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(42, 5).Text = "Moniteur"
        Me.FpLanguages_Sheet1.Cells.Get(43, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(43, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 1).Text = "tabDevices"
        Me.FpLanguages_Sheet1.Cells.Get(43, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 2).Text = "Devices"
        Me.FpLanguages_Sheet1.Cells.Get(43, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 3).Text = "Devices and internals"
        Me.FpLanguages_Sheet1.Cells.Get(43, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 4).Text = "Device"
        Me.FpLanguages_Sheet1.Cells.Get(43, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(43, 5).Text = "P�riph�riques"
        Me.FpLanguages_Sheet1.Cells.Get(44, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 0).Text = "maintab"
        Me.FpLanguages_Sheet1.Cells.Get(44, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 1).Text = "tabCallsignTranslation"
        Me.FpLanguages_Sheet1.Cells.Get(44, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 2).Text = "Callsign Translation"
        Me.FpLanguages_Sheet1.Cells.Get(44, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 3).Text = "Translation stuff"
        Me.FpLanguages_Sheet1.Cells.Get(44, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 4).Text = "Traduzione dei Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(44, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(44, 5).Text = "Traduction Indicatif"
        Me.FpLanguages_Sheet1.Cells.Get(45, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(45, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 1).Text = "LocalPort"
        Me.FpLanguages_Sheet1.Cells.Get(45, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 2).Text = "Local Port"
        Me.FpLanguages_Sheet1.Cells.Get(45, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 3).Text = "Home Port"
        Me.FpLanguages_Sheet1.Cells.Get(45, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 4).Text = "Porta Locale"
        Me.FpLanguages_Sheet1.Cells.Get(45, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(45, 5).Text = "Port Local"
        Me.FpLanguages_Sheet1.Cells.Get(46, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(46, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 1).Text = "LocalAddress"
        Me.FpLanguages_Sheet1.Cells.Get(46, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 2).Text = "Local Address"
        Me.FpLanguages_Sheet1.Cells.Get(46, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 3).Text = "Home Address"
        Me.FpLanguages_Sheet1.Cells.Get(46, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 4).Text = "Indirizzo Locale"
        Me.FpLanguages_Sheet1.Cells.Get(46, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(46, 5).Text = "Adresse Locale"
        Me.FpLanguages_Sheet1.Cells.Get(47, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(47, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 1).Text = "RemotePort"
        Me.FpLanguages_Sheet1.Cells.Get(47, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 2).Text = "Remote Port"
        Me.FpLanguages_Sheet1.Cells.Get(47, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 3).Text = "Their Port"
        Me.FpLanguages_Sheet1.Cells.Get(47, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 4).Text = "Porta Remota"
        Me.FpLanguages_Sheet1.Cells.Get(47, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(47, 5).Text = "Port � distance"
        Me.FpLanguages_Sheet1.Cells.Get(48, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(48, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 1).Text = "RemoteAddress"
        Me.FpLanguages_Sheet1.Cells.Get(48, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 2).Text = "Remote Address"
        Me.FpLanguages_Sheet1.Cells.Get(48, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 3).Text = "Their Address"
        Me.FpLanguages_Sheet1.Cells.Get(48, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 4).Text = "Indirizzo Remoto"
        Me.FpLanguages_Sheet1.Cells.Get(48, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(48, 5).Text = "Adresse � distance"
        Me.FpLanguages_Sheet1.Cells.Get(49, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(49, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 1).Text = "StreamID"
        Me.FpLanguages_Sheet1.Cells.Get(49, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 2).Text = "Stream ID"
        Me.FpLanguages_Sheet1.Cells.Get(49, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 3).Text = "Random Number"
        Me.FpLanguages_Sheet1.Cells.Get(49, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 4).Text = "Identificativo di Flusso Dati"
        Me.FpLanguages_Sheet1.Cells.Get(49, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(49, 5).Text = "Stream ID"
        Me.FpLanguages_Sheet1.Cells.Get(50, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(50, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 1).Text = "Dataline"
        Me.FpLanguages_Sheet1.Cells.Get(50, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 2).Text = "Data Line"
        Me.FpLanguages_Sheet1.Cells.Get(50, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 3).Text = "What we got from them"
        Me.FpLanguages_Sheet1.Cells.Get(50, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 4).Text = "Stringa Dati"
        Me.FpLanguages_Sheet1.Cells.Get(50, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(50, 5).Text = "Data Line"
        Me.FpLanguages_Sheet1.Cells.Get(51, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(51, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 1).Text = "user"
        Me.FpLanguages_Sheet1.Cells.Get(51, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 2).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(51, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 3).Text = "Their Name"
        Me.FpLanguages_Sheet1.Cells.Get(51, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 4).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(51, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(51, 5).Text = "Indicatif"
        Me.FpLanguages_Sheet1.Cells.Get(52, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(52, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 1).Text = "LastRX"
        Me.FpLanguages_Sheet1.Cells.Get(52, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 2).Text = "Last RX"
        Me.FpLanguages_Sheet1.Cells.Get(52, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 3).Text = "When"
        Me.FpLanguages_Sheet1.Cells.Get(52, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 4).Text = "Ultima Ricezione"
        Me.FpLanguages_Sheet1.Cells.Get(52, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(52, 5).Text = "Dernier re�u"
        Me.FpLanguages_Sheet1.Cells.Get(53, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(53, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(53, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(53, 1).Text = "Driver"
        Me.FpLanguages_Sheet1.Cells.Get(54, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(54, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 1).Text = "DriverID"
        Me.FpLanguages_Sheet1.Cells.Get(54, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 2).Text = "Type"
        Me.FpLanguages_Sheet1.Cells.Get(54, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 3).Text = "Are they real"
        Me.FpLanguages_Sheet1.Cells.Get(54, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 4).Text = "Tipo"
        Me.FpLanguages_Sheet1.Cells.Get(54, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(54, 5).Text = "Type"
        Me.FpLanguages_Sheet1.Cells.Get(55, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 0).Text = "fptcpaprsserverspread"
        Me.FpLanguages_Sheet1.Cells.Get(55, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 1).Text = "Disconnect"
        Me.FpLanguages_Sheet1.Cells.Get(55, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 2).Text = "Disconnect"
        Me.FpLanguages_Sheet1.Cells.Get(55, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 3).Text = "Kill 'Em."
        Me.FpLanguages_Sheet1.Cells.Get(55, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 4).Text = "Disconnetti"
        Me.FpLanguages_Sheet1.Cells.Get(55, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(55, 5).Text = "Deconnecter"
        Me.FpLanguages_Sheet1.Cells.Get(56, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 0).Text = "fpCallsignTranslation"
        Me.FpLanguages_Sheet1.Cells.Get(56, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 1).Text = "OldCallsign"
        Me.FpLanguages_Sheet1.Cells.Get(56, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 2).Text = "From"
        Me.FpLanguages_Sheet1.Cells.Get(56, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 3).Text = "Stupid Name"
        Me.FpLanguages_Sheet1.Cells.Get(56, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 4).Text = "Da"
        Me.FpLanguages_Sheet1.Cells.Get(56, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(56, 5).Text = "DE"
        Me.FpLanguages_Sheet1.Cells.Get(57, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 0).Text = "fpCallsignTranslation"
        Me.FpLanguages_Sheet1.Cells.Get(57, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 1).Text = "NewCallsign"
        Me.FpLanguages_Sheet1.Cells.Get(57, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 2).Text = "To"
        Me.FpLanguages_Sheet1.Cells.Get(57, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 3).Text = "Great Name"
        Me.FpLanguages_Sheet1.Cells.Get(57, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 4).Text = "A"
        Me.FpLanguages_Sheet1.Cells.Get(57, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(57, 5).Text = "VERS"
        Me.FpLanguages_Sheet1.Cells.Get(58, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(58, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 1).Text = "scOziExplorerID"
        Me.FpLanguages_Sheet1.Cells.Get(58, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 2).Text = "OziID"
        Me.FpLanguages_Sheet1.Cells.Get(58, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 3).Text = "Ozi Internal"
        Me.FpLanguages_Sheet1.Cells.Get(58, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 4).Text = "Ozi-ID"
        Me.FpLanguages_Sheet1.Cells.Get(58, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(58, 5).Text = "OziID"
        Me.FpLanguages_Sheet1.Cells.Get(59, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(59, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 1).Text = "scMonitor"
        Me.FpLanguages_Sheet1.Cells.Get(59, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 2).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(59, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 3).Text = "Watch"
        Me.FpLanguages_Sheet1.Cells.Get(59, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 4).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(59, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(59, 5).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(60, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(60, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 1).Text = "scTrack"
        Me.FpLanguages_Sheet1.Cells.Get(60, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 2).Text = "Trk"
        Me.FpLanguages_Sheet1.Cells.Get(60, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 3).Text = "Spy"
        Me.FpLanguages_Sheet1.Cells.Get(60, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 4).Text = "Tr.cia"
        Me.FpLanguages_Sheet1.Cells.Get(60, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(60, 5).Text = "Traj."
        Me.FpLanguages_Sheet1.Cells.Get(61, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(61, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 1).Text = "scCallsign"
        Me.FpLanguages_Sheet1.Cells.Get(61, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 2).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(61, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 3).Text = "His Name"
        Me.FpLanguages_Sheet1.Cells.Get(61, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 4).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(61, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(61, 5).Text = "Indicatif"
        Me.FpLanguages_Sheet1.Cells.Get(62, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(62, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 1).Text = "scSymbol"
        Me.FpLanguages_Sheet1.Cells.Get(62, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 2).Text = "Symbol"
        Me.FpLanguages_Sheet1.Cells.Get(62, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 3).Text = "His icon"
        Me.FpLanguages_Sheet1.Cells.Get(62, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 4).Text = "Simbolo"
        Me.FpLanguages_Sheet1.Cells.Get(62, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(62, 5).Text = "Symbole"
        Me.FpLanguages_Sheet1.Cells.Get(63, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(63, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 1).Text = "scLat"
        Me.FpLanguages_Sheet1.Cells.Get(63, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 2).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(63, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 3).Text = "South"
        Me.FpLanguages_Sheet1.Cells.Get(63, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 4).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(63, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(63, 5).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(64, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(64, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 1).Text = "scLon"
        Me.FpLanguages_Sheet1.Cells.Get(64, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 2).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(64, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 3).Text = "East"
        Me.FpLanguages_Sheet1.Cells.Get(64, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 4).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(64, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(64, 5).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(65, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(65, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 1).Text = "scAlt"
        Me.FpLanguages_Sheet1.Cells.Get(65, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 2).Text = "Alt"
        Me.FpLanguages_Sheet1.Cells.Get(65, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 3).Text = "How High"
        Me.FpLanguages_Sheet1.Cells.Get(65, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 4).Text = "Alt"
        Me.FpLanguages_Sheet1.Cells.Get(65, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(65, 5).Text = "Alt"
        Me.FpLanguages_Sheet1.Cells.Get(66, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(66, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 1).Text = "scSpeed"
        Me.FpLanguages_Sheet1.Cells.Get(66, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 2).Text = "Spd"
        Me.FpLanguages_Sheet1.Cells.Get(66, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 3).Text = "Go Faster"
        Me.FpLanguages_Sheet1.Cells.Get(66, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 4).Text = "Vel"
        Me.FpLanguages_Sheet1.Cells.Get(66, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(66, 5).Text = "Vit."
        Me.FpLanguages_Sheet1.Cells.Get(67, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(67, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 1).Text = "scHeading"
        Me.FpLanguages_Sheet1.Cells.Get(67, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 2).Text = "Hdg"
        Me.FpLanguages_Sheet1.Cells.Get(67, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 3).Text = "That way"
        Me.FpLanguages_Sheet1.Cells.Get(67, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 4).Text = "Dir.ne"
        Me.FpLanguages_Sheet1.Cells.Get(67, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(67, 5).Text = "Cap"
        Me.FpLanguages_Sheet1.Cells.Get(68, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(68, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 1).Text = "scStatus"
        Me.FpLanguages_Sheet1.Cells.Get(68, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 2).Text = "Status"
        Me.FpLanguages_Sheet1.Cells.Get(68, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 3).Text = "Got Fuel?"
        Me.FpLanguages_Sheet1.Cells.Get(68, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 4).Text = "Stato"
        Me.FpLanguages_Sheet1.Cells.Get(68, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(68, 5).Text = "Status"
        Me.FpLanguages_Sheet1.Cells.Get(69, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(69, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 1).Text = "scDescription"
        Me.FpLanguages_Sheet1.Cells.Get(69, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 2).Text = "Desc"
        Me.FpLanguages_Sheet1.Cells.Get(69, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 3).Text = "Des"
        Me.FpLanguages_Sheet1.Cells.Get(69, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 4).Text = "Descr."
        Me.FpLanguages_Sheet1.Cells.Get(69, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(69, 5).Text = "Desc"
        Me.FpLanguages_Sheet1.Cells.Get(70, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(70, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 1).Text = "scUpdated"
        Me.FpLanguages_Sheet1.Cells.Get(70, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 2).Text = "Upd"
        Me.FpLanguages_Sheet1.Cells.Get(70, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 3).Text = "When"
        Me.FpLanguages_Sheet1.Cells.Get(70, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 4).Text = "Aggrn."
        Me.FpLanguages_Sheet1.Cells.Get(70, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(70, 5).Text = "MAJ"
        Me.FpLanguages_Sheet1.Cells.Get(71, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(71, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 1).Text = "scUpdatedRead"
        Me.FpLanguages_Sheet1.Cells.Get(71, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 2).Text = "Upd Read"
        Me.FpLanguages_Sheet1.Cells.Get(71, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 3).Text = "When Real"
        Me.FpLanguages_Sheet1.Cells.Get(71, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 4).Text = "Lettura Aggrn."
        Me.FpLanguages_Sheet1.Cells.Get(71, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(71, 5).Text = "Lire MAJ"
        Me.FpLanguages_Sheet1.Cells.Get(72, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(72, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 1).Text = "scDataSource"
        Me.FpLanguages_Sheet1.Cells.Get(72, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 2).Text = "Sec"
        Me.FpLanguages_Sheet1.Cells.Get(72, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 3).Text = "From Where"
        Me.FpLanguages_Sheet1.Cells.Get(72, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 4).Text = "Sec"
        Me.FpLanguages_Sheet1.Cells.Get(72, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(72, 5).Text = "Sec"
        Me.FpLanguages_Sheet1.Cells.Get(73, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(73, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 1).Text = "scLine"
        Me.FpLanguages_Sheet1.Cells.Get(73, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 2).Text = "Line"
        Me.FpLanguages_Sheet1.Cells.Get(73, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 3).Text = "Lines and Line"
        Me.FpLanguages_Sheet1.Cells.Get(73, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 4).Text = "Linea"
        Me.FpLanguages_Sheet1.Cells.Get(73, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(73, 5).Text = "Ligne"
        Me.FpLanguages_Sheet1.Cells.Get(74, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(74, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 1).Text = "scDetail"
        Me.FpLanguages_Sheet1.Cells.Get(74, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 2).Text = "Detail"
        Me.FpLanguages_Sheet1.Cells.Get(74, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 3).Text = "More Details"
        Me.FpLanguages_Sheet1.Cells.Get(74, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 4).Text = "Dettagli"
        Me.FpLanguages_Sheet1.Cells.Get(74, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(74, 5).Text = "D�tail"
        Me.FpLanguages_Sheet1.Cells.Get(75, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(75, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 1).Text = "scColor"
        Me.FpLanguages_Sheet1.Cells.Get(75, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 2).Text = "Colour"
        Me.FpLanguages_Sheet1.Cells.Get(75, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 3).Text = "Black and White"
        Me.FpLanguages_Sheet1.Cells.Get(75, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 4).Text = "Colore"
        Me.FpLanguages_Sheet1.Cells.Get(75, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(75, 5).Text = "Couleur"
        Me.FpLanguages_Sheet1.Cells.Get(76, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(76, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 1).Text = "scMapPointID"
        Me.FpLanguages_Sheet1.Cells.Get(76, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 2).Text = "MapPointID"
        Me.FpLanguages_Sheet1.Cells.Get(76, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 3).Text = "Microsoft Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(76, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 4).Text = "MapPoint-ID"
        Me.FpLanguages_Sheet1.Cells.Get(76, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(76, 5).Text = "ID Map Point"
        Me.FpLanguages_Sheet1.Cells.Get(77, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(77, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 1).Text = "scStale"
        Me.FpLanguages_Sheet1.Cells.Get(77, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 2).Text = "Stale"
        Me.FpLanguages_Sheet1.Cells.Get(77, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 3).Text = "Stinks"
        Me.FpLanguages_Sheet1.Cells.Get(77, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 4).Text = "Non Aggiornato"
        Me.FpLanguages_Sheet1.Cells.Get(77, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(77, 5).Text = "Etat"
        Me.FpLanguages_Sheet1.Cells.Get(78, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(78, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 1).Text = "scTrail"
        Me.FpLanguages_Sheet1.Cells.Get(78, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 2).Text = "Trail"
        Me.FpLanguages_Sheet1.Cells.Get(78, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 3).Text = "Snail Trail"
        Me.FpLanguages_Sheet1.Cells.Get(78, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 4).Text = "Percorso"
        Me.FpLanguages_Sheet1.Cells.Get(78, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(78, 5).Text = "Trace"
        Me.FpLanguages_Sheet1.Cells.Get(79, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(79, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 1).Text = "scTrailNumber"
        Me.FpLanguages_Sheet1.Cells.Get(79, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 2).Text = "Trail No"
        Me.FpLanguages_Sheet1.Cells.Get(79, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 3).Text = "Snail Trail Number"
        Me.FpLanguages_Sheet1.Cells.Get(79, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 4).Text = "Num. Percorso"
        Me.FpLanguages_Sheet1.Cells.Get(79, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(79, 5).Text = "N�Trace"
        Me.FpLanguages_Sheet1.Cells.Get(80, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 0).Text = "fpDevGuiMaster"
        Me.FpLanguages_Sheet1.Cells.Get(80, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 1).Text = "scGPRMC"
        Me.FpLanguages_Sheet1.Cells.Get(80, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 2).Text = "GPRMC"
        Me.FpLanguages_Sheet1.Cells.Get(80, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 3).Text = "GPS Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(80, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 4).Text = "GPRMC"
        Me.FpLanguages_Sheet1.Cells.Get(80, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(80, 5).Text = "GPRMC"
        Me.FpLanguages_Sheet1.Cells.Get(81, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(81, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 1).Text = "Monitor"
        Me.FpLanguages_Sheet1.Cells.Get(81, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 2).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(81, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 3).Text = "Spy"
        Me.FpLanguages_Sheet1.Cells.Get(81, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 4).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(81, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(81, 5).Text = "Mon"
        Me.FpLanguages_Sheet1.Cells.Get(82, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(82, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 1).Text = "Detail"
        Me.FpLanguages_Sheet1.Cells.Get(82, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 2).Text = "Detail"
        Me.FpLanguages_Sheet1.Cells.Get(82, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 3).Text = "Spy Better"
        Me.FpLanguages_Sheet1.Cells.Get(82, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 4).Text = "Dettagli"
        Me.FpLanguages_Sheet1.Cells.Get(82, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(82, 5).Text = "Detail"
        Me.FpLanguages_Sheet1.Cells.Get(83, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(83, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 1).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(83, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 2).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(83, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 3).Text = "His Name"
        Me.FpLanguages_Sheet1.Cells.Get(83, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 4).Text = "Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(83, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(83, 5).Text = "Indicatif"
        Me.FpLanguages_Sheet1.Cells.Get(84, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(84, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 1).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(84, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 2).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(84, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 3).Text = "North"
        Me.FpLanguages_Sheet1.Cells.Get(84, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 4).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(84, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(84, 5).Text = "Lat"
        Me.FpLanguages_Sheet1.Cells.Get(85, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(85, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 1).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(85, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 2).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(85, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 3).Text = "East"
        Me.FpLanguages_Sheet1.Cells.Get(85, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 4).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(85, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(85, 5).Text = "Lon"
        Me.FpLanguages_Sheet1.Cells.Get(86, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(86, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 1).Text = "Alt"
        Me.FpLanguages_Sheet1.Cells.Get(86, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 2).Text = "Hdg"
        Me.FpLanguages_Sheet1.Cells.Get(86, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 3).Text = "High?"
        Me.FpLanguages_Sheet1.Cells.Get(86, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 4).Text = "Alt"
        Me.FpLanguages_Sheet1.Cells.Get(86, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(86, 5).Text = "Cap"
        Me.FpLanguages_Sheet1.Cells.Get(87, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(87, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 1).Text = "Spd"
        Me.FpLanguages_Sheet1.Cells.Get(87, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 2).Text = "Speed"
        Me.FpLanguages_Sheet1.Cells.Get(87, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 3).Text = "Speed Up"
        Me.FpLanguages_Sheet1.Cells.Get(87, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 4).Text = "Vel"
        Me.FpLanguages_Sheet1.Cells.Get(87, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(87, 5).Text = "Vit."
        Me.FpLanguages_Sheet1.Cells.Get(88, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(88, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 1).Text = "Heading"
        Me.FpLanguages_Sheet1.Cells.Get(88, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 2).Text = "Hdg"
        Me.FpLanguages_Sheet1.Cells.Get(88, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 3).Text = "That way"
        Me.FpLanguages_Sheet1.Cells.Get(88, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 4).Text = "Direz."
        Me.FpLanguages_Sheet1.Cells.Get(88, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(88, 5).Text = "Cap"
        Me.FpLanguages_Sheet1.Cells.Get(89, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(89, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 1).Text = "Time"
        Me.FpLanguages_Sheet1.Cells.Get(89, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 2).Text = "Time"
        Me.FpLanguages_Sheet1.Cells.Get(89, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 3).Text = "Stopwatch"
        Me.FpLanguages_Sheet1.Cells.Get(89, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 4).Text = "Data e Ora"
        Me.FpLanguages_Sheet1.Cells.Get(89, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(89, 5).Text = "Heure"
        Me.FpLanguages_Sheet1.Cells.Get(90, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(90, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 1).Text = "Track"
        Me.FpLanguages_Sheet1.Cells.Get(90, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 2).Text = "Track"
        Me.FpLanguages_Sheet1.Cells.Get(90, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 3).Text = "Spy Constantly"
        Me.FpLanguages_Sheet1.Cells.Get(90, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 4).Text = "Descr."
        Me.FpLanguages_Sheet1.Cells.Get(90, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(90, 5).Text = "Trajet"
        Me.FpLanguages_Sheet1.Cells.Get(91, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 0).Text = "fpDevGui"
        Me.FpLanguages_Sheet1.Cells.Get(91, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 1).Text = "Trail"
        Me.FpLanguages_Sheet1.Cells.Get(91, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 2).Text = "Trail"
        Me.FpLanguages_Sheet1.Cells.Get(91, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 3).Text = "Snail Him"
        Me.FpLanguages_Sheet1.Cells.Get(91, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 4).Text = "Percorso"
        Me.FpLanguages_Sheet1.Cells.Get(91, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(91, 5).Text = "Trac�"
        Me.FpLanguages_Sheet1.Cells.Get(92, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(92, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 1).Text = "lblCallsign"
        Me.FpLanguages_Sheet1.Cells.Get(92, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 2).Text = "Station Callsign"
        Me.FpLanguages_Sheet1.Cells.Get(92, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 3).Text = "My Name"
        Me.FpLanguages_Sheet1.Cells.Get(92, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 4).Text = "Callsign della Stazione"
        Me.FpLanguages_Sheet1.Cells.Get(92, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(92, 5).Text = "Indic.Station"
        Me.FpLanguages_Sheet1.Cells.Get(93, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(93, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 1).Text = "lblLat"
        Me.FpLanguages_Sheet1.Cells.Get(93, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 2).Text = "Default Lattidude"
        Me.FpLanguages_Sheet1.Cells.Get(93, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 3).Text = "My North"
        Me.FpLanguages_Sheet1.Cells.Get(93, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 4).Text = "Latitudine di Default"
        Me.FpLanguages_Sheet1.Cells.Get(93, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(93, 5).Text = "Latitude d�faut"
        Me.FpLanguages_Sheet1.Cells.Get(94, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(94, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 1).Text = "lblLon"
        Me.FpLanguages_Sheet1.Cells.Get(94, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 2).Text = "Default Longitude"
        Me.FpLanguages_Sheet1.Cells.Get(94, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 3).Text = "My East"
        Me.FpLanguages_Sheet1.Cells.Get(94, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 4).Text = "Longitudine di Default"
        Me.FpLanguages_Sheet1.Cells.Get(94, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(94, 5).Text = "Longitude d�faut"
        Me.FpLanguages_Sheet1.Cells.Get(95, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(95, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 1).Text = "grpGPS"
        Me.FpLanguages_Sheet1.Cells.Get(95, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 2).Text = "GPS"
        Me.FpLanguages_Sheet1.Cells.Get(95, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 3).Text = "GPS Data"
        Me.FpLanguages_Sheet1.Cells.Get(95, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 4).Text = "GPS"
        Me.FpLanguages_Sheet1.Cells.Get(95, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(95, 5).Text = "GPS"
        Me.FpLanguages_Sheet1.Cells.Get(96, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(96, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 1).Text = "lblGPSport"
        Me.FpLanguages_Sheet1.Cells.Get(96, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 2).Text = "GPS Port"
        Me.FpLanguages_Sheet1.Cells.Get(96, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 3).Text = "GPS COM"
        Me.FpLanguages_Sheet1.Cells.Get(96, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 4).Text = "Porta GPS"
        Me.FpLanguages_Sheet1.Cells.Get(96, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(96, 5).Text = "Port GPS"
        Me.FpLanguages_Sheet1.Cells.Get(97, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(97, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 1).Text = "lblGPSspeed"
        Me.FpLanguages_Sheet1.Cells.Get(97, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 2).Text = "GPS Speed"
        Me.FpLanguages_Sheet1.Cells.Get(97, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 3).Text = "GPS spd"
        Me.FpLanguages_Sheet1.Cells.Get(97, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 4).Text = "Velocit� GPS"
        Me.FpLanguages_Sheet1.Cells.Get(97, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(97, 5).Text = "Vitesse GPS"
        Me.FpLanguages_Sheet1.Cells.Get(98, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(98, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 1).Text = "chkLoopbackPos"
        Me.FpLanguages_Sheet1.Cells.Get(98, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 2).Text = "Loopback my position reports"
        Me.FpLanguages_Sheet1.Cells.Get(98, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 3).Text = "I see myself?"
        Me.FpLanguages_Sheet1.Cells.Get(98, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 4).Text = "Esegui il Loopback della mia Posizione"
        Me.FpLanguages_Sheet1.Cells.Get(98, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(98, 5).Text = "Relecture rep. Posit."
        Me.FpLanguages_Sheet1.Cells.Get(99, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(99, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 1).Text = "lblNetworkBeacon"
        Me.FpLanguages_Sheet1.Cells.Get(99, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 2).Text = "Network Beacon Rate (secs)"
        Me.FpLanguages_Sheet1.Cells.Get(99, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 3).Text = "Net beacon rate"
        Me.FpLanguages_Sheet1.Cells.Get(99, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 4).Text = "Frequenza Network Beacon (sec)"
        Me.FpLanguages_Sheet1.Cells.Get(99, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(99, 5).Text = "Network Beacon Rate (secs)"
        Me.FpLanguages_Sheet1.Cells.Get(100, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(100, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 1).Text = "lblRadioBeacon"
        Me.FpLanguages_Sheet1.Cells.Get(100, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 2).Text = "Radio Beacon Rate (secs)"
        Me.FpLanguages_Sheet1.Cells.Get(100, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 3).Text = "RF Beacon Rate"
        Me.FpLanguages_Sheet1.Cells.Get(100, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 4).Text = "Frequenza Radio Beacon (sec)"
        Me.FpLanguages_Sheet1.Cells.Get(100, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(100, 5).Text = "Radio Beacon Rate (secs)"
        Me.FpLanguages_Sheet1.Cells.Get(101, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(101, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 1).Text = "chkNMEAauto"
        Me.FpLanguages_Sheet1.Cells.Get(101, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 2).Text = "Auto NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(101, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 3).Text = "Auto GPS"
        Me.FpLanguages_Sheet1.Cells.Get(101, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 4).Text = "Auto NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(101, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(101, 5).Text = "Auto NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(102, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(102, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 1).Text = "grpOutgoing"
        Me.FpLanguages_Sheet1.Cells.Get(102, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 2).Text = "Outgoing"
        Me.FpLanguages_Sheet1.Cells.Get(102, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 3).Text = "Extrovert Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(102, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 4).Text = "In Uscita"
        Me.FpLanguages_Sheet1.Cells.Get(102, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(102, 5).Text = "en sortie"
        Me.FpLanguages_Sheet1.Cells.Get(103, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(103, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 1).Text = "lblOutgoingServer"
        Me.FpLanguages_Sheet1.Cells.Get(103, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 2).Text = "Outgoing Server"
        Me.FpLanguages_Sheet1.Cells.Get(103, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 3).Text = "Very Outgoing"
        Me.FpLanguages_Sheet1.Cells.Get(103, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 4).Text = "Server"
        Me.FpLanguages_Sheet1.Cells.Get(103, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(103, 5).Text = "sortie du serveur"
        Me.FpLanguages_Sheet1.Cells.Get(104, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(104, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 1).Text = "lblLoginString"
        Me.FpLanguages_Sheet1.Cells.Get(104, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 2).Text = "Login String"
        Me.FpLanguages_Sheet1.Cells.Get(104, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 3).Text = "Introducing"
        Me.FpLanguages_Sheet1.Cells.Get(104, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 4).Text = "Stringa di Login"
        Me.FpLanguages_Sheet1.Cells.Get(104, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(104, 5).Text = "Login String"
        Me.FpLanguages_Sheet1.Cells.Get(105, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(105, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 1).Text = "lblOnConnect"
        Me.FpLanguages_Sheet1.Cells.Get(105, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 2).Text = "On Connect String"
        Me.FpLanguages_Sheet1.Cells.Get(105, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 3).Text = "My Job"
        Me.FpLanguages_Sheet1.Cells.Get(105, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 4).Text = "Stringa di Connessione"
        Me.FpLanguages_Sheet1.Cells.Get(105, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(105, 5).Text = "On Connect String"
        Me.FpLanguages_Sheet1.Cells.Get(106, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(106, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 1).Text = "chkAutoServerConnect"
        Me.FpLanguages_Sheet1.Cells.Get(106, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 2).Text = "Auto Connect to Server"
        Me.FpLanguages_Sheet1.Cells.Get(106, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 3).Text = "Always Extroverted"
        Me.FpLanguages_Sheet1.Cells.Get(106, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 4).Text = "Connetti Automaticamente al Server"
        Me.FpLanguages_Sheet1.Cells.Get(106, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(106, 5).Text = "Connect. Auto au serveur"
        Me.FpLanguages_Sheet1.Cells.Get(107, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(107, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 1).Text = "grpIncoming"
        Me.FpLanguages_Sheet1.Cells.Get(107, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 2).Text = "Incoming"
        Me.FpLanguages_Sheet1.Cells.Get(107, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 3).Text = "Chat me up"
        Me.FpLanguages_Sheet1.Cells.Get(107, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 4).Text = "In Entrata"
        Me.FpLanguages_Sheet1.Cells.Get(107, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(107, 5).Text = "En entr�e"
        Me.FpLanguages_Sheet1.Cells.Get(108, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(108, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 1).Text = "chkHubDumpHistory"
        Me.FpLanguages_Sheet1.Cells.Get(108, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 2).Text = "Dump history on connect"
        Me.FpLanguages_Sheet1.Cells.Get(108, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 3).Text = "Previous relationships?"
        Me.FpLanguages_Sheet1.Cells.Get(108, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 4).Text = "Scarica Dati Pregressi alla Connessione"
        Me.FpLanguages_Sheet1.Cells.Get(108, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(108, 5).Text = "Historique � la connection"
        Me.FpLanguages_Sheet1.Cells.Get(109, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(109, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 1).Text = "chkHubAutoListen"
        Me.FpLanguages_Sheet1.Cells.Get(109, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 2).Text = "Auto HUB listen"
        Me.FpLanguages_Sheet1.Cells.Get(109, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 3).Text = "Hub eh?"
        Me.FpLanguages_Sheet1.Cells.Get(109, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 4).Text = "Ascolta Automaticamente l'Hub"
        Me.FpLanguages_Sheet1.Cells.Get(109, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(109, 5).Text = "�coute auto du Hub"
        Me.FpLanguages_Sheet1.Cells.Get(110, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(110, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 1).Text = "chkAutoGPRSlisten"
        Me.FpLanguages_Sheet1.Cells.Get(110, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 2).Text = "Auto GPRS listen"
        Me.FpLanguages_Sheet1.Cells.Get(110, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 3).Text = "GPRS spying"
        Me.FpLanguages_Sheet1.Cells.Get(110, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 4).Text = "Ascolta Automaticamente il GPRS"
        Me.FpLanguages_Sheet1.Cells.Get(110, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(110, 5).Text = "�coute du GPRS"
        Me.FpLanguages_Sheet1.Cells.Get(111, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(111, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 1).Text = "chkAutoNetGPSListen"
        Me.FpLanguages_Sheet1.Cells.Get(111, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 2).Text = "Auto NetGPS listen"
        Me.FpLanguages_Sheet1.Cells.Get(111, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 3).Text = "Listening for NetGPS"
        Me.FpLanguages_Sheet1.Cells.Get(111, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 4).Text = "Ascolta Automaticamente NetGPS"
        Me.FpLanguages_Sheet1.Cells.Get(111, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(111, 5).Text = "�coute de netGPS"
        Me.FpLanguages_Sheet1.Cells.Get(112, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(112, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 1).Text = "chkCallsignTranslation"
        Me.FpLanguages_Sheet1.Cells.Get(112, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 2).Text = "Callsign Traslation on Startup"
        Me.FpLanguages_Sheet1.Cells.Get(112, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 3).Text = "Get the nicer names always"
        Me.FpLanguages_Sheet1.Cells.Get(112, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 4).Text = "Traduzione dei Callsign all'Avvio"
        Me.FpLanguages_Sheet1.Cells.Get(112, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(112, 5).Text = "Traduc. Indic. Au d�part"
        Me.FpLanguages_Sheet1.Cells.Get(113, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(113, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 1).Text = "lblTNCComPort"
        Me.FpLanguages_Sheet1.Cells.Get(113, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 2).Text = "TNC COM Port"
        Me.FpLanguages_Sheet1.Cells.Get(113, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 3).Text = "Radio Com Port"
        Me.FpLanguages_Sheet1.Cells.Get(113, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 4).Text = "Porta COM del Modem TNC"
        Me.FpLanguages_Sheet1.Cells.Get(113, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(113, 5).Text = "port COM du TNC"
        Me.FpLanguages_Sheet1.Cells.Get(114, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(114, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 1).Text = "lblTNCspeed"
        Me.FpLanguages_Sheet1.Cells.Get(114, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 2).Text = "TNC Speed"
        Me.FpLanguages_Sheet1.Cells.Get(114, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 3).Text = "Speed? For the TNC"
        Me.FpLanguages_Sheet1.Cells.Get(114, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 4).Text = "Velocit� del Modem TNC"
        Me.FpLanguages_Sheet1.Cells.Get(114, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(114, 5).Text = "vitesse du TNC"
        Me.FpLanguages_Sheet1.Cells.Get(115, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(115, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 1).Text = "chkTNCKiss"
        Me.FpLanguages_Sheet1.Cells.Get(115, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 2).Text = "TNC KISS Mode"
        Me.FpLanguages_Sheet1.Cells.Get(115, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 3).Text = "Kiss me?"
        Me.FpLanguages_Sheet1.Cells.Get(115, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 4).Text = "Modalit� Kiss"
        Me.FpLanguages_Sheet1.Cells.Get(115, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(115, 5).Text = "mode Kiss du TNC"
        Me.FpLanguages_Sheet1.Cells.Get(116, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(116, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 1).Text = "chkTNCAuto"
        Me.FpLanguages_Sheet1.Cells.Get(116, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 2).Text = "TNC Auto Connect"
        Me.FpLanguages_Sheet1.Cells.Get(116, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 3).Text = "Radio Modem Connect"
        Me.FpLanguages_Sheet1.Cells.Get(116, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 4).Text = "Connessione Automatica del Modem TNC"
        Me.FpLanguages_Sheet1.Cells.Get(116, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(116, 5).Text = "Connect. Auto du TNC"
        Me.FpLanguages_Sheet1.Cells.Get(117, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(117, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 1).Text = "chkTNCMonitorOnly"
        Me.FpLanguages_Sheet1.Cells.Get(117, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 2).Text = "Monitor TNC Only"
        Me.FpLanguages_Sheet1.Cells.Get(117, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 3).Text = "No French Kissing :-)"
        Me.FpLanguages_Sheet1.Cells.Get(117, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 4).Text = "Controlla Solo il Modem TNC"
        Me.FpLanguages_Sheet1.Cells.Get(117, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(117, 5).Text = "Moniteur TNC seul"
        Me.FpLanguages_Sheet1.Cells.Get(118, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(118, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 1).Text = "chkAGWPEauto"
        Me.FpLanguages_Sheet1.Cells.Get(118, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 2).Text = "Auto Connect to AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(118, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 3).Text = "Leech from AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(118, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 4).Text = "Connessione Automatica alla AGWPE"
        Me.FpLanguages_Sheet1.Cells.Get(118, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(118, 5).Text = "Connect.auto AGPWE"
        Me.FpLanguages_Sheet1.Cells.Get(119, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(119, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 1).Text = "chkUploadDelay"
        Me.FpLanguages_Sheet1.Cells.Get(119, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 2).Text = "Upload eveny 30 seconds only"
        Me.FpLanguages_Sheet1.Cells.Get(119, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 3).Text = "Delay stuff"
        Me.FpLanguages_Sheet1.Cells.Get(119, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 4).Text = "Aggiorna Solo Ogni 30 Secondi"
        Me.FpLanguages_Sheet1.Cells.Get(119, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(119, 5).Text = "maj ttes les 30 s. seulement"
        Me.FpLanguages_Sheet1.Cells.Get(120, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(120, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 1).Text = "grpRINO"
        Me.FpLanguages_Sheet1.Cells.Get(120, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 2).Text = "RINO"
        Me.FpLanguages_Sheet1.Cells.Get(120, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 3).Text = "Rhino from Garmin"
        Me.FpLanguages_Sheet1.Cells.Get(120, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 4).Text = "RINO"
        Me.FpLanguages_Sheet1.Cells.Get(120, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(120, 5).Text = "RINO"
        Me.FpLanguages_Sheet1.Cells.Get(121, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(121, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 1).Text = "lblRINOcomport"
        Me.FpLanguages_Sheet1.Cells.Get(121, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 2).Text = "RINO Com Port"
        Me.FpLanguages_Sheet1.Cells.Get(121, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 3).Text = "Garmin COM"
        Me.FpLanguages_Sheet1.Cells.Get(121, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 4).Text = "Porta COM del RINO"
        Me.FpLanguages_Sheet1.Cells.Get(121, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(121, 5).Text = "port COM du RINO"
        Me.FpLanguages_Sheet1.Cells.Get(122, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(122, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 1).Text = "chkRINOauto"
        Me.FpLanguages_Sheet1.Cells.Get(122, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 2).Text = "Automatically download RINO"
        Me.FpLanguages_Sheet1.Cells.Get(122, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 3).Text = "Automatically visit Africa"
        Me.FpLanguages_Sheet1.Cells.Get(122, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 4).Text = "Scarica Automaticamente Dal RINO"
        Me.FpLanguages_Sheet1.Cells.Get(122, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(122, 5).Text = "charge.du RINO automatique"
        Me.FpLanguages_Sheet1.Cells.Get(123, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(123, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 1).Text = "grpXML"
        Me.FpLanguages_Sheet1.Cells.Get(123, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 2).Text = "XML"
        Me.FpLanguages_Sheet1.Cells.Get(123, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 3).Text = "XML? Ex-ML?"
        Me.FpLanguages_Sheet1.Cells.Get(123, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 4).Text = "XML"
        Me.FpLanguages_Sheet1.Cells.Get(123, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(123, 5).Text = "XML"
        Me.FpLanguages_Sheet1.Cells.Get(124, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(124, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 1).Text = "chkXMLautoexport"
        Me.FpLanguages_Sheet1.Cells.Get(124, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 2).Text = "Automatic XML Export"
        Me.FpLanguages_Sheet1.Cells.Get(124, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 3).Text = "Export EXML"
        Me.FpLanguages_Sheet1.Cells.Get(124, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 4).Text = "Esporta Automaticamente su XML"
        Me.FpLanguages_Sheet1.Cells.Get(124, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(124, 5).Text = "Export auto. XML"
        Me.FpLanguages_Sheet1.Cells.Get(125, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(125, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 1).Text = "lblXMLdirectory"
        Me.FpLanguages_Sheet1.Cells.Get(125, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 2).Text = "XML Export Directory"
        Me.FpLanguages_Sheet1.Cells.Get(125, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 3).Text = "Export Place"
        Me.FpLanguages_Sheet1.Cells.Get(125, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 4).Text = "Cartella di Esportazione XML"
        Me.FpLanguages_Sheet1.Cells.Get(125, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(125, 5).Text = "R�pert. Export XML"
        Me.FpLanguages_Sheet1.Cells.Get(126, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(126, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 1).Text = "grpPrograms"
        Me.FpLanguages_Sheet1.Cells.Get(126, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 2).Text = "Programs"
        Me.FpLanguages_Sheet1.Cells.Get(126, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 3).Text = "Programmes - For what?"
        Me.FpLanguages_Sheet1.Cells.Get(126, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 4).Text = "Programmi"
        Me.FpLanguages_Sheet1.Cells.Get(126, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(126, 5).Text = "Programmes"
        Me.FpLanguages_Sheet1.Cells.Get(127, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(127, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 1).Text = "chkInterfaceOziStartup"
        Me.FpLanguages_Sheet1.Cells.Get(127, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 2).Text = "Connect to OziExplorer on Startup"
        Me.FpLanguages_Sheet1.Cells.Get(127, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 3).Text = "Ozi Ozi Ozi always"
        Me.FpLanguages_Sheet1.Cells.Get(127, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 4).Text = "Connetti a OziExplorer all'Avvio"
        Me.FpLanguages_Sheet1.Cells.Get(127, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(127, 5).Text = "Connect. OziExp. Au d�marrage"
        Me.FpLanguages_Sheet1.Cells.Get(128, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(128, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 1).Text = "chkDecayAuto"
        Me.FpLanguages_Sheet1.Cells.Get(128, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 2).Text = "Decaying Icons"
        Me.FpLanguages_Sheet1.Cells.Get(128, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 3).Text = "Ozi Gets gray"
        Me.FpLanguages_Sheet1.Cells.Get(128, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 4).Text = "Icone che Decadono"
        Me.FpLanguages_Sheet1.Cells.Get(128, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(128, 5).Text = "Decaying Icons"
        Me.FpLanguages_Sheet1.Cells.Get(129, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(129, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 1).Text = "chkOziOnTop"
        Me.FpLanguages_Sheet1.Cells.Get(129, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 2).Text = "Keep Ozi on top"
        Me.FpLanguages_Sheet1.Cells.Get(129, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 3).Text = "Ozi Rulez"
        Me.FpLanguages_Sheet1.Cells.Get(129, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 4).Text = "Mantieni OziExplorer in Primo Piano"
        Me.FpLanguages_Sheet1.Cells.Get(129, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(129, 5).Text = "Garder Ozi 1er plan"
        Me.FpLanguages_Sheet1.Cells.Get(130, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(130, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 1).Text = "chkOziTrail"
        Me.FpLanguages_Sheet1.Cells.Get(130, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 2).Text = "Auto Trail Moving Stations"
        Me.FpLanguages_Sheet1.Cells.Get(130, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 3).Text = "Snail Trail always"
        Me.FpLanguages_Sheet1.Cells.Get(130, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 4).Text = "Crea il Percorso delle Stazioni in Movimento"
        Me.FpLanguages_Sheet1.Cells.Get(130, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(130, 5).Text = "Trace Auto stations mobiles"
        Me.FpLanguages_Sheet1.Cells.Get(131, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(131, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 1).Text = "chkOziDownloadMypos"
        Me.FpLanguages_Sheet1.Cells.Get(131, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 2).Text = "Download my Pos from Ozi"
        Me.FpLanguages_Sheet1.Cells.Get(131, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 3).Text = "Snarf from Ozi where I am"
        Me.FpLanguages_Sheet1.Cells.Get(131, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 4).Text = "Scarica la Mia Posizione da OziExplorer"
        Me.FpLanguages_Sheet1.Cells.Get(131, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(131, 5).Text = "Vider ma Pos de Ozi"
        Me.FpLanguages_Sheet1.Cells.Get(132, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(132, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 1).Text = "chkInterfaceMappointStartup"
        Me.FpLanguages_Sheet1.Cells.Get(132, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 2).Text = "Connect to MapPoint on Startup"
        Me.FpLanguages_Sheet1.Cells.Get(132, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 3).Text = "Microsoft Connect"
        Me.FpLanguages_Sheet1.Cells.Get(132, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 4).Text = "Connetti a MapPoint all'Avvio"
        Me.FpLanguages_Sheet1.Cells.Get(132, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(132, 5).Text = "Connect. MapPoint au d�mmar."
        Me.FpLanguages_Sheet1.Cells.Get(133, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(133, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 1).Text = "chkInterfaceUIViewStartup"
        Me.FpLanguages_Sheet1.Cells.Get(133, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 2).Text = "Connect to UI-View on Startup"
        Me.FpLanguages_Sheet1.Cells.Get(133, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 3).Text = "UI-View grab"
        Me.FpLanguages_Sheet1.Cells.Get(133, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 4).Text = "Connetti ad UI-View all'Avvio"
        Me.FpLanguages_Sheet1.Cells.Get(133, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(133, 5).Text = "Connect. UI-View au d�mmar."
        Me.FpLanguages_Sheet1.Cells.Get(134, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(134, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 1).Text = "chkMonAuto"
        Me.FpLanguages_Sheet1.Cells.Get(134, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 2).Text = "Upload Only Monitored Positions"
        Me.FpLanguages_Sheet1.Cells.Get(134, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 3).Text = "Only upload sometimes"
        Me.FpLanguages_Sheet1.Cells.Get(134, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 4).Text = "Scarica solo le Posizioni Monitorate"
        Me.FpLanguages_Sheet1.Cells.Get(134, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(134, 5).Text = "Charger seul. Pos. Moniteur"
        Me.FpLanguages_Sheet1.Cells.Get(135, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(135, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 1).Text = "chkGeoAuto"
        Me.FpLanguages_Sheet1.Cells.Get(135, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 2).Text = "Auto GeoGraphic filtering"
        Me.FpLanguages_Sheet1.Cells.Get(135, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 3).Text = "Local stuff only"
        Me.FpLanguages_Sheet1.Cells.Get(135, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 4).Text = "GeoFiltering Automatico"
        Me.FpLanguages_Sheet1.Cells.Get(135, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(135, 5).Text = "Filtre geo automatique"
        Me.FpLanguages_Sheet1.Cells.Get(136, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(136, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 1).Text = "chkStateSaveAuto"
        Me.FpLanguages_Sheet1.Cells.Get(136, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 2).Text = "Auto Save State"
        Me.FpLanguages_Sheet1.Cells.Get(136, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 3).Text = "Auto save things"
        Me.FpLanguages_Sheet1.Cells.Get(136, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 4).Text = "Salvataggio Automatico Stato "
        Me.FpLanguages_Sheet1.Cells.Get(136, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(136, 5).Text = "Sauve �tat automatqie"
        Me.FpLanguages_Sheet1.Cells.Get(137, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(137, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 1).Text = "lblStateFilename"
        Me.FpLanguages_Sheet1.Cells.Get(137, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 2).Text = "Auto Save State Filename"
        Me.FpLanguages_Sheet1.Cells.Get(137, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 3).Text = "Auto save filename"
        Me.FpLanguages_Sheet1.Cells.Get(137, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 4).Text = "Salvataggio Automatico Stato su File"
        Me.FpLanguages_Sheet1.Cells.Get(137, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(137, 5).Text = "Sauve �tat vers � auto."
        Me.FpLanguages_Sheet1.Cells.Get(138, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(138, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 1).Text = "chkStateLoadAuto"
        Me.FpLanguages_Sheet1.Cells.Get(138, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 2).Text = "Auto Load State"
        Me.FpLanguages_Sheet1.Cells.Get(138, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 3).Text = "Auto Load state on startup"
        Me.FpLanguages_Sheet1.Cells.Get(138, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 4).Text = "Caricamento Automatico Stato"
        Me.FpLanguages_Sheet1.Cells.Get(138, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(138, 5).Text = "Charge �tat automatique"
        Me.FpLanguages_Sheet1.Cells.Get(139, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(139, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 1).Text = "grpiGate"
        Me.FpLanguages_Sheet1.Cells.Get(139, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 2).Text = "iGate"
        Me.FpLanguages_Sheet1.Cells.Get(139, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 3).Text = "World Wide System"
        Me.FpLanguages_Sheet1.Cells.Get(139, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 4).Text = "iGate"
        Me.FpLanguages_Sheet1.Cells.Get(139, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(139, 5).Text = "iGate"
        Me.FpLanguages_Sheet1.Cells.Get(140, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(140, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 1).Text = "lblRateLimit"
        Me.FpLanguages_Sheet1.Cells.Get(140, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 2).Text = "Rate Limit"
        Me.FpLanguages_Sheet1.Cells.Get(140, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 3).Text = "Speed Limitz"
        Me.FpLanguages_Sheet1.Cells.Get(140, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 4).Text = "Limite di Frequenza"
        Me.FpLanguages_Sheet1.Cells.Get(140, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(140, 5).Text = "Limite de cadencement"
        Me.FpLanguages_Sheet1.Cells.Get(141, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(141, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 1).Text = "chkiGatePosRF"
        Me.FpLanguages_Sheet1.Cells.Get(141, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 2).Text = "iGate Positions to RF"
        Me.FpLanguages_Sheet1.Cells.Get(141, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 3).Text = "Send Pos WW"
        Me.FpLanguages_Sheet1.Cells.Get(141, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 4).Text = "iGate Posizioni su RF"
        Me.FpLanguages_Sheet1.Cells.Get(141, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(141, 5).Text = "iGate Positions to RF"
        Me.FpLanguages_Sheet1.Cells.Get(142, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(142, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 1).Text = "chkIGateMsgRf"
        Me.FpLanguages_Sheet1.Cells.Get(142, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 2).Text = "iGate Messages to RF"
        Me.FpLanguages_Sheet1.Cells.Get(142, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 3).Text = "Send msgs WW"
        Me.FpLanguages_Sheet1.Cells.Get(142, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 4).Text = "iGate Messaggi su RF"
        Me.FpLanguages_Sheet1.Cells.Get(142, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(142, 5).Text = "iGate Messages to RF"
        Me.FpLanguages_Sheet1.Cells.Get(143, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(143, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 1).Text = "chkIGateObjRF"
        Me.FpLanguages_Sheet1.Cells.Get(143, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 2).Text = "iGate Objects to RF"
        Me.FpLanguages_Sheet1.Cells.Get(143, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 3).Text = "Send Objs WW"
        Me.FpLanguages_Sheet1.Cells.Get(143, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 4).Text = "iGate Oggetti su RF"
        Me.FpLanguages_Sheet1.Cells.Get(143, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(143, 5).Text = "iGate Objects to RF"
        Me.FpLanguages_Sheet1.Cells.Get(144, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(144, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 1).Text = "chkIGateWxRf"
        Me.FpLanguages_Sheet1.Cells.Get(144, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 2).Text = "igate Weather to RF"
        Me.FpLanguages_Sheet1.Cells.Get(144, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 3).Text = "Send WX WW"
        Me.FpLanguages_Sheet1.Cells.Get(144, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 4).Text = "iGate Meteo di RF"
        Me.FpLanguages_Sheet1.Cells.Get(144, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(144, 5).Text = "igate Weather to RF"
        Me.FpLanguages_Sheet1.Cells.Get(145, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(145, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 1).Text = "lbliGateTotalLimit"
        Me.FpLanguages_Sheet1.Cells.Get(145, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 2).Text = "Overall Limit"
        Me.FpLanguages_Sheet1.Cells.Get(145, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 3).Text = "Overall speed limit"
        Me.FpLanguages_Sheet1.Cells.Get(145, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 4).Text = "Limite Globale"
        Me.FpLanguages_Sheet1.Cells.Get(145, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(145, 5).Text = "Limite maxi"
        Me.FpLanguages_Sheet1.Cells.Get(146, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(146, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 1).Text = "grpDatabase"
        Me.FpLanguages_Sheet1.Cells.Get(146, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 2).Text = "Database"
        Me.FpLanguages_Sheet1.Cells.Get(146, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 3).Text = "Big Brother stuff"
        Me.FpLanguages_Sheet1.Cells.Get(146, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 4).Text = "Database"
        Me.FpLanguages_Sheet1.Cells.Get(146, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(146, 5).Text = "Base de Donn�es"
        Me.FpLanguages_Sheet1.Cells.Get(147, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(147, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 1).Text = "lblDatabaseFilename"
        Me.FpLanguages_Sheet1.Cells.Get(147, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 2).Text = "Database Filename"
        Me.FpLanguages_Sheet1.Cells.Get(147, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 3).Text = "Filename for recording database"
        Me.FpLanguages_Sheet1.Cells.Get(147, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 4).Text = "Nome del File Database"
        Me.FpLanguages_Sheet1.Cells.Get(147, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(147, 5).Text = "Nom Base de Donn�es"
        Me.FpLanguages_Sheet1.Cells.Get(148, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(148, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 1).Text = "chkDBConnectAuto"
        Me.FpLanguages_Sheet1.Cells.Get(148, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 2).Text = "AutoConnect Database"
        Me.FpLanguages_Sheet1.Cells.Get(148, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 3).Text = "Automatic Big Brother"
        Me.FpLanguages_Sheet1.Cells.Get(148, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 4).Text = "Connetti Automaticamente al Database"
        Me.FpLanguages_Sheet1.Cells.Get(148, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(148, 5).Text = "Connection auto B.D."
        Me.FpLanguages_Sheet1.Cells.Get(149, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(149, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 1).Text = "lblLogFilename"
        Me.FpLanguages_Sheet1.Cells.Get(149, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 2).Text = "Log File Name"
        Me.FpLanguages_Sheet1.Cells.Get(149, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 3).Text = "Log filename for big brother"
        Me.FpLanguages_Sheet1.Cells.Get(149, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 4).Text = "Log su File"
        Me.FpLanguages_Sheet1.Cells.Get(149, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(149, 5).Text = "Nom fichier log"
        Me.FpLanguages_Sheet1.Cells.Get(150, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(150, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 1).Text = "chkLogAuto"
        Me.FpLanguages_Sheet1.Cells.Get(150, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 2).Text = "Auto LOG"
        Me.FpLanguages_Sheet1.Cells.Get(150, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 3).Text = "Log Always and never forget"
        Me.FpLanguages_Sheet1.Cells.Get(150, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 4).Text = "AutoLog"
        Me.FpLanguages_Sheet1.Cells.Get(150, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(150, 5).Text = "Log Auto"
        Me.FpLanguages_Sheet1.Cells.Get(151, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(151, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 1).Text = "lblIPAddress"
        Me.FpLanguages_Sheet1.Cells.Get(151, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 2).Text = "IP Address"
        Me.FpLanguages_Sheet1.Cells.Get(151, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 3).Text = "IP place"
        Me.FpLanguages_Sheet1.Cells.Get(151, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 4).Text = "Indirizzo IP"
        Me.FpLanguages_Sheet1.Cells.Get(151, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(151, 5).Text = "Adresse IP"
        Me.FpLanguages_Sheet1.Cells.Get(152, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(152, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 1).Text = "lblIPPort"
        Me.FpLanguages_Sheet1.Cells.Get(152, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 2).Text = "Port"
        Me.FpLanguages_Sheet1.Cells.Get(152, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 3).Text = "Brandy; or Port"
        Me.FpLanguages_Sheet1.Cells.Get(152, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 4).Text = "Porta"
        Me.FpLanguages_Sheet1.Cells.Get(152, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(152, 5).Text = "Port "
        Me.FpLanguages_Sheet1.Cells.Get(153, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(153, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 1).Text = "lblServer1"
        Me.FpLanguages_Sheet1.Cells.Get(153, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 2).Text = "Server #1"
        Me.FpLanguages_Sheet1.Cells.Get(153, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 3).Text = "Machine 1"
        Me.FpLanguages_Sheet1.Cells.Get(153, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 4).Text = "Server #1"
        Me.FpLanguages_Sheet1.Cells.Get(153, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(153, 5).Text = "Serveur nr 1"
        Me.FpLanguages_Sheet1.Cells.Get(154, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(154, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 1).Text = "lblServer2"
        Me.FpLanguages_Sheet1.Cells.Get(154, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 2).Text = "Server #2"
        Me.FpLanguages_Sheet1.Cells.Get(154, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 3).Text = "Machine 2"
        Me.FpLanguages_Sheet1.Cells.Get(154, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 4).Text = "Server #2"
        Me.FpLanguages_Sheet1.Cells.Get(154, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(154, 5).Text = "Serveur nr 2"
        Me.FpLanguages_Sheet1.Cells.Get(155, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(155, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 1).Text = "lblAPN"
        Me.FpLanguages_Sheet1.Cells.Get(155, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 2).Text = "APN"
        Me.FpLanguages_Sheet1.Cells.Get(155, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 3).Text = "APN, ATM"
        Me.FpLanguages_Sheet1.Cells.Get(155, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 4).Text = "APN"
        Me.FpLanguages_Sheet1.Cells.Get(155, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(155, 5).Text = "APN"
        Me.FpLanguages_Sheet1.Cells.Get(156, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(156, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 1).Text = "lblRate"
        Me.FpLanguages_Sheet1.Cells.Get(156, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 2).Text = "Rate"
        Me.FpLanguages_Sheet1.Cells.Get(156, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 3).Text = "When?"
        Me.FpLanguages_Sheet1.Cells.Get(156, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 4).Text = "Frequenza"
        Me.FpLanguages_Sheet1.Cells.Get(156, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(156, 5).Text = "Rate"
        Me.FpLanguages_Sheet1.Cells.Get(157, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(157, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 1).Text = "lblIGPRScom"
        Me.FpLanguages_Sheet1.Cells.Get(157, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 2).Text = "COM"
        Me.FpLanguages_Sheet1.Cells.Get(157, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 3).Text = "NET"
        Me.FpLanguages_Sheet1.Cells.Get(157, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 4).Text = "COM"
        Me.FpLanguages_Sheet1.Cells.Get(157, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(157, 5).Text = "COM"
        Me.FpLanguages_Sheet1.Cells.Get(158, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(158, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 1).Text = "btnConfig"
        Me.FpLanguages_Sheet1.Cells.Get(158, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 2).Text = "Config"
        Me.FpLanguages_Sheet1.Cells.Get(158, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 3).Text = "Settup Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(158, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 4).Text = "Config"
        Me.FpLanguages_Sheet1.Cells.Get(158, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(158, 5).Text = "Config"
        Me.FpLanguages_Sheet1.Cells.Get(159, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(159, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 1).Text = "btnReset"
        Me.FpLanguages_Sheet1.Cells.Get(159, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 2).Text = "Reset"
        Me.FpLanguages_Sheet1.Cells.Get(159, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 3).Text = "Start Over"
        Me.FpLanguages_Sheet1.Cells.Get(159, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 4).Text = "Reset"
        Me.FpLanguages_Sheet1.Cells.Get(159, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(159, 5).Text = "Reset"
        Me.FpLanguages_Sheet1.Cells.Get(160, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(160, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 1).Text = "lblDigiPath"
        Me.FpLanguages_Sheet1.Cells.Get(160, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 2).Text = "Digi Path"
        Me.FpLanguages_Sheet1.Cells.Get(160, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 3).Text = "Path for stuff"
        Me.FpLanguages_Sheet1.Cells.Get(160, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 4).Text = "Digi Path"
        Me.FpLanguages_Sheet1.Cells.Get(160, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(160, 5).Text = "Digi Path"
        Me.FpLanguages_Sheet1.Cells.Get(161, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(161, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 1).Text = "lblSymbol"
        Me.FpLanguages_Sheet1.Cells.Get(161, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 2).Text = "Symbol"
        Me.FpLanguages_Sheet1.Cells.Get(161, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 3).Text = "My Icon"
        Me.FpLanguages_Sheet1.Cells.Get(161, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 4).Text = "Simbolo"
        Me.FpLanguages_Sheet1.Cells.Get(161, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(161, 5).Text = "Symbole"
        Me.FpLanguages_Sheet1.Cells.Get(162, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(162, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 1).Text = "lblTable"
        Me.FpLanguages_Sheet1.Cells.Get(162, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 2).Text = "Table/Overlay"
        Me.FpLanguages_Sheet1.Cells.Get(162, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 3).Text = "my Table"
        Me.FpLanguages_Sheet1.Cells.Get(162, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 4).Text = "Tabella/Visualizzazione"
        Me.FpLanguages_Sheet1.Cells.Get(162, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(162, 5).Text = "Table/Overlay"
        Me.FpLanguages_Sheet1.Cells.Get(163, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(163, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 1).Text = "lblAutoTXRate"
        Me.FpLanguages_Sheet1.Cells.Get(163, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 2).Text = "Auto Transmit Rate"
        Me.FpLanguages_Sheet1.Cells.Get(163, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 3).Text = "Tx Rate"
        Me.FpLanguages_Sheet1.Cells.Get(163, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 4).Text = "Frequenza Trasmissione Automatica"
        Me.FpLanguages_Sheet1.Cells.Get(163, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(163, 5).Text = "Auto Transmit Rate"
        Me.FpLanguages_Sheet1.Cells.Get(164, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(164, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 1).Text = "grpStatus"
        Me.FpLanguages_Sheet1.Cells.Get(164, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 2).Text = "Status"
        Me.FpLanguages_Sheet1.Cells.Get(164, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 3).Text = "My Info"
        Me.FpLanguages_Sheet1.Cells.Get(164, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 4).Text = "Stato"
        Me.FpLanguages_Sheet1.Cells.Get(164, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(164, 5).Text = "Status"
        Me.FpLanguages_Sheet1.Cells.Get(165, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(165, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 1).Text = "lblStatusText"
        Me.FpLanguages_Sheet1.Cells.Get(165, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 2).Text = "Status Text"
        Me.FpLanguages_Sheet1.Cells.Get(165, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 3).Text = "My Info Text"
        Me.FpLanguages_Sheet1.Cells.Get(165, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 4).Text = "Testo dello Stato"
        Me.FpLanguages_Sheet1.Cells.Get(165, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(165, 5).Text = "Status Text"
        Me.FpLanguages_Sheet1.Cells.Get(166, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(166, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 1).Text = "lblSendEvery"
        Me.FpLanguages_Sheet1.Cells.Get(166, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 2).Text = "Send Every"
        Me.FpLanguages_Sheet1.Cells.Get(166, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 3).Text = "How Often"
        Me.FpLanguages_Sheet1.Cells.Get(166, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 4).Text = "Trasmetti Ogni"
        Me.FpLanguages_Sheet1.Cells.Get(166, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(166, 5).Text = "Send Every"
        Me.FpLanguages_Sheet1.Cells.Get(167, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(167, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 1).Text = "chkSendSeperate"
        Me.FpLanguages_Sheet1.Cells.Get(167, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 2).Text = "Send Separate"
        Me.FpLanguages_Sheet1.Cells.Get(167, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 3).Text = "Separate Msg"
        Me.FpLanguages_Sheet1.Cells.Get(167, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 4).Text = "Trasmetti Separato"
        Me.FpLanguages_Sheet1.Cells.Get(167, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(167, 5).Text = "Send Separate"
        Me.FpLanguages_Sheet1.Cells.Get(168, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(168, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 1).Text = "chkTTValid"
        Me.FpLanguages_Sheet1.Cells.Get(168, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 2).Text = "Only Send Valid"
        Me.FpLanguages_Sheet1.Cells.Get(168, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 3).Text = "Valid Only"
        Me.FpLanguages_Sheet1.Cells.Get(168, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 4).Text = "Trasmetti Solo se Valido"
        Me.FpLanguages_Sheet1.Cells.Get(168, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(168, 5).Text = "Only Send Valid"
        Me.FpLanguages_Sheet1.Cells.Get(169, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(169, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 1).Text = "chkTimestampDHM"
        Me.FpLanguages_Sheet1.Cells.Get(169, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 2).Text = "Timestamp DHM"
        Me.FpLanguages_Sheet1.Cells.Get(169, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 3).Text = "DHM???"
        Me.FpLanguages_Sheet1.Cells.Get(169, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 4).Text = "TimeStamp DHM"
        Me.FpLanguages_Sheet1.Cells.Get(169, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(169, 5).Text = "Timestamp DHM"
        Me.FpLanguages_Sheet1.Cells.Get(170, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(170, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 1).Text = "chkTimestampHMS"
        Me.FpLanguages_Sheet1.Cells.Get(170, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 2).Text = "Timestamp HMS"
        Me.FpLanguages_Sheet1.Cells.Get(170, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 3).Text = "HMS???"
        Me.FpLanguages_Sheet1.Cells.Get(170, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 4).Text = "TimeStamp HMS"
        Me.FpLanguages_Sheet1.Cells.Get(170, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(170, 5).Text = "Timestamp HMS"
        Me.FpLanguages_Sheet1.Cells.Get(171, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(171, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 1).Text = "chkAlternateDigis"
        Me.FpLanguages_Sheet1.Cells.Get(171, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 2).Text = "Alternate Digi Paths"
        Me.FpLanguages_Sheet1.Cells.Get(171, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 3).Text = "Alternate digis"
        Me.FpLanguages_Sheet1.Cells.Get(171, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 4).Text = "Alterna Digi Path"
        Me.FpLanguages_Sheet1.Cells.Get(171, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(171, 5).Text = "Alternate Digi Paths"
        Me.FpLanguages_Sheet1.Cells.Get(172, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(172, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 1).Text = "chkSendAltitude"
        Me.FpLanguages_Sheet1.Cells.Get(172, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 2).Text = "Send Altitude"
        Me.FpLanguages_Sheet1.Cells.Get(172, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 3).Text = "Sent how high"
        Me.FpLanguages_Sheet1.Cells.Get(172, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 4).Text = "Trasmetti Altitudine"
        Me.FpLanguages_Sheet1.Cells.Get(172, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(172, 5).Text = "Send Altitude"
        Me.FpLanguages_Sheet1.Cells.Get(173, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(173, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 1).Text = "chkNMEASend"
        Me.FpLanguages_Sheet1.Cells.Get(173, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 2).Text = "Send NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(173, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 3).Text = "Send NMES with the lot"
        Me.FpLanguages_Sheet1.Cells.Get(173, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 4).Text = "Trasmetti NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(173, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(173, 5).Text = "Send NMEA"
        Me.FpLanguages_Sheet1.Cells.Get(174, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(174, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 1).Text = "grpMICE"
        Me.FpLanguages_Sheet1.Cells.Get(174, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 2).Text = "MIC-E"
        Me.FpLanguages_Sheet1.Cells.Get(174, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 3).Text = "MIC-E, or Mice"
        Me.FpLanguages_Sheet1.Cells.Get(174, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 4).Text = "MIC-E"
        Me.FpLanguages_Sheet1.Cells.Get(174, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(174, 5).Text = "MIC-E"
        Me.FpLanguages_Sheet1.Cells.Get(175, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(175, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 1).Text = "chkMICEEnable"
        Me.FpLanguages_Sheet1.Cells.Get(175, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 2).Text = "Enable"
        Me.FpLanguages_Sheet1.Cells.Get(175, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 3).Text = "OK to use?"
        Me.FpLanguages_Sheet1.Cells.Get(175, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 4).Text = "Attiva"
        Me.FpLanguages_Sheet1.Cells.Get(175, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(175, 5).Text = "Enable"
        Me.FpLanguages_Sheet1.Cells.Get(176, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(176, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 1).Text = "chkMICEPrintable"
        Me.FpLanguages_Sheet1.Cells.Get(176, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 2).Text = "Force Printable"
        Me.FpLanguages_Sheet1.Cells.Get(176, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 3).Text = "Printable, or not?"
        Me.FpLanguages_Sheet1.Cells.Get(176, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 4).Text = "Forza la Funziona di Stampa"
        Me.FpLanguages_Sheet1.Cells.Get(176, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(176, 5).Text = "Force Printable"
        Me.FpLanguages_Sheet1.Cells.Get(177, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(177, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 1).Text = "lblMICEMessage"
        Me.FpLanguages_Sheet1.Cells.Get(177, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 2).Text = "Message"
        Me.FpLanguages_Sheet1.Cells.Get(177, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 3).Text = "Msg"
        Me.FpLanguages_Sheet1.Cells.Get(177, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 4).Text = "Messaggio"
        Me.FpLanguages_Sheet1.Cells.Get(177, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(177, 5).Text = "Message"
        Me.FpLanguages_Sheet1.Cells.Get(178, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(178, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 1).Text = "lblMICEPath"
        Me.FpLanguages_Sheet1.Cells.Get(178, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 2).Text = "Path"
        Me.FpLanguages_Sheet1.Cells.Get(178, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 3).Text = "Path, or sidewalk"
        Me.FpLanguages_Sheet1.Cells.Get(178, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 4).Text = "Percorso"
        Me.FpLanguages_Sheet1.Cells.Get(178, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(178, 5).Text = "Path"
        Me.FpLanguages_Sheet1.Cells.Get(179, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(179, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 1).Text = "grpSmartBeacon"
        Me.FpLanguages_Sheet1.Cells.Get(179, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 2).Text = "Smart Beaconing"
        Me.FpLanguages_Sheet1.Cells.Get(179, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 3).Text = "Smart Stuff"
        Me.FpLanguages_Sheet1.Cells.Get(179, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 4).Text = "Beaconing Intelligente"
        Me.FpLanguages_Sheet1.Cells.Get(179, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(179, 5).Text = "Smart Beaconing"
        Me.FpLanguages_Sheet1.Cells.Get(180, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(180, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 1).Text = "chkSmartEnable"
        Me.FpLanguages_Sheet1.Cells.Get(180, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 2).Text = "Enable"
        Me.FpLanguages_Sheet1.Cells.Get(180, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 3).Text = "OK?"
        Me.FpLanguages_Sheet1.Cells.Get(180, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 4).Text = "Consenti"
        Me.FpLanguages_Sheet1.Cells.Get(180, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(180, 5).Text = "Enable"
        Me.FpLanguages_Sheet1.Cells.Get(181, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(181, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 1).Text = "lblMinTurnAngle"
        Me.FpLanguages_Sheet1.Cells.Get(181, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 2).Text = "Min Turn Angle"
        Me.FpLanguages_Sheet1.Cells.Get(181, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 3).Text = "Off Course"
        Me.FpLanguages_Sheet1.Cells.Get(181, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 4).Text = "Angolo Min di Svolta"
        Me.FpLanguages_Sheet1.Cells.Get(181, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(181, 5).Text = "Min Turn Angle"
        Me.FpLanguages_Sheet1.Cells.Get(182, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(182, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 1).Text = "lblTurnSlope"
        Me.FpLanguages_Sheet1.Cells.Get(182, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 2).Text = "Turn Slope"
        Me.FpLanguages_Sheet1.Cells.Get(182, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 3).Text = "Slopes"
        Me.FpLanguages_Sheet1.Cells.Get(182, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 4).Text = "Curvatura di Svolta"
        Me.FpLanguages_Sheet1.Cells.Get(182, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(182, 5).Text = "Turn Slope"
        Me.FpLanguages_Sheet1.Cells.Get(183, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(183, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 1).Text = "lblMinTurnTime"
        Me.FpLanguages_Sheet1.Cells.Get(183, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 2).Text = "Turn Time"
        Me.FpLanguages_Sheet1.Cells.Get(183, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 3).Text = "Times?"
        Me.FpLanguages_Sheet1.Cells.Get(183, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 4).Text = "Tempo di Svolta"
        Me.FpLanguages_Sheet1.Cells.Get(183, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(183, 5).Text = "Turn Time"
        Me.FpLanguages_Sheet1.Cells.Get(184, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(184, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 1).Text = "lblTurnSeconds"
        Me.FpLanguages_Sheet1.Cells.Get(184, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 2).Text = "Seconds"
        Me.FpLanguages_Sheet1.Cells.Get(184, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 3).Text = "S"
        Me.FpLanguages_Sheet1.Cells.Get(184, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 4).Text = "Secondi"
        Me.FpLanguages_Sheet1.Cells.Get(184, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(184, 5).Text = "Seconds"
        Me.FpLanguages_Sheet1.Cells.Get(185, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(185, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 1).Text = "lblSlowSpeed"
        Me.FpLanguages_Sheet1.Cells.Get(185, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 2).Text = "Slow Speed"
        Me.FpLanguages_Sheet1.Cells.Get(185, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 3).Text = "Slowww "
        Me.FpLanguages_Sheet1.Cells.Get(185, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 4).Text = "Velocit� Bassa"
        Me.FpLanguages_Sheet1.Cells.Get(185, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(185, 5).Text = "Slow Speed"
        Me.FpLanguages_Sheet1.Cells.Get(186, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(186, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 1).Text = "lblSlowRate"
        Me.FpLanguages_Sheet1.Cells.Get(186, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 2).Text = "Slow Rate"
        Me.FpLanguages_Sheet1.Cells.Get(186, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 3).Text = "Slowww Rate"
        Me.FpLanguages_Sheet1.Cells.Get(186, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 4).Text = "Frequenza Bassa"
        Me.FpLanguages_Sheet1.Cells.Get(186, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(186, 5).Text = "Slow Rate"
        Me.FpLanguages_Sheet1.Cells.Get(187, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(187, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 1).Text = "lblFastSpeed"
        Me.FpLanguages_Sheet1.Cells.Get(187, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 2).Text = "Fast Speed"
        Me.FpLanguages_Sheet1.Cells.Get(187, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 3).Text = "FAST spd"
        Me.FpLanguages_Sheet1.Cells.Get(187, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 4).Text = "Velocit� Rapida"
        Me.FpLanguages_Sheet1.Cells.Get(187, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(187, 5).Text = "Fast Speed"
        Me.FpLanguages_Sheet1.Cells.Get(188, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(188, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 1).Text = "lblFastRate"
        Me.FpLanguages_Sheet1.Cells.Get(188, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 2).Text = "Fast Rate"
        Me.FpLanguages_Sheet1.Cells.Get(188, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 3).Text = "Fast Rte"
        Me.FpLanguages_Sheet1.Cells.Get(188, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 4).Text = "Frequenza Rapida"
        Me.FpLanguages_Sheet1.Cells.Get(188, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(188, 5).Text = "Fast Rate"
        Me.FpLanguages_Sheet1.Cells.Get(189, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(189, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 1).Text = "lblFastRateSeconds"
        Me.FpLanguages_Sheet1.Cells.Get(189, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 2).Text = "Seconds"
        Me.FpLanguages_Sheet1.Cells.Get(189, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 3).Text = "Secs"
        Me.FpLanguages_Sheet1.Cells.Get(189, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 4).Text = "Secondi"
        Me.FpLanguages_Sheet1.Cells.Get(189, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(189, 5).Text = "Seconds"
        Me.FpLanguages_Sheet1.Cells.Get(190, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 0).Text = "frmSetup"
        Me.FpLanguages_Sheet1.Cells.Get(190, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 1).Text = "lblSlowRateSeconds"
        Me.FpLanguages_Sheet1.Cells.Get(190, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 2).Text = "seconds"
        Me.FpLanguages_Sheet1.Cells.Get(190, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 3).Text = "Sess"
        Me.FpLanguages_Sheet1.Cells.Get(190, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 4).Text = "Secondi"
        Me.FpLanguages_Sheet1.Cells.Get(190, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(190, 5).Text = "seconds"
        Me.FpLanguages_Sheet1.Cells.Get(191, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(191, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 1).Text = "lblDatabaseState"
        Me.FpLanguages_Sheet1.Cells.Get(191, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 2).Text = "State of Database at a specific time"
        Me.FpLanguages_Sheet1.Cells.Get(191, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 3).Text = "Big Brother at a time"
        Me.FpLanguages_Sheet1.Cells.Get(191, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 4).Text = "Stato del Database in un Preciso Istante"
        Me.FpLanguages_Sheet1.Cells.Get(191, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(191, 5).Text = "�tat B.D. � heure sp�cifique"
        Me.FpLanguages_Sheet1.Cells.Get(192, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(192, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 1).Text = "lblDatabaseStart"
        Me.FpLanguages_Sheet1.Cells.Get(192, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 2).Text = "Start"
        Me.FpLanguages_Sheet1.Cells.Get(192, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 3).Text = "Before the game"
        Me.FpLanguages_Sheet1.Cells.Get(192, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 4).Text = "Start"
        Me.FpLanguages_Sheet1.Cells.Get(192, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(192, 5).Text = "Debut"
        Me.FpLanguages_Sheet1.Cells.Get(193, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(193, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 1).Text = "lblDatabaseStop"
        Me.FpLanguages_Sheet1.Cells.Get(193, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 2).Text = "Stop"
        Me.FpLanguages_Sheet1.Cells.Get(193, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 3).Text = "After the game"
        Me.FpLanguages_Sheet1.Cells.Get(193, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 4).Text = "Stop"
        Me.FpLanguages_Sheet1.Cells.Get(193, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(193, 5).Text = "Stop"
        Me.FpLanguages_Sheet1.Cells.Get(194, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(194, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 1).Text = "lblTrackStations"
        Me.FpLanguages_Sheet1.Cells.Get(194, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 2).Text = "Track Stations"
        Me.FpLanguages_Sheet1.Cells.Get(194, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 3).Text = "Trak em"
        Me.FpLanguages_Sheet1.Cells.Get(194, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 4).Text = "Traccia Stazioni"
        Me.FpLanguages_Sheet1.Cells.Get(194, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(194, 5).Text = "Suivre Stations"
        Me.FpLanguages_Sheet1.Cells.Get(195, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(195, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 1).Text = "cmdGrabLatestPositions"
        Me.FpLanguages_Sheet1.Cells.Get(195, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 2).Text = "Grab Latest Positions"
        Me.FpLanguages_Sheet1.Cells.Get(195, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 3).Text = "Grab em"
        Me.FpLanguages_Sheet1.Cells.Get(195, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 4).Text = "Raccogli Ultime Posizioni"
        Me.FpLanguages_Sheet1.Cells.Get(195, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(195, 5).Text = "Attrap. Dreni�re position"
        Me.FpLanguages_Sheet1.Cells.Get(196, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(196, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 1).Text = "cmdTrackAll"
        Me.FpLanguages_Sheet1.Cells.Get(196, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 2).Text = "Track All"
        Me.FpLanguages_Sheet1.Cells.Get(196, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 3).Text = "trak em all"
        Me.FpLanguages_Sheet1.Cells.Get(196, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 4).Text = "Traccia Tutto"
        Me.FpLanguages_Sheet1.Cells.Get(196, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(196, 5).Text = "Suivre Tous"
        Me.FpLanguages_Sheet1.Cells.Get(197, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(197, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 1).Text = "cmdTrackCall"
        Me.FpLanguages_Sheet1.Cells.Get(197, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 2).Text = "Track Call"
        Me.FpLanguages_Sheet1.Cells.Get(197, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 3).Text = "Spy on one"
        Me.FpLanguages_Sheet1.Cells.Get(197, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 4).Text = "Disponi il Tracciamento"
        Me.FpLanguages_Sheet1.Cells.Get(197, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(197, 5).Text = "cmdTrackCall"
        Me.FpLanguages_Sheet1.Cells.Get(198, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 0).Text = "devDatabaseGui"
        Me.FpLanguages_Sheet1.Cells.Get(198, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 1).Text = "cmdGenList"
        Me.FpLanguages_Sheet1.Cells.Get(198, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 2).Text = "Generate List"
        Me.FpLanguages_Sheet1.Cells.Get(198, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 3).Text = "Gen List"
        Me.FpLanguages_Sheet1.Cells.Get(198, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 4).Text = "Genera Lista"
        Me.FpLanguages_Sheet1.Cells.Get(198, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(198, 5).Text = "G�n�rer liste"
        Me.FpLanguages_Sheet1.Cells.Get(199, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(199, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 1).Text = "mnuPollNearby"
        Me.FpLanguages_Sheet1.Cells.Get(199, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 2).Text = "Poll Stations Nearby"
        Me.FpLanguages_Sheet1.Cells.Get(199, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 3).Text = "Cooee"
        Me.FpLanguages_Sheet1.Cells.Get(199, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 4).Text = "Richiedi Stazioni Vicine"
        Me.FpLanguages_Sheet1.Cells.Get(199, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(199, 5).Text = "Poll stations proches"
        Me.FpLanguages_Sheet1.Cells.Get(200, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(200, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 1).Text = "mnuPopupAdd"
        Me.FpLanguages_Sheet1.Cells.Get(200, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 2).Text = "Add"
        Me.FpLanguages_Sheet1.Cells.Get(200, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 3).Text = "Pile another"
        Me.FpLanguages_Sheet1.Cells.Get(200, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 4).Text = "Aggiungi"
        Me.FpLanguages_Sheet1.Cells.Get(200, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(200, 5).Text = "Ajouter"
        Me.FpLanguages_Sheet1.Cells.Get(201, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(201, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 1).Text = "mnuPopupStationAdd"
        Me.FpLanguages_Sheet1.Cells.Get(201, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 2).Text = "Station Add"
        Me.FpLanguages_Sheet1.Cells.Get(201, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 3).Text = "One more"
        Me.FpLanguages_Sheet1.Cells.Get(201, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 4).Text = "Aggiungi Stazione"
        Me.FpLanguages_Sheet1.Cells.Get(201, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(201, 5).Text = "Ajouter Stations"
        Me.FpLanguages_Sheet1.Cells.Get(202, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(202, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 1).Text = "mnuPopupMove"
        Me.FpLanguages_Sheet1.Cells.Get(202, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 2).Text = "Move Waypoint"
        Me.FpLanguages_Sheet1.Cells.Get(202, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 3).Text = "Push Off over tehre"
        Me.FpLanguages_Sheet1.Cells.Get(202, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 4).Text = "Muovi Waypoint"
        Me.FpLanguages_Sheet1.Cells.Get(202, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(202, 5).Text = "D�placer WayPoint"
        Me.FpLanguages_Sheet1.Cells.Get(203, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(203, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 1).Text = "mnuPopupFilter1"
        Me.FpLanguages_Sheet1.Cells.Get(203, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 2).Text = "Filter Top/Left"
        Me.FpLanguages_Sheet1.Cells.Get(203, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 3).Text = "Left and top"
        Me.FpLanguages_Sheet1.Cells.Get(203, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 4).Text = "Filtro Angolo Alto/Sin"
        Me.FpLanguages_Sheet1.Cells.Get(203, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(203, 5).Text = "Filtrer Haut/Gauche"
        Me.FpLanguages_Sheet1.Cells.Get(204, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(204, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 1).Text = "mnuPopupFilter2"
        Me.FpLanguages_Sheet1.Cells.Get(204, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 2).Text = "Filter Bottom/Right"
        Me.FpLanguages_Sheet1.Cells.Get(204, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 3).Text = "right and bottom"
        Me.FpLanguages_Sheet1.Cells.Get(204, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 4).Text = "Filtro Angolo Basso/Des"
        Me.FpLanguages_Sheet1.Cells.Get(204, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(204, 5).Text = "Filtrer Bas/Droite"
        Me.FpLanguages_Sheet1.Cells.Get(205, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 0).Text = "mnuPopup"
        Me.FpLanguages_Sheet1.Cells.Get(205, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 1).Text = "mnuPopupCancel"
        Me.FpLanguages_Sheet1.Cells.Get(205, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 2).Text = "Cancel"
        Me.FpLanguages_Sheet1.Cells.Get(205, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 3).Text = "Really push off and outa here"
        Me.FpLanguages_Sheet1.Cells.Get(205, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 4).Text = "Cancella"
        Me.FpLanguages_Sheet1.Cells.Get(205, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(205, 5).Text = "Annuler"
        Me.FpLanguages_Sheet1.Cells.Get(206, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(206, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 1).Text = "mnuCallsign"
        Me.FpLanguages_Sheet1.Cells.Get(206, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 2).Text = "Callsign:"
        Me.FpLanguages_Sheet1.Cells.Get(206, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 3).Text = "He is:"
        Me.FpLanguages_Sheet1.Cells.Get(206, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 4).Text = "Callsign:"
        Me.FpLanguages_Sheet1.Cells.Get(206, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(206, 5).Text = "Indicatif"
        Me.FpLanguages_Sheet1.Cells.Get(207, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(207, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 1).Text = "mnuCallsignPoll"
        Me.FpLanguages_Sheet1.Cells.Get(207, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 2).Text = "Poll for latest position"
        Me.FpLanguages_Sheet1.Cells.Get(207, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 3).Text = "Where is he right now"
        Me.FpLanguages_Sheet1.Cells.Get(207, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 4).Text = "Richiedi le Ultime Posizioni"
        Me.FpLanguages_Sheet1.Cells.Get(207, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(207, 5).Text = "Poll derni�re Position"
        Me.FpLanguages_Sheet1.Cells.Get(208, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(208, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 1).Text = "mnuCallsignPopupQRZ"
        Me.FpLanguages_Sheet1.Cells.Get(208, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 2).Text = "Lookup in QRZ.COM"
        Me.FpLanguages_Sheet1.Cells.Get(208, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 3).Text = "Look up on net"
        Me.FpLanguages_Sheet1.Cells.Get(208, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 4).Text = "Localizza su QRZ.COM"
        Me.FpLanguages_Sheet1.Cells.Get(208, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(208, 5).Text = "Chercher dans QRZ.com"
        Me.FpLanguages_Sheet1.Cells.Get(209, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(209, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 1).Text = "mnuCallsignPopupFindu"
        Me.FpLanguages_Sheet1.Cells.Get(209, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 2).Text = "Lookup in FindU.Com"
        Me.FpLanguages_Sheet1.Cells.Get(209, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 3).Text = "Where does steve say he is?"
        Me.FpLanguages_Sheet1.Cells.Get(209, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 4).Text = "Localizza su FindU.Com"
        Me.FpLanguages_Sheet1.Cells.Get(209, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(209, 5).Text = "Chercher dans FindU.com"
        Me.FpLanguages_Sheet1.Cells.Get(210, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(210, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 1).Text = "mnuCallsignPopupDynamic"
        Me.FpLanguages_Sheet1.Cells.Get(210, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 2).Text = "Dynamic Display"
        Me.FpLanguages_Sheet1.Cells.Get(210, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 3).Text = "Spy on him closely"
        Me.FpLanguages_Sheet1.Cells.Get(210, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 4).Text = "Display Dinamico"
        Me.FpLanguages_Sheet1.Cells.Get(210, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(210, 5).Text = "Affichage Dynamique"
        Me.FpLanguages_Sheet1.Cells.Get(211, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(211, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 1).Text = "mnuCallsignPopupMessage"
        Me.FpLanguages_Sheet1.Cells.Get(211, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 2).Text = "Send Message"
        Me.FpLanguages_Sheet1.Cells.Get(211, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 3).Text = "Text Him"
        Me.FpLanguages_Sheet1.Cells.Get(211, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 4).Text = "Trasmetti Messaggio"
        Me.FpLanguages_Sheet1.Cells.Get(211, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(211, 5).Text = "Envoyer Message"
        Me.FpLanguages_Sheet1.Cells.Get(212, 0).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 0).Text = "mnuCallsignPopup"
        Me.FpLanguages_Sheet1.Cells.Get(212, 1).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 1).Text = "mnuCallsignPopupCancel"
        Me.FpLanguages_Sheet1.Cells.Get(212, 2).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 2).Text = "Cancel"
        Me.FpLanguages_Sheet1.Cells.Get(212, 3).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 3).Text = "Shove Off"
        Me.FpLanguages_Sheet1.Cells.Get(212, 4).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 4).Text = "Cancella"
        Me.FpLanguages_Sheet1.Cells.Get(212, 5).ParseFormatString = "G"
        Me.FpLanguages_Sheet1.Cells.Get(212, 5).Text = "Annuler"
        Me.FpLanguages_Sheet1.Columns.Default.Width = 64.0!
        Me.FpLanguages_Sheet1.Columns.Get(0).Width = 159.0!
        Me.FpLanguages_Sheet1.Columns.Get(1).Width = 226.0!
        Me.FpLanguages_Sheet1.Columns.Get(2).Width = 299.0!
        Me.FpLanguages_Sheet1.Columns.Get(3).Width = 292.0!
        Me.FpLanguages_Sheet1.Columns.Get(4).Width = 291.0!
        Me.FpLanguages_Sheet1.Columns.Get(5).Width = 249.0!
        Me.FpLanguages_Sheet1.DefaultStyleName = "Excel-0-15"
        Me.FpLanguages_Sheet1.MaximumIterations = 100
        Me.FpLanguages_Sheet1.PrintInfo.Margin.Footer = 60
        Me.FpLanguages_Sheet1.PrintInfo.Margin.Header = 60
        Me.FpLanguages_Sheet1.PrintInfo.PageOrder = FarPoint.Win.Spread.PrintPageOrder.DownThenOver
        Me.FpLanguages_Sheet1.PrintInfo.ShowBorder = False
        Me.FpLanguages_Sheet1.PrintInfo.ShowColor = True
        Me.FpLanguages_Sheet1.PrintInfo.ShowColumnHeaders = False
        Me.FpLanguages_Sheet1.PrintInfo.ShowGrid = False
        Me.FpLanguages_Sheet1.PrintInfo.ShowRowHeaders = False
        Me.FpLanguages_Sheet1.Protect = False
        Me.FpLanguages_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.FpLanguages_Sheet1.Rows.Default.Height = 23.0!
        Me.FpLanguages_Sheet1.Rows.Get(0).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(1).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(2).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(3).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(4).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(5).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(6).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(7).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(8).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(9).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(10).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(11).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(12).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(13).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(14).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(15).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(16).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(17).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(18).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(19).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(20).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(21).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(22).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(23).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(24).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(25).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(26).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(27).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(28).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(29).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(30).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(31).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(32).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(33).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(34).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(35).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(36).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(37).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(38).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(39).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(40).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(41).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(42).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(43).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(44).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(45).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(46).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(47).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(48).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(49).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(50).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(51).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(52).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(53).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(54).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(55).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(56).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(57).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(58).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(59).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(60).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(61).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(62).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(63).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(64).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(65).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(66).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(67).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(68).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(69).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(70).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(71).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(72).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(73).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(74).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(75).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(76).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(77).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(78).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(79).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(80).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(81).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(82).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(83).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(84).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(85).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(86).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(87).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(88).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(89).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(90).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(91).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(92).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(93).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(94).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(95).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(96).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(97).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(98).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(99).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(100).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(101).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(102).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(103).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(104).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(105).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(106).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(107).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(108).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(109).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(110).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(111).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(112).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(113).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(114).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(115).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(116).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(117).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(118).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(119).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(120).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(121).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(122).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(123).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(124).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(125).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(126).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(127).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(128).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(129).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(130).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(131).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(132).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(133).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(134).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(135).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(136).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(137).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(138).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(139).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(140).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(141).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(142).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(143).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(144).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(145).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(146).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(147).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(148).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(149).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(150).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(151).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(152).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(153).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(154).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(155).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(156).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(157).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(158).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(159).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(160).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(161).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(162).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(163).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(164).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(165).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(166).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(167).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(168).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(169).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(170).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(171).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(172).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(173).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(174).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(175).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(176).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(177).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(178).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(179).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(180).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(181).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(182).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(183).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(184).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(185).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(186).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(187).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(188).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(189).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(190).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(191).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(192).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(193).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(194).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(195).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(196).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(197).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(198).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(199).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(200).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(201).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(202).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(203).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(204).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(205).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(206).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(207).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(208).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(209).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(210).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(211).Height = 22.0!
        Me.FpLanguages_Sheet1.Rows.Get(212).Height = 22.0!
        Me.FpLanguages_Sheet1.SheetName = "Sheet1"
        '
        'cron
        '
        Me.cron.Interval = 500
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuServices, Me.mnuInterfaces, Me.mnuGui, Me.mnuHelp, Me.MenuItem2, Me.MenuItem11, Me.MenuItem4})
        Me.MainMenu1.RightToLeft = CType(resources.GetObject("MainMenu1.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'mnuFile
        '
        Me.mnuFile.Enabled = CType(resources.GetObject("mnuFile.Enabled"), Boolean)
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileSetup, Me.MenuItem3, Me.mnuFileLoad, Me.mnuFilesave})
        Me.mnuFile.Shortcut = CType(resources.GetObject("mnuFile.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuFile.ShowShortcut = CType(resources.GetObject("mnuFile.ShowShortcut"), Boolean)
        Me.mnuFile.Text = resources.GetString("mnuFile.Text")
        Me.mnuFile.Visible = CType(resources.GetObject("mnuFile.Visible"), Boolean)
        '
        'mnuFileSetup
        '
        Me.mnuFileSetup.Enabled = CType(resources.GetObject("mnuFileSetup.Enabled"), Boolean)
        Me.mnuFileSetup.Index = 0
        Me.mnuFileSetup.Shortcut = CType(resources.GetObject("mnuFileSetup.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuFileSetup.ShowShortcut = CType(resources.GetObject("mnuFileSetup.ShowShortcut"), Boolean)
        Me.mnuFileSetup.Text = resources.GetString("mnuFileSetup.Text")
        Me.mnuFileSetup.Visible = CType(resources.GetObject("mnuFileSetup.Visible"), Boolean)
        '
        'MenuItem3
        '
        Me.MenuItem3.Enabled = CType(resources.GetObject("MenuItem3.Enabled"), Boolean)
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Shortcut = CType(resources.GetObject("MenuItem3.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem3.ShowShortcut = CType(resources.GetObject("MenuItem3.ShowShortcut"), Boolean)
        Me.MenuItem3.Text = resources.GetString("MenuItem3.Text")
        Me.MenuItem3.Visible = CType(resources.GetObject("MenuItem3.Visible"), Boolean)
        '
        'mnuFileLoad
        '
        Me.mnuFileLoad.Enabled = CType(resources.GetObject("mnuFileLoad.Enabled"), Boolean)
        Me.mnuFileLoad.Index = 2
        Me.mnuFileLoad.Shortcut = CType(resources.GetObject("mnuFileLoad.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuFileLoad.ShowShortcut = CType(resources.GetObject("mnuFileLoad.ShowShortcut"), Boolean)
        Me.mnuFileLoad.Text = resources.GetString("mnuFileLoad.Text")
        Me.mnuFileLoad.Visible = CType(resources.GetObject("mnuFileLoad.Visible"), Boolean)
        '
        'mnuFilesave
        '
        Me.mnuFilesave.Enabled = CType(resources.GetObject("mnuFilesave.Enabled"), Boolean)
        Me.mnuFilesave.Index = 3
        Me.mnuFilesave.Shortcut = CType(resources.GetObject("mnuFilesave.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuFilesave.ShowShortcut = CType(resources.GetObject("mnuFilesave.ShowShortcut"), Boolean)
        Me.mnuFilesave.Text = resources.GetString("mnuFilesave.Text")
        Me.mnuFilesave.Visible = CType(resources.GetObject("mnuFilesave.Visible"), Boolean)
        '
        'mnuServices
        '
        Me.mnuServices.Enabled = CType(resources.GetObject("mnuServices.Enabled"), Boolean)
        Me.mnuServices.Index = 1
        Me.mnuServices.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuServAPRSServ, Me.mnuServAGWPE, Me.mnuServTNC, Me.mnuServGPS, Me.mnuServWx, Me.mnuServRINO, Me.mnuServDatabase, Me.mnuServUIView, Me.MenuItem7, Me.mnuServOzi, Me.mnuServMapPoint, Me.MenuItem8, Me.mnuServHub, Me.mnuServGPRS, Me.mnuServNetGPS, Me.mnuServRealTrack, Me.MenuItem6, Me.mnuServLog})
        Me.mnuServices.Shortcut = CType(resources.GetObject("mnuServices.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServices.ShowShortcut = CType(resources.GetObject("mnuServices.ShowShortcut"), Boolean)
        Me.mnuServices.Text = resources.GetString("mnuServices.Text")
        Me.mnuServices.Visible = CType(resources.GetObject("mnuServices.Visible"), Boolean)
        '
        'mnuServAPRSServ
        '
        Me.mnuServAPRSServ.Enabled = CType(resources.GetObject("mnuServAPRSServ.Enabled"), Boolean)
        Me.mnuServAPRSServ.Index = 0
        Me.mnuServAPRSServ.Shortcut = CType(resources.GetObject("mnuServAPRSServ.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServAPRSServ.ShowShortcut = CType(resources.GetObject("mnuServAPRSServ.ShowShortcut"), Boolean)
        Me.mnuServAPRSServ.Text = resources.GetString("mnuServAPRSServ.Text")
        Me.mnuServAPRSServ.Visible = CType(resources.GetObject("mnuServAPRSServ.Visible"), Boolean)
        '
        'mnuServAGWPE
        '
        Me.mnuServAGWPE.Enabled = CType(resources.GetObject("mnuServAGWPE.Enabled"), Boolean)
        Me.mnuServAGWPE.Index = 1
        Me.mnuServAGWPE.Shortcut = CType(resources.GetObject("mnuServAGWPE.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServAGWPE.ShowShortcut = CType(resources.GetObject("mnuServAGWPE.ShowShortcut"), Boolean)
        Me.mnuServAGWPE.Text = resources.GetString("mnuServAGWPE.Text")
        Me.mnuServAGWPE.Visible = CType(resources.GetObject("mnuServAGWPE.Visible"), Boolean)
        '
        'mnuServTNC
        '
        Me.mnuServTNC.Enabled = CType(resources.GetObject("mnuServTNC.Enabled"), Boolean)
        Me.mnuServTNC.Index = 2
        Me.mnuServTNC.Shortcut = CType(resources.GetObject("mnuServTNC.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServTNC.ShowShortcut = CType(resources.GetObject("mnuServTNC.ShowShortcut"), Boolean)
        Me.mnuServTNC.Text = resources.GetString("mnuServTNC.Text")
        Me.mnuServTNC.Visible = CType(resources.GetObject("mnuServTNC.Visible"), Boolean)
        '
        'mnuServGPS
        '
        Me.mnuServGPS.Enabled = CType(resources.GetObject("mnuServGPS.Enabled"), Boolean)
        Me.mnuServGPS.Index = 3
        Me.mnuServGPS.Shortcut = CType(resources.GetObject("mnuServGPS.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServGPS.ShowShortcut = CType(resources.GetObject("mnuServGPS.ShowShortcut"), Boolean)
        Me.mnuServGPS.Text = resources.GetString("mnuServGPS.Text")
        Me.mnuServGPS.Visible = CType(resources.GetObject("mnuServGPS.Visible"), Boolean)
        '
        'mnuServWx
        '
        Me.mnuServWx.Enabled = CType(resources.GetObject("mnuServWx.Enabled"), Boolean)
        Me.mnuServWx.Index = 4
        Me.mnuServWx.Shortcut = CType(resources.GetObject("mnuServWx.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServWx.ShowShortcut = CType(resources.GetObject("mnuServWx.ShowShortcut"), Boolean)
        Me.mnuServWx.Text = resources.GetString("mnuServWx.Text")
        Me.mnuServWx.Visible = CType(resources.GetObject("mnuServWx.Visible"), Boolean)
        '
        'mnuServRINO
        '
        Me.mnuServRINO.Enabled = CType(resources.GetObject("mnuServRINO.Enabled"), Boolean)
        Me.mnuServRINO.Index = 5
        Me.mnuServRINO.Shortcut = CType(resources.GetObject("mnuServRINO.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServRINO.ShowShortcut = CType(resources.GetObject("mnuServRINO.ShowShortcut"), Boolean)
        Me.mnuServRINO.Text = resources.GetString("mnuServRINO.Text")
        Me.mnuServRINO.Visible = CType(resources.GetObject("mnuServRINO.Visible"), Boolean)
        '
        'mnuServDatabase
        '
        Me.mnuServDatabase.Enabled = CType(resources.GetObject("mnuServDatabase.Enabled"), Boolean)
        Me.mnuServDatabase.Index = 6
        Me.mnuServDatabase.Shortcut = CType(resources.GetObject("mnuServDatabase.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServDatabase.ShowShortcut = CType(resources.GetObject("mnuServDatabase.ShowShortcut"), Boolean)
        Me.mnuServDatabase.Text = resources.GetString("mnuServDatabase.Text")
        Me.mnuServDatabase.Visible = CType(resources.GetObject("mnuServDatabase.Visible"), Boolean)
        '
        'mnuServUIView
        '
        Me.mnuServUIView.Enabled = CType(resources.GetObject("mnuServUIView.Enabled"), Boolean)
        Me.mnuServUIView.Index = 7
        Me.mnuServUIView.Shortcut = CType(resources.GetObject("mnuServUIView.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServUIView.ShowShortcut = CType(resources.GetObject("mnuServUIView.ShowShortcut"), Boolean)
        Me.mnuServUIView.Text = resources.GetString("mnuServUIView.Text")
        Me.mnuServUIView.Visible = CType(resources.GetObject("mnuServUIView.Visible"), Boolean)
        '
        'MenuItem7
        '
        Me.MenuItem7.Enabled = CType(resources.GetObject("MenuItem7.Enabled"), Boolean)
        Me.MenuItem7.Index = 8
        Me.MenuItem7.Shortcut = CType(resources.GetObject("MenuItem7.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem7.ShowShortcut = CType(resources.GetObject("MenuItem7.ShowShortcut"), Boolean)
        Me.MenuItem7.Text = resources.GetString("MenuItem7.Text")
        Me.MenuItem7.Visible = CType(resources.GetObject("MenuItem7.Visible"), Boolean)
        '
        'mnuServOzi
        '
        Me.mnuServOzi.Enabled = CType(resources.GetObject("mnuServOzi.Enabled"), Boolean)
        Me.mnuServOzi.Index = 9
        Me.mnuServOzi.Shortcut = CType(resources.GetObject("mnuServOzi.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServOzi.ShowShortcut = CType(resources.GetObject("mnuServOzi.ShowShortcut"), Boolean)
        Me.mnuServOzi.Text = resources.GetString("mnuServOzi.Text")
        Me.mnuServOzi.Visible = CType(resources.GetObject("mnuServOzi.Visible"), Boolean)
        '
        'mnuServMapPoint
        '
        Me.mnuServMapPoint.Enabled = CType(resources.GetObject("mnuServMapPoint.Enabled"), Boolean)
        Me.mnuServMapPoint.Index = 10
        Me.mnuServMapPoint.Shortcut = CType(resources.GetObject("mnuServMapPoint.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServMapPoint.ShowShortcut = CType(resources.GetObject("mnuServMapPoint.ShowShortcut"), Boolean)
        Me.mnuServMapPoint.Text = resources.GetString("mnuServMapPoint.Text")
        Me.mnuServMapPoint.Visible = CType(resources.GetObject("mnuServMapPoint.Visible"), Boolean)
        '
        'MenuItem8
        '
        Me.MenuItem8.Enabled = CType(resources.GetObject("MenuItem8.Enabled"), Boolean)
        Me.MenuItem8.Index = 11
        Me.MenuItem8.Shortcut = CType(resources.GetObject("MenuItem8.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem8.ShowShortcut = CType(resources.GetObject("MenuItem8.ShowShortcut"), Boolean)
        Me.MenuItem8.Text = resources.GetString("MenuItem8.Text")
        Me.MenuItem8.Visible = CType(resources.GetObject("MenuItem8.Visible"), Boolean)
        '
        'mnuServHub
        '
        Me.mnuServHub.Enabled = CType(resources.GetObject("mnuServHub.Enabled"), Boolean)
        Me.mnuServHub.Index = 12
        Me.mnuServHub.Shortcut = CType(resources.GetObject("mnuServHub.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServHub.ShowShortcut = CType(resources.GetObject("mnuServHub.ShowShortcut"), Boolean)
        Me.mnuServHub.Text = resources.GetString("mnuServHub.Text")
        Me.mnuServHub.Visible = CType(resources.GetObject("mnuServHub.Visible"), Boolean)
        '
        'mnuServGPRS
        '
        Me.mnuServGPRS.Enabled = CType(resources.GetObject("mnuServGPRS.Enabled"), Boolean)
        Me.mnuServGPRS.Index = 13
        Me.mnuServGPRS.Shortcut = CType(resources.GetObject("mnuServGPRS.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServGPRS.ShowShortcut = CType(resources.GetObject("mnuServGPRS.ShowShortcut"), Boolean)
        Me.mnuServGPRS.Text = resources.GetString("mnuServGPRS.Text")
        Me.mnuServGPRS.Visible = CType(resources.GetObject("mnuServGPRS.Visible"), Boolean)
        '
        'mnuServNetGPS
        '
        Me.mnuServNetGPS.Enabled = CType(resources.GetObject("mnuServNetGPS.Enabled"), Boolean)
        Me.mnuServNetGPS.Index = 14
        Me.mnuServNetGPS.Shortcut = CType(resources.GetObject("mnuServNetGPS.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServNetGPS.ShowShortcut = CType(resources.GetObject("mnuServNetGPS.ShowShortcut"), Boolean)
        Me.mnuServNetGPS.Text = resources.GetString("mnuServNetGPS.Text")
        Me.mnuServNetGPS.Visible = CType(resources.GetObject("mnuServNetGPS.Visible"), Boolean)
        '
        'mnuServRealTrack
        '
        Me.mnuServRealTrack.Enabled = CType(resources.GetObject("mnuServRealTrack.Enabled"), Boolean)
        Me.mnuServRealTrack.Index = 15
        Me.mnuServRealTrack.Shortcut = CType(resources.GetObject("mnuServRealTrack.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServRealTrack.ShowShortcut = CType(resources.GetObject("mnuServRealTrack.ShowShortcut"), Boolean)
        Me.mnuServRealTrack.Text = resources.GetString("mnuServRealTrack.Text")
        Me.mnuServRealTrack.Visible = CType(resources.GetObject("mnuServRealTrack.Visible"), Boolean)
        '
        'MenuItem6
        '
        Me.MenuItem6.Enabled = CType(resources.GetObject("MenuItem6.Enabled"), Boolean)
        Me.MenuItem6.Index = 16
        Me.MenuItem6.Shortcut = CType(resources.GetObject("MenuItem6.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem6.ShowShortcut = CType(resources.GetObject("MenuItem6.ShowShortcut"), Boolean)
        Me.MenuItem6.Text = resources.GetString("MenuItem6.Text")
        Me.MenuItem6.Visible = CType(resources.GetObject("MenuItem6.Visible"), Boolean)
        '
        'mnuServLog
        '
        Me.mnuServLog.Enabled = CType(resources.GetObject("mnuServLog.Enabled"), Boolean)
        Me.mnuServLog.Index = 17
        Me.mnuServLog.Shortcut = CType(resources.GetObject("mnuServLog.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServLog.ShowShortcut = CType(resources.GetObject("mnuServLog.ShowShortcut"), Boolean)
        Me.mnuServLog.Text = resources.GetString("mnuServLog.Text")
        Me.mnuServLog.Visible = CType(resources.GetObject("mnuServLog.Visible"), Boolean)
        '
        'mnuInterfaces
        '
        Me.mnuInterfaces.Enabled = CType(resources.GetObject("mnuInterfaces.Enabled"), Boolean)
        Me.mnuInterfaces.Index = 2
        Me.mnuInterfaces.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuInterfacesOziExplorer})
        Me.mnuInterfaces.Shortcut = CType(resources.GetObject("mnuInterfaces.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfaces.ShowShortcut = CType(resources.GetObject("mnuInterfaces.ShowShortcut"), Boolean)
        Me.mnuInterfaces.Text = resources.GetString("mnuInterfaces.Text")
        Me.mnuInterfaces.Visible = CType(resources.GetObject("mnuInterfaces.Visible"), Boolean)
        '
        'mnuInterfacesOziExplorer
        '
        Me.mnuInterfacesOziExplorer.Enabled = CType(resources.GetObject("mnuInterfacesOziExplorer.Enabled"), Boolean)
        Me.mnuInterfacesOziExplorer.Index = 0
        Me.mnuInterfacesOziExplorer.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuInterfacesOziSync, Me.mnuInterfacesOziClear, Me.mnuInterfaceOziDecay, Me.mnuInterfaceOziAutoTrail, Me.mnuInterfaceOziGetGPS})
        Me.mnuInterfacesOziExplorer.Shortcut = CType(resources.GetObject("mnuInterfacesOziExplorer.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfacesOziExplorer.ShowShortcut = CType(resources.GetObject("mnuInterfacesOziExplorer.ShowShortcut"), Boolean)
        Me.mnuInterfacesOziExplorer.Text = resources.GetString("mnuInterfacesOziExplorer.Text")
        Me.mnuInterfacesOziExplorer.Visible = CType(resources.GetObject("mnuInterfacesOziExplorer.Visible"), Boolean)
        '
        'mnuInterfacesOziSync
        '
        Me.mnuInterfacesOziSync.Enabled = CType(resources.GetObject("mnuInterfacesOziSync.Enabled"), Boolean)
        Me.mnuInterfacesOziSync.Index = 0
        Me.mnuInterfacesOziSync.Shortcut = CType(resources.GetObject("mnuInterfacesOziSync.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfacesOziSync.ShowShortcut = CType(resources.GetObject("mnuInterfacesOziSync.ShowShortcut"), Boolean)
        Me.mnuInterfacesOziSync.Text = resources.GetString("mnuInterfacesOziSync.Text")
        Me.mnuInterfacesOziSync.Visible = CType(resources.GetObject("mnuInterfacesOziSync.Visible"), Boolean)
        '
        'mnuInterfacesOziClear
        '
        Me.mnuInterfacesOziClear.Enabled = CType(resources.GetObject("mnuInterfacesOziClear.Enabled"), Boolean)
        Me.mnuInterfacesOziClear.Index = 1
        Me.mnuInterfacesOziClear.Shortcut = CType(resources.GetObject("mnuInterfacesOziClear.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfacesOziClear.ShowShortcut = CType(resources.GetObject("mnuInterfacesOziClear.ShowShortcut"), Boolean)
        Me.mnuInterfacesOziClear.Text = resources.GetString("mnuInterfacesOziClear.Text")
        Me.mnuInterfacesOziClear.Visible = CType(resources.GetObject("mnuInterfacesOziClear.Visible"), Boolean)
        '
        'mnuInterfaceOziDecay
        '
        Me.mnuInterfaceOziDecay.Enabled = CType(resources.GetObject("mnuInterfaceOziDecay.Enabled"), Boolean)
        Me.mnuInterfaceOziDecay.Index = 2
        Me.mnuInterfaceOziDecay.Shortcut = CType(resources.GetObject("mnuInterfaceOziDecay.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfaceOziDecay.ShowShortcut = CType(resources.GetObject("mnuInterfaceOziDecay.ShowShortcut"), Boolean)
        Me.mnuInterfaceOziDecay.Text = resources.GetString("mnuInterfaceOziDecay.Text")
        Me.mnuInterfaceOziDecay.Visible = CType(resources.GetObject("mnuInterfaceOziDecay.Visible"), Boolean)
        '
        'mnuInterfaceOziAutoTrail
        '
        Me.mnuInterfaceOziAutoTrail.Enabled = CType(resources.GetObject("mnuInterfaceOziAutoTrail.Enabled"), Boolean)
        Me.mnuInterfaceOziAutoTrail.Index = 3
        Me.mnuInterfaceOziAutoTrail.Shortcut = CType(resources.GetObject("mnuInterfaceOziAutoTrail.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfaceOziAutoTrail.ShowShortcut = CType(resources.GetObject("mnuInterfaceOziAutoTrail.ShowShortcut"), Boolean)
        Me.mnuInterfaceOziAutoTrail.Text = resources.GetString("mnuInterfaceOziAutoTrail.Text")
        Me.mnuInterfaceOziAutoTrail.Visible = CType(resources.GetObject("mnuInterfaceOziAutoTrail.Visible"), Boolean)
        '
        'mnuInterfaceOziGetGPS
        '
        Me.mnuInterfaceOziGetGPS.Enabled = CType(resources.GetObject("mnuInterfaceOziGetGPS.Enabled"), Boolean)
        Me.mnuInterfaceOziGetGPS.Index = 4
        Me.mnuInterfaceOziGetGPS.Shortcut = CType(resources.GetObject("mnuInterfaceOziGetGPS.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuInterfaceOziGetGPS.ShowShortcut = CType(resources.GetObject("mnuInterfaceOziGetGPS.ShowShortcut"), Boolean)
        Me.mnuInterfaceOziGetGPS.Text = resources.GetString("mnuInterfaceOziGetGPS.Text")
        Me.mnuInterfaceOziGetGPS.Visible = CType(resources.GetObject("mnuInterfaceOziGetGPS.Visible"), Boolean)
        '
        'mnuGui
        '
        Me.mnuGui.Enabled = CType(resources.GetObject("mnuGui.Enabled"), Boolean)
        Me.mnuGui.Index = 3
        Me.mnuGui.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGuiGeo, Me.mnuGuiMonitored, Me.mnuGuiTranslate, Me.MenuItem16, Me.mnuGuiState, Me.MenuItem34, Me.mnuGUIdatabase})
        Me.mnuGui.Shortcut = CType(resources.GetObject("mnuGui.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGui.ShowShortcut = CType(resources.GetObject("mnuGui.ShowShortcut"), Boolean)
        Me.mnuGui.Text = resources.GetString("mnuGui.Text")
        Me.mnuGui.Visible = CType(resources.GetObject("mnuGui.Visible"), Boolean)
        '
        'mnuGuiGeo
        '
        Me.mnuGuiGeo.Enabled = CType(resources.GetObject("mnuGuiGeo.Enabled"), Boolean)
        Me.mnuGuiGeo.Index = 0
        Me.mnuGuiGeo.Shortcut = CType(resources.GetObject("mnuGuiGeo.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiGeo.ShowShortcut = CType(resources.GetObject("mnuGuiGeo.ShowShortcut"), Boolean)
        Me.mnuGuiGeo.Text = resources.GetString("mnuGuiGeo.Text")
        Me.mnuGuiGeo.Visible = CType(resources.GetObject("mnuGuiGeo.Visible"), Boolean)
        '
        'mnuGuiMonitored
        '
        Me.mnuGuiMonitored.Enabled = CType(resources.GetObject("mnuGuiMonitored.Enabled"), Boolean)
        Me.mnuGuiMonitored.Index = 1
        Me.mnuGuiMonitored.Shortcut = CType(resources.GetObject("mnuGuiMonitored.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiMonitored.ShowShortcut = CType(resources.GetObject("mnuGuiMonitored.ShowShortcut"), Boolean)
        Me.mnuGuiMonitored.Text = resources.GetString("mnuGuiMonitored.Text")
        Me.mnuGuiMonitored.Visible = CType(resources.GetObject("mnuGuiMonitored.Visible"), Boolean)
        '
        'mnuGuiTranslate
        '
        Me.mnuGuiTranslate.Enabled = CType(resources.GetObject("mnuGuiTranslate.Enabled"), Boolean)
        Me.mnuGuiTranslate.Index = 2
        Me.mnuGuiTranslate.Shortcut = CType(resources.GetObject("mnuGuiTranslate.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiTranslate.ShowShortcut = CType(resources.GetObject("mnuGuiTranslate.ShowShortcut"), Boolean)
        Me.mnuGuiTranslate.Text = resources.GetString("mnuGuiTranslate.Text")
        Me.mnuGuiTranslate.Visible = CType(resources.GetObject("mnuGuiTranslate.Visible"), Boolean)
        '
        'MenuItem16
        '
        Me.MenuItem16.Enabled = CType(resources.GetObject("MenuItem16.Enabled"), Boolean)
        Me.MenuItem16.Index = 3
        Me.MenuItem16.Shortcut = CType(resources.GetObject("MenuItem16.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem16.ShowShortcut = CType(resources.GetObject("MenuItem16.ShowShortcut"), Boolean)
        Me.MenuItem16.Text = resources.GetString("MenuItem16.Text")
        Me.MenuItem16.Visible = CType(resources.GetObject("MenuItem16.Visible"), Boolean)
        '
        'mnuGuiState
        '
        Me.mnuGuiState.Enabled = CType(resources.GetObject("mnuGuiState.Enabled"), Boolean)
        Me.mnuGuiState.Index = 4
        Me.mnuGuiState.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuGuiStateSave, Me.mnuGuiStateSaveFilename, Me.mnuGuiStateLoad, Me.mnuGuiStateLoadFilename})
        Me.mnuGuiState.Shortcut = CType(resources.GetObject("mnuGuiState.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiState.ShowShortcut = CType(resources.GetObject("mnuGuiState.ShowShortcut"), Boolean)
        Me.mnuGuiState.Text = resources.GetString("mnuGuiState.Text")
        Me.mnuGuiState.Visible = CType(resources.GetObject("mnuGuiState.Visible"), Boolean)
        '
        'mnuGuiStateSave
        '
        Me.mnuGuiStateSave.Enabled = CType(resources.GetObject("mnuGuiStateSave.Enabled"), Boolean)
        Me.mnuGuiStateSave.Index = 0
        Me.mnuGuiStateSave.Shortcut = CType(resources.GetObject("mnuGuiStateSave.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiStateSave.ShowShortcut = CType(resources.GetObject("mnuGuiStateSave.ShowShortcut"), Boolean)
        Me.mnuGuiStateSave.Text = resources.GetString("mnuGuiStateSave.Text")
        Me.mnuGuiStateSave.Visible = CType(resources.GetObject("mnuGuiStateSave.Visible"), Boolean)
        '
        'mnuGuiStateSaveFilename
        '
        Me.mnuGuiStateSaveFilename.Enabled = CType(resources.GetObject("mnuGuiStateSaveFilename.Enabled"), Boolean)
        Me.mnuGuiStateSaveFilename.Index = 1
        Me.mnuGuiStateSaveFilename.Shortcut = CType(resources.GetObject("mnuGuiStateSaveFilename.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiStateSaveFilename.ShowShortcut = CType(resources.GetObject("mnuGuiStateSaveFilename.ShowShortcut"), Boolean)
        Me.mnuGuiStateSaveFilename.Text = resources.GetString("mnuGuiStateSaveFilename.Text")
        Me.mnuGuiStateSaveFilename.Visible = CType(resources.GetObject("mnuGuiStateSaveFilename.Visible"), Boolean)
        '
        'mnuGuiStateLoad
        '
        Me.mnuGuiStateLoad.Enabled = CType(resources.GetObject("mnuGuiStateLoad.Enabled"), Boolean)
        Me.mnuGuiStateLoad.Index = 2
        Me.mnuGuiStateLoad.Shortcut = CType(resources.GetObject("mnuGuiStateLoad.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiStateLoad.ShowShortcut = CType(resources.GetObject("mnuGuiStateLoad.ShowShortcut"), Boolean)
        Me.mnuGuiStateLoad.Text = resources.GetString("mnuGuiStateLoad.Text")
        Me.mnuGuiStateLoad.Visible = CType(resources.GetObject("mnuGuiStateLoad.Visible"), Boolean)
        '
        'mnuGuiStateLoadFilename
        '
        Me.mnuGuiStateLoadFilename.Enabled = CType(resources.GetObject("mnuGuiStateLoadFilename.Enabled"), Boolean)
        Me.mnuGuiStateLoadFilename.Index = 3
        Me.mnuGuiStateLoadFilename.Shortcut = CType(resources.GetObject("mnuGuiStateLoadFilename.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGuiStateLoadFilename.ShowShortcut = CType(resources.GetObject("mnuGuiStateLoadFilename.ShowShortcut"), Boolean)
        Me.mnuGuiStateLoadFilename.Text = resources.GetString("mnuGuiStateLoadFilename.Text")
        Me.mnuGuiStateLoadFilename.Visible = CType(resources.GetObject("mnuGuiStateLoadFilename.Visible"), Boolean)
        '
        'MenuItem34
        '
        Me.MenuItem34.Enabled = CType(resources.GetObject("MenuItem34.Enabled"), Boolean)
        Me.MenuItem34.Index = 5
        Me.MenuItem34.Shortcut = CType(resources.GetObject("MenuItem34.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem34.ShowShortcut = CType(resources.GetObject("MenuItem34.ShowShortcut"), Boolean)
        Me.MenuItem34.Text = resources.GetString("MenuItem34.Text")
        Me.MenuItem34.Visible = CType(resources.GetObject("MenuItem34.Visible"), Boolean)
        '
        'mnuGUIdatabase
        '
        Me.mnuGUIdatabase.Enabled = CType(resources.GetObject("mnuGUIdatabase.Enabled"), Boolean)
        Me.mnuGUIdatabase.Index = 6
        Me.mnuGUIdatabase.Shortcut = CType(resources.GetObject("mnuGUIdatabase.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuGUIdatabase.ShowShortcut = CType(resources.GetObject("mnuGUIdatabase.ShowShortcut"), Boolean)
        Me.mnuGUIdatabase.Text = resources.GetString("mnuGUIdatabase.Text")
        Me.mnuGUIdatabase.Visible = CType(resources.GetObject("mnuGUIdatabase.Visible"), Boolean)
        '
        'mnuHelp
        '
        Me.mnuHelp.Enabled = CType(resources.GetObject("mnuHelp.Enabled"), Boolean)
        Me.mnuHelp.Index = 4
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpRegister, Me.mnuHelpAbout})
        Me.mnuHelp.Shortcut = CType(resources.GetObject("mnuHelp.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuHelp.ShowShortcut = CType(resources.GetObject("mnuHelp.ShowShortcut"), Boolean)
        Me.mnuHelp.Text = resources.GetString("mnuHelp.Text")
        Me.mnuHelp.Visible = CType(resources.GetObject("mnuHelp.Visible"), Boolean)
        '
        'mnuHelpRegister
        '
        Me.mnuHelpRegister.Enabled = CType(resources.GetObject("mnuHelpRegister.Enabled"), Boolean)
        Me.mnuHelpRegister.Index = 0
        Me.mnuHelpRegister.Shortcut = CType(resources.GetObject("mnuHelpRegister.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuHelpRegister.ShowShortcut = CType(resources.GetObject("mnuHelpRegister.ShowShortcut"), Boolean)
        Me.mnuHelpRegister.Text = resources.GetString("mnuHelpRegister.Text")
        Me.mnuHelpRegister.Visible = CType(resources.GetObject("mnuHelpRegister.Visible"), Boolean)
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Enabled = CType(resources.GetObject("mnuHelpAbout.Enabled"), Boolean)
        Me.mnuHelpAbout.Index = 1
        Me.mnuHelpAbout.Shortcut = CType(resources.GetObject("mnuHelpAbout.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuHelpAbout.ShowShortcut = CType(resources.GetObject("mnuHelpAbout.ShowShortcut"), Boolean)
        Me.mnuHelpAbout.Text = resources.GetString("mnuHelpAbout.Text")
        Me.mnuHelpAbout.Visible = CType(resources.GetObject("mnuHelpAbout.Visible"), Boolean)
        '
        'MenuItem2
        '
        Me.MenuItem2.Enabled = CType(resources.GetObject("MenuItem2.Enabled"), Boolean)
        Me.MenuItem2.Index = 5
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuProductBasic, Me.mnuProductLive, Me.mnuProductPro})
        Me.MenuItem2.Shortcut = CType(resources.GetObject("MenuItem2.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem2.ShowShortcut = CType(resources.GetObject("MenuItem2.ShowShortcut"), Boolean)
        Me.MenuItem2.Text = resources.GetString("MenuItem2.Text")
        Me.MenuItem2.Visible = CType(resources.GetObject("MenuItem2.Visible"), Boolean)
        '
        'mnuProductBasic
        '
        Me.mnuProductBasic.Checked = True
        Me.mnuProductBasic.Enabled = CType(resources.GetObject("mnuProductBasic.Enabled"), Boolean)
        Me.mnuProductBasic.Index = 0
        Me.mnuProductBasic.Shortcut = CType(resources.GetObject("mnuProductBasic.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuProductBasic.ShowShortcut = CType(resources.GetObject("mnuProductBasic.ShowShortcut"), Boolean)
        Me.mnuProductBasic.Text = resources.GetString("mnuProductBasic.Text")
        Me.mnuProductBasic.Visible = CType(resources.GetObject("mnuProductBasic.Visible"), Boolean)
        '
        'mnuProductLive
        '
        Me.mnuProductLive.Enabled = CType(resources.GetObject("mnuProductLive.Enabled"), Boolean)
        Me.mnuProductLive.Index = 1
        Me.mnuProductLive.Shortcut = CType(resources.GetObject("mnuProductLive.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuProductLive.ShowShortcut = CType(resources.GetObject("mnuProductLive.ShowShortcut"), Boolean)
        Me.mnuProductLive.Text = resources.GetString("mnuProductLive.Text")
        Me.mnuProductLive.Visible = CType(resources.GetObject("mnuProductLive.Visible"), Boolean)
        '
        'mnuProductPro
        '
        Me.mnuProductPro.Enabled = CType(resources.GetObject("mnuProductPro.Enabled"), Boolean)
        Me.mnuProductPro.Index = 2
        Me.mnuProductPro.Shortcut = CType(resources.GetObject("mnuProductPro.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuProductPro.ShowShortcut = CType(resources.GetObject("mnuProductPro.ShowShortcut"), Boolean)
        Me.mnuProductPro.Text = resources.GetString("mnuProductPro.Text")
        Me.mnuProductPro.Visible = CType(resources.GetObject("mnuProductPro.Visible"), Boolean)
        '
        'MenuItem11
        '
        Me.MenuItem11.Enabled = CType(resources.GetObject("MenuItem11.Enabled"), Boolean)
        Me.MenuItem11.Index = 6
        Me.MenuItem11.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.frmModeLive, Me.frmModePlayback, Me.frmModeRecording})
        Me.MenuItem11.Shortcut = CType(resources.GetObject("MenuItem11.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem11.ShowShortcut = CType(resources.GetObject("MenuItem11.ShowShortcut"), Boolean)
        Me.MenuItem11.Text = resources.GetString("MenuItem11.Text")
        Me.MenuItem11.Visible = CType(resources.GetObject("MenuItem11.Visible"), Boolean)
        '
        'frmModeLive
        '
        Me.frmModeLive.Checked = True
        Me.frmModeLive.Enabled = CType(resources.GetObject("frmModeLive.Enabled"), Boolean)
        Me.frmModeLive.Index = 0
        Me.frmModeLive.Shortcut = CType(resources.GetObject("frmModeLive.Shortcut"), System.Windows.Forms.Shortcut)
        Me.frmModeLive.ShowShortcut = CType(resources.GetObject("frmModeLive.ShowShortcut"), Boolean)
        Me.frmModeLive.Text = resources.GetString("frmModeLive.Text")
        Me.frmModeLive.Visible = CType(resources.GetObject("frmModeLive.Visible"), Boolean)
        '
        'frmModePlayback
        '
        Me.frmModePlayback.Enabled = CType(resources.GetObject("frmModePlayback.Enabled"), Boolean)
        Me.frmModePlayback.Index = 1
        Me.frmModePlayback.Shortcut = CType(resources.GetObject("frmModePlayback.Shortcut"), System.Windows.Forms.Shortcut)
        Me.frmModePlayback.ShowShortcut = CType(resources.GetObject("frmModePlayback.ShowShortcut"), Boolean)
        Me.frmModePlayback.Text = resources.GetString("frmModePlayback.Text")
        Me.frmModePlayback.Visible = CType(resources.GetObject("frmModePlayback.Visible"), Boolean)
        '
        'frmModeRecording
        '
        Me.frmModeRecording.Enabled = CType(resources.GetObject("frmModeRecording.Enabled"), Boolean)
        Me.frmModeRecording.Index = 2
        Me.frmModeRecording.Shortcut = CType(resources.GetObject("frmModeRecording.Shortcut"), System.Windows.Forms.Shortcut)
        Me.frmModeRecording.ShowShortcut = CType(resources.GetObject("frmModeRecording.ShowShortcut"), Boolean)
        Me.frmModeRecording.Text = resources.GetString("frmModeRecording.Text")
        Me.frmModeRecording.Visible = CType(resources.GetObject("frmModeRecording.Visible"), Boolean)
        '
        'MenuItem4
        '
        Me.MenuItem4.Enabled = CType(resources.GetObject("MenuItem4.Enabled"), Boolean)
        Me.MenuItem4.Index = 7
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuServerAGWPE, Me.MenuItem12, Me.mnuTNCcom, Me.mnuTNCconnect, Me.mnuTNCkiss, Me.MenuItem19, Me.mnuTestClear})
        Me.MenuItem4.Shortcut = CType(resources.GetObject("MenuItem4.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem4.ShowShortcut = CType(resources.GetObject("MenuItem4.ShowShortcut"), Boolean)
        Me.MenuItem4.Text = resources.GetString("MenuItem4.Text")
        Me.MenuItem4.Visible = CType(resources.GetObject("MenuItem4.Visible"), Boolean)
        '
        'mnuServerAGWPE
        '
        Me.mnuServerAGWPE.Enabled = CType(resources.GetObject("mnuServerAGWPE.Enabled"), Boolean)
        Me.mnuServerAGWPE.Index = 0
        Me.mnuServerAGWPE.Shortcut = CType(resources.GetObject("mnuServerAGWPE.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuServerAGWPE.ShowShortcut = CType(resources.GetObject("mnuServerAGWPE.ShowShortcut"), Boolean)
        Me.mnuServerAGWPE.Text = resources.GetString("mnuServerAGWPE.Text")
        Me.mnuServerAGWPE.Visible = CType(resources.GetObject("mnuServerAGWPE.Visible"), Boolean)
        '
        'MenuItem12
        '
        Me.MenuItem12.Enabled = CType(resources.GetObject("MenuItem12.Enabled"), Boolean)
        Me.MenuItem12.Index = 1
        Me.MenuItem12.Shortcut = CType(resources.GetObject("MenuItem12.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem12.ShowShortcut = CType(resources.GetObject("MenuItem12.ShowShortcut"), Boolean)
        Me.MenuItem12.Text = resources.GetString("MenuItem12.Text")
        Me.MenuItem12.Visible = CType(resources.GetObject("MenuItem12.Visible"), Boolean)
        '
        'mnuTNCcom
        '
        Me.mnuTNCcom.Enabled = CType(resources.GetObject("mnuTNCcom.Enabled"), Boolean)
        Me.mnuTNCcom.Index = 2
        Me.mnuTNCcom.Shortcut = CType(resources.GetObject("mnuTNCcom.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuTNCcom.ShowShortcut = CType(resources.GetObject("mnuTNCcom.ShowShortcut"), Boolean)
        Me.mnuTNCcom.Text = resources.GetString("mnuTNCcom.Text")
        Me.mnuTNCcom.Visible = CType(resources.GetObject("mnuTNCcom.Visible"), Boolean)
        '
        'mnuTNCconnect
        '
        Me.mnuTNCconnect.Enabled = CType(resources.GetObject("mnuTNCconnect.Enabled"), Boolean)
        Me.mnuTNCconnect.Index = 3
        Me.mnuTNCconnect.Shortcut = CType(resources.GetObject("mnuTNCconnect.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuTNCconnect.ShowShortcut = CType(resources.GetObject("mnuTNCconnect.ShowShortcut"), Boolean)
        Me.mnuTNCconnect.Text = resources.GetString("mnuTNCconnect.Text")
        Me.mnuTNCconnect.Visible = CType(resources.GetObject("mnuTNCconnect.Visible"), Boolean)
        '
        'mnuTNCkiss
        '
        Me.mnuTNCkiss.Enabled = CType(resources.GetObject("mnuTNCkiss.Enabled"), Boolean)
        Me.mnuTNCkiss.Index = 4
        Me.mnuTNCkiss.Shortcut = CType(resources.GetObject("mnuTNCkiss.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuTNCkiss.ShowShortcut = CType(resources.GetObject("mnuTNCkiss.ShowShortcut"), Boolean)
        Me.mnuTNCkiss.Text = resources.GetString("mnuTNCkiss.Text")
        Me.mnuTNCkiss.Visible = CType(resources.GetObject("mnuTNCkiss.Visible"), Boolean)
        '
        'MenuItem19
        '
        Me.MenuItem19.Enabled = CType(resources.GetObject("MenuItem19.Enabled"), Boolean)
        Me.MenuItem19.Index = 5
        Me.MenuItem19.Shortcut = CType(resources.GetObject("MenuItem19.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem19.ShowShortcut = CType(resources.GetObject("MenuItem19.ShowShortcut"), Boolean)
        Me.MenuItem19.Text = resources.GetString("MenuItem19.Text")
        Me.MenuItem19.Visible = CType(resources.GetObject("MenuItem19.Visible"), Boolean)
        '
        'mnuTestClear
        '
        Me.mnuTestClear.Enabled = CType(resources.GetObject("mnuTestClear.Enabled"), Boolean)
        Me.mnuTestClear.Index = 6
        Me.mnuTestClear.Shortcut = CType(resources.GetObject("mnuTestClear.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuTestClear.ShowShortcut = CType(resources.GetObject("mnuTestClear.ShowShortcut"), Boolean)
        Me.mnuTestClear.Text = resources.GetString("mnuTestClear.Text")
        Me.mnuTestClear.Visible = CType(resources.GetObject("mnuTestClear.Visible"), Boolean)
        '
        'tcpAPRS
        '
        '
        'WebServer80
        '
        Me.WebServer80.Editor = Me.WebServer80
        '
        'tcpAGWPE
        '
        '
        'mnuPopup
        '
        Me.mnuPopup.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem9, Me.MenuItem10, Me.mnuMapAtCursor, Me.mnuBestMapAtCursor, Me.MenuItem1, Me.mnuPollNearby, Me.mnuPopupAdd, Me.mnuPopupMove, Me.MenuItem14, Me.mnuPopupFilter1, Me.mnuPopupFilter2, Me.MenuItem17, Me.mnuPopupCancel})
        Me.mnuPopup.RightToLeft = CType(resources.GetObject("mnuPopup.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'MenuItem9
        '
        Me.MenuItem9.Enabled = CType(resources.GetObject("MenuItem9.Enabled"), Boolean)
        Me.MenuItem9.Index = 0
        Me.MenuItem9.Shortcut = CType(resources.GetObject("MenuItem9.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem9.ShowShortcut = CType(resources.GetObject("MenuItem9.ShowShortcut"), Boolean)
        Me.MenuItem9.Text = resources.GetString("MenuItem9.Text")
        Me.MenuItem9.Visible = CType(resources.GetObject("MenuItem9.Visible"), Boolean)
        '
        'MenuItem10
        '
        Me.MenuItem10.Enabled = CType(resources.GetObject("MenuItem10.Enabled"), Boolean)
        Me.MenuItem10.Index = 1
        Me.MenuItem10.Shortcut = CType(resources.GetObject("MenuItem10.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem10.ShowShortcut = CType(resources.GetObject("MenuItem10.ShowShortcut"), Boolean)
        Me.MenuItem10.Text = resources.GetString("MenuItem10.Text")
        Me.MenuItem10.Visible = CType(resources.GetObject("MenuItem10.Visible"), Boolean)
        '
        'mnuMapAtCursor
        '
        Me.mnuMapAtCursor.Enabled = CType(resources.GetObject("mnuMapAtCursor.Enabled"), Boolean)
        Me.mnuMapAtCursor.Index = 2
        Me.mnuMapAtCursor.Shortcut = CType(resources.GetObject("mnuMapAtCursor.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuMapAtCursor.ShowShortcut = CType(resources.GetObject("mnuMapAtCursor.ShowShortcut"), Boolean)
        Me.mnuMapAtCursor.Text = resources.GetString("mnuMapAtCursor.Text")
        Me.mnuMapAtCursor.Visible = CType(resources.GetObject("mnuMapAtCursor.Visible"), Boolean)
        '
        'mnuBestMapAtCursor
        '
        Me.mnuBestMapAtCursor.Enabled = CType(resources.GetObject("mnuBestMapAtCursor.Enabled"), Boolean)
        Me.mnuBestMapAtCursor.Index = 3
        Me.mnuBestMapAtCursor.Shortcut = CType(resources.GetObject("mnuBestMapAtCursor.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuBestMapAtCursor.ShowShortcut = CType(resources.GetObject("mnuBestMapAtCursor.ShowShortcut"), Boolean)
        Me.mnuBestMapAtCursor.Text = resources.GetString("mnuBestMapAtCursor.Text")
        Me.mnuBestMapAtCursor.Visible = CType(resources.GetObject("mnuBestMapAtCursor.Visible"), Boolean)
        '
        'MenuItem1
        '
        Me.MenuItem1.Enabled = CType(resources.GetObject("MenuItem1.Enabled"), Boolean)
        Me.MenuItem1.Index = 4
        Me.MenuItem1.Shortcut = CType(resources.GetObject("MenuItem1.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem1.ShowShortcut = CType(resources.GetObject("MenuItem1.ShowShortcut"), Boolean)
        Me.MenuItem1.Text = resources.GetString("MenuItem1.Text")
        Me.MenuItem1.Visible = CType(resources.GetObject("MenuItem1.Visible"), Boolean)
        '
        'mnuPollNearby
        '
        Me.mnuPollNearby.Enabled = CType(resources.GetObject("mnuPollNearby.Enabled"), Boolean)
        Me.mnuPollNearby.Index = 5
        Me.mnuPollNearby.Shortcut = CType(resources.GetObject("mnuPollNearby.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPollNearby.ShowShortcut = CType(resources.GetObject("mnuPollNearby.ShowShortcut"), Boolean)
        Me.mnuPollNearby.Text = resources.GetString("mnuPollNearby.Text")
        Me.mnuPollNearby.Visible = CType(resources.GetObject("mnuPollNearby.Visible"), Boolean)
        '
        'mnuPopupAdd
        '
        Me.mnuPopupAdd.Enabled = CType(resources.GetObject("mnuPopupAdd.Enabled"), Boolean)
        Me.mnuPopupAdd.Index = 6
        Me.mnuPopupAdd.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuPopupAddStation})
        Me.mnuPopupAdd.Shortcut = CType(resources.GetObject("mnuPopupAdd.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupAdd.ShowShortcut = CType(resources.GetObject("mnuPopupAdd.ShowShortcut"), Boolean)
        Me.mnuPopupAdd.Text = resources.GetString("mnuPopupAdd.Text")
        Me.mnuPopupAdd.Visible = CType(resources.GetObject("mnuPopupAdd.Visible"), Boolean)
        '
        'mnuPopupAddStation
        '
        Me.mnuPopupAddStation.Enabled = CType(resources.GetObject("mnuPopupAddStation.Enabled"), Boolean)
        Me.mnuPopupAddStation.Index = 0
        Me.mnuPopupAddStation.Shortcut = CType(resources.GetObject("mnuPopupAddStation.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupAddStation.ShowShortcut = CType(resources.GetObject("mnuPopupAddStation.ShowShortcut"), Boolean)
        Me.mnuPopupAddStation.Text = resources.GetString("mnuPopupAddStation.Text")
        Me.mnuPopupAddStation.Visible = CType(resources.GetObject("mnuPopupAddStation.Visible"), Boolean)
        '
        'mnuPopupMove
        '
        Me.mnuPopupMove.Enabled = CType(resources.GetObject("mnuPopupMove.Enabled"), Boolean)
        Me.mnuPopupMove.Index = 7
        Me.mnuPopupMove.Shortcut = CType(resources.GetObject("mnuPopupMove.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupMove.ShowShortcut = CType(resources.GetObject("mnuPopupMove.ShowShortcut"), Boolean)
        Me.mnuPopupMove.Text = resources.GetString("mnuPopupMove.Text")
        Me.mnuPopupMove.Visible = CType(resources.GetObject("mnuPopupMove.Visible"), Boolean)
        '
        'MenuItem14
        '
        Me.MenuItem14.Enabled = CType(resources.GetObject("MenuItem14.Enabled"), Boolean)
        Me.MenuItem14.Index = 8
        Me.MenuItem14.Shortcut = CType(resources.GetObject("MenuItem14.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem14.ShowShortcut = CType(resources.GetObject("MenuItem14.ShowShortcut"), Boolean)
        Me.MenuItem14.Text = resources.GetString("MenuItem14.Text")
        Me.MenuItem14.Visible = CType(resources.GetObject("MenuItem14.Visible"), Boolean)
        '
        'mnuPopupFilter1
        '
        Me.mnuPopupFilter1.Enabled = CType(resources.GetObject("mnuPopupFilter1.Enabled"), Boolean)
        Me.mnuPopupFilter1.Index = 9
        Me.mnuPopupFilter1.Shortcut = CType(resources.GetObject("mnuPopupFilter1.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupFilter1.ShowShortcut = CType(resources.GetObject("mnuPopupFilter1.ShowShortcut"), Boolean)
        Me.mnuPopupFilter1.Text = resources.GetString("mnuPopupFilter1.Text")
        Me.mnuPopupFilter1.Visible = CType(resources.GetObject("mnuPopupFilter1.Visible"), Boolean)
        '
        'mnuPopupFilter2
        '
        Me.mnuPopupFilter2.Enabled = CType(resources.GetObject("mnuPopupFilter2.Enabled"), Boolean)
        Me.mnuPopupFilter2.Index = 10
        Me.mnuPopupFilter2.Shortcut = CType(resources.GetObject("mnuPopupFilter2.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupFilter2.ShowShortcut = CType(resources.GetObject("mnuPopupFilter2.ShowShortcut"), Boolean)
        Me.mnuPopupFilter2.Text = resources.GetString("mnuPopupFilter2.Text")
        Me.mnuPopupFilter2.Visible = CType(resources.GetObject("mnuPopupFilter2.Visible"), Boolean)
        '
        'MenuItem17
        '
        Me.MenuItem17.Enabled = CType(resources.GetObject("MenuItem17.Enabled"), Boolean)
        Me.MenuItem17.Index = 11
        Me.MenuItem17.Shortcut = CType(resources.GetObject("MenuItem17.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem17.ShowShortcut = CType(resources.GetObject("MenuItem17.ShowShortcut"), Boolean)
        Me.MenuItem17.Text = resources.GetString("MenuItem17.Text")
        Me.MenuItem17.Visible = CType(resources.GetObject("MenuItem17.Visible"), Boolean)
        '
        'mnuPopupCancel
        '
        Me.mnuPopupCancel.Enabled = CType(resources.GetObject("mnuPopupCancel.Enabled"), Boolean)
        Me.mnuPopupCancel.Index = 12
        Me.mnuPopupCancel.Shortcut = CType(resources.GetObject("mnuPopupCancel.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuPopupCancel.ShowShortcut = CType(resources.GetObject("mnuPopupCancel.ShowShortcut"), Boolean)
        Me.mnuPopupCancel.Text = resources.GetString("mnuPopupCancel.Text")
        Me.mnuPopupCancel.Visible = CType(resources.GetObject("mnuPopupCancel.Visible"), Boolean)
        '
        'mnuCallsignPopup
        '
        Me.mnuCallsignPopup.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCallsign, Me.MenuItem20, Me.mnuCallsignPoll, Me.mnuCallsignPopupQRZ, Me.mnuCallsignPopupFindU, Me.mnuCallsignPopupDynamic, Me.MenuItem32, Me.mnuCallsignPopupMessage, Me.MenuItem24, Me.mnuCallsignPopupCancel})
        Me.mnuCallsignPopup.RightToLeft = CType(resources.GetObject("mnuCallsignPopup.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'mnuCallsign
        '
        Me.mnuCallsign.Enabled = CType(resources.GetObject("mnuCallsign.Enabled"), Boolean)
        Me.mnuCallsign.Index = 0
        Me.mnuCallsign.Shortcut = CType(resources.GetObject("mnuCallsign.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsign.ShowShortcut = CType(resources.GetObject("mnuCallsign.ShowShortcut"), Boolean)
        Me.mnuCallsign.Text = resources.GetString("mnuCallsign.Text")
        Me.mnuCallsign.Visible = CType(resources.GetObject("mnuCallsign.Visible"), Boolean)
        '
        'MenuItem20
        '
        Me.MenuItem20.Enabled = CType(resources.GetObject("MenuItem20.Enabled"), Boolean)
        Me.MenuItem20.Index = 1
        Me.MenuItem20.Shortcut = CType(resources.GetObject("MenuItem20.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem20.ShowShortcut = CType(resources.GetObject("MenuItem20.ShowShortcut"), Boolean)
        Me.MenuItem20.Text = resources.GetString("MenuItem20.Text")
        Me.MenuItem20.Visible = CType(resources.GetObject("MenuItem20.Visible"), Boolean)
        '
        'mnuCallsignPoll
        '
        Me.mnuCallsignPoll.Enabled = CType(resources.GetObject("mnuCallsignPoll.Enabled"), Boolean)
        Me.mnuCallsignPoll.Index = 2
        Me.mnuCallsignPoll.Shortcut = CType(resources.GetObject("mnuCallsignPoll.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPoll.ShowShortcut = CType(resources.GetObject("mnuCallsignPoll.ShowShortcut"), Boolean)
        Me.mnuCallsignPoll.Text = resources.GetString("mnuCallsignPoll.Text")
        Me.mnuCallsignPoll.Visible = CType(resources.GetObject("mnuCallsignPoll.Visible"), Boolean)
        '
        'mnuCallsignPopupQRZ
        '
        Me.mnuCallsignPopupQRZ.Enabled = CType(resources.GetObject("mnuCallsignPopupQRZ.Enabled"), Boolean)
        Me.mnuCallsignPopupQRZ.Index = 3
        Me.mnuCallsignPopupQRZ.Shortcut = CType(resources.GetObject("mnuCallsignPopupQRZ.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPopupQRZ.ShowShortcut = CType(resources.GetObject("mnuCallsignPopupQRZ.ShowShortcut"), Boolean)
        Me.mnuCallsignPopupQRZ.Text = resources.GetString("mnuCallsignPopupQRZ.Text")
        Me.mnuCallsignPopupQRZ.Visible = CType(resources.GetObject("mnuCallsignPopupQRZ.Visible"), Boolean)
        '
        'mnuCallsignPopupFindU
        '
        Me.mnuCallsignPopupFindU.Enabled = CType(resources.GetObject("mnuCallsignPopupFindU.Enabled"), Boolean)
        Me.mnuCallsignPopupFindU.Index = 4
        Me.mnuCallsignPopupFindU.Shortcut = CType(resources.GetObject("mnuCallsignPopupFindU.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPopupFindU.ShowShortcut = CType(resources.GetObject("mnuCallsignPopupFindU.ShowShortcut"), Boolean)
        Me.mnuCallsignPopupFindU.Text = resources.GetString("mnuCallsignPopupFindU.Text")
        Me.mnuCallsignPopupFindU.Visible = CType(resources.GetObject("mnuCallsignPopupFindU.Visible"), Boolean)
        '
        'mnuCallsignPopupDynamic
        '
        Me.mnuCallsignPopupDynamic.Enabled = CType(resources.GetObject("mnuCallsignPopupDynamic.Enabled"), Boolean)
        Me.mnuCallsignPopupDynamic.Index = 5
        Me.mnuCallsignPopupDynamic.Shortcut = CType(resources.GetObject("mnuCallsignPopupDynamic.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPopupDynamic.ShowShortcut = CType(resources.GetObject("mnuCallsignPopupDynamic.ShowShortcut"), Boolean)
        Me.mnuCallsignPopupDynamic.Text = resources.GetString("mnuCallsignPopupDynamic.Text")
        Me.mnuCallsignPopupDynamic.Visible = CType(resources.GetObject("mnuCallsignPopupDynamic.Visible"), Boolean)
        '
        'MenuItem32
        '
        Me.MenuItem32.Enabled = CType(resources.GetObject("MenuItem32.Enabled"), Boolean)
        Me.MenuItem32.Index = 6
        Me.MenuItem32.Shortcut = CType(resources.GetObject("MenuItem32.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem32.ShowShortcut = CType(resources.GetObject("MenuItem32.ShowShortcut"), Boolean)
        Me.MenuItem32.Text = resources.GetString("MenuItem32.Text")
        Me.MenuItem32.Visible = CType(resources.GetObject("MenuItem32.Visible"), Boolean)
        '
        'mnuCallsignPopupMessage
        '
        Me.mnuCallsignPopupMessage.Enabled = CType(resources.GetObject("mnuCallsignPopupMessage.Enabled"), Boolean)
        Me.mnuCallsignPopupMessage.Index = 7
        Me.mnuCallsignPopupMessage.Shortcut = CType(resources.GetObject("mnuCallsignPopupMessage.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPopupMessage.ShowShortcut = CType(resources.GetObject("mnuCallsignPopupMessage.ShowShortcut"), Boolean)
        Me.mnuCallsignPopupMessage.Text = resources.GetString("mnuCallsignPopupMessage.Text")
        Me.mnuCallsignPopupMessage.Visible = CType(resources.GetObject("mnuCallsignPopupMessage.Visible"), Boolean)
        '
        'MenuItem24
        '
        Me.MenuItem24.Enabled = CType(resources.GetObject("MenuItem24.Enabled"), Boolean)
        Me.MenuItem24.Index = 8
        Me.MenuItem24.Shortcut = CType(resources.GetObject("MenuItem24.Shortcut"), System.Windows.Forms.Shortcut)
        Me.MenuItem24.ShowShortcut = CType(resources.GetObject("MenuItem24.ShowShortcut"), Boolean)
        Me.MenuItem24.Text = resources.GetString("MenuItem24.Text")
        Me.MenuItem24.Visible = CType(resources.GetObject("MenuItem24.Visible"), Boolean)
        '
        'mnuCallsignPopupCancel
        '
        Me.mnuCallsignPopupCancel.Enabled = CType(resources.GetObject("mnuCallsignPopupCancel.Enabled"), Boolean)
        Me.mnuCallsignPopupCancel.Index = 9
        Me.mnuCallsignPopupCancel.Shortcut = CType(resources.GetObject("mnuCallsignPopupCancel.Shortcut"), System.Windows.Forms.Shortcut)
        Me.mnuCallsignPopupCancel.ShowShortcut = CType(resources.GetObject("mnuCallsignPopupCancel.ShowShortcut"), Boolean)
        Me.mnuCallsignPopupCancel.Text = resources.GetString("mnuCallsignPopupCancel.Text")
        Me.mnuCallsignPopupCancel.Visible = CType(resources.GetObject("mnuCallsignPopupCancel.Visible"), Boolean)
        '
        'tcpGPRSserver
        '
        Me.tcpGPRSserver.Editor = Me.tcpGPRSserver
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AccessibleDescription = resources.GetString("PrintPreviewDialog1.AccessibleDescription")
        Me.PrintPreviewDialog1.AccessibleName = resources.GetString("PrintPreviewDialog1.AccessibleName")
        Me.PrintPreviewDialog1.Anchor = CType(resources.GetObject("PrintPreviewDialog1.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.PrintPreviewDialog1.AutoScaleBaseSize = CType(resources.GetObject("PrintPreviewDialog1.AutoScaleBaseSize"), System.Drawing.Size)
        Me.PrintPreviewDialog1.AutoScroll = CType(resources.GetObject("PrintPreviewDialog1.AutoScroll"), Boolean)
        Me.PrintPreviewDialog1.AutoScrollMargin = CType(resources.GetObject("PrintPreviewDialog1.AutoScrollMargin"), System.Drawing.Size)
        Me.PrintPreviewDialog1.AutoScrollMinSize = CType(resources.GetObject("PrintPreviewDialog1.AutoScrollMinSize"), System.Drawing.Size)
        Me.PrintPreviewDialog1.BackgroundImage = CType(resources.GetObject("PrintPreviewDialog1.BackgroundImage"), System.Drawing.Image)
        Me.PrintPreviewDialog1.ClientSize = CType(resources.GetObject("PrintPreviewDialog1.ClientSize"), System.Drawing.Size)
        Me.PrintPreviewDialog1.Dock = CType(resources.GetObject("PrintPreviewDialog1.Dock"), System.Windows.Forms.DockStyle)
        Me.PrintPreviewDialog1.Enabled = CType(resources.GetObject("PrintPreviewDialog1.Enabled"), Boolean)
        Me.PrintPreviewDialog1.Font = CType(resources.GetObject("PrintPreviewDialog1.Font"), System.Drawing.Font)
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.ImeMode = CType(resources.GetObject("PrintPreviewDialog1.ImeMode"), System.Windows.Forms.ImeMode)
        Me.PrintPreviewDialog1.Location = CType(resources.GetObject("PrintPreviewDialog1.Location1"), System.Drawing.Point)
        Me.PrintPreviewDialog1.MaximumSize = CType(resources.GetObject("PrintPreviewDialog1.MaximumSize"), System.Drawing.Size)
        Me.PrintPreviewDialog1.MinimumSize = CType(resources.GetObject("PrintPreviewDialog1.MinimumSize"), System.Drawing.Size)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.RightToLeft = CType(resources.GetObject("PrintPreviewDialog1.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.PrintPreviewDialog1.StartPosition = CType(resources.GetObject("PrintPreviewDialog1.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.PrintPreviewDialog1.Text = resources.GetString("PrintPreviewDialog1.Text")
        Me.PrintPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.PrintPreviewDialog1.Visible = CType(resources.GetObject("PrintPreviewDialog1.Visible"), Boolean)
        '
        'tcpRealTrack
        '
        Me.tcpRealTrack.Editor = Me.tcpRealTrack
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = resources.GetString("OpenFileDialog1.Filter")
        Me.OpenFileDialog1.Title = resources.GetString("OpenFileDialog1.Title")
        '
        'frmmain
        '
        Me.AccessibleDescription = resources.GetString("$this.AccessibleDescription")
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.Controls.Add(Me.TabControl1)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.Menu = Me.MainMenu1
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "frmmain"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.TabControl1.ResumeLayout(False)
        Me.tabDisplayPositions.ResumeLayout(False)
        CType(Me.FpDevGuiDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpDevGuiDisplay_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxeWaypoint1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VideoPanel.ResumeLayout(False)
        Me.Group.ResumeLayout(False)
        Me.tabMessages.ResumeLayout(False)
        CType(Me.FpSpreadMessages, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpreadMessages_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAllPositions.ResumeLayout(False)
        CType(Me.FpDevGuiMaster, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpDevGuiMaster_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabCallsignTranslation.ResumeLayout(False)
        CType(Me.FpCallsignTranslation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpCallsignTranslation_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAPRSserver.ResumeLayout(False)
        CType(Me.FpTCPAPRSServerSpread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpTCPAPRSServerSpread_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabMonitor.ResumeLayout(False)
        Me.tabDevices.ResumeLayout(False)
        CType(Me.FpPortsCrosspoint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpPortsCrosspoint_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.tabLanguages.ResumeLayout(False)
        CType(Me.FpLanguages, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpLanguages_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    '    Delegate Sub DeviceDelegate(ByVal PortIn As Integer, ByVal Line As String)

    Public delay As Boolean = True
    Private mcolTCPAPRSServer As New Hashtable
    Private lckTCPAPRSServerSpread As New Object
    Private lckMcolTCPAPRSServer As New Object
    Public WeAreClosing As Boolean
    Private tcpAPRSServer_ListeningPort As Integer
    Private tcpAPRS_ListeningPort As Integer

    Private WithEvents devUIVIEW As UIView32.clsUIV

    Private boolInBuildString As Boolean
    Private tick = 0

    Public crosspoint As crosspoint

    Const tcpServerConnectionTextCount = 100
    Private tcpAPRS_InputText As String

    Const MaximumDevGuiMasterRows = 1000

    Private marData(1024) As Byte
    Private tcpAGWPEData(1024) As Byte

    Private tcpServerConnectionText(tcpServerConnectionTextCount) As String
    Private tcpServerConnectionTextStreams(tcpServerConnectionTextCount) As String

    Private tcpAGWPE_InputText As String

    Private portAGWPE As Integer
    Public devLog As devLog
    Private portLog As Integer
    Public devWeb As devWeb
    Public devOzi As devOzi
    Public devMapPoint As devMapPoint
    Public devTNC As devTNC
    Public portTNC As Integer
    Public portGui As Integer
    Private portAPRS As Integer
    Public portRINO As Integer
    Public devRINO As devRINO
    Public devDatabase As devDatabase
    Public portDatabase As Integer
    Public devDatabaseGui As devDatabaseGui
    Public portUIView As Integer
    Private frmSetup As frmSetup
    Public Language As String = "ENGLISH"
    Public portCamTrack As Integer


    Public devGPS As devGPS
    Public portGPS As Integer

    'Public devRealTrack As devRealTrack
    Dim portRealTrack As Integer


    Private WithEvents GPS As New Receiver

    Private myMOveWaypoint As MoveWaypoint

    Public Enum TCPAPRSServerConnections
        LocalPort = 0
        LocalAddress = 1
        RemotePort = 2
        RemoteAddress = 3
        StreamID = 4
        DataLine = 5
        User = 6

        LastRX = 7
        Driver = 8
        DriverID = 9
        Disconnect = 10
    End Enum

    Public Enum CallSignTranslations
        OldCallsign = 0
        NewCallsign = 1
    End Enum

#Region "Moving Map Ozi Callbacks"
    Declare Function oziSendMMpositionOFF Lib "oziapi" () As Integer
    Declare Function oziSendMMpositionON Lib "oziapi" (ByVal p As TMMpositionCallback) As Integer
    Delegate Sub TMMpositionCallback(ByVal Lat As Double, ByVal lon As Double, _
        ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)

    ' THIS ****MUST**** be Global because of GC bugs
    Public delTMMpositionCallback As TMMpositionCallback
#End Region




    Public setup As frmSetup.SetupStructure
#Region "Public Sub SetupLanguages(ByVal myform As String, ByVal language As String)"

    Public Sub SetupLanguages(ByVal myform As String, ByVal language As String)
        Dim i, j As Integer
        Dim t, s As String
        With FpLanguages.ActiveSheet
            If .RowCount > 250 Then .RowCount = 250
            For i = 0 To .RowCount - 1
                Select Case UCase(language)
                    Case "ENGLISH"
                        Exit Sub
                    Case "AUSSIE"
                        t = .Cells(i, 3).Text
                    Case "ITALIAN"
                        t = .Cells(i, 4).Text
                    Case "FRENCH"
                        t = .Cells(i, 5).Text
                    Case "ITALIAN"
                        t = .Cells(i, 3).Text
                    Case "ARAMAIC"
                        t = .Cells(i, 3).Text
                    Case Else
                        Exit Sub

                End Select


                s = .Cells(i, 1).Text

                If UCase(.Cells(i, 0).Text) = "MAIN" And myform = "" Then

                    Select Case s
                        Case "mnuFile"
                            mnuFile.Text = t
                            GoTo NextFor
                            GoTo NextFor
                        Case "mnuFileSetup"
                            mnuFileSetup.Text = t
                            GoTo NextFor
                        Case "mnuServices"
                            mnuServices.Text = t
                            GoTo NextFor
                        Case "mnuServAPRSserv"
                            mnuServAPRSServ.Text = t
                            GoTo NextFor
                        Case "mnuServAGWPE"
                            mnuServAGWPE.Text = t
                            GoTo NextFor
                        Case "mnuServTNC"
                            mnuServTNC.Text = t
                            GoTo NextFor
                        Case "mnuServGPS"
                            mnuServGPS.Text = t
                            GoTo NextFor
                        Case "mnuServWx"
                            mnuServWx.Text = t
                            GoTo NextFor
                        Case "mnuServRINO"
                            mnuServRINO.Text = t
                            GoTo NextFor
                        Case "mnuServData"
                            mnuServDatabase.Text = t
                            GoTo NextFor
                        Case "mnuServUIView"
                            mnuServUIView.Text = t
                            GoTo NextFor
                        Case "mnuServOzi"
                            mnuServOzi.Text = t
                            GoTo NextFor
                        Case "mnuServMapPoint"
                            mnuServMapPoint.Text = t
                            GoTo NextFor
                        Case "mnuServHub"
                            mnuServHub.Text = t
                            GoTo NextFor
                        Case "mnuServGPRS"
                            mnuServGPRS.Text = t
                            GoTo NextFor
                        Case "mnuServNetGPS"
                            mnuServNetGPS.Text = t
                            GoTo NextFor
                        Case "mnuServLog"
                            mnuServLog.Text = t
                            GoTo NextFor
                        Case "mnuGui"
                            mnuGui.Text = t
                            GoTo NextFor
                        Case "mnuGuiGeo"
                            mnuGuiGeo.Text = t
                            GoTo NextFor
                        Case "mnuGuiMonitored"
                            mnuGuiMonitored.Text = t
                            GoTo NextFor
                        Case "mnuGuiTranslate"
                            mnuGuiTranslate.Text = t
                            GoTo NextFor
                        Case "mnuGuiState"
                            mnuGuiState.Text = t
                            GoTo NextFor
                        Case "mnuGuiStateLoad"
                            mnuGuiStateLoad.Text = t
                            GoTo NextFor
                        Case "mnuGuiStateLoadFilename"
                            mnuGuiStateLoadFilename.Text = t
                            GoTo NextFor
                        Case "mnuGuiStateSave"
                            mnuGuiStateSave.Text = t
                            GoTo NextFor
                        Case "mnuGuiStateSaveFilename"
                            mnuGuiStateSaveFilename.Text = t
                            GoTo NextFor
                        Case "mnuGuiDatabase"
                            mnuGUIdatabase.Text = t
                            GoTo NextFor
                        Case "mnuInterfaces"
                            mnuInterfaces.Text = t
                            GoTo NextFor
                        Case "mnuInterfacesOziExplorer"
                            mnuInterfacesOziExplorer.Text = t
                            GoTo NextFor
                        Case "mnuInterfacesOziSync"
                            mnuInterfacesOziSync.Text = t
                            GoTo NextFor
                        Case "mnuInterfacesOziClear"
                            mnuInterfacesOziClear.Text = t
                            GoTo NextFor
                        Case "mnuInterfacesOziDecay"
                            mnuInterfaceOziDecay.Text = t
                            GoTo NextFor
                        Case "mnuInterfacesOziAutoTrail"
                            mnuInterfaceOziAutoTrail.Text = t
                            GoTo NextFor
                        Case "mnuHelp"
                            mnuHelp.Text = t
                            GoTo NextFor
                        Case "mnuHelpRegister"
                            mnuHelpRegister.Text = t
                            GoTo NextFor
                        Case "mnuHelpAbout"
                            mnuHelpAbout.Text = t
                        Case Else
                            MsgBox("Languages:MAIN: Could not find " & s & " :: " & t)
                    End Select
                End If
                If UCase(.Cells(i, 0).Text) = "MNUPOPUP" And myform = "" Then
                    Select Case s
                        Case "mnuPollNearby"
                            mnuPollNearby.Text = t
                        Case "mnuPopupAdd"
                            mnuPopupAdd.Text = t
                        Case "mnuPopupStationAdd"
                            mnuPopupAddStation.Text = t
                        Case "mnuPopupMove"
                            mnuPopupMove.Text = t
                        Case "mnuPopupFilter1"
                            mnuPopupFilter1.Text = t
                        Case "mnuPopupFilter2"
                            mnuPopupFilter2.Text = t
                        Case "mnuPopupCancel"
                            mnuPopupCancel.Text = t
                        Case Else
                            MsgBox("Languages:MNUPopup: Could not find " & s & " :: " & t)

                    End Select
                    GoTo NextFor
                End If

                If UCase(.Cells(i, 0).Text) = "MNUCALLSIGNPOPUP" And myform = "" Then
                    Select Case s
                        Case "mnuCallsign"
                            mnuCallsign.Text = t
                        Case "mnuCallsignPoll"
                            mnuCallsignPoll.Text = t
                        Case "mnuCallsignPopupQRZ"
                            mnuCallsignPopupQRZ.Text = t
                        Case "mnuCallsignPopupFindu"
                            mnuCallsignPopupFindU.Text = t
                        Case "mnuCallsignPopupDynamic"
                            mnuCallsignPopupDynamic.Text = t
                        Case "mnuCallsignPopupMessage"
                            mnuCallsignPopupMessage.Text = t
                        Case "mnuCallsignPopupCancel"
                            mnuCallsignPopupCancel.Text = t
                    End Select
                    GoTo NextFor
                End If

                If UCase(.Cells(i, 0).Text) = "MAINTAB" Then
                    Select Case s
                        Case "tabDisplayPositions"
                            tabDisplayPositions.Text = t
                            GoTo NextFor
                        Case "tabAllPositions"
                            tabAllPositions.Text = t
                            GoTo NextFor
                        Case "tabMessages"
                            tabMessages.Text = t
                            GoTo NextFor
                        Case "tabAPRSserver"
                            tabAPRSserver.Text = t
                            GoTo NextFor
                        Case "tabMonitor"
                            tabMonitor.Text = t
                            GoTo NextFor
                        Case "tabDevices"
                            tabDevices.Text = t
                            GoTo NextFor
                        Case "tabCallsignTranslation"
                            tabCallsignTranslation.Text = t
                        Case Else
                            MsgBox("Languages:MAINtab: Could not find " & s & " :: " & t)

                    End Select
                End If
                If UCase(.Cells(i, 0).Text) = "FPTCPAPRSSERVERSPREAD" And myform = "" Then
                    Select Case s
                        Case "LocalPort"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.LocalPort).Label = t
                            GoTo NextFor
                        Case "LocalAddress"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.LocalAddress).Label = t
                            GoTo NextFor
                        Case "RemotePort"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.RemoteAddress).Label = t
                            GoTo NextFor
                        Case "RemoteAddress"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.RemotePort).Label = t
                            GoTo NextFor
                        Case "StreamID"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.StreamID).Label = t
                            GoTo NextFor
                        Case "Dataline"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.DataLine).Label = t
                            GoTo NextFor
                        Case "user"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.User).Label = t
                            GoTo NextFor
                        Case "LastRX"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.LastRX).Label = t
                            GoTo NextFor
                        Case "Driver"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.Driver).Label = t
                            GoTo NextFor
                        Case "DriverID"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.DriverID).Label = t
                            GoTo NextFor
                        Case "Disconnect"
                            FpTCPAPRSServerSpread.ActiveSheet.ColumnHeader.Columns.Item(TCPAPRSServerConnections.Disconnect).Label = t
                        Case Else
                            MsgBox("Languages:TCPSERV: Could not find " & s & " :: " & t)

                    End Select
                End If
                If UCase(.Cells(i, 0).Text) = "FPCALLSIGNTRANSLATION" And myform = "" Then
                    Select Case s
                        Case "OldCallsign"
                            FpCallsignTranslation.ActiveSheet.ColumnHeader.Columns.Item(CallSignTranslations.OldCallsign).Label = t
                            GoTo NextFor
                        Case "NewCallsign"
                            FpCallsignTranslation.ActiveSheet.ColumnHeader.Columns.Item(CallSignTranslations.NewCallsign).Label = t
                        Case Else
                            MsgBox("Languages:CALLXLATE: Could not find " & s & " :: " & t)

                    End Select
                End If

                If UCase(.Cells(i, 0).Text) = "FPDEVGUIMASTER" Then
                    Select Case s
                        Case "scOziExplorerID"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scOziExplorerID).Label = t
                            GoTo NextFor
                        Case "scMonitor"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scMonitor).Label = t
                            GoTo NextFor
                        Case "scTrack"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scTrack).Label = t
                            GoTo NextFor
                        Case "scCallsign"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scCallsign).Label = t
                            GoTo NextFor
                        Case "scSymbol"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scSymbol).Label = t
                            GoTo NextFor
                        Case "scLat"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scLat).Label = t
                            GoTo NextFor
                        Case "scLon"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scLon).Label = t
                            GoTo NextFor
                        Case "scAlt"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scAlt).Label = t
                            GoTo NextFor
                        Case "scSpeed"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scSpeed).Label = t
                            GoTo NextFor
                        Case "scHeading"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scHeading).Label = t
                            GoTo NextFor
                        Case "scStatus"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scStatus).Label = t
                            GoTo NextFor
                        Case "scDescription"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scDescription).Label = t
                            GoTo NextFor
                        Case "scUpdated"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scUpdated).Label = t
                            GoTo NextFor
                        Case "scUpdatedRead"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scUpdatedReal).Label = t
                            GoTo NextFor
                        Case "scDataSource"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scDataSource).Label = t
                            GoTo NextFor
                        Case "scLine"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scLine).Label = t
                            GoTo NextFor
                        Case "scDetail"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scDetail).Label = t
                            GoTo NextFor
                        Case "scColor"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scColor).Label = t
                            GoTo NextFor
                        Case "scMapPointID"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scMapPointID).Label = t
                            GoTo NextFor
                        Case "scStale"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scStale).Label = t
                            GoTo NextFor
                        Case "scTrail"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scTrail).Label = t
                            GoTo NextFor
                        Case "scTrailNumber"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scTrailNumber).Label = t
                            GoTo NextFor
                        Case "scGPRMC"
                            FpDevGuiMaster.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiMasterCols.scGPRMC).Label = t
                        Case Else
                            MsgBox("Languages:GUIMASTER: Could not find " & s & " :: " & t)

                    End Select
                End If
                If UCase(.Cells(i, 0).Text) = "FPDEVGUI" And myform = "" Then
                    Select Case s
                        Case "Monitor"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Monitor).Label = t
                            GoTo NextFor
                        Case "Detail"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Detail).Label = t
                            GoTo NextFor
                        Case "Callsign"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Callsign).Label = t
                            GoTo NextFor
                        Case "Lat"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Lat).Label = t
                            GoTo NextFor
                        Case "Lon"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Lon).Label = t
                            GoTo NextFor
                        Case "Alt"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.Alt).Label = t
                            GoTo NextFor
                        Case "Spd"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.spd).Label = t
                            GoTo NextFor
                        Case "Heading"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.heading).Label = t
                            GoTo NextFor
                        Case "Time"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.time).Label = t
                            GoTo NextFor
                        Case "Track"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.track).Label = t
                            GoTo NextFor
                        Case "Trail"
                            FpDevGuiDisplay.ActiveSheet.ColumnHeader.Columns.Item(crosspoint.DevGuiCols.trail).Label = t
                        Case Else
                            MsgBox("Languages:DEVGUI: Could not find " & s & " :: " & t)

                    End Select
                End If
                If UCase(.Cells(i, 0).Text) = "FRMSETUP" And myform = "SETUP" Then
                    With frmSetup
                        Select Case s
                            Case "lblCallsign"
                                .lblCallsign.Text = t
                                GoTo NextFor
                            Case "lblCallsign"
                                .lblCallsign.Text = t
                                GoTo NextFor
                            Case "lblLat"
                                .lblLat.Text = t
                                GoTo NextFor
                            Case "lblLon"
                                .lblLon.Text = t
                                GoTo NextFor
                            Case "grpGPS"
                                .grpGPS.Text = t
                                GoTo NextFor
                            Case "lblGPSport"
                                .lblGPSport.Text = t
                                GoTo NextFor
                            Case "lblGPSspeed"
                                .lblGPSspeed.Text = t
                                GoTo NextFor
                            Case "chkLoopbackPos"
                                .chkLoopbackPos.Text = t
                                GoTo NextFor
                            Case "lblNetworkBeacon"
                                .lblNetworkBeacon.Text = t
                                GoTo NextFor
                            Case "lblRadioBeacon"
                                .lblRadioBeacon.Text = t
                                GoTo NextFor
                            Case "chkNMEAauto"
                                .chkNMEAauto.Text = t
                                GoTo NextFor
                            Case "grpOutgoing"
                                .gprOutgoing.Text = t
                                GoTo NextFor
                            Case "lblOutgoingServer"
                                .lblOutgoingServer.Text = t
                                GoTo NextFor
                            Case "lblLoginString"
                                .lblLoginString.Text = t
                                GoTo NextFor
                            Case "lblOnConnect"
                                .lblOnConnect.Text = t
                                GoTo NextFor
                            Case "chkAutoServerConnect"
                                .chkAutoServerConnect.Text = t
                                GoTo NextFor
                            Case "grpIncoming"
                                .grpIncoming.Text = t
                                GoTo NextFor
                            Case "chkHubDumpHistory"
                                .chkHubDumpHistory.Text = t
                                GoTo NextFor
                            Case "chkHubAutoListen"
                                .chkAutoHUBlisten.Text = t
                                GoTo NextFor
                            Case "chkAutoGPRSlisten"
                                .chkAutoGPRSListen.Text = t
                                GoTo NextFor
                            Case "chkAutoNetGPSListen"
                                .chkAutoNetGPSListen.Text = t
                                GoTo NextFor
                            Case "chkCallsignTranslation"
                                .chkCallsignTranslation.Text = t
                                GoTo NextFor
                            Case "lblTNCComPort"
                                .lblTNCComPort.Text = t
                                GoTo NextFor
                            Case "lblTNCspeed"
                                .lblTNCSpeed.Text = t
                                GoTo NextFor
                            Case "chkTNCKiss"
                                .chkTNCKiss.Text = t
                                GoTo NextFor
                            Case "chkTNCAuto"
                                .chkTNCAuto.Text = t
                                GoTo NextFor
                            Case "chkTNCMonitorOnly"
                                .chkTNCMonitorOnly.Text = t
                                GoTo NextFor
                            Case "chkAGWPEauto"
                                .chkAGWPEauto.Text = t
                                GoTo NextFor
                            Case "chkUploadDelay"
                                .chkUploadDelay.Text = t
                                GoTo NextFor
                            Case "grpRINO"
                                .grpRINO.Text = t
                                GoTo NextFor
                            Case "lblRINOcomport"
                                .lblRINOcomport.Text = t
                                GoTo NextFor
                            Case "chkRINOauto"
                                .chkRINOauto.Text = t
                                GoTo NextFor
                            Case "grpXML"
                                .grpXML.Text = t
                                GoTo NextFor
                            Case "chkXMLautoexport"
                                .chkXMLAutoExport.Text = t
                                GoTo NextFor
                            Case "lblXMLdirectory"
                                .lblXMLdirectory.Text = t
                                GoTo NextFor
                            Case "grpPrograms"
                                .grpPrograms.Text = t
                                GoTo NextFor
                            Case "chkInterfaceOziStartup"
                                .chkInterfaceOziStartup.Text = t
                                GoTo NextFor
                            Case "chkDecayAuto"
                                .ChkDecayAuto.Text = t
                                GoTo NextFor
                            Case "chkOziOnTop"
                                .chkOziOnTop.Text = t
                                GoTo NextFor
                            Case "chkOziTrail"
                                .chkOziTrail.Text = t
                                GoTo NextFor
                            Case "chkOziDownloadMypos"
                                .chkOziDownloadMyPos.Text = t
                                GoTo NextFor
                            Case "chkInterfaceMappointStartup"
                                .chkInterfaceMappointStartup.Text = t
                                GoTo NextFor
                            Case "chkInterfaceUIViewStartup"
                                .chkInterfaceUIViewStartup.Text = t
                                GoTo NextFor
                            Case "chkMonAuto"
                                .chkMonAuto.Text = t
                                GoTo NextFor
                            Case "chkGeoAuto"
                                .ChkGeoAuto.Text = t
                                GoTo NextFor
                            Case "chkStateSaveAuto"
                                .chkStateLoadAuto.Text = t
                                GoTo NextFor
                            Case "lblStateFilename"
                                .lblStateFilename.Text = t
                                GoTo NextFor
                            Case "chkStateLoadAuto"
                                .chkStateLoadAuto.Text = t
                                GoTo NextFor
                            Case "grpiGate"
                                .gpriGate.Text = t
                                GoTo NextFor
                            Case "lblRateLimit"
                                .lblRateLimit.Text = t
                                GoTo NextFor
                            Case "chkiGatePosRF"
                                .chkIGatePosRF.Text = t
                                GoTo NextFor
                            Case "chkIGateMsgRf"
                                .chkIGateMsgRF.Text = t
                                GoTo NextFor
                            Case "chkIGateObjRF"
                                .chkIGateObjRF.Text = t
                                GoTo NextFor
                            Case "chkIGateWxRf"
                                .chkIGateWxRF.Text = t
                                GoTo NextFor
                            Case "lbliGateTotalLimit"
                                .lbliGateTotalLimit.Text = t
                                GoTo NextFor
                            Case "grpDatabase"
                                .grpDatabase.Text = t
                                GoTo NextFor
                            Case "lblDatabaseFilename"
                                .lblDatabaseFilename.Text = t
                                GoTo NextFor
                            Case "chkDBConnectAuto"
                                .chkDBConnectAuto.Text = t
                            Case "lblLogFilename"
                                .lblLogFilename.Text = t
                            Case "chkLogAuto"
                                .chkLogAuto.Text = t
                            Case "lblIPAddress"
                                .lblIPaddress.Text = t
                            Case "lblIPPort"
                                .lblIPPort.Text = t
                            Case "lblServer1"
                                .lblServer1.Text = t
                            Case "lblServer2"
                                .lblServer2.Text = t
                            Case "lblAPN"
                                .lblAPN.Text = t
                            Case "lblRate"
                                .lblRateLimit.Text = t
                            Case "lblIGPRScom"
                                .lbliGPRSCom.Text = t
                                GoTo NextFor
                            Case "btnConfig"
                                .btnConfig.Text = t
                                GoTo NextFor
                            Case "btnReset"
                                .btnReset.Text = t
                                GoTo NextFor
                            Case "lblDigiPath"
                                .lblDigiPath.Text = t
                                GoTo NextFor
                            Case "lblSymbol"
                                .lblSymbol.Text = t
                                GoTo NextFor
                            Case "lblTable"
                                .lblTable.Text = t
                                GoTo NextFor
                            Case "lblAutoTXRate"
                                .lblAutoTXRate.Text = t
                                GoTo NextFor
                            Case "grpStatus"
                                .gprStatus.Text = t
                                GoTo NextFor
                            Case "lblStatusText"
                                .lblStatustext.Text = t
                                GoTo NextFor
                            Case "lblSendEvery"
                                .lblSendEvery.Text = t
                                GoTo NextFor
                            Case "chkSendSeperate"
                                .chkBCNSendSeperate.Text = t
                                GoTo NextFor
                            Case "chkTTValid"
                                .chkBCNValid.Text = t
                                GoTo NextFor
                            Case "chkTimestampDHM"
                                .chkBcnDHM.Text = t
                                GoTo NextFor
                            Case "chkTimestampHMS"
                                .chkBCNHMS.Text = t
                                GoTo NextFor
                            Case "chkAlternateDigis"
                                .chkBCNAltDigi.Text = t
                                GoTo NextFor
                            Case "chkSendAltitude"
                                .chkBCNSendAlt.Text = t
                                GoTo NextFor
                            Case "chkNMEASend"
                                .chkNMEASend.Text = t
                                GoTo NextFor
                            Case "grpMICE"
                                .grpMICE.Text = t
                                GoTo NextFor
                            Case "chkMICEEnable"
                                .chkMICEEnable.Text = t
                                GoTo NextFor
                            Case "chkMICEPrintable"
                                .chkMICEprintable.Text = t
                                GoTo NextFor
                            Case "lblMICEMessage"
                                .lblMICEMessage.Text = t
                                GoTo NextFor
                            Case "lblMICEPath"
                                .lblMICEPath.Text = t
                                GoTo NextFor
                            Case "grpSmartBeacon"
                                .grpSmartBeacon.Text = t
                                GoTo NextFor
                            Case "chkSmartEnable"
                                .chkSmartEnable.Text = t
                                GoTo NextFor
                            Case "lblMinTurnAngle"
                                .lblMinTurnAngle.Text = t
                                GoTo NextFor
                            Case "lblTurnSlope"
                                .lblTurnSlope.Text = t
                                GoTo NextFor
                            Case "lblMinTurnTime"
                                .lblTurnTime.Text = t
                                GoTo NextFor
                            Case "lblTurnSeconds"
                                .lblTurnSeconds.Text = t
                                GoTo NextFor
                            Case "lblSlowSpeed"
                                .lblSlowSpeed.Text = t
                                GoTo NextFor
                            Case "lblSlowRate"
                                .lblSlowRate.Text = t
                                GoTo NextFor
                            Case "lblFastSpeed"
                                .lblFastSpeed.Text = t
                                GoTo NextFor
                            Case "lblFastRate"
                                .lblFastRate.Text = t
                                GoTo NextFor
                            Case "lblFastRateSeconds"
                                .lblFastRateSeconds.Text = t
                                GoTo NextFor
                            Case "lblSlowRateSeconds"
                                .lblSlowRateSeconds.Text = t
                            Case Else
                                MsgBox("Languages:SETUP: Could not find " & s & " :: " & t)

                        End Select
                    End With
                End If
                If UCase(.Cells(i, 0).Text) = "DEVDATABASEGUI" And myform = "DATABASE" Then
                    With frmSetup
                        Select Case s
                            Case "lblDatabaseState"
                                devDatabaseGui.lblDatabaseState.Text = t
                                GoTo NextFor
                            Case "lblDatabaseStart"
                                devDatabaseGui.lblDatabaseStart.Text = t
                                GoTo NextFor
                            Case "lblDatabaseStop"
                                devDatabaseGui.lblDatabaseStop.Text = t
                                GoTo NextFor
                            Case "lblTrackStations"
                                devDatabaseGui.lblTrackStations.Text = t
                                GoTo NextFor
                            Case "cmdGrabLatestPositions"
                                devDatabaseGui.cmdGrabLatestPositions.Text = t
                                GoTo NextFor
                            Case "cmdTrackAll"
                                devDatabaseGui.cmdTrackAll.Text = t
                                GoTo NextFor
                            Case "cmdTrackCall"
                                devDatabaseGui.cmdTrackCall.Text = t
                                GoTo NextFor
                            Case "cmdGenList"
                                devDatabaseGui.cmdGenList.Text = t
                            Case Else
                                MsgBox("Languages:DBGUI: Could not find " & s & " :: " & t)

                        End Select
                    End With
                End If

NextFor:

            Next
        End With
    End Sub
#End Region



    Private Sub SetUpSpread()



        With FpTCPAPRSServerSpread.ActiveSheet
            .ColumnCount = 11
            .RowCount = 100 ' Yes, this is DUMB, but is needed
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.LocalPort).Label = "Local Port"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.LocalAddress).Label = "Local Address"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.RemotePort).Label = "Remote Port"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.RemoteAddress).Label = "Remote Address"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.StreamID).Label = "Stream ID"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.DataLine).Label = "DataLine"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.User).Label = "Callsign"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.LastRX).Label = "Last RX"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.DriverID).Label = "Driver ID"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.Driver).Label = "TYPE"
            .ColumnHeader.Columns.Item(TCPAPRSServerConnections.Disconnect).Label = "Disconnect"
            Dim objPlainCell As FarPoint.Win.spread.CellType.GeneralCellType

            .Columns(TCPAPRSServerConnections.LocalPort).CellType = objPlainCell
            .Columns(TCPAPRSServerConnections.RemotePort).CellType = objPlainCell
            .Columns(TCPAPRSServerConnections.StreamID).CellType = objPlainCell
            '            Dim objButtonCell As FarPoint.Win.spread.celltype.ButtonCellType
            '            .Columns(TCPAPRSServerConnections.StreamID).CellType = objButtonCell
        End With

        With FpCallsignTranslation.ActiveSheet
            .ColumnCount = 2
            .RowCount = 25
            .ColumnHeader.Columns.Item(CallSignTranslations.OldCallsign).Label = "From"
            .ColumnHeader.Columns.Item(CallSignTranslations.NewCallsign).Label = "To"


        End With


    End Sub


    Private Sub GetSettingsAndCommandLine()
        Dim data As String
        Dim datalength As Int32

        setup = getApplicationSettings()

        With setup
            If .boolOutgoingServerAutoConnect = True Then
                mnuServAPRSServ_Click(Nothing, Nothing)
            End If
            If .boolAGWPEAutoConnect = True Then
                mnuServAGWPE_Click(Nothing, Nothing)
            End If
            If .boolTNCAutoConnect = True Then
                mnuServTNC_Click(Nothing, Nothing)
            End If
            If .boolNMEAAutoStart = True Then
                mnuServGPS_Click(Nothing, Nothing)
            End If
            If .boolIncomingServerAutoStart = True Then
                mnuServHub_Click(Nothing, Nothing)
            End If
            If .boolIncomingGPRSAutoStart = True Then
                mnuServGPRS_Click(Nothing, Nothing)
            End If
            If .boolIncomingNetGPSAutoStart = True Then
                mnuServNetGPS_Click(Nothing, Nothing)
            End If
            If .boolDebugLogAutoStart = True Then
                mnuServLog_Click(Nothing, Nothing)
            End If
            If .boolDatabaseAutoStart = True Then
                mnuServDatabase_Click(Nothing, Nothing)
            End If
            If .boolInterfaceOziStartup = True Then
                mnuServOzi_Click(Nothing, Nothing)

            End If
            If .boolInterfaceMapPointStartup = True Then
                mnuServMapPoint_Click(Nothing, Nothing)
            End If
            If .boolInterfaceUIViewStartup = True Then
                mnuServUIView_Click(Nothing, Nothing)
            End If
            If .boolInterfaceOziDecay = True Then
                mnuInterfaceOziDecay_Click(Nothing, Nothing)
            End If
            If .boolInterfaceOziAutoTrailMoving = True Then
                mnuInterfaceOziAutoTrail_Click(Nothing, Nothing)
            End If
            If .boolRinoAutoStart = True Then
                mnuServRINO_Click(Nothing, Nothing)
            End If
            If .boolCallsignTranslate = True Then
                mnuGuiTranslate_Click(Nothing, Nothing)
            End If
            If .boolGeoFilterAutoStart = True Then
                mnuGuiGeo_Click(Nothing, Nothing)
            End If

            If .boolInterfaceOziGPS = True Then
                mnuInterfaceOziGetGPS_Click(Nothing, Nothing)
            End If


            mnuFile.Visible = .boolShowFile
            mnuFileSetup.Visible = .boolShowSetup
            mnuServices.Visible = .boolShowServices
            mnuGui.Visible = .boolShowGUI
            mnuHelp.Visible = .boolShowHelp
            mnuServTNC.Visible = .boolShowTNC
            mnuServGPS.Visible = .boolShowGPS
            mnuServWx.Visible = .boolShowWX
            mnuServRINO.Visible = .boolShowRINO
            mnuServLog.Visible = .boolShowLOG
            mnuServDatabase.Visible = .boolShowLogDatabase


            ' 3 x SPECIAL ONES
            mnuServNetGPS.Visible = .boolShowNetwork
            mnuServAPRSServ.Visible = .boolShowNetwork
            mnuServGPRS.Visible = .boolShowNetwork

            mnuServOzi.Visible = .boolShowOzi
            mnuServMapPoint.Visible = .boolShowMapPoint

            ' 2 x SPECIAL ONES
            mnuServAGWPE.Visible = .boolShowAGWPEUIVIEW
            mnuServUIView.Visible = .boolShowAGWPEUIVIEW

            ' 2 x Special ones
            mnuInterfacesOziSync.Visible = .boolShowOziSyncClear
            mnuInterfacesOziClear.Visible = .boolShowOziSyncClear

            mnuInterfaceOziDecay.Visible = .boolShowOziDecay
            mnuInterfaceOziAutoTrail.Visible = .boolShowOziAutotrail
            mnuGuiGeo.Visible = .boolShowGeoFilter
            mnuGUIdatabase.Visible = .boolShowDatabase
            mnuGuiMonitored.Visible = .boolShowUploadMonitored
            mnuGuiTranslate.Visible = .boolShowTranslated



        End With





    End Sub



    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim NewPort As Integer
        Dim i As Integer

        For i = 0 To tcpServerConnectionTextCount - 1
            tcpServerConnectionText(i) = "NULL"
        Next



        Dim frmSplash As New frmSplash(Me)

        frmSplash.Show()

        While delay = True
            Application.DoEvents()
        End While
        frmSplash.Close()

        crosspoint = New Crosspoint(PortsList, FpPortsCrosspoint, FpDevGuiMaster, FpDevGuiDisplay, Me)

        ' Enable the DEBUG device
        NewPort = crosspoint.NewPort(crosspoint.devices.devDEBUG, AddressOf crosspoint.DeviceDebug)
        crosspoint.CrosspointEnable(-1, NewPort, True)
        crosspoint.CrosspointEnable(NewPort, NewPort, False)

        ' Enable the Logging Device

        ' Enable the Monitor Device
        NewPort = crosspoint.NewPort(crosspoint.devices.devMonitor, AddressOf DevMonitor_SendOut)
        crosspoint.CrosspointEnable(-1, NewPort, True)
        crosspoint.CrosspointEnable(NewPort, NewPort, False)

        ' Enable the GUI Device
        crosspoint.DevGui_Init()
        portGui = crosspoint.NewPort(crosspoint.devices.devGUI, AddressOf crosspoint.DeviceGUI)
        crosspoint.CrosspointEnable(-1, portGui, True)
        'crosspoint.CrosspointEnable(NewPort, N, False) ' we want to see our own stuff 


        portCamTrack = crosspoint.NewPort(crosspoint.devices.devCamTrack, AddressOf DevCamtrack_SendOut)
        crosspoint.CrosspointEnable(-1, NewPort, True)
        crosspoint.CrosspointEnable(NewPort, NewPort, False)





        SetUpSpread()

        'devGuiMaster = New devOzi(FpDevOziMaster, MaximumDevOziRows)

        'crosspoint.devgui_startup(FpDevGuiMaster, MaximumDevGuiMasterRows)


        GetSettingsAndCommandLine()



        SetupLanguages(Nothing, setup.strLanguage)



        TabControl1.TabPages.Remove(tabLanguages)
        TabControl1.SelectedIndex = 0

        With cron
            .Interval = 500
            .Enabled = True
        End With

        '        devOzi.oziMapDblClickON(AddressOf MapDoubleClickCallback)




        SatelliteViewer1.Receiver = GPS



    End Sub





    Private Sub tcpAPRS_Start(ByVal server As String, ByVal port As Integer)


        portAPRS = crosspoint.NewPort(crosspoint.devices.devTCPAPRS, AddressOf tcpAPRS_SendOut)
        tcpAPRS_ListeningPort = portAPRS
        crosspoint.CrosspointEnable(-1, portAPRS, True)
        crosspoint.CrosspointEnable(portAPRS, portAPRS, False)


        tcpAPRS_Startup(server, port)

    End Sub



    Private Sub tcpAPRS_Stop()

        crosspoint.closePort(portAPRS)
        tcpAPRS.Close()

    End Sub

    Private Sub tcpAGWPE_Stop()

        crosspoint.closePort(portAGWPE)
        tcpAGWPE.Close()

    End Sub


    Function MapDoubleClickCallback(ByRef oType As String, ByVal X As Integer, ByVal Y As Integer, _
              ByVal lat As Double, ByVal lon As Double, _
          ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double) As Integer

        'MsgBox("Hello")

        '    oType = ConvertStr(oType) 'convert to VB format
        '    UTMzone = ConvertStr(UTMzone) 'convert to VB format

        '    'must do something with it
        '    'here we just show it in an edit box
        '    'MsgBox oType & Format(lat) & " " & Format(lon)


        If lat = 0 And lon = 0 Then
            Exit Function
        End If

        txtLat.Text = lat
        txtLon.Text = lon

        Dim points = New Point
        points = Cursor.Position


        mnuPopup.Show(Me, New Point(points.x - Left, points.y - Top - 100))
        'masterform.mnuPopup.Show(masterform, New Point(X - masterform.Left, Y - masterform.Top))
        'masterform.ContextMenu.Show(masterform.mnuPopup, New Point(X, Y))

        'masterform.mnupopup() 'popupmenu(masterform.mnuPopup)
        'treeView1.ContextMenu.Show(treeView1, New Point(e.X, e.Y))

        'popupmenu()


        '    frmMain.PopupMenu(frmMain.mnuPopup)




    End Function





    Private Sub tcpAGWPE_Startup(ByVal server As String, ByVal port As Integer)

        Dim message As String

        Static myserver As String
        Static myport As Integer

        If server <> "" Then
            myserver = server
            myport = port
        End If

        Dim junk As Integer
        With tcpAGWPE

            Try
                junk = .Stream.CanRead()

                If junk = False Then
                    Try
                        .ReceiveBufferSize = 1024
                        .Connect(myserver, myport)
                        .BeginReceive(tcpAGWPEData)
                        .Send(Realstrings(4, Chr(0)) & "m" & Realstrings(31, Chr(0)))

                        '                        Button1.Text = "Connected"
                    Catch ex2 As Exception

                    End Try
                Else
                    '.Send(strings(4, Chr(0)) & "m" & strings(31, Chr(0)))
                End If

            Catch ex As Exception
                If .Stream Is Nothing Then
                Else
                    .Close()
                End If
            End Try
        End With


    End Sub


    Private Sub tcpAPRS_Startup(ByVal server As String, ByVal port As Integer)

        Dim message As String
        Static myserver As String
        Static myport As Integer

        If server <> "" Then
            myserver = server
            myport = port
        End If

        Dim junk As Integer
        With tcpAPRS

            Try
                junk = .Stream.CanRead()

                If junk = False Then
                    Try
                        .ReceiveBufferSize = 1024
                        .Connect(myserver, myport)
                        .BeginReceive(marData)
                        '                        Button1.Text = "Connected"
                    Catch ex2 As Exception

                    End Try

                End If

            Catch ex As Exception
                If .Stream Is Nothing Then
                Else
                    .Close()
                End If
            End Try
        End With


    End Sub

    Private Sub tcpAPRS_ReceiveLines(ByVal sender As Object, ByVal e As Dart.PowerTCP.Sockets.SegmentEventArgs) _
        Handles tcpAPRS.EndReceive



        If e.Exception Is Nothing Then

            tcpAPRS_InputText = tcpAPRS_InputText & e.Segment.ToString()
        End If

        'If tcpAPRS.Stream.CanRead Then
        '    tcpAPRS.BeginReceive(marData)
        'End If


    End Sub
    Private Sub tcpAGWPE_BuildString()


        Dim i As Integer
        Dim strdata As String
        Static strAll As String
        Dim finger As Integer

        Dim finger2 As Integer


        If Len(tcpAGWPE_InputText) = 0 Then

            Exit Sub
        End If

        strAll = strAll & tcpAGWPE_InputText
        tcpAGWPE_InputText = ""

        If Mid(strAll, 5, 1) = "U" Then
            strAll = Mid(mytrim(Mid(strAll, 37)), 7)
            '    MsgBox strAll
            finger = InStr(1, strAll, " To ")
            strAll = Mid(strAll, 1, finger - 1) & ">" & Mid(strAll, finger + 4)
            finger = InStr(1, strAll, " Via ")
            If finger > 0 Then
                strAll = Mid(strAll, 1, finger - 1) & "," & Mid(strAll, finger + 5)
            End If
            finger = InStr(1, strAll, " <")
            finger2 = InStr(1, strAll, "]")
            ' was + 2 instead of +8 on the next line
            strAll = Mid(strAll, 1, finger - 1) & ":" & Mid(strAll, finger2 + 8)
            strAll = Mid(strAll, 1, Len(strAll) - 2)

            crosspoint.Submit(portAGWPE, strAll)


            'If Processline(strAll, "AGWPE") = True Then
            '    oziTCP(strAll, 3, -1)
            'End If

            strdata = ""
            strAll = ""
            Exit Sub

        End If
        strdata = ""
        strAll = ""

    End Sub


    Private Sub tcpAPRS_BuildString()
        Dim intIndex As Integer
        Dim junk As String
        Dim i As Integer
        Dim j As Integer

        boolInBuildString = True

        If Len(tcpAPRS_InputText) > 10240 Then
            tcpAPRS_InputText = 10240
        End If

        '        While Len(tcpAPRS_InputText) > 0
        While InStr(tcpAPRS_InputText, Chr(13)) > 0 Or InStr(tcpAPRS_InputText, Chr(10)) > 0
            Application.DoEvents()


            StatusBar1.Text = Format(Len(tcpAPRS_InputText))

            i = InStr(tcpAPRS_InputText, Chr(13))
            j = InStr(tcpAPRS_InputText, Chr(10))

            If i = 0 Then
                i = j + 1
            End If
            If j = 0 Then
                j = i + 1
            End If

            If i > j Then
                i = j
            Else
                i = i
            End If

            If i > 1 Then
                junk = Mid(tcpAPRS_InputText, 1, i - 1)
            Else
                junk = Mid(tcpAPRS_InputText, 2)
            End If
            If Len(tcpAPRS_InputText) > i + 1 Then
                tcpAPRS_InputText = Mid(tcpAPRS_InputText, i + 1)
            Else
                tcpAPRS_InputText = ""
            End If

            If Len(junk) > 5 Then
                crosspoint.Submit(tcpAPRS_ListeningPort, junk)
            End If
ExitSub:
        End While
        boolInBuildString = False
    End Sub
    Private Function tcpAGWPE_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)

        'Try
        '    tcpAPRS.Send(Line & vbCrLf)
        'Catch ex As Exception
        'End Try

    End Function




    Private Function tcpAPRS_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)

        Dim i As Integer

        Dim d As DictionaryEntry
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs

        If WeAreClosing Then Exit Function

        Dim IncomingPort As Integer

        With FpTCPAPRSServerSpread.ActiveSheet
            For i = 0 To .RowCount - 1
                IncomingPort = Val(.Cells(i, TCPAPRSServerConnections.LocalPort).Text)
                If setup.intIncomingHubport = IncomingPort Then
                    For Each d In mcolTCPAPRSServer
                        If d.Key = .Cells(i, TCPAPRSServerConnections.StreamID).Text Then
                            objClient = d.Value
                            If objClient.Tcp.Stream.CanWrite = True Then
                                objClient.Tcp.Send(Line & vbCrLf)
                            End If
                        End If
                    Next
                End If
            Next i
        End With


    End Function


    Private Function DevMonitor_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)

        With devMonitor
            If Val(.Tag) < 1 Then .Tag = "20"
            While .Items.Count >= .Tag
                .Items.RemoveAt(0)
            End While
            .Items.Add("::" & Format(PortIn) & "::" & Format(Line))

        End With
    End Function

    Private Function DevUIView_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)

    End Function



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        crosspoint.Submit(0, "THIS IS A TEST")

    End Sub

    Private Sub tcpserver_start()
        Dim NewPort As Integer

        NewPort = crosspoint.NewPort(crosspoint.devices.devTCPAPRSSERV, AddressOf tcpserver_SendOut)
        tcpAPRSServer_ListeningPort = NewPort

        crosspoint.CrosspointEnable(-1, NewPort, True)
        crosspoint.CrosspointEnable(NewPort, NewPort, False)

    End Sub


    Private Sub tcpGPRSServer_Start(ByVal tcpPort As Integer)
        Dim i As Integer

        ' Enable the Logging Device
        If mnuServHub.Checked = False Then
            tcpserver_start()
        End If
        tcpGPRSserver.Listen(tcpPort)
    End Sub


    Private Sub tcpAPRSServer_Start(ByVal tcpPort As Integer)
        Dim i As Integer

        ' Enable the Logging Device
        If mnuServGPRS.Checked = False Then
            tcpserver_start()
        End If
        tcpAPRSServer.Listen(tcpPort)
    End Sub

    Private Sub tcpAPRSServer_Stop()
        tcpAPRSServer.Close()
    End Sub

    Private Sub tcpGPRSServer_Stop()
        tcpAPRSServer.Close()
    End Sub


    Private Function tcpserver_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded) As Object
        Dim d As DictionaryEntry
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs

        If WeAreClosing Then Exit Function

        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                objClient = d.Value
                'Dont send out this port if it is an incoming only port
                'TODO: Implement directed return packets
                If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> setup.intIncomingGPRSport And objClient.Tcp.LocalEndPoint.Port <> 1596 Then
                    objClient.Tcp.Stream.Write(Line.ToString & vbCrLf)
                End If
            Next
        End SyncLock

    End Function

    Private Sub tcpServer_Listening(ByVal sender As System.Object, ByVal e As Dart.PowerTCP.Sockets.ConnectionEventArgs) Handles tcpAPRSServer.Connection, tcpGPRSserver.Connection

        Dim i As Integer

        Dim found As Boolean = False
        Dim StreamID As String
        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                i = findnewconnectionsrow()
                .Cells(i, TCPAPRSServerConnections.LocalPort).Text = e.Tcp.LocalEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.LocalAddress).Text = e.Tcp.LocalEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.RemotePort).Text = e.Tcp.RemoteEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.RemoteAddress).Text = e.Tcp.RemoteEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.StreamID).Text = e.Tcp.Socket.Handle.ToString
                StreamID = e.Tcp.Socket.Handle.ToString
                .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
            End With
        End SyncLock
        e.Tcp.SendTimeout = 250

        SyncLock lckMcolTCPAPRSServer
            mcolTCPAPRSServer.Add(StreamID, e)
            For i = 0 To tcpServerConnectionTextCount - 1
                If tcpServerConnectionText(i) = "NULL" Then
                    tcpServerConnectionText(i) = ""
                    tcpServerConnectionTextStreams(i) = StreamID
                    Exit For
                End If
            Next
        End SyncLock

        'If e.Tcp.LocalEndPoint.Port = 5001 Then
        '    Try
        '        e.Tcp.Stream.Write(MessageQueue.GetLatestPositions())
        '    Catch ex As Exception

        '    End Try
        'End If

        Dim s As String
        Do While (e.Tcp.Connected)
            Try
                s = e.Tcp.Stream.Read(vbCr, 256, found)
            Catch ex As Exception

            End Try
            s = s & ""
            's = s.Trim()
            s = s.Replace(vbCr, "")
            s = s.Replace(vbLf, "")

tryagain:

            SyncLock lckMcolTCPAPRSServer
                tcpServerConnectionText(GetIndexfromStreamID(StreamID)) &= s & vbCr
            End SyncLock


            s = ""

        Loop

WeAreClosingTheConnectionNow:

        '        UpdateStatus("Disconnected - " & fpspreadtcpAPRSServerConnections.ActiveSheet.Cells(i, TCPAPRSServerConnections.LocalPort).Text)
        SyncLock lckMcolTCPAPRSServer
            ' SyncLock mcolText.SyncRoot
            mcolTCPAPRSServer.Remove(StreamID)

            tcpServerConnectionText(GetIndexfromStreamID(StreamID)) = "NULL"
            tcpServerConnectionTextStreams(GetIndexfromStreamID(StreamID)) = ""
            mcolTCPAPRSServer.Remove(StreamID)
            ' End SyncLock
        End SyncLock


        If WeAreClosing Then Exit Sub

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                For i = 0 To .RowCount - 1
                    If .RowCount > -1 Then
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = StreamID Then
                            Dim j As Integer
                            For j = 0 To .ColumnCount - 2
                                .Cells(i, j).Text = ""
                            Next
                            Exit For
                        End If
                    End If
                Next i
            End With
        End SyncLock

    End Sub
    Private Function tcpRealTrack_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded) As Object
        Dim d As DictionaryEntry
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs

        If WeAreClosing Then Exit Function

        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                objClient = d.Value
                'Dont send out this port if it is an incoming only port
                'TODO: Implement directed return packets
                If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> setup.intIncomingGPRSport Then
                    objClient.Tcp.Stream.Write(Line.ToString & vbCrLf)
                End If
            Next
        End SyncLock

    End Function


    Private Sub tcpRealtrack_Listening(ByVal sender As System.Object, ByVal e As Dart.PowerTCP.Sockets.ConnectionEventArgs) Handles tcpRealTrack.Connection

        Dim i As Integer

        Dim found As Boolean = False
        Dim StreamID As String
        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                i = findnewconnectionsrow()
                .Cells(i, TCPAPRSServerConnections.LocalPort).Text = e.Tcp.LocalEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.LocalAddress).Text = e.Tcp.LocalEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.RemotePort).Text = e.Tcp.RemoteEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.RemoteAddress).Text = e.Tcp.RemoteEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.StreamID).Text = e.Tcp.Socket.Handle.ToString
                StreamID = e.Tcp.Socket.Handle.ToString
                .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
            End With
        End SyncLock
        e.Tcp.SendTimeout = 250

        SyncLock lckMcolTCPAPRSServer
            mcolTCPAPRSServer.Add(StreamID, e)
            For i = 0 To tcpServerConnectionTextCount - 1
                If tcpServerConnectionText(i) = "NULL" Then
                    tcpServerConnectionText(i) = ""
                    tcpServerConnectionTextStreams(i) = StreamID
                    Exit For
                End If
            Next
        End SyncLock

        'If e.Tcp.LocalEndPoint.Port = 5001 Then
        '    Try
        '        e.Tcp.Stream.Write(MessageQueue.GetLatestPositions())
        '    Catch ex As Exception

        '    End Try
        'End If

        Dim s As String
        DirectedSendOut(StreamID, "$id#")
        Do While (e.Tcp.Connected)
            Try
                s = e.Tcp.Stream.Read("#", 128, found)
            Catch ex As Exception

            End Try
            s = s & ""
            's = s.Trim()
            s = s.Replace(vbCr, "")
            s = s.Replace(vbLf, "")

tryagain:

            SyncLock lckMcolTCPAPRSServer
                tcpServerConnectionText(GetIndexfromStreamID(StreamID)) &= s & vbCr
            End SyncLock


            s = ""

        Loop

WeAreClosingTheConnectionNow:

        '        UpdateStatus("Disconnected - " & fpspreadtcpAPRSServerConnections.ActiveSheet.Cells(i, TCPAPRSServerConnections.LocalPort).Text)
        SyncLock lckMcolTCPAPRSServer
            ' SyncLock mcolText.SyncRoot
            mcolTCPAPRSServer.Remove(StreamID)

            tcpServerConnectionText(GetIndexfromStreamID(StreamID)) = "NULL"
            tcpServerConnectionTextStreams(GetIndexfromStreamID(StreamID)) = ""
            mcolTCPAPRSServer.Remove(StreamID)
            ' End SyncLock
        End SyncLock


        If WeAreClosing Then Exit Sub

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                For i = 0 To .RowCount - 1
                    If .RowCount > -1 Then
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = StreamID Then
                            Dim j As Integer
                            For j = 0 To .ColumnCount - 2
                                .Cells(i, j).Text = ""
                            Next
                            Exit For
                        End If
                    End If
                Next i
            End With
        End SyncLock

    End Sub



    Private Function GetIndexfromStreamID(ByVal StreamID As String) As Integer
        Dim i As Integer

        For i = 0 To tcpServerConnectionTextCount - 1
            If tcpServerConnectionTextStreams(i) = StreamID Then
                Return i
            End If
        Next



    End Function


    Private Function findnewconnectionsrow()
        Dim i As Integer
        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                For i = 0 To .RowCount - 1
                    If .Cells(i, TCPAPRSServerConnections.LocalAddress).Text = "" Then
                        Return i
                    End If
                Next
            End With
        End SyncLock
        MsgBox("Please contact Radioactive Networks for more licenses")
        Return 0
    End Function


    Private Sub OnNet960Received(ByVal senderID As String, ByVal Data As String)
        Console.WriteLine("OnNet960Received " & Data)


        Dim temp As String
        Dim strIMEI As String
        Dim i As Integer
        Dim strID As String = ""

        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry

        Dim gprs As Boolean = False


        If Mid(Data, 1, 9) = "#CONNECT," Then
            strID = Mid(Data, 10)
            strID = Mid(strID, 1, 15)
            gprs = True
            GoTo FoundAddress
        End If



        If Mid(Data, 1, 5) = "#MSG," Then
            Data = Mid(Data, 6)
        End If

        If Data.Length > 180 And (InStr(7, Data, ">") - 6) > 0 Then
            Data = Mid(Data, InStr(7, Data, ">") - 6)
        End If


        If Data.Length <= 10 Then Exit Sub
        '        UpdateStatus("Line:" & Data)


        If InStr(Data, ">") < 20 And InStr(Data, ">") > 1 Then
            strID = Mid(Data, 1, InStr(Data, ">") - 1)
        End If






FoundAddress:
        Dim strCallsign As String
        strCallsign = strID
        'Dim mymessagequeue As New MessageQueue(fpOutgoingMessageQueue, dgdUsers, dgdVehicles, FpPositions, fpSpreadConnections, Me)

        'UpdateStatus("Callsign:" & strCallsign)


        'Try





        Dim DriverID As Integer

        Dim TempCallsign As String

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If .RowCount > 0 Then
                    For i = 0 To .RowCount - 1
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = senderID Then
                            'UpdateStatus("Found the senderid of :" & senderID)
                            .Cells(i, TCPAPRSServerConnections.DataLine).Text = Data
                            If strCallsign <> "" Then
                                .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign
                            Else
                                strCallsign = .Cells(i, TCPAPRSServerConnections.User).Text
                            End If
                            If gprs Then
                                .Cells(i, TCPAPRSServerConnections.Driver).Text = "GPRS"
                            End If
                            .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
                            If strCallsign.Length < 2 Then
                                GoTo NoGood
                            End If
                            If Mid(Data, 1, 3) = "#GP" Then
                                Data = "$GP" & Mid(Data, 4)
                            End If
                            If InStr(Data, ">") > 0 Then
                                Data = strCallsign & Data.Substring(Data.IndexOf(">"))
                            Else
                                Data = strCallsign & ">APRS:" & Data
                            End If


                            If mnuGuiTranslate.Checked = True Then
                                Data = CallsignTranslate(strCallsign) & Data.Substring(Data.IndexOf(">"))
                            End If

                            crosspoint.Submit(tcpAPRSServer_ListeningPort, Data.ToString)
                            GoTo resumehere
                        End If
                    Next i


                End If

            End With


        End SyncLock


resumehere:

        If Len(FpTCPAPRSServerSpread.ActiveSheet.Cells(i, TCPAPRSServerConnections.Driver).Text) > 0 Then

            SyncLock lckTCPAPRSServerSpread
                With FpTCPAPRSServerSpread.ActiveSheet
                    If .RowCount > 0 Then
                        For i = 0 To .RowCount - 1


                            If .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign And Len(.Cells(i, TCPAPRSServerConnections.User).Text) > 0 And Len(strCallsign) > 0 Then
                                If .Cells(i, TCPAPRSServerConnections.StreamID).Text <> senderID Then
                                    SyncLock lckMcolTCPAPRSServer
                                        For Each d In mcolTCPAPRSServer

                                            If d.Key = .Cells(i, TCPAPRSServerConnections.StreamID).Text Then
                                                d.Value.tcp.close()
                                            End If
                                        Next
                                    End SyncLock
                                End If
                            End If
                        Next i
                    End If
                End With
            End SyncLock
        End If

        If Len(Data) = 0 Then Exit Sub

        If Mid(Data, 1, 1) = "#" Or Mid(Data, 1, 5) = "$IMEI" Then
            Exit Sub
        End If
        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                If d.Key <> senderID Then
                    objClient = d.Value
                    If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> setup.intIncomingGPRSport Then
                        If (InStr(Data, ">") > 0 And InStr(Data, ">") <> 0) Then
                            objClient.Tcp.Stream.Write(Data.ToString & vbCrLf)
                        Else
                            objClient.Tcp.Stream.Write(strCallsign & ">APRS:" & Data.ToString & vbCrLf)
                        End If
                    End If
                End If
            Next
        End SyncLock
NoGood:


    End Sub
    Private Sub OnHubReceived(ByVal senderID As String, ByVal Data As String)
        Console.WriteLine("OnNet960Received " & Data)


        Dim temp As String
        Dim strIMEI As String
        Dim i As Integer
        Dim strID As String = ""
        Dim gprs As Boolean = False


        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry

        If Mid(Data, 1, 9) = "#CONNECT," Then
            strID = Mid(Data, 10)
            strID = Mid(strID, 1, 15)
            gprs = True
            GoTo FoundAddress
        End If



        If Mid(Data, 1, 5) = "#MSG," Then
            Data = Mid(Data, 6)
        End If

        If Data.Length > 180 Then
            Data = Mid(Data, InStr(7, Data, ">") - 6)
        End If


        If Data.Length <= 10 Then Exit Sub
        '        UpdateStatus("Line:" & Data)


        If InStr(Data, ">") < 20 And InStr(Data, ">") > 1 Then
            strID = Mid(Data, 1, InStr(Data, ">") - 1)
        End If






FoundAddress:
        Dim strCallsign As String
        strCallsign = strID
        'Dim mymessagequeue As New MessageQueue(fpOutgoingMessageQueue, dgdUsers, dgdVehicles, FpPositions, fpSpreadConnections, Me)

        'UpdateStatus("Callsign:" & strCallsign)


        'Try

        Dim DriverID As Integer

        Dim TempCallsign As String

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If .RowCount > 0 Then
                    For i = 0 To .RowCount - 1
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = senderID Then
                            'UpdateStatus("Found the senderid of :" & senderID)
                            .Cells(i, TCPAPRSServerConnections.DataLine).Text = Data
                            If strCallsign <> "" Then
                                .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign
                            Else
                                strCallsign = .Cells(i, TCPAPRSServerConnections.User).Text
                            End If
                            If gprs Then
                                .Cells(i, TCPAPRSServerConnections.Driver).Text = "GPRS"
                            End If
                            .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
                            If strCallsign.Length < 2 Then
                                GoTo NoGood
                            End If
                            If Mid(Data, 1, 3) = "#GP" Then
                                Data = "$GP" & Mid(Data, 4)
                            End If
                            If InStr(Data, ">") > 0 Then
                                Data = strCallsign & Data.Substring(Data.IndexOf(">"))
                            Else
                                Data = strCallsign & ">APRS:" & Data
                            End If

                            If mnuGuiTranslate.Checked = True Then
                                Data = CallsignTranslate(strCallsign) & Data.Substring(Data.IndexOf(">"))
                            End If


                            crosspoint.Submit(tcpAPRSServer_ListeningPort, Data.ToString)
                            GoTo resumehere
                        End If
                    Next i


                End If

            End With


        End SyncLock


resumehere:



        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If Len(.Cells(i, TCPAPRSServerConnections.Driver).Text) > 0 Then
                    If .RowCount > 0 Then
                        For i = 0 To .RowCount - 1


                            If .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign And Len(.Cells(i, TCPAPRSServerConnections.User).Text) > 0 And Len(strCallsign) > 0 Then
                                If .Cells(i, TCPAPRSServerConnections.StreamID).Text <> senderID Then
                                    SyncLock lckMcolTCPAPRSServer
                                        For Each d In mcolTCPAPRSServer

                                            If d.Key = .Cells(i, TCPAPRSServerConnections.StreamID).Text Then
                                                d.Value.tcp.close()
                                            End If
                                        Next
                                    End SyncLock
                                End If
                            End If
                        Next i
                    End If
                End If
            End With
        End SyncLock


        If Len(Data) = 0 Then Exit Sub

        If Mid(Data, 1, 1) = "#" Or Mid(Data, 1, 5) = "$IMEI" Then
            Exit Sub
        End If
        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                If d.Key <> senderID Then
                    objClient = d.Value
                    If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> setup.intIncomingGPRSport Then
                        If (InStr(Data, ">") > 0 And InStr(Data, ">") <> 0) Then
                            objClient.Tcp.Stream.Write(Data.ToString & vbCrLf)
                        Else
                            objClient.Tcp.Stream.Write(strCallsign & ">APRS:" & Data.ToString & vbCrLf)
                        End If
                    End If
                End If
            Next
        End SyncLock
NoGood:


    End Sub

    Private Sub DirectedSendOut(ByVal SenderID As String, ByVal data As String)
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry


        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                If d.Key = SenderID Then
                    objClient = d.Value
                    If objClient.Tcp.Stream.CanWrite = True Then
                        objClient.Tcp.Stream.Write(data.ToString)
                    End If
                End If
            Next
        End SyncLock

    End Sub


    Private Sub tcprealtrack_poll()
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry


        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                objClient = d.Value
                If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port = 1596 Then
                    objClient.Tcp.Stream.Write("$!#")
                End If

            Next
        End SyncLock

    End Sub



    Private Sub OnRealTrackReceived(ByVal senderID As String, ByVal Data As String)
        Console.WriteLine("OnNet960Received " & Data)


        Dim temp As String
        Dim strIMEI As String
        Dim i As Integer
        Dim strID As String = ""
        Dim gprs As Boolean = False


        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry


        If InStr(Data, "#") = 0 Then
            GoTo NoGood
        End If
        If Mid(Data, 1, 4) = "$ID," Then
            strID = Mid(Data, 5)
            strID = Mid(strID, 1, InStr(strID, "#") - 1)
            DirectedSendOut(senderID, "$ok#")
            GoTo FoundAddress
        End If

        If Mid(Data, 1, 4) = "$CE," Then
            temp = Mid(Data, 5)
            temp = Mid(temp, 1, InStr(temp, "#") - 1)
            'DirectedSendOut(senderID, "$!#")
            GoTo FoundAddress
        End If

        If Mid(Data, 1, 5) = "$MSG," Then
            strID = Mid(Data, 6)
            strID = Mid(strID, 1, InStr(strID, "#") - 1)
            gprs = True
            'DirectedSendOut(senderID, "$!#")
            GoTo FoundAddress
        End If




FoundAddress:
        Dim strCallsign As String
        strCallsign = strID

        Dim TempCallsign As String

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If .RowCount > 0 Then
                    For i = 0 To .RowCount - 1
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = senderID Then
                            'UpdateStatus("Found the senderid of :" & senderID)
                            .Cells(i, TCPAPRSServerConnections.DataLine).Text = Data
                            If strCallsign <> "" Then
                                .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign
                            Else
                                strCallsign = .Cells(i, TCPAPRSServerConnections.User).Text
                            End If

                            .Cells(i, TCPAPRSServerConnections.Driver).Text = "REALTRACK"

                            .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
                            If strCallsign.Length < 2 Then
                                GoTo NoGood
                            End If

                            'If mnuGuiTranslate.Checked = True Then
                            '    Data = CallsignTranslate(strCallsign) & Data.Substring(Data.IndexOf(">"))
                            'End If


                            crosspoint.Submit(tcpAPRSServer_ListeningPort, Data.ToString)
                            GoTo resumehere
                        End If
                    Next i


                End If

            End With


        End SyncLock


resumehere:



        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If Len(.Cells(i, TCPAPRSServerConnections.Driver).Text) > 0 Then
                    If .RowCount > 0 Then
                        For i = 0 To .RowCount - 1


                            If .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign And Len(.Cells(i, TCPAPRSServerConnections.User).Text) > 0 And Len(strCallsign) > 0 Then
                                If .Cells(i, TCPAPRSServerConnections.StreamID).Text <> senderID Then
                                    SyncLock lckMcolTCPAPRSServer
                                        For Each d In mcolTCPAPRSServer

                                            If d.Key = .Cells(i, TCPAPRSServerConnections.StreamID).Text Then
                                                d.Value.tcp.close()
                                            End If
                                        Next
                                    End SyncLock
                                End If
                            End If
                        Next i
                    End If
                End If
            End With
        End SyncLock


        If Len(Data) = 0 Then Exit Sub

        If Mid(Data, 1, 1) = "#" Or Mid(Data, 1, 5) = "$IMEI" Then
            Exit Sub
        End If
        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                If d.Key <> senderID Then
                    objClient = d.Value
                    If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> setup.intIncomingGPRSport Then
                        If (InStr(Data, ">") > 0 And InStr(Data, ">") <> 0) Then
                            objClient.Tcp.Stream.Write(Data.ToString & vbCrLf)
                        Else
                            objClient.Tcp.Stream.Write(strCallsign & ">APRS:" & Data.ToString & vbCrLf)
                        End If
                    End If
                End If
            Next
        End SyncLock
NoGood:


    End Sub



    Private Sub Tick_Process()
        Dim d As IDictionaryEnumerator = mcolTCPAPRSServer.GetEnumerator

        Dim key As Object
        Dim value As String
        Dim port As Integer

        Dim i As Integer

        Dim j As Integer
        SyncLock mcolTCPAPRSServer
            For j = 0 To tcpServerConnectionTextCount - 1
                key = tcpServerConnectionTextStreams(j)
                value = tcpServerConnectionText(j)
                If value = "NULL" Or key = "" Then GoTo endfor

                port = mcolTCPAPRSServer.Item(key).Tcp.LocalEndPoint.Port()


                Select Case port
                    Case 1596
                        If InStr(value, "#") > 0 Then
                            OnRealTrackReceived(key, value)
                            tcpServerConnectionText(j) = ""
                        End If
                    Case setup.intIncomingHubport, setup.intIncomingGPRSport
                        While InStr(value, vbCr) > 0
                            i = InStr(value, vbCr)
                            If i > 1 Then
                                Select Case mcolTCPAPRSServer.Item(key).Tcp.LocalEndPoint.Port()
                                    Case setup.intIncomingHubport
                                        OnHubReceived(key, Mid(value, 1, i - 1))
                                    Case setup.intIncomingGPRSport
                                        OnNet960Received(key, Mid(value, 1, i - 1))
                                    Case 1596
                                        'OnRealTrackReceived(key, Mid(value, 1, i - 1))
                                End Select
                            End If
                            If Len(value) > i + 1 Then
                                value = Mid(value, i + 1)
                            Else
                                value = ""
                            End If
                            tcpServerConnectionText(j) = value
                        End While
                End Select

endfor:
            Next
        End SyncLock



    End Sub

    Private Sub cron_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cron.Tick

        tick += 1

        Tick_Process()
        tcpAPRS_BuildString()
        tcpAGWPE_BuildString()
        If boolInBuildString = False Then
            If tcpAPRS.Stream.CanRead Then
                tcpAPRS.BeginReceive(marData)
            End If
        End If

        If setup.intBCNtxrate <> 0 Then
            If tick Mod (setup.intBCNtxrate * 2) = setup.intBCNtxrate And mnuServAGWPE.Checked = True Then
                tcpAGWPE_SendBeacon()
            End If
        End If




        If tick Mod 60 = 0 Then
            'every 30 seconds do the reconnect if required

            If mnuServRealTrack.Checked = True Then
                tcprealtrack_poll()
            End If


            If mnuServAGWPE.Checked = True Then
                tcpAGWPE_Startup("", 0)
            End If
            If mnuServAPRSServ.Checked = True Then
                tcpAPRS_Startup("", 0)
            End If


        End If

        If tick Mod 20 = 10 Then 'And mnuServRINO.Checked = True Then
            'devRINO.process()
            'tcpAGWPE_SendBeacon()


        End If



        If tick Mod 60 = 30 And mnuServRINO.Checked = True Then
            devRINO.process()


        End If


        If tick Mod 120 = 0 And setup.boolInterfaceOziDecay = True Then ' every 60 seconds 
            crosspoint.DevGui_DecayIcons()
        End If



    End Sub

    Private Sub mnuInterfacesOziSync_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInterfacesOziSync.Click
        crosspoint.DevGui_SyncOziWPs()
    End Sub

    Private Sub mnuInterfacesOziClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInterfacesOziClear.Click
        crosspoint.DevGui_ClearOziWPs()
    End Sub


    'FpSpread1.ActiveSheet.Cells(0, 0).CellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType

    'Private Sub FpSpread1_ButtonClicked(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs) Handles FpSpread1.ButtonClicked
    '    If TypeOf e.EditingControl Is FarPoint.Win.FpCheckBox Then
    '        MessageBox.Show(e.View.Sheets(0).Cells(e.Row, e.Column).Value)
    '    End If
    'End Sub

    Private Sub FpDevGuiDisplay_ButtonClicked(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs)

        crosspoint.fpdevgui_ButtonClicked(sender, e)

        'Dim state As Boolean
        'state = FpPortsCrosspoint.ActiveSheet.Cells(e.Row, e.Column).Value
        'crosspoint.CrosspointEnable(e.Row, e.Column, state)


    End Sub



    Private Sub FpPortsCrosspoint_ButtonClicked(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs) Handles FpPortsCrosspoint.ButtonClicked

        Dim state As Boolean
        state = FpPortsCrosspoint.ActiveSheet.Cells(e.Row, e.Column).Value
        crosspoint.CrosspointEnable(e.Row, e.Column, state)


    End Sub

    Private Sub WebServer80_Connection(ByVal sender As Object, ByVal e As Dart.PowerTCP.Sockets.ConnectionEventArgs) Handles WebServer80.Connection
        devWeb.WebServer80_Connection(sender, e)

    End Sub

    Public Sub SaveApplicationSettings(ByVal mysetup As frmSetup.SetupStructure)
        setup = mysetup

        SaveSetting("NetAPRS", "NetAPRS", "strStationCallsign", setup.strStationCallsign)
        SaveSetting("NetAPRS", "NetAPRS", "strLanguage", setup.strLanguage)

        SaveSetting("NetAPRS", "NetAPRS", "strOutgoingServer", setup.strOutgoingServer)
        SaveSetting("NetAPRS", "NetAPRS", "strOutgoingServerLogin", setup.strOutgoingServerLogin)
        SaveSetting("NetAPRS", "NetAPRS", "strOutgoingServerConnectString", setup.strOutgoingServerConnectString)
        SaveSetting("NetAPRS", "NetAPRS", "boolOutgoingServerAutoConnect", setup.boolOutgoingServerAutoConnect)
        SaveSetting("NetAPRS", "NetAPRS", "boolIncomingServerAutoStart", setup.boolIncomingServerAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolIncomingServerDumpHistory", setup.boolIncomingServerDumpHistory)
        SaveSetting("NetAPRS", "NetAPRS", "boolIncomingGPRSAutoStart", setup.boolIncomingGPRSAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolIncomingNetGPSAutoStart", setup.boolIncomingNetGPSAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "intTNCComPort", setup.intTNCComPort)
        SaveSetting("NetAPRS", "NetAPRS", "intTNCComSpeed", setup.intTNCComSpeed)
        SaveSetting("NetAPRS", "NetAPRS", "boolTNCKissMode", setup.boolTNCKissMode)
        SaveSetting("NetAPRS", "NetAPRS", "boolTNCAutoConnect", setup.boolTNCAutoConnect)
        SaveSetting("NetAPRS", "NetAPRS", "boolAGWPEAutoConnect", setup.boolAGWPEAutoConnect)
        SaveSetting("NetAPRS", "NetAPRS", "boolUploadNonLive", setup.boolUploadNonLive)
        SaveSetting("NetAPRS", "NetAPRS", "dblLat", setup.dblLat)
        SaveSetting("NetAPRS", "NetAPRS", "dblLon", setup.dblLon)
        SaveSetting("NetAPRS", "NetAPRS", "MyCall", setup.strStationCallsign)
        SaveSetting("NetAPRS", "NetAPRS", "MyCall", setup.strStationCallsign)
        SaveSetting("NetAPRS", "NetAPRS", "boolNMEAOziAutoStart", setup.boolNMEAOziAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolNMEAAutoStart", setup.boolNMEAAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "intNMEAComPort", setup.intNMEAComPort)
        SaveSetting("NetAPRS", "NetAPRS", "intNMEAComSpeed", setup.intNMEAComSpeed)
        SaveSetting("NetAPRS", "NetAPRS", "intRINOComPort", setup.intRINOComPort)
        SaveSetting("NetAPRS", "NetAPRS", "boolRinoAutoStart", setup.boolRinoAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolMonitorUploadOnly", setup.boolMonitorUploadOnly)
        SaveSetting("NetAPRS", "NetAPRS", "boolGeoFilterAutoStart", setup.boolGeoFilterAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "dblGeoFilterLat1", setup.dblGeoFilterLat1)
        SaveSetting("NetAPRS", "NetAPRS", "dblGeoFilterLat2", setup.dblGeoFilterLat2)
        SaveSetting("NetAPRS", "NetAPRS", "dblGeoFilterLon2", setup.dblGeoFilterLon2)
        SaveSetting("NetAPRS", "NetAPRS", "dblGeoFilterLon1", setup.dblGeoFilterLon1)
        'SaveSetting("NetAPRS", "NetAPRS", "boolDecayAutoStart", setup.boolDecayAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolStateAutosave", setup.boolStateAutosave)
        SaveSetting("NetAPRS", "NetAPRS", "strStateFilename", setup.strStateFilename)
        SaveSetting("NetAPRS", "NetAPRS", "boolStateAutoload", setup.boolStateAutoload)
        SaveSetting("NetAPRS", "NetAPRS", "strDatabaseFilename", setup.strDatabaseFilename)
        SaveSetting("NetAPRS", "NetAPRS", "boolDatabaseAutoStart", setup.boolDatabaseAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "strDebugLogFilename", setup.strDebugLogFilename)
        SaveSetting("NetAPRS", "NetAPRS", "boolDebugLogAutoStart", setup.boolDebugLogAutoStart)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceOziStartup", setup.boolInterfaceOziStartup)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceMapPointStartup", setup.boolInterfaceMapPointStartup)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceUIViewStartup", setup.boolInterfaceUIViewStartup)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceOziDecayStartup ", setup.boolInterfaceOziDecayStartup)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceOziOntop", setup.boolInterfaceOziOntop)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceOziAutoTrailMoving", setup.boolInterfaceOziAutoTrailMoving)
        SaveSetting("NetAPRS", "NetAPRS", "intIncomingHubport", setup.intIncomingHubport)
        SaveSetting("NetAPRS", "NetAPRS", "intIncomingGPRSport", setup.intIncomingGPRSport)
        SaveSetting("NetAPRS", "NetAPRS", "intIncomingNetGPSport", setup.intIncomingNetGPSport)

        SaveSetting("NetAPRS", "NetAPRS", "strIGPRSip_1", setup.strIGPRSip_1)
        SaveSetting("NetAPRS", "NetAPRS", "strIGPRSip_2", setup.strIGPRSip_2)
        SaveSetting("NetAPRS", "NetAPRS", "intIGPRSp_1", setup.intIGPRSp_1)
        SaveSetting("NetAPRS", "NetAPRS", "intIGPRSp_2", setup.intIGPRSp_2)
        SaveSetting("NetAPRS", "NetAPRS", "strIGPRSapn", setup.strIGPRSapn)
        SaveSetting("NetAPRS", "NetAPRS", "intIGPRSrate", setup.intIGPRSrate)
        SaveSetting("NetAPRS", "NetAPRS", "intIGPRSport", setup.intIGPRSport)
        SaveSetting("NetAPRS", "NetAPRS", "boolTNCMonitorOnly", setup.boolTNCMonitorOnly)

        SaveSetting("NetAPRS", "NetAPRS", "intIGatePosRate", setup.intIGatePosRate)
        SaveSetting("NetAPRS", "NetAPRS", "intIGateMsgRate", setup.intIGateMsgRate)
        SaveSetting("NetAPRS", "NetAPRS", "intIGateObjRate", setup.intIGateObjRate)
        SaveSetting("NetAPRS", "NetAPRS", "intIGateWxRate", setup.intIGateWxRate)
        SaveSetting("NetAPRS", "NetAPRS", "intIGateRate", setup.intIGateRate)
        SaveSetting("NetAPRS", "NetAPRS", "boolIGatePosRf", setup.boolIGatePosRf)
        SaveSetting("NetAPRS", "NetAPRS", "booliGateMsgRF", setup.booliGateMsgRF)
        SaveSetting("NetAPRS", "NetAPRS", "booliGateObjRf", setup.booliGateObjRf)
        SaveSetting("NetAPRS", "NetAPRS", "booliGateWxRf", setup.booliGateWxRf)
        SaveSetting("NetAPRS", "NetAPRS", "strCallsignTranslations", setup.strCallsignTranslations)
        SaveSetting("NetAPRS", "NetAPRS", "boolCallsignTranslate", setup.boolCallsignTranslate)

        SaveSetting("NetAPRS", "NetAPRS", "boolShowFile", setup.boolShowFile)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowSetup", setup.boolShowSetup)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowServices", setup.boolShowServices)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowGUI", setup.boolShowGUI)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowHelp", setup.boolShowHelp)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowTNC", setup.boolShowTNC)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowGPS", setup.boolShowGPS)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowWX", setup.boolShowWX)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowRINO", setup.boolShowRINO)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowLOG", setup.boolShowLOG)

        SaveSetting("NetAPRS", "NetAPRS", "boolShowNetwork", setup.boolShowNetwork)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowOzi", setup.boolShowOzi)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowMapPoint", setup.boolShowMapPoint)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowAGWPEUIVIEW", setup.boolShowAGWPEUIVIEW)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowOziSyncClear", setup.boolShowOziSyncClear)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowOziDecay", setup.boolShowOziDecay)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowOziAutotrail", setup.boolShowOziAutotrail)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowGeoFilter", setup.boolShowGeoFilter)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowDatabase", setup.boolShowDatabase)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowUploadMonitored", setup.boolShowUploadMonitored)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowTranslated", setup.boolShowTranslated)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowTranslated", setup.boolShowLogDatabase)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowInterface", setup.boolShowInterface)


        SaveSetting("NetAPRS", "NetAPRS", "boolUIShowPos", setup.boolUIShowPos)
        SaveSetting("NetAPRS", "NetAPRS", "boolShowTraboolUIShowWxnslated", setup.boolUIShowWx)
        SaveSetting("NetAPRS", "NetAPRS", "boolUIShowObjs", setup.boolUIShowObjs)
        SaveSetting("NetAPRS", "NetAPRS", "boolUIShowMsgs", setup.boolUIShowMsgs)
        SaveSetting("NetAPRS", "NetAPRS", "boolErrorMsg", setup.boolErrorMsg)
        SaveSetting("NetAPRS", "NetAPRS", "boolErrorLog", setup.boolErrorLog)
        SaveSetting("NetAPRS", "NetAPRS", "boolInterfaceOziGPS", setup.boolInterfaceOziGPS)





        SaveSetting("NetAPRS", "NetAPRS", "txtBCNdigi", setup.txtBCNdigi)
        SaveSetting("NetAPRS", "NetAPRS", "txtBCNsymbol", setup.txtBCNsymbol)
        SaveSetting("NetAPRS", "NetAPRS", "txtBCNtable", setup.txtBCNtable)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNtxrate", setup.intBCNtxrate)
        SaveSetting("NetAPRS", "NetAPRS", "chkSmartEnable", setup.chkSmartEnable)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNTurnAngle", setup.intBCNTurnAngle)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNTurnAngle", setup.intBCNTurnAngle)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNTurnSlope", setup.intBCNTurnSlope)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNTurnTIme", setup.intBCNTurnTIme)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNSlowSpeed", setup.intBCNSlowSpeed)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNslowRate", setup.intBCNslowRate)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNfastSpeed", setup.intBCNfastSpeed)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNfastRate", setup.intBCNfastRate)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNMICE", setup.boolBCNMICE)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNMICEPrintable", setup.boolBCNMICEPrintable)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNMICEmessage", setup.intBCNMICEmessage)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNmicePATH", setup.intBCNmicePATH)

        SaveSetting("NetAPRS", "NetAPRS", "boolBCNvalid", setup.boolBCNvalid)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNDHM", setup.boolBCNDHM)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNHMS", setup.boolBCNHMS)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNSendAlt", setup.boolBCNSendAlt)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNSendNMEA", setup.boolBCNSendNMEA)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNAltDigi", setup.boolBCNAltDigi)
        SaveSetting("NetAPRS", "NetAPRS", "txtBCNStatus", setup.txtBCNStatus)
        SaveSetting("NetAPRS", "NetAPRS", "intBCNSendEvery", setup.intBCNSendEvery)
        SaveSetting("NetAPRS", "NetAPRS", "boolBCNSendSeperate", setup.boolBCNSendSeperate)

        SaveSetting("NetAPRS", "NetAPRS", "intGPSport", setup.intGPSport)


    End Sub

    Public Function getApplicationSettings() As frmSetup.SetupStructure
        Dim mySetup As frmSetup.SetupStructure




        mySetup.strStationCallsign = GetSetting("NetAPRS", "NetAPRS", "strStationCallsign", "N0CALL")
        mySetup.strLanguage = GetSetting("NetAPRS", "NetAPRS", "strLanguage", "English")


        mySetup.strOutgoingServer = GetSetting("NetAPRS", "NetAPRS", "strOutgoingServer", "APRS.NET.AU:10153")
        mySetup.strOutgoingServerLogin = GetSetting("NetAPRS", "NetAPRS", "strOutgoingServerLogin", setup.strOutgoingServerLogin)
        mySetup.strOutgoingServerConnectString = GetSetting("NetAPRS", "NetAPRS", "strOutgoingServerConnectString", setup.strOutgoingServerConnectString)
        mySetup.boolOutgoingServerAutoConnect = GetSetting("NetAPRS", "NetAPRS", "boolOutgoingServerAutoConnect", "True")
        mySetup.boolIncomingServerAutoStart = GetSetting("NetAPRS", "NetAPRS", "boolIncomingServerAutoStart", setup.boolIncomingServerAutoStart)

        mySetup.boolIncomingServerDumpHistory = GetSetting("NetAPRS", "NetAPRS", "boolIncomingServerDumpHistory", setup.boolIncomingServerDumpHistory)
        mySetup.boolIncomingGPRSAutoStart = GetSetting("NetAPRS", "NetAPRS", "boolIncomingGPRSAutoStart", setup.boolIncomingGPRSAutoStart)
        mySetup.boolIncomingNetGPSAutoStart = GetSetting("NetAPRS", "NetAPRS", "boolIncomingNetGPSAutoStart", setup.boolIncomingNetGPSAutoStart)
        mySetup.intTNCComPort = GetSetting("NetAPRS", "NetAPRS", "intTNCComPort", "1")
        mySetup.intTNCComSpeed = GetSetting("NetAPRS", "NetAPRS", "intTNCComSpeed", "9600")

        mySetup.boolTNCKissMode = cbl(GetSetting("NetAPRS", "NetAPRS", "boolTNCKissMode", setup.boolTNCKissMode))
        mySetup.boolTNCAutoConnect = cbl(GetSetting("NetAPRS", "NetAPRS", "boolTNCAutoConnect", setup.boolTNCAutoConnect))
        mySetup.boolAGWPEAutoConnect = cbl(GetSetting("NetAPRS", "NetAPRS", "boolAGWPEAutoConnect", setup.boolAGWPEAutoConnect))
        mySetup.boolUploadNonLive = GetSetting("NetAPRS", "NetAPRS", "boolUploadNonLive", setup.boolUploadNonLive)
        mySetup.dblLat = GetSetting("NetAPRS", "NetAPRS", "dblLat", setup.dblLat)
        mySetup.dblLon = GetSetting("NetAPRS", "NetAPRS", "dblLon", setup.dblLon)
        mySetup.boolNMEAOziAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolNMEAOziAutoStart", 1))
        mySetup.boolNMEAAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolNMEAAutoStart", setup.boolNMEAAutoStart))
        mySetup.intNMEAComPort = GetSetting("NetAPRS", "NetAPRS", "intNMEAComPort", setup.intNMEAComPort)
        mySetup.intNMEAComSpeed = GetSetting("NetAPRS", "NetAPRS", "intNMEAComSpeed", setup.intNMEAComSpeed)
        mySetup.intRINOComPort = GetSetting("NetAPRS", "NetAPRS", "intRINOComPort", setup.intRINOComPort)
        mySetup.boolRinoAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolRinoAutoStart", setup.boolRinoAutoStart))
        mySetup.boolMonitorUploadOnly = cbl(GetSetting("NetAPRS", "NetAPRS", "boolMonitorUploadOnly", setup.boolMonitorUploadOnly))
        mySetup.boolGeoFilterAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolGeoFilterAutoStart", setup.boolGeoFilterAutoStart))
        mySetup.dblGeoFilterLat1 = GetSetting("NetAPRS", "NetAPRS", "dblGeoFilterLat1", setup.dblGeoFilterLat1)
        mySetup.dblGeoFilterLat2 = GetSetting("NetAPRS", "NetAPRS", "dblGeoFilterLat2", setup.dblGeoFilterLat2)
        mySetup.dblGeoFilterLon2 = GetSetting("NetAPRS", "NetAPRS", "dblGeoFilterLon2", setup.dblGeoFilterLon2)
        mySetup.dblGeoFilterLon1 = GetSetting("NetAPRS", "NetAPRS", "dblGeoFilterLon1", setup.dblGeoFilterLon1)
        'mySetup.boolDecayAutoStart = cdbl(GetSetting("NetAPRS", "NetAPRS", "boolDecayAutoStart", setup.boolDecayAutoStart)
        mySetup.boolStateAutosave = cbl(GetSetting("NetAPRS", "NetAPRS", "boolDecayAutoStart", setup.boolStateAutosave))
        mySetup.strStateFilename = GetSetting("NetAPRS", "NetAPRS", "strStateFilename", setup.strStateFilename)
        mySetup.boolStateAutoload = cbl(GetSetting("NetAPRS", "NetAPRS", "boolStateAutoload", setup.boolStateAutoload))
        mySetup.strDatabaseFilename = GetSetting("NetAPRS", "NetAPRS", "strDatabaseFilename", setup.strDatabaseFilename)
        mySetup.boolDatabaseAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolDatabaseAutoStart", setup.boolDatabaseAutoStart))
        mySetup.strDebugLogFilename = GetSetting("NetAPRS", "NetAPRS", "strDebugLogFilename", setup.strDebugLogFilename)
        mySetup.boolDebugLogAutoStart = cbl(GetSetting("NetAPRS", "NetAPRS", "boolDebugLogAutoStart", setup.boolDebugLogAutoStart))
        mySetup.boolInterfaceOziStartup = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziStartup", setup.boolInterfaceOziStartup))
        mySetup.boolInterfaceOziOntop = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziOntop", setup.boolInterfaceOziOntop))
        mySetup.boolInterfaceMapPointStartup = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceMapPointStartup", setup.boolInterfaceMapPointStartup))
        mySetup.boolInterfaceUIViewStartup = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceUIViewStartup", setup.boolInterfaceUIViewStartup))
        mySetup.boolInterfaceOziDecayStartup = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziDecayStartup", setup.boolInterfaceOziDecayStartup))
        mySetup.boolInterfaceOziOntop = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziOntop", setup.boolInterfaceOziOntop))
        mySetup.boolInterfaceOziAutoTrailMoving = cbl(GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziAutoTrailMoving", setup.boolInterfaceOziAutoTrailMoving))
        mySetup.intIncomingHubport = GetSetting("NetAPRS", "NetAPRS", "intIncomingHubport", 10151)
        mySetup.intIncomingGPRSport = GetSetting("NetAPRS", "NetAPRS", "intIncomingGPRSport", 8001)
        mySetup.intIncomingNetGPSport = GetSetting("NetAPRS", "NetAPRS", "intIncomingNetGPSport", 80)

        mySetup.strIGPRSip_1 = GetSetting("NetAPRS", "NetAPRS", "strIGPRSip_1", "127.0.0.1")
        mySetup.strIGPRSip_2 = GetSetting("NetAPRS", "NetAPRS", "strIGPRSip_2", "127.0.0.1")
        mySetup.intIGPRSp_1 = GetSetting("NetAPRS", "NetAPRS", "intIGPRSp_1", 8001)
        mySetup.intIGPRSp_2 = GetSetting("NetAPRS", "NetAPRS", "intIGPRSp_2", 8001)
        mySetup.strIGPRSapn = GetSetting("NetAPRS", "NetAPRS", "strIGPRSapn", "telstra.internet")
        mySetup.intIGPRSrate = GetSetting("NetAPRS", "NetAPRS", "intIGPRSrate", 30)
        mySetup.intIGPRSport = GetSetting("NetAPRS", "NetAPRS", "intIGPRSport", 1)
        mySetup.boolTNCMonitorOnly = GetSetting("NetAPRS", "NetAPRS", "boolTNCMonitorOnly", True)


        mySetup.intIGatePosRate = GetSetting("NetAPRS", "NetAPRS", "intIGatePosRate", 1)
        mySetup.intIGateMsgRate = GetSetting("NetAPRS", "NetAPRS", "intIGateMsgRate", 1)
        mySetup.intIGateObjRate = GetSetting("NetAPRS", "NetAPRS", "intIGateObjRate", 1)
        mySetup.intIGateWxRate = GetSetting("NetAPRS", "NetAPRS", "intIGateWxRate", 1)
        mySetup.intIGateRate = GetSetting("NetAPRS", "NetAPRS", "intIGateRate", 1)
        mySetup.boolIGatePosRf = GetSetting("NetAPRS", "NetAPRS", "boolIGatePosRf", 1)
        mySetup.booliGateMsgRF = GetSetting("NetAPRS", "NetAPRS", "booliGateMsgRF", 1)
        mySetup.booliGateObjRf = GetSetting("NetAPRS", "NetAPRS", "booliGateObjRf", 1)
        mySetup.booliGateWxRf = GetSetting("NetAPRS", "NetAPRS", "booliGateWxRf", 1)
        mySetup.strCallsignTranslations = GetSetting("NetAPRS", "NetAPRS", "strCallsignTranslations", "")
        LoadCallsignTranslations(mySetup.strCallsignTranslations)
        mySetup.boolCallsignTranslate = GetSetting("NetAPRS", "NetAPRS", "boolCallsignTranslate", 1)



        mySetup.boolShowFile = GetSetting("NetAPRS", "NetAPRS", "boolShowFile", 1)
        mySetup.boolShowSetup = GetSetting("NetAPRS", "NetAPRS", "boolShowSetup", 1)
        mySetup.boolShowServices = GetSetting("NetAPRS", "NetAPRS", "boolShowServices", 1)
        mySetup.boolShowGUI = GetSetting("NetAPRS", "NetAPRS", "boolShowGUI", 1)
        mySetup.boolShowHelp = GetSetting("NetAPRS", "NetAPRS", "boolShowHelp", 1)
        mySetup.boolShowTNC = GetSetting("NetAPRS", "NetAPRS", "boolShowTNC", 1)
        mySetup.boolShowGPS = GetSetting("NetAPRS", "NetAPRS", "boolShowGPS", 1)
        mySetup.boolShowWX = GetSetting("NetAPRS", "NetAPRS", "boolShowWX", 1)
        mySetup.boolShowRINO = GetSetting("NetAPRS", "NetAPRS", "boolShowRINO", 1)
        mySetup.boolShowLOG = GetSetting("NetAPRS", "NetAPRS", "boolShowLOG", 1)
        mySetup.boolShowInterface = GetSetting("NetAPRS", "NetAPRS", "boolShowInterface", 1)

        mySetup.boolShowNetwork = GetSetting("NetAPRS", "NetAPRS", "boolShowNetwork", 1)
        mySetup.boolShowOzi = GetSetting("NetAPRS", "NetAPRS", "boolShowOzi", 1)
        mySetup.boolShowMapPoint = GetSetting("NetAPRS", "NetAPRS", "boolShowMapPoint", 1)
        mySetup.boolShowAGWPEUIVIEW = GetSetting("NetAPRS", "NetAPRS", "boolShowAGWPEUIVIEW", 1)
        mySetup.boolShowOziSyncClear = GetSetting("NetAPRS", "NetAPRS", "boolShowOziSyncClear", 1)
        mySetup.boolShowOziDecay = GetSetting("NetAPRS", "NetAPRS", "boolShowOziDecay", 1)
        mySetup.boolShowOziAutotrail = GetSetting("NetAPRS", "NetAPRS", "boolShowOziAutotrail", 1)
        mySetup.boolShowGeoFilter = GetSetting("NetAPRS", "NetAPRS", "boolShowGeoFilter", 1)
        mySetup.boolShowDatabase = GetSetting("NetAPRS", "NetAPRS", "boolShowDatabase", 1)
        mySetup.boolShowUploadMonitored = GetSetting("NetAPRS", "NetAPRS", "boolShowUploadMonitored", 1)
        mySetup.boolShowTranslated = GetSetting("NetAPRS", "NetAPRS", "boolShowTranslated", 1)
        mySetup.boolShowLogDatabase = GetSetting("NetAPRS", "NetAPRS", "boolShowLogDatabase", 1)



        mySetup.boolUIShowPos = GetSetting("NetAPRS", "NetAPRS", "boolUIShowPos", 1)
        mySetup.boolUIShowWx = GetSetting("NetAPRS", "NetAPRS", "boolUIShowWx", 1)
        mySetup.boolUIShowMsgs = GetSetting("NetAPRS", "NetAPRS", "boolUIShowMsgs", 1)
        mySetup.boolUIShowObjs = GetSetting("NetAPRS", "NetAPRS", "boolUIShowObjs", 1)

        mySetup.boolErrorLog = GetSetting("NetAPRS", "NetAPRS", "boolErrorLog", 0)
        mySetup.boolErrorMsg = GetSetting("NetAPRS", "NetAPRS", "boolErrorMsg", 0)
        mySetup.boolInterfaceOziGPS = GetSetting("NetAPRS", "NetAPRS", "boolInterfaceOziGPS", 0)

        mySetup.txtBCNdigi = GetSetting("NetAPRS", "NetAPRS", "txtBCNdigi", 0)
        mySetup.txtBCNsymbol = GetSetting("NetAPRS", "NetAPRS", "txtBCNsymbol", 0)
        mySetup.txtBCNtable = GetSetting("NetAPRS", "NetAPRS", "txtBCNtable", 0)
        mySetup.intBCNtxrate = GetSetting("NetAPRS", "NetAPRS", "intBCNtxrate", 0)

        mySetup.chkSmartEnable = GetSetting("NetAPRS", "NetAPRS", "chkSmartEnable", 0)
        mySetup.intBCNTurnAngle = GetSetting("NetAPRS", "NetAPRS", "intBCNTurnAngle", 0)
        mySetup.intBCNTurnSlope = GetSetting("NetAPRS", "NetAPRS", "intBCNTurnSlope", 0)
        mySetup.intBCNTurnTIme = GetSetting("NetAPRS", "NetAPRS", "intBCNTurnTIme", 0)

        mySetup.intBCNSlowSpeed = GetSetting("NetAPRS", "NetAPRS", "intBCNSlowSpeed", 0)
        mySetup.intBCNslowRate = GetSetting("NetAPRS", "NetAPRS", "intBCNslowRate", 0)
        mySetup.intBCNfastSpeed = GetSetting("NetAPRS", "NetAPRS", "intBCNfastSpeed", 0)
        mySetup.intBCNfastRate = GetSetting("NetAPRS", "NetAPRS", "intBCNfastRate", 0)

        mySetup.boolBCNMICE = GetSetting("NetAPRS", "NetAPRS", "boolBCNMICE", 0)
        mySetup.boolBCNMICEPrintable = GetSetting("NetAPRS", "NetAPRS", "boolBCNMICEPrintable", 0)
        mySetup.intBCNMICEmessage = GetSetting("NetAPRS", "NetAPRS", "intBCNMICEmessage", 0)
        mySetup.intBCNmicePATH = GetSetting("NetAPRS", "NetAPRS", "intBCNmicePATH", 0)

        mySetup.boolBCNvalid = GetSetting("NetAPRS", "NetAPRS", "boolBCNvalid", 0)
        mySetup.boolBCNDHM = GetSetting("NetAPRS", "NetAPRS", "boolBCNDHM", 0)
        mySetup.boolBCNHMS = GetSetting("NetAPRS", "NetAPRS", "boolBCNHMS", 0)
        mySetup.boolBCNSendAlt = GetSetting("NetAPRS", "NetAPRS", "boolBCNSendAlt", 0)
        mySetup.boolBCNSendNMEA = GetSetting("NetAPRS", "NetAPRS", "boolBCNSendNMEA", 0)
        mySetup.boolBCNAltDigi = GetSetting("NetAPRS", "NetAPRS", "boolBCNAltDigi", 0)

        mySetup.txtBCNStatus = GetSetting("NetAPRS", "NetAPRS", "txtBCNStatus", 0)
        mySetup.intBCNSendEvery = GetSetting("NetAPRS", "NetAPRS", "intBCNSendEvery", 0)
        mySetup.boolBCNSendSeperate = GetSetting("NetAPRS", "NetAPRS", "boolBCNSendSeperate", 0)

        mySetup.intGPSport = GetSetting("NetAPRS", "NetAPRS", "intGPSport", 0)

        Return mySetup



    End Function



    Private Sub mnuServAPRSServ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServAPRSServ.Click
        Dim server As String
        Dim port As Integer
        If mnuServAPRSServ.Checked = True Then
            mnuServAPRSServ.Checked = False
            tcpAPRS_Stop()

        Else
            mnuServAPRSServ.Checked = True
            Try
                server = Mid(setup.strOutgoingServer, 1, InStr(setup.strOutgoingServer, ":") - 1)
                port = Mid(setup.strOutgoingServer, InStr(setup.strOutgoingServer, ":") + 1)
            Catch ex As Exception

            End Try

            tcpAPRS_Start(server, port)

        End If




    End Sub

    Private Sub mnuServAGWPE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServAGWPE.Click

        If mnuServAGWPE.Checked = True Then
            mnuServAGWPE.Checked = False
            tcpAGWPE_Stop()

        Else
            mnuServAGWPE.Checked = True
            portAGWPE = crosspoint.NewPort(crosspoint.devices.devAGWPE, AddressOf tcpAGWPE_SendOut)
            crosspoint.CrosspointEnable(-1, portAGWPE, True)
            crosspoint.CrosspointEnable(portAGWPE, portAGWPE, False)
            tcpAGWPE_Startup("127.0.0.1", 8000)
        End If

    End Sub



    Private Sub mnuServTNC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServTNC.Click

        If mnuServTNC.Checked = True Then
            mnuServTNC.Checked = False
        Else
            mnuServTNC.Checked = True
            'sdkads()
            CommTNC = New SerialNET.Port
            Dim lic = New SerialNET.License
            lic.licenseKey = "ThHGhbBKUCaAOuo3HMLdqsPQK0ZC3OXOTiLF"
            'Me.Controls.Add(CommTNC)




            devTNC = New devTNC(Me, CommTNC, setup)
            'devTNC = New devTNC(Me, Nothing, setup)
            portTNC = crosspoint.NewPort(crosspoint.devices.devTNC, AddressOf devTNC.devTNC_SendOut)
            'devWeb.SetPort(portTNC)
            crosspoint.CrosspointEnable(-1, portTNC, True)
            crosspoint.CrosspointEnable(portTNC, portTNC, False)

        End If

    End Sub



    Private Sub mnuServGPS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServGPS.Click

        'TODO: AGWPE

        If mnuServGPS.Checked = True Then
            mnuServGPS.Checked = False
            GPS_COMStop()

        Else
            mnuServGPS.Checked = True

            devGPS = New devGPS(Me, setup)


            GPS_COMStart()



            portTNC = crosspoint.NewPort(crosspoint.devices.devGPS, AddressOf crosspoint.nullfunction)
            'devWeb.SetPort(portTNC)
            crosspoint.CrosspointEnable(-1, portTNC, False)
            crosspoint.CrosspointEnable(portGPS, portAGWPE, True)
            crosspoint.CrosspointEnable(portGPS, portTNC, True)
            crosspoint.CrosspointEnable(portGPS, portGPS, False)

        End If

    End Sub

    Private Sub mnuServHub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServHub.Click
        If mnuServHub.Checked = True Then
            mnuServHub.Checked = False
            tcpAPRSServer_Stop()
        Else
            mnuServHub.Checked = True
            tcpAPRSServer_Start(setup.intIncomingHubport)


        End If


    End Sub

    Private Sub mnuServNetGPS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServNetGPS.Click
        Dim newport As Integer

        If mnuServNetGPS.Checked = True Then
            mnuServNetGPS.Checked = False
            devWeb.close()

        Else
            mnuServNetGPS.Checked = True
            devWeb = New devWeb(PortsList, FpPortsCrosspoint, FpDevGuiMaster, FpDevGuiDisplay, WebServer80, AddressOf crosspoint.Submit)
            newport = crosspoint.NewPort(crosspoint.devices.devWWW, AddressOf devWeb.DeviceWWW)
            devWeb.SetPort(newport)
            crosspoint.CrosspointEnable(-1, newport, True)
            crosspoint.CrosspointEnable(newport, newport, False)


        End If




        ' Enable the WWW server

    End Sub

    Private Sub mnuServLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServLog.Click

        If mnuServLog.Checked = True Then
            mnuServLog.Checked = False
            crosspoint.closePort(portLog)
            devLog.close()
            devLog = Nothing

        Else
            mnuServLog.Checked = True
            devLog = New devLog(setup.strDebugLogFilename)
            portLog = crosspoint.NewPort(crosspoint.devices.devLOG, AddressOf devLog.DeviceLog)
            crosspoint.CrosspointEnable(-1, portLog, True)
            crosspoint.CrosspointEnable(portLog, portLog, False)



        End If

    End Sub

    Private Sub mnuServDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServDatabase.Click
        If mnuServDatabase.Checked = True Then
            mnuServDatabase.Checked = False
            crosspoint.CrosspointEnable(-1, portDatabase, False)
            devDatabase = Nothing
        Else
            mnuServDatabase.Checked = True
            devDatabase = New devDatabase(setup.strDatabaseFilename, setup)
            portDatabase = crosspoint.NewPort(crosspoint.devices.devDATABASE, AddressOf devDatabase.devDatabase_SendOut)
            crosspoint.CrosspointEnable(-1, portDatabase, True)
            crosspoint.CrosspointEnable(portDatabase, portDatabase, False)


        End If
    End Sub

    Private Sub mnuServGPRS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServGPRS.Click
        If mnuServGPRS.Checked = True Then
            mnuServGPRS.Checked = False
            tcpGPRSServer_Stop()
        Else
            mnuServGPRS.Checked = True
            tcpGPRSServer_Start(setup.intIncomingGPRSport)
        End If



    End Sub

    Private Sub mnuServOzi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServOzi.Click
        Dim data As String
        Dim datalength As Int32
        If mnuServOzi.Checked = True Then
            mnuServOzi.Checked = False
            setup.boolInterfaceOziConnected = False
        Else
            devOzi.oziGetOziVersion(data, datalength)
            If Len(data) > 0 Then  'MsgBox(data)
                mnuServOzi.Checked = True
                devOzi = New devOzi(FpDevGuiMaster, FpDevGuiMaster.ActiveSheet.RowCount, Me)
                'TODO: Do we actually need this next line? NEWPORT.
                'portLog = crosspoint.NewPort(crosspoint.devices.devOzi, AddressOf devOzi.DeviceOzi)
                setup.boolInterfaceOziConnected = True

            End If


        End If

    End Sub

    Private Sub mnuServMapPoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServMapPoint.Click
        If mnuServMapPoint.Checked = True Then
            mnuServMapPoint.Checked = False
            devMapPoint.close()
            setup.boolInterfaceMapPOintConnected = False
        Else
            mnuServMapPoint.Checked = True
            devMapPoint = New devMapPoint(Me)
            setup.boolInterfaceMapPOintConnected = True
        End If
    End Sub

    Private Sub mnuServUIView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServUIView.Click
        If mnuServUIView.Checked = True Then
            mnuServUIView.Checked = False
            crosspoint.closePort(portUIView)
        Else
            mnuServUIView.Checked = True
            portUIView = crosspoint.NewPort(crosspoint.devices.devUIView, AddressOf DevUIView_SendOut)
            crosspoint.CrosspointEnable(-1, portUIView, True)
            crosspoint.CrosspointEnable(portUIView, portUIView, False)

            devUIVIEW = New UIView32.clsUIV

        End If

        'Private Sub mUIV_DataAvailable()
        '        Dim cInfo As New clsFrameInfo

        '        'This is the only time when the info returned by
        '        'GetFrameInfo() will be valid. If you call it
        '        'at any other time, then you will not know to
        '        'which frame the info returned relates.
        '        If mUIV.GetFrameInfo(cInfo) Then
        '            '    Debug.Print cInfo.strSourceAddress
        '            '    Debug.Print cInfo.strDestAddress
        '            '    Debug.Print cInfo.eSource
        '            '    Debug.Print cInfo.ePacketClass
        '            '    Debug.Print cInfo.blnDirect
        '            '    Debug.Print cInfo.blnThirdParty
        '            '    Debug.Print cInfo.eDisplayType
        '        End If

        '        ShowText(txtAPRS, mUIV.strAPRSData)

    End Sub








    Private Sub mnuInterfaceOziDecay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInterfaceOziDecay.Click
        If mnuInterfaceOziDecay.Checked = True Then
            mnuInterfaceOziDecay.Checked = False
            setup.boolInterfaceOziDecay = False
        Else
            mnuInterfaceOziDecay.Checked = True
            setup.boolInterfaceOziDecay = True
        End If
    End Sub

    Private Sub tcpAGWPE_EndReceive(ByVal sender As Object, ByVal e As Dart.PowerTCP.Sockets.SegmentEventArgs) Handles tcpAGWPE.EndReceive

        If e.Exception Is Nothing Then

            tcpAGWPE_InputText = tcpAGWPE_InputText & fixmicrosoft(e.Segment.Buffer)
        End If

        If tcpAGWPE.Stream.CanRead Then
            tcpAGWPE.BeginReceive(tcpAGWPEData)
        End If

    End Sub



    Private Sub tcpAGWPE_Send(ByVal Line As String)

        tcpAGWPE.Send(Line)

    End Sub


    Private Sub tcpAGWPE_SendBeacon()
        Dim line As String
        line = Chr(1) & Chr(0) & Chr(0) & Chr(0)
        line = line & "M" & Chr(0) & Chr(0) & Chr(0)
        line = line & AGW_CALLSIGN(setup.strStationCallsign)
        line = line & AGW_CALLSIGN("APRS")
        line = line & Chr(Len(NMEAline.Text)) & Chr(0) & Chr(0) & Chr(0)
        line = line & Chr(0) & Chr(0) & Chr(0) & Chr(0)
        line = line & NMEAline.Text

        'nmealine.Text 
        Dim ToSend(200) As Byte
        For i As Integer = 1 To Len(line)
            ToSend(i - 1) = Asc(Mid(line, i, 1))
        Next

        If mnuServAGWPE.Checked = True Then
            Try
                tcpAGWPE.Send(ToSend, 0, Len(line), Net.Sockets.SocketFlags.None)
            Catch ex As Exception

            End Try
        End If

    End Sub


    Private Function AGW_CALLSIGN(line as String)

        Dim outline As String
        outline = line.Trim
        outline = outline & Chr(0)
        outline = outline & "          "
        Return Mid(outline, 1, 10)

    End Function



    Private Sub tcpAGWPE_EndConnect(ByVal sender As Object, ByVal e As Dart.PowerTCP.Sockets.ExceptionEventArgs)
        'tcpAGWPE.Send(strings(4, Chr(0)) & "m" & strings(31, Chr(0)))

    End Sub

    Private Sub mnuPopupAddStation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPopupAddStation.Click
        Dim junk As String
        Dim s6 As String
        Dim myreturn As Integer

        junk = InputBox("Please enter Callsign for this position")
        'MsgBox("Hello")
        'junk = "vk2tds"
        'Beep()
        If Len(junk) > 0 Then
            s6 = junk & ">APRS:!" & double_to_dms(txtOziLat.Text, 1) & "/" & double_to_dms(txtOziLon.Text, 0) & "-"
            crosspoint.Submit(portGui, s6)
        End If



    End Sub

    Public Function double_to_dms(ByVal theCoord As Double, ByVal lat As Integer) As String
        Dim temp As String

        temp = Format(Int(Math.Abs(theCoord)), "000")
        temp = temp & Format((Math.Abs(theCoord) - Int(Math.Abs(theCoord))) * 60, "00.00")
        If lat = 0 Then
            If theCoord > 0 Then
                temp = temp & "E"
            Else
                temp = temp & "W"
            End If

        Else
            If theCoord > 0 Then
                temp = temp & "N"
            Else
                temp = temp & "S"
            End If


            temp = Mid(temp, 2)
        End If


        double_to_dms = temp

    End Function



    Private Sub mnuCallsignPopupQRZ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCallsignPopupQRZ.Click

        If InStr(1, txtPopupCallsign.Text, "-") > 0 Then
            Process.Start("http://www.qrz.com/" & Mid(txtPopupCallsign.Text, 1, InStr(1, txtPopupCallsign.Text, "-") - 1))
            '          LaunchUrl("http://www.qrz.com/" & Mid(txtPopupCallsign.Text, 1, InStr(1, txtPopupCallsign.Text, "-") - 1))
        Else
            Process.Start("http://www.qrz.com/" & txtPopupCallsign.Text)
        End If


    End Sub

    Private Sub mnuCallsignPopupFindU_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCallsignPopupFindU.Click

        Process.Start("http://map.findu.com/" & txtPopupCallsign.Text)

    End Sub

    Private Sub mnuPopupFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPopupFilter1.Click, mnuPopupFilter2.Click
        Dim temp As Double

        With setup

            If sender Is mnuPopupFilter1 Then

                .dblGeoFilterLat1 = txtOziLat.Text
                .dblGeoFilterLon1 = txtOziLon.Text

            Else
                .dblGeoFilterLat2 = txtOziLat.Text
                .dblGeoFilterLon2 = txtOziLon.Text

            End If


            If .dblGeoFilterLon1 = 0 Or .dblGeoFilterLon2 = 0 Or .dblGeoFilterLat1 = 0 Or .dblGeoFilterLat2 = 0 Then
            Else
                If .dblGeoFilterLat1 < .dblGeoFilterLat2 Then
                    temp = .dblGeoFilterLat1
                    .dblGeoFilterLat1 = .dblGeoFilterLat2
                    .dblGeoFilterLat2 = temp
                End If

                If .dblGeoFilterLon1 > .dblGeoFilterLon2 Then
                    temp = .dblGeoFilterLon1
                    .dblGeoFilterLon1 = .dblGeoFilterLon2
                    .dblGeoFilterLon2 = temp
                End If
            End If

            SaveApplicationSettings(setup)
            UpdateGeoFilters()
        End With

    End Sub
    Private Sub UpdateGeoFilters()
        With setup
            crosspoint.Submit(portGui, "FILTER-1>APRS:!" & double_to_dms(.dblGeoFilterLat1, 1) & "/" & double_to_dms(.dblGeoFilterLon1, 0) & "-")
            crosspoint.Submit(portGui, "FILTER-2>APRS:!" & double_to_dms(.dblGeoFilterLat2, 1) & "/" & double_to_dms(.dblGeoFilterLon2, 0) & "-")
        End With
    End Sub


    Private Sub mnuPopupMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPopupMove.Click
        'Dim move As New MoveWaypoint(Me)
        If myMOveWaypoint Is Nothing Then
            myMOveWaypoint = New MoveWaypoint(Me)
        Else
            myMOveWaypoint.init()

        End If
        myMOveWaypoint.Show()

    End Sub

    Public Sub CloseMoveWaypoint()
        If Not myMOveWaypoint Is Nothing Then
            myMOveWaypoint.Close()
        End If
    End Sub

    Private Sub FpDevGuiDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuCallsignPopup_Popup(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCallsignPopup.Popup

    End Sub

    Private Sub mnuInterfaceOziAutoTrail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInterfaceOziAutoTrail.Click
        If mnuInterfaceOziAutoTrail.Checked = True Then
            mnuInterfaceOziAutoTrail.Checked = False
        Else
            mnuInterfaceOziAutoTrail.Checked = True
        End If
    End Sub

    Private Sub MenuItem28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpRegister.Click
        Dim frmRegister As New frmRegister(Me)
        frmRegister.Show()

    End Sub

    Private Sub mnuIGPRShardware_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub


    Private Sub CommTNC_OnComm(ByVal line As String) Handles CommTNC.OnRead
        If mnuServTNC.Checked = True Then
            If Not devTNC Is Nothing Then
                Dim junk As Byte()
                Dim temp As String
                Dim i As Integer
                junk = CommTNC.StringToByteArray(line)
                temp = CommTNC.ByteArrayToString(junk)
                temp = ""
                For i = 1 To Len(line)
                    temp = temp & Chr(junk(i - 1))
                Next
                devTNC.msCommTNC_OnComm(junk)
            End If
        End If


    End Sub

    Private Sub mnuServRINO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServRINO.Click
        If mnuServRINO.Checked = True Then
            mnuServRINO.Checked = False
            crosspoint.closePort(portRINO)
            devRINO = Nothing
        Else
            mnuServRINO.Checked = True
            AxeWaypoint1.ComMask = 2 ^ (setup.intRINOComPort - 1)

            devRINO = New devRINO(Me, setup)
            portRINO = crosspoint.NewPort(crosspoint.devices.devRINO, AddressOf devRINO.devRINO_SendOut)
            crosspoint.CrosspointEnable(-1, portRINO, True)
            crosspoint.CrosspointEnable(portRINO, portRINO, False)




        End If







    End Sub





    Private Sub AxeWaypoint1_WaypointStatus(ByVal sender As System.Object, ByVal e As AxEWAYPOINTLib._IeWaypointEvents_WaypointStatusEvent) Handles AxeWaypoint1.WaypointStatus

        With devMonitor
            If .Items.Count > 20 Then
                .Items.RemoveAt(0)
            End If
            .Items.Add(e.status)

        End With


    End Sub

    Private Sub mnuGUIdatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGUIdatabase.Click

        If devDatabaseGui Is Nothing Then
            devDatabaseGui = New devDatabaseGui(Me, setup.strDatabaseFilename)

            devDatabaseGui.Show()
            SetupLanguages("DATABASE", setup.strLanguage)
        Else
            devDatabaseGui.Show()

        End If


    End Sub

    Private Sub devUIVIEW_DataAvailable() Handles devUIVIEW.DataAvailable
        Dim temp As String

        '        Dim cInfo As New UIView32.clsFrameInfo

        'This is the only time when the info returned by
        'GetFrameInfo() will be valid. If you call it
        'at any other time, then you will not know to
        'which frame the info returned relates.
        '       If mUIV.GetFrameInfo(cInfo) Then
        '    Debug.Print cInfo.strSourceAddress
        '    Debug.Print cInfo.strDestAddress
        '    Debug.Print cInfo.eSource
        '    Debug.Print cInfo.ePacketClass
        '    Debug.Print cInfo.blnDirect
        '    Debug.Print cInfo.blnThirdParty
        '    Debug.Print cInfo.eDisplayType
        '      End If

        'ShowText(txtAPRS, mUIV.strAPRSData)
        Dim inputline, header, packet As String

        inputline = devUIVIEW.strAPRSData
        If Len(inputline) < 10 Then
            Exit Sub
        End If
        If Mid(inputline, 1, 1) = "#" Then Exit Sub

        header = Mid(Mid(inputline, 1, InStr(1, inputline, Chr(13)) - 1), 2)
        Dim uifrom, uito As String

        If InStr(3, header, "fm ") = 3 Then
            uifrom = Mid(header, 6, InStr(6, header, " ") - 6)
            uito = Mid(header, InStr(7, header, " ") + 4)
            uito = Mid(uito, 1, InStr(1, uito, " ") - 1)
            header = uifrom & ">" & uito & ":"
            GoTo continuehere
        End If


        If Mid(header, 3, 1) = ":" Then
            header = Mid(header, 11)
        End If
        If InStr(header, " ") > 0 Then
            header = Mid(header, 1, InStr(1, header, " ") - 1)
            If Mid(header, Len(header), 1) <> ":" Then
                header = header & ":"
            End If
        End If

continuehere:
        packet = Mid(inputline, InStr(1, inputline, Chr(13)) + 2)
        packet = Mid(packet, 1, Len(packet) - 2)

        inputline = header & packet

        crosspoint.Submit(portUIView, inputline)

    End Sub

    Private Sub devUIVIEW_UIView32IsClosing() Handles devUIVIEW.UIView32IsClosing
        crosspoint.closePort(portUIView)
        mnuServUIView_Click(Nothing, Nothing)

        devUIVIEW = Nothing

    End Sub

    Private Sub frmmain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        With devMonitor
            .Tag = Int(.Height / .ItemHeight)

        End With

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SaveCallsignTranslations()
    End Sub

    Private Sub SaveCallsignTranslations()

        Dim junk As String
        Dim i As Integer

        junk = "<?xml version=" & Chr(34) & "1.0" & Chr(34) & " standalone=" & Chr(34) & "no" & Chr(34) & " ?>" & vbCrLf & _
            "<!--  Generated by abc. Copyright xyz  --> " & vbCrLf & _
            "<CallsignTranslation>" & vbCrLf

        With FpCallsignTranslation.ActiveSheet
            For i = 0 To .RowCount - 1
                If Len(.Cells(i, CallSignTranslations.OldCallsign).Text) > 0 Then
                    junk = junk & "<Callsigns>" & vbCrLf & _
                    "<FromCallsign>" & vbCrLf & _
                    .Cells(i, CallSignTranslations.OldCallsign).Text() & _
                    "</FromCallsign>" & vbCrLf & _
                    "<ToCallsign>" & vbCrLf & _
                    .Cells(i, CallSignTranslations.NewCallsign).Text() & _
                    "</ToCallsign>" & vbCrLf & _
                    "</Callsigns>" & vbCrLf
                End If
            Next
        End With

        junk = junk & "</CallsignTranslation>" & vbCrLf
        setup.strCallsignTranslations = junk
        SaveSetting("NetAPRS", "NetAPRS", "strCallsignTranslations", junk)

    End Sub



    Private Sub LoadCallsignTranslations(ByVal xmltext As String)



        Dim xmldoc As New XmlDocument

        Dim nodes As XmlNodeList
        Dim node As XmlNode
        Dim basenodes As XmlNodeList
        Dim basenode As XmlNode

        Dim twoxmldoc As New XmlDocument

        Dim twonodes As XmlNodeList
        Dim twonode As XmlNode
        Dim twobasenodes As XmlNodeList
        Dim twobasenode As XmlNode
        Dim i As Integer
        Dim temp As String
        'Return
        Try

            xmldoc.LoadXml(xmltext)
            'Debug.WriteLine("Start POSITION")
            i = 0

            nodes = xmldoc.GetElementsByTagName("CallsignTranslation")
            For Each node In nodes
                basenodes = node.ChildNodes
                For Each basenode In basenodes
                    Select Case basenode.Name
                        Case "Callsigns"
                            twoxmldoc.LoadXml(basenode.OuterXml)
                            twonodes = twoxmldoc.GetElementsByTagName("Callsigns")
                            twobasenodes = twonodes.Item(0).ChildNodes
                            With FpCallsignTranslation.ActiveSheet
                                For Each twobasenode In twobasenodes
                                    temp = Trim(twobasenode.InnerText)
                                    temp = temp.Replace(vbCr, "")
                                    temp = temp.Replace(vbLf, "")
                                    Select Case twobasenode.Name
                                        Case "FromCallsign"
                                            .Cells(i, CallSignTranslations.OldCallsign).Text = temp
                                        Case "ToCallsign"
                                            .Cells(i, CallSignTranslations.NewCallsign).Text = temp
                                    End Select
                                Next
                            End With
                            i += 1
                        Case Else
                    End Select
                Next
            Next
        Catch ex As Exception

        End Try

    End Sub

    Public Function CallsignTranslate(ByVal InCallsign As String) As String
        Dim i As Integer

        With FpCallsignTranslation.ActiveSheet
            For i = 0 To .RowCount - 1
                If .Cells(i, CallSignTranslations.OldCallsign).Text = InCallsign Then
                    Return .Cells(i, CallSignTranslations.NewCallsign).Text
                End If
            Next
            Return InCallsign
        End With

    End Function


    Private Sub mnuGuiTranslate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGuiTranslate.Click
        If mnuGuiTranslate.Checked = True Then
            mnuGuiTranslate.Checked = False
        Else
            mnuGuiTranslate.Checked = True
        End If


    End Sub

    Private Sub mnuGuiGeo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGuiGeo.Click
        If mnuGuiGeo.Checked = True Then
            mnuGuiGeo.Checked = False
            setup.boolInterfaceGeo = False
        Else
            mnuGuiGeo.Checked = True
            setup.boolInterfaceGeo = True
            UpdateGeoFilters()
        End If
    End Sub

    Private Sub mnuFileSetup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSetup.Click
        frmSetup = New frmSetup(setup, Me)

        frmSetup.Show()
        SetupLanguages("SETUP", setup.strLanguage)
    End Sub

    Private Sub mnuGuiMonitored_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGuiMonitored.Click

    End Sub

    Private Sub mnuPopup_Popup(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPopup.Popup

    End Sub

    Private Sub FpLanguages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FpLanguages.Click

    End Sub

    Private Sub FpDevGuiDisplay_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FpDevGuiDisplay.Click

    End Sub
    Public Sub CrosspointSubmitProxy(ByVal PortIn As Integer, ByVal line As String)
        Call crosspoint.Submit(PortIn, line)

    End Sub

    Private Sub mnuServRealTrack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuServRealTrack.Click
        If mnuServRealTrack.Checked = True Then
            mnuServRealTrack.Checked = False
            crosspoint.closePort(portRealTrack)
            'devRealTrack = Nothing
        Else
            mnuServRealTrack.Checked = True
            'devRealTrack = New devRealTrack(Me, setup)

            portRealTrack = crosspoint.NewPort(crosspoint.devices.devRealTrack, Nothing)
            crosspoint.CrosspointEnable(-1, portRealTrack, False)
            crosspoint.CrosspointEnable(portRealTrack, portRealTrack, False)

            tcpRealTrack.Listen(1596)

        End If
    End Sub

    Private Sub mnuInterfaceOziGetGPS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInterfaceOziGetGPS.Click
        If mnuInterfaceOziGetGPS.Checked = True Then
            mnuInterfaceOziGetGPS.Checked = False
            oziSendMMpositionOFF()
        Else
            mnuInterfaceOziGetGPS.Checked = True
            delTMMpositionCallback = AddressOf positionCallback
            oziSendMMpositionON(delTMMpositionCallback)
        End If
    End Sub

    Private Sub positionCallback(ByVal Lat As Double, ByVal lon As Double, _
    ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)

        '"#GPRMC,092204.999,A,4250.5589,S,14718.5084,E,2.00,89.68,211200,," + Constants.ROWDELIMITER

        txtOziLat.Text = Lat
        txtOziLon.Text = lon



        Dim nmeastring As String
        Dim directionns As String
        Dim directionwe As String


        nmeastring = "#GPRMC,"
        nmeastring = nmeastring & Format(Now, "HHmmss") & ".000,A,"

        If Lat < 0 Then
            directionns = "S"
        Else
            directionns = "N"
        End If
        Lat = Math.Abs(Lat)
        nmeastring = nmeastring & Format(Int(Lat), "00")
        Lat = Lat - Int(Lat)
        Lat = Lat * 60
        nmeastring = nmeastring & Format(Lat, "00.0000")
        nmeastring = nmeastring & "," & directionns & ","

        If lon < 0 Then
            directionwe = "W"
        Else
            directionwe = "E"
        End If
        lon = Math.Abs(lon)
        nmeastring = nmeastring & Format(Int(lon), "000")
        lon = lon - Int(lon)
        lon = lon * 60
        nmeastring = nmeastring & Format(lon, "00.0000")
        nmeastring = nmeastring & "," & directionwe
        nmeastring = nmeastring & "," & Format(Speed) & "," & Format(COurse)
        nmeastring = nmeastring & "," & Format(Now, "ddMMyy") & ",012.6,E"
        NMEAline.Text = nmeastring



    End Sub

    Private Sub GPS_PositionChanged(ByVal sender As Object, ByVal e As PositionEventArgs) Handles GPS.PositionChanged

        Dim lat As Double
        Dim lon As Double
        lon = e.Position.Longitude.DecimalDegrees
        lat = e.Position.Latitude.DecimalDegrees

        Dim junk As String


        '"#GPRMC,092204.999,A,4250.5589,S,14718.5084,E,2.00,89.68,211200,," + Constants.ROWDELIMITER

        txtLat.Text = lat
        txtLon.Text = lon



        Dim nmeastring As String
        Dim directionns As String
        Dim directionwe As String


        nmeastring = "$GPRMC,"
        nmeastring = nmeastring & Format(GPS.UtcDateTime, "HHmmss") & ".000,A,"

        If lat < 0 Then
            directionns = "S"
        Else
            directionns = "N"
        End If
        lat = Math.Abs(lat)
        nmeastring = nmeastring & Format(Int(lat), "00")
        lat = lat - Int(lat)
        lat = lat * 60
        nmeastring = nmeastring & Format(lat, "00.0000")
        nmeastring = nmeastring & "," & directionns & ","

        If lon < 0 Then
            directionwe = "W"
        Else
            directionwe = "E"
        End If
        lon = Math.Abs(lon)
        nmeastring = nmeastring & Format(Int(lon), "000")
        lon = lon - Int(lon)
        lon = lon * 60
        nmeastring = nmeastring & Format(lon, "00.0000")
        nmeastring = nmeastring & "," & directionwe
        nmeastring = nmeastring & "," & Format(GPS.Speed.Value) & "," & Format(GPS.Bearing.DecimalDegrees)
        nmeastring = nmeastring & "," & Format(GPS.UtcDateTime, "ddMMyy") & ",012.6,E"
        NMEAline.Text = nmeastring

    End Sub

#Region " Starting and Stopping GPS Information "
    Private Sub GPS_COMStart()
        ' Make sure we have a valid COM port
        '        If ComPort.Text = "" Then
        '        MsgBox("Please select the COM port connected to your GPS device, then click Start.", MsgBoxStyle.Information Or MsgBoxStyle.OKOnly)
        '        Exit Sub
        'End If
        ' Set the COM port to the numeric portion of the selected item in to combo box
        GPS.Device.Settings.ComPort = setup.intGPSport
        ' NOTE: It's important to add error checking around the Start() method and Enabled property
        Try
            ' Start receiving messages
            GPS.Start()
            ' Enable the Stop button, disable the Start button
        Catch ex As GpsException
            ' Notify of the error
            MsgBox(ex.Message, MsgBoxStyle.Exclamation Or MsgBoxStyle.OKOnly)
        End Try
    End Sub

    Private Sub GPS_COMStop()
        GPS.Stop()
    End Sub
#End Region

    Public Function cbl(ByVal onestring As String) As Boolean
        Try
            Return CBool(onestring)
        Catch ex As Exception
            Return False

        End Try
        Return False

    End Function

    Public Function fixmicrosoft(ByVal ar() As Byte) As String
        Dim i As Integer
        Dim temp As String = ""
        For i = 0 To ar.GetLength(0) - 1
            temp = temp & Chr(ar(i))
        Next
        Return temp

    End Function


    Public Function mytrim(ByVal mystr As String) As String
        If InStr(1, mystr, Chr(0)) > 1 Then
            mystr = Mid(mystr, 1, InStr(1, mystr, Chr(0)) - 1)
            mytrim = mystr
        Else
            mytrim = mystr
        End If


    End Function

    Public Function realstrings(ByVal length As Integer, ByVal charac As String) As String
        Dim i As Integer
        Dim temp As String = ""

        For i = 1 To length
            temp = temp & charac
        Next
        Return temp

    End Function
    Declare Function oziFindBestMap Lib "oziapi" (ByVal lat As Double, ByVal lon As Double, ByVal subfolders As Integer, ByRef Path As String, ByRef MapFile As String) As Integer
    Declare Function oziFindMapAtPosition Lib "oziapi" (ByVal lat As Double, ByVal lon As Double) As Integer

    Private Sub mnuMapAtCursor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMapAtCursor.Click
        oziFindMapAtPosition(CDbl(txtOziLat.Text), CDbl(txtOziLon.Text))

    End Sub

    Private Sub mnuBestMapAtCursor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBestMapAtCursor.Click
        oziFindBestMap(CDbl(txtOziLat.Text), CDbl(txtOziLon.Text), 1, "", "")
    End Sub

    Private Sub Command4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command4.Click
        Dim MediaPlayer1 As Object
        Dim temp As Object

        If mnuServerAGWPE.Checked = False Then
            MsgBox("Please connect to AGWPE first")
        End If


        With OpenFileDialog1



            .FileName = filename
            .DefaultExt = ".wmv"
            .Filter = "WMV files (*.wmv)|*.wmv"
            .Title = "Please choose the WMV file to load"
            .ShowDialog()

            'UPGRADE_WARNING: Couldn't resolve default property of object temp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            temp = .FileName

        End With


        'UPGRADE_WARNING: Couldn't resolve default property of object MediaPlayer1.filename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        'UPGRADE_WARNING: Couldn't resolve default property of object temp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        MediaPlayer1.filename = temp

        frmModeRecording_Click(frmModeRecording, New System.EventArgs)

        'MediaPlayer1.Play

    End Sub

    Private Sub Command1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command1.Click
        Dim MediaPlayer1 As Object



        'UPGRADE_WARNING: Couldn't resolve default property of object MediaPlayer1.filename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        MediaPlayer1.filename = filename
        MediaPlayer1.Play()

    End Sub

    Dim t1 As Double
    Dim t2 As Double

    Dim filename As String

    Dim Lines() As String
    Dim LinesTime() As Double
    Dim LineCount As Short
    Dim LineCountPointer As Short


    Dim l1 As String
    Dim l2 As String


    Private Sub InitLines()
        t1 = 240000
        t2 = 0
        l1 = ""
        l2 = ""

    End Sub

    Private video As Microsoft.DirectX.AudioVideoPlayback.Video

    Private Sub Command5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command5.Click
        'Dim MediaPlayer1 As Object
        Dim mediafilename As Object

        InitLines()
        'Dim filename As String




        'MediaPlayer1.filename = "c:\temp\testx.wmv"
        'Close #7
        If Len(filename) > 3 Then
            'UPGRADE_WARNING: Couldn't resolve default property of object mediafilename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            mediafilename = Mid(filename, 1, Len(filename) - 3) & "WMV"
        Else
            'UPGRADE_WARNING: Couldn't resolve default property of object mediafilename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            mediafilename = "jjjdskfa"
        End If
        'UPGRADE_WARNING: Couldn't resolve default property of object mediafilename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        'UPGRADE_WARNING: Dir has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1041"'
        If Len(Dir(mediafilename)) > 0 Then

            'UPGRADE_WARNING: Couldn't resolve default property of object MediaPlayer1.filename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            'UPGRADE_WARNING: Couldn't resolve default property of object mediafilename. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'

            frmModePlayback_Click(frmModePlayback, New System.EventArgs)

            If Not video Is Nothing Then
                With video
                    .Stop()
                    .Dispose()
                End With
                video = Nothing
            End If

            video = New Microsoft.DirectX.AudioVideoPlayback.Video(mediafilename)

            If video Is Nothing Then
            Else
                With video
                    .Owner = VideoPanel
                    .Size = VideoPanel.Size
                    .Play()
                    Timer1.Enabled = True
                End With

            End If
        Else

            MsgBox("MediaPlayer File Not Found")

        End If


    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProductLive.Click
        mnuProductBasic.Checked = False
        mnuProductLive.Checked = True
        mnuProductPro.Checked = False

        mnuFilesave.Enabled = False

        mnuTNCcom.Enabled = True
        mnuTNCconnect.Enabled = True

        mnuServerAGWPE.Enabled = True

    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmModeLive.Click
        frmModePlayback.Checked = False
        frmModeRecording.Checked = True
        frmModeLive.Checked = False

    End Sub

    Private Sub mnuProductBasic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProductBasic.Click
        mnuProductBasic.Checked = True
        mnuProductLive.Checked = False
        mnuProductPro.Checked = False

        mnuTNCcom.Enabled = False
        mnuTNCconnect.Enabled = False

        mnuServerAGWPE.Enabled = False
        mnuFilesave.Enabled = False

    End Sub

    Private Sub mnuProductPro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProductPro.Click
        mnuProductBasic.Checked = False
        mnuProductLive.Checked = False
        mnuProductPro.Checked = True

        mnuTNCcom.Enabled = True
        mnuTNCconnect.Enabled = True

        mnuServerAGWPE.Enabled = True

        mnuFilesave.Enabled = False


    End Sub

    Private Sub frmModePlayback_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmModePlayback.Click
        frmModePlayback.Checked = True
        frmModeRecording.Checked = False
        frmModeLive.Checked = False

    End Sub

    Private Sub frmModeRecording_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmModeRecording.Click
        frmModePlayback.Checked = False
        frmModeRecording.Checked = False
        frmModeLive.Checked = True

    End Sub

    Private Sub mnuFileLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileLoad.Click

        Dim temp As String

        With OpenFileDialog1


            .FileName = filename
            .DefaultExt = ".ctp"
            .Filter = "CamTrak files (*.ctp)|*.ctp"
            .Title = "Please enter full filename to load"
            .ShowDialog()

            temp = .FileName

            If temp <> "" Then
                filename = temp
                LoadFile((filename))
            End If



        End With
    End Sub
    Private Sub LoadFile(ByRef filename As Object)
        Dim myline As Object

        If System.IO.File.Exists(Mid(filename, 1, Len(filename) - 3) & "WMV") = False Then
            MsgBox("The WMV was not found in the direactory")
            Exit Sub
        End If

        FileOpen(7, filename, OpenMode.Input)
        LineCount = 0

        On Error GoTo MyError
        While Not EOF(7)
            LineCount = LineCount + 1
            ReDim Preserve Lines(LineCount)
            ReDim Preserve LinesTime(LineCount)
            myline = LineInput(7)

            Lines(LineCount) = Mid(myline, InStr(1, myline, ",") + 1)
            LinesTime(LineCount) = CDbl(Mid(myline, 1, InStr(1, myline, ",") - 1))

        End While
        FileClose(7)

        On Error GoTo 0
        Exit Sub
MyError:

        MsgBox("NO CTP FILE FOUND")


    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim i As Object
        Dim e1 As Object
        Dim b As Object
        'Dim MediaPlayer1 As Object

        Dim mytime As Double


        'UPGRADE_WARNING: Couldn't resolve default property of object MediaPlayer1.CurrentPosition. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        mytime = video.CurrentPosition



        On Error Resume Next
        If mytime < t2 And mytime > t1 Then


        Else

            If mytime < LinesTime(1) Or mytime > LinesTime(LineCount) Then
                GoTo done
            End If

            If LineCountPointer = 0 Then
                LineCountPointer = LineCount
            End If

            b = 1
            e1 = LineCount - 1

            If mytime < t1 Then
                e1 = LineCountPointer
            Else
                b = LineCountPointer
            End If
            For i = b To e1
                If LinesTime(i) < mytime And LinesTime(i + 1) > mytime Then
                    t2 = LinesTime(i + 1)
                    t1 = LinesTime(i)
                    LineCountPointer = i

                    GoTo done

                End If

            Next i



        End If

        On Error GoTo 0


done:
        Processline(Lines(LineCountPointer), "")
        Timer1.Enabled = True


    End Sub


    Private Function DevCamtrack_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)
        Processline(Line, "AGWPE")

    End Function



    Function Processline(ByRef inputline As String, ByRef datasource As String, Optional ByRef TimeDate As Double = 0, Optional ByRef TimeOffset As Short = 0) As Short
        Dim directionWE As Object
        Dim lon As Object
        Dim directionNS As Object
        Dim lat As Object
        Dim NmeaString As Object
        Dim waypoint As Object
        Dim myreturn As Object
        Dim feet As Object
        Dim mytime As Object
        Dim retval As Object
        'Dim MediaPlayer1 As Object
        ' Process the incoming line


        Dim header As String
        Dim Packet As String
        Dim mycall As String
        Dim lllat As Double
        Dim lllong As Double
        Dim mycol As Integer
        Dim i As Short
        Dim originalline As String
        Dim weather As String
        Dim direction As String

        Processline = False


        If frmModeRecording.Checked Then


            LineCount = LineCount + 1
            ReDim Preserve Lines(LineCount)
            ReDim Preserve LinesTime(LineCount)


            Lines(LineCount) = inputline
            LinesTime(LineCount) = CDbl(video.CurrentPosition)


        End If


        Text2.Text = inputline '& " " & Format(MediaPlayer1.CurrentPosition)
        Select Case Label1.Text
            Case "|"
                Label1.Text = "/"
            Case "/"
                Label1.Text = "-"
            Case "-"
                Label1.Text = "\"
            Case Else
                Label1.Text = "|"
        End Select



        originalline = inputline

        For i = 1 To Len(inputline)
            If Asc(Mid(inputline, i, 1)) < 28 Or Asc(Mid(inputline, i, 1)) > 127 Then
                Processline(Mid(inputline, i + 1), datasource)
                If i > 1 Then
                    inputline = Strings.Left(inputline, i - 1)
                Else
                    inputline = ""
                End If
                Exit For
            End If
        Next i

        crosspoint.Submit(1, inputline)

        ''UPGRADE_WARNING: Couldn't resolve default property of object retval. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        'retval = aprs_decode(inputline)

        'If (dataValid) Then
        '    'Text1.Text = packetSource
        '    mycol = RGB(255, 255, 0)
        '    weather = ""
        '    If Len(packetWindSpeed) > 0 Then
        '        weather = weather & "Wind Speed and Direction :: " & packetWindSpeed & "Knots " & packetWindDirection & "Deg" & vbCrLf
        '        mycol = RGB(255, 128, 128)
        '    End If
        '    If Val(packetTemperature) <> 0 Then
        '        weather = weather & "Temperature :: " & packetTemperature & "F or " & VB6.Format((CShort(Val(packetTemperature)) - 32) * 5 / 8) & "C" & vbCrLf
        '    End If
        '    'UPGRADE_WARNING: Couldn't resolve default property of object mytime. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    mytime = "Last Heard: " & VB6.Format(TimeValue(CStr(TimeOfDay)).ToOADate() + DateValue(CStr(Today)).ToOADate(), "General date")

        '    If Len(inputline) > 40 Then
        '        inputline = Mid(inputline, 1, Len(inputline) / 2) & vbCrLf & "   " & Mid(inputline, Len(inputline) / 2 + 1)
        '    End If
        '    If packetSpeed > 0 Or packetcourse > 0 Or packetAltitude > 0 Then
        '        'UPGRADE_WARNING: Couldn't resolve default property of object feet. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        inputline = inputline & vbCrLf & "Speed " & VB6.Format(packetSpeed) & " knots, Course " & VB6.Format(packetcourse, "##0") & " degrees, Altitude " & VB6.Format(packetAltitude, "####0") & " " & feet
        '        mycol = RGB(128, 255, 128)
        '    End If
        '    If TimeDate = 0 Then
        '        'UPGRADE_WARNING: Couldn't resolve default property of object mytime. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(packetLong, packetLongMin, packetLongSec). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object myreturn. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        myreturn = spreadAddUpdate(0, packetSource, 0, dms_to_double(packetLat, packetLatMin, packetLatSec), dms_to_double(packetLong, packetLongMin, packetLongSec), packetAltitude, packetSpeed, packetcourse, vbCrLf & weather & inputline & vbCrLf & mytime & vbCrLf, datasource, originalline, mycol, System.Date.FromOADate(Today.ToOADate() + TimeOfDay.ToOADate()), System.Date.FromOADate(CShort(TimeZoneData.Bias)))
        '    Else
        '        'UPGRADE_WARNING: Couldn't resolve default property of object mytime. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(packetLong, packetLongMin, packetLongSec). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        'UPGRADE_WARNING: Couldn't resolve default property of object myreturn. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        myreturn = spreadAddUpdate(0, packetSource, 0, dms_to_double(packetLat, packetLatMin, packetLatSec), dms_to_double(packetLong, packetLongMin, packetLongSec), packetAltitude, packetSpeed, packetcourse, vbCrLf & weather & inputline & vbCrLf & mytime & vbCrLf, datasource, originalline, mycol, System.Date.FromOADate(CDbl(TimeDate)), System.Date.FromOADate(CShort(TimeOffset)))
        '    End If

        '    'UPGRADE_WARNING: Couldn't resolve default property of object waypoint. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    waypoint = "$GPWPL,"

        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = "$GPWPL,"
        '    'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lat. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lat = dms_to_double(packetLat, packetLatMin, packetLatSec)
        '    If packetLat < 0 Then
        '        'UPGRADE_WARNING: Couldn't resolve default property of object directionNS. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        directionNS = "S"
        '    Else
        '        'UPGRADE_WARNING: Couldn't resolve default property of object directionNS. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        directionNS = "N"
        '    End If
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lat. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lat = System.Math.Abs(lat)
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & VB6.Format(Int(CDbl(lat)), "00")
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lat. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lat = lat - Int(CDbl(lat))
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lat. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lat = lat * 60
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lat. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & VB6.Format(lat, "00.000")
        '    'UPGRADE_WARNING: Couldn't resolve default property of object directionNS. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & "," & directionNS & ","

        '    'UPGRADE_WARNING: Couldn't resolve default property of object dms_to_double(). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lon = dms_to_double(packetLong, packetLongMin, packetLongSec)
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    If lon < 0 Then
        '        'UPGRADE_WARNING: Couldn't resolve default property of object directionWE. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        directionWE = "W"
        '    Else
        '        'UPGRADE_WARNING: Couldn't resolve default property of object directionWE. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '        directionWE = "E"
        '    End If
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lon = System.Math.Abs(lon)
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & VB6.Format(Int(CDbl(lon)), "000")
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lon = lon - Int(CDbl(lon))
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    lon = lon * 60
        '    'UPGRADE_WARNING: Couldn't resolve default property of object lon. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & VB6.Format(lon, "00.000")
        '    'UPGRADE_WARNING: Couldn't resolve default property of object directionWE. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    'UPGRADE_WARNING: Couldn't resolve default property of object NmeaString. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        '    NmeaString = NmeaString & "," & directionWE & "," & packetSource
        '    'For x = 0 To frmMain.wsArray.UBound
        '    '    If frmMain.wsArray(x).LocalPort = 8001 Then
        '    '        If frmMain.wsArray(x).State = 7 Then
        '    '            frmMain.wsArray(x).SendData NmeaString & vbCrLf
        '    '        End If
        '    '    End If
        '    'Next x
        'Else
        '    'If data not valid
        'End If

        Processline = True
    End Function

    Private Sub VideoPanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles VideoPanel.Paint

    End Sub

    Private Sub VideoPanel_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles VideoPanel.Resize
        If Not video Is Nothing Then
            video.Size = VideoPanel.Size
        End If
    End Sub

    Private Sub Command5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command5.Click

    End Sub
End Class
