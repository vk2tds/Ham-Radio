Imports System.Xml

Public Class frmSetup
    Inherits System.Windows.Forms.Form
    Private crc32Table() As Long
    Dim CommTNC As SerialNET.Port

    Public Structure SetupStructure
        'Station
        Dim strStationCallsign As String ' Mycall
        Dim strLanguage As String
        'Network
        Dim strOutgoingServer As String
        Dim strOutgoingServerLogin As String
        Dim strOutgoingServerConnectString As String
        Dim boolOutgoingServerAutoConnect As Boolean

        Dim boolIncomingServerAutoStart As Boolean
        Dim boolIncomingServerDumpHistory As Boolean
        Dim boolIncomingGPRSAutoStart As Boolean
        Dim boolIncomingNetGPSAutoStart As Boolean
        'Interfaces
        Dim intTNCComPort As Integer
        Dim intTNCComSpeed As Integer
        Dim boolTNCKissMode As Boolean
        Dim boolTNCAutoConnect As Boolean
        Dim boolAGWPEAutoConnect As Boolean
        Dim boolUploadNonLive As Boolean
        Dim boolInterfaceOziAutoTrailMoving As Boolean
        Dim intIncomingGPRSport As Integer
        Dim intIncomingHubport As Integer
        Dim intIncomingNetGPSport As Integer
        Dim boolTNCMonitorOnly As Boolean


        'Dim dblOziLat As Double
        'Dim dblOziLon As Double

        Dim dblLat As Double
        Dim dblLon As Double
        Dim boolNMEAOziAutoStart As Boolean
        Dim boolNMEAAutoStart As Boolean
        Dim intNMEAComPort As Integer
        Dim intNMEAComSpeed As Integer

        Dim intRINOComPort As Integer
        Dim boolRinoAutoStart As Boolean

        Dim boolMonitorUploadOnly As Boolean
        Dim boolGeoFilterAutoStart As Boolean
        Dim dblGeoFilterLat1 As Double
        Dim dblGeoFilterLat2 As Double
        Dim dblGeoFilterLon1 As Double
        Dim dblGeoFilterLon2 As Double

        '        Dim boolDecayAutoStart As Boolean
        Dim boolStateAutosave As String
        Dim strStateFilename As String
        Dim boolStateAutoload As Boolean
        Dim boolInterfaceOziStartup As Boolean
        Dim boolInterfaceOziOntop As Boolean
        Dim boolInterfaceMapPointStartup As Boolean
        Dim boolInterfaceUIViewStartup As Boolean


        ' Database

        Dim strDatabaseFilename As String
        Dim boolDatabaseAutoStart As String

        'Debug
        Dim strDebugLogFilename As String
        Dim boolDebugLogAutoStart As String

        ' iGPRS
        Dim strIGPRSip_1 As String
        Dim strIGPRSip_2 As String
        Dim strIGPRSapn As String
        Dim intIGPRSp_1 As Integer
        Dim intIGPRSp_2 As Integer
        Dim intIGPRSport As Integer
        Dim intIGPRSrate As Integer

        ' iGate
        Dim boolIGatePosRf As Boolean
        Dim booliGateMsgRF As Boolean
        Dim booliGateObjRf As Boolean
        Dim booliGateWxRf As Boolean

        Dim intIGatePosRate As Integer
        Dim intIGateMsgRate As Integer
        Dim intIGateObjRate As Integer
        Dim intIGateWxRate As Integer
        Dim intIGateRate As Integer

        Dim strCallsignTranslations As String
        Dim boolCallsignTranslate As Boolean



        Dim boolShowFile As Boolean
        Dim boolShowSetup As Boolean
        Dim boolShowServices As Boolean
        Dim boolShowGUI As Boolean
        Dim boolShowHelp As Boolean
        Dim boolShowTNC As Boolean
        Dim boolShowGPS As Boolean
        Dim boolShowWX As Boolean
        Dim boolShowRINO As Boolean
        Dim boolShowLOG As Boolean

        Dim boolShowNetwork As Boolean
        Dim boolShowOzi As Boolean
        Dim boolShowMapPoint As Boolean
        Dim boolShowAGWPEUIVIEW As Boolean
        Dim boolShowOziSyncClear As Boolean
        Dim boolShowOziDecay As Boolean
        Dim boolShowOziAutotrail As Boolean
        Dim boolShowGeoFilter As Boolean
        Dim boolShowDatabase As Boolean
        Dim boolShowUploadMonitored As Boolean
        Dim boolShowTranslated As Boolean
        Dim boolShowInterface As Boolean
        Dim boolShowLogDatabase As Boolean

        Dim boolUIShowPos As Boolean
        Dim boolUIShowWx As Boolean
        Dim boolUIShowMsgs As Boolean
        Dim boolUIShowObjs As Boolean

        Dim boolErrorLog As Boolean
        Dim boolErrorMsg As Boolean


        Dim txtBCNdigi As String
        Dim txtBCNsymbol As String
        Dim txtBCNtable As String
        Dim intBCNtxrate As String

        Dim chkSmartEnable As Boolean
        Dim intBCNTurnAngle As Integer
        Dim intBCNTurnSlope As Integer
        Dim intBCNTurnTIme As Integer

        Dim intBCNSlowSpeed As Integer
        Dim intBCNslowRate As Integer
        Dim intBCNfastSpeed As Integer
        Dim intBCNfastRate As Integer

        Dim boolBCNMICE As Boolean
        Dim boolBCNMICEPrintable As Boolean
        Dim intBCNMICEmessage As Integer
        Dim intBCNmicePATH As Integer

        Dim boolBCNvalid As Boolean
        Dim boolBCNDHM As Boolean
        Dim boolBCNHMS As Boolean
        Dim boolBCNSendAlt As Boolean
        Dim boolBCNSendNMEA As Boolean
        Dim boolBCNAltDigi As Boolean

        Dim txtBCNStatus As String
        Dim intBCNSendEvery As Integer
        Dim boolBCNSendSeperate As Boolean


        Dim intGPSport As Integer

        ' Non UI things

        Dim boolInterfaceOziConnected As Boolean
        Dim boolInterfaceMapPOintConnected As Boolean
        Dim boolInterfaceOziDecay As Boolean
        Dim boolInterfaceOziDecayStartup As Boolean
        Dim boolInterfaceOziAutoTrailNow As Boolean
        Dim boolInterfaceGeo As Boolean
        Dim boolInterfaceOziGPS As Boolean

        ' Rate Temp Buffer
        Dim intIGatePosRate1 As Integer
        Dim intIGateMsgRate1 As Integer
        Dim intIGateObjRate1 As Integer
        Dim intIGateWxRate1 As Integer
        Dim intIGateRate1 As Integer
        Dim intIGatePosRate2 As Integer
        Dim intIGateMsgRate2 As Integer
        Dim intIGateObjRate2 As Integer
        Dim intIGateWxRate2 As Integer
        Dim intIGateRate2 As Integer



    End Structure

    Dim MasterForm As Object
    Dim setup As SetupStructure

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal mySetup As SetupStructure, ByVal myMasterForm As Object)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        setup = mySetup
        MasterForm = myMasterForm

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkAutoGPRSListen As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoHUBlisten As System.Windows.Forms.CheckBox
    Friend WithEvents chkHubDumpHistory As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoServerConnect As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoNetGPSListen As System.Windows.Forms.CheckBox
    Friend WithEvents chkRINOauto As System.Windows.Forms.CheckBox
    Friend WithEvents chkTNCAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkTNCKiss As System.Windows.Forms.CheckBox
    Friend WithEvents chkAGWPEauto As System.Windows.Forms.CheckBox
    Friend WithEvents chkUploadDelay As System.Windows.Forms.CheckBox
    Friend WithEvents chkStateSaveAuto As System.Windows.Forms.CheckBox
    Friend WithEvents ChkGeoAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkMonAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkLogAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkStateLoadAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkInterfaceOziStartup As System.Windows.Forms.CheckBox
    Friend WithEvents chkInterfaceMappointStartup As System.Windows.Forms.CheckBox
    Friend WithEvents chkInterfaceUIViewStartup As System.Windows.Forms.CheckBox
    Friend WithEvents ChkDecayAuto As System.Windows.Forms.CheckBox
    Friend WithEvents txtCallsign As System.Windows.Forms.TextBox
    Friend WithEvents txtOutgoingServer As System.Windows.Forms.TextBox
    Friend WithEvents txtLogFilename As System.Windows.Forms.TextBox
    Friend WithEvents txtLoginString As System.Windows.Forms.TextBox
    Friend WithEvents txtConnectString As System.Windows.Forms.TextBox
    Friend WithEvents txtAutoSaveFilename As System.Windows.Forms.TextBox
    Friend WithEvents chkOziOnTop As System.Windows.Forms.CheckBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents cmbRINOcom As System.Windows.Forms.ComboBox
    Friend WithEvents cmbTNCSpeed As System.Windows.Forms.ComboBox
    Friend WithEvents cmbTNCcom As System.Windows.Forms.ComboBox
    Friend WithEvents chkOziTrail As System.Windows.Forms.CheckBox
    Friend WithEvents chkNMEAauto As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents chkDBConnectAuto As System.Windows.Forms.CheckBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents txtDatabaseFilename As System.Windows.Forms.TextBox
    Friend WithEvents cboNetGPSport As System.Windows.Forms.ComboBox
    Friend WithEvents cboGPRSport As System.Windows.Forms.ComboBox
    Friend WithEvents cboHubPort As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Delay As System.Windows.Forms.TextBox
    Friend WithEvents APN As System.Windows.Forms.TextBox
    Friend WithEvents Port_2 As System.Windows.Forms.TextBox
    Friend WithEvents IP_2 As System.Windows.Forms.TextBox
    Friend WithEvents Port_1 As System.Windows.Forms.TextBox
    Friend WithEvents IP_1 As System.Windows.Forms.TextBox
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents cboIGPRSport As System.Windows.Forms.ComboBox
    Friend WithEvents chkTNCMonitorOnly As System.Windows.Forms.CheckBox
    Friend WithEvents chkIGatePosRF As System.Windows.Forms.CheckBox
    Friend WithEvents chkIGateMsgRF As System.Windows.Forms.CheckBox
    Friend WithEvents chkIGateObjRF As System.Windows.Forms.CheckBox
    Friend WithEvents chkIGateWxRF As System.Windows.Forms.CheckBox
    Friend WithEvents txtIGatePosRate As System.Windows.Forms.TextBox
    Friend WithEvents txtIGateMsgRate As System.Windows.Forms.TextBox
    Friend WithEvents txtIGateObjRate As System.Windows.Forms.TextBox
    Friend WithEvents txtIGateWxRate As System.Windows.Forms.TextBox
    Friend WithEvents txtIGateRate As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents chkCallsignTranslation As System.Windows.Forms.CheckBox
    Friend WithEvents grpGPS As System.Windows.Forms.GroupBox
    Friend WithEvents lblGPSspeed As System.Windows.Forms.Label
    Friend WithEvents lblGPSport As System.Windows.Forms.Label
    Friend WithEvents lblRadioBeacon As System.Windows.Forms.Label
    Friend WithEvents lblNetworkBeacon As System.Windows.Forms.Label
    Friend WithEvents chkLoopbackPos As System.Windows.Forms.CheckBox
    Friend WithEvents lblCallsign As System.Windows.Forms.Label
    Friend WithEvents grpIncoming As System.Windows.Forms.GroupBox
    Friend WithEvents gprOutgoing As System.Windows.Forms.GroupBox
    Friend WithEvents lblOnConnect As System.Windows.Forms.Label
    Friend WithEvents lblLoginString As System.Windows.Forms.Label
    Friend WithEvents lblOutgoingServer As System.Windows.Forms.Label
    Friend WithEvents grpXML As System.Windows.Forms.GroupBox
    Friend WithEvents lblXMLdirectory As System.Windows.Forms.Label
    Friend WithEvents chkXMLAutoExport As System.Windows.Forms.CheckBox
    Friend WithEvents grpPrograms As System.Windows.Forms.GroupBox
    Friend WithEvents chkOziDownloadMyPos As System.Windows.Forms.CheckBox
    Friend WithEvents grpRINO As System.Windows.Forms.GroupBox
    Friend WithEvents lblRINOcomport As System.Windows.Forms.Label
    Friend WithEvents lblTNCSpeed As System.Windows.Forms.Label
    Friend WithEvents lblTNCComPort As System.Windows.Forms.Label
    Friend WithEvents gpriGate As System.Windows.Forms.GroupBox
    Friend WithEvents lbliGateTotalLimit As System.Windows.Forms.Label
    Friend WithEvents lblRateLimit As System.Windows.Forms.Label
    Friend WithEvents lblStateFilename As System.Windows.Forms.Label
    Friend WithEvents grpDatabase As System.Windows.Forms.GroupBox
    Friend WithEvents lblDatabaseFilename As System.Windows.Forms.Label
    Friend WithEvents lblLogFilename As System.Windows.Forms.Label
    Friend WithEvents lbliGPRSCom As System.Windows.Forms.Label
    Friend WithEvents lblrate As System.Windows.Forms.Label
    Friend WithEvents lblAPN As System.Windows.Forms.Label
    Friend WithEvents lblIPPort As System.Windows.Forms.Label
    Friend WithEvents lblIPaddress As System.Windows.Forms.Label
    Friend WithEvents lblServer2 As System.Windows.Forms.Label
    Friend WithEvents lblServer1 As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnConfig As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboLanguage As System.Windows.Forms.ComboBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents chkShowOzi As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowNetwork As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowHelp As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowGUI As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowServices As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowFile As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowSetup As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowMapPoint As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowAGWPEUIVIEW As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowTNC As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowGPS As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowWx As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowRINO As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowLOG As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowGeofiltering As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowUploadMonitored As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowTranslate As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowOziSyncClear As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowOziDecay As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowOziAutotrail As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowDatabase As System.Windows.Forms.CheckBox
    Friend WithEvents chkUIShowObjs As System.Windows.Forms.CheckBox
    Friend WithEvents chkUIShowMsg As System.Windows.Forms.CheckBox
    Friend WithEvents chkUIShowWX As System.Windows.Forms.CheckBox
    Friend WithEvents chkUIShowPos As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowLogDatabase As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowInterface As System.Windows.Forms.CheckBox
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents grpSmartBeacon As System.Windows.Forms.GroupBox
    Friend WithEvents lblTurnSeconds As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents lblTurnTime As System.Windows.Forms.Label
    Friend WithEvents lblTurnSlope As System.Windows.Forms.Label
    Friend WithEvents lblMinTurnAngle As System.Windows.Forms.Label
    Friend WithEvents chkSmartEnable As System.Windows.Forms.CheckBox
    Friend WithEvents lblSlowRate As System.Windows.Forms.Label
    Friend WithEvents lblFastSpeed As System.Windows.Forms.Label
    Friend WithEvents lblFastRate As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents lblFastRateSeconds As System.Windows.Forms.Label
    Friend WithEvents lblSlowSpeed As System.Windows.Forms.Label
    Friend WithEvents lblSlowRateSeconds As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents grpMICE As System.Windows.Forms.GroupBox
    Friend WithEvents lblMICEPath As System.Windows.Forms.Label
    Friend WithEvents lblMICEMessage As System.Windows.Forms.Label
    Friend WithEvents chkMICEprintable As System.Windows.Forms.CheckBox
    Friend WithEvents chkMICEEnable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDefaultLon As System.Windows.Forms.TextBox
    Friend WithEvents txtDefaultLat As System.Windows.Forms.TextBox
    Friend WithEvents lblLon As System.Windows.Forms.Label
    Friend WithEvents lblLat As System.Windows.Forms.Label
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage14 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents chkNMEASend As System.Windows.Forms.CheckBox
    Friend WithEvents gprStatus As System.Windows.Forms.GroupBox
    Friend WithEvents lblSendEvery As System.Windows.Forms.Label
    Friend WithEvents lblStatustext As System.Windows.Forms.Label
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents lblDigiPath As System.Windows.Forms.Label
    Friend WithEvents lblAutoTXRate As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents lblSymbol As System.Windows.Forms.Label
    Friend WithEvents lblTable As System.Windows.Forms.Label
    Friend WithEvents chkErrorLog As System.Windows.Forms.CheckBox
    Friend WithEvents chkErrorMsg As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoOziGPS As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoComGPS As System.Windows.Forms.CheckBox
    Friend WithEvents GPSport As System.Windows.Forms.ComboBox
    Friend WithEvents txtBCNDigi As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNtxRate As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNsymbol As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNtable As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNturntime As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNturnslope As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNturnangle As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNfastspeed As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNfastrate As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNslowspeed As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNslowrate As System.Windows.Forms.TextBox
    Friend WithEvents cboMICEpath As System.Windows.Forms.ComboBox
    Friend WithEvents cboMICEmessage As System.Windows.Forms.ComboBox
    Friend WithEvents txtBCNsendevery As System.Windows.Forms.TextBox
    Friend WithEvents txtBCNstatus As System.Windows.Forms.TextBox
    Friend WithEvents chkBCNSendSeperate As System.Windows.Forms.CheckBox
    Friend WithEvents chkBCNAltDigi As System.Windows.Forms.CheckBox
    Friend WithEvents chkBCNSendAlt As System.Windows.Forms.CheckBox
    Friend WithEvents chkBCNHMS As System.Windows.Forms.CheckBox
    Friend WithEvents chkBcnDHM As System.Windows.Forms.CheckBox
    Friend WithEvents chkBCNValid As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button14 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSetup))
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.cboLanguage = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpGPS = New System.Windows.Forms.GroupBox
        Me.chkAutoOziGPS = New System.Windows.Forms.CheckBox
        Me.chkAutoComGPS = New System.Windows.Forms.CheckBox
        Me.CheckBox4 = New System.Windows.Forms.CheckBox
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.lblGPSspeed = New System.Windows.Forms.Label
        Me.GPSport = New System.Windows.Forms.ComboBox
        Me.lblGPSport = New System.Windows.Forms.Label
        Me.lblRadioBeacon = New System.Windows.Forms.Label
        Me.lblNetworkBeacon = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.chkLoopbackPos = New System.Windows.Forms.CheckBox
        Me.chkNMEAauto = New System.Windows.Forms.CheckBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtCallsign = New System.Windows.Forms.TextBox
        Me.lblCallsign = New System.Windows.Forms.Label
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.grpDatabase = New System.Windows.Forms.GroupBox
        Me.Button4 = New System.Windows.Forms.Button
        Me.txtDatabaseFilename = New System.Windows.Forms.TextBox
        Me.lblDatabaseFilename = New System.Windows.Forms.Label
        Me.chkDBConnectAuto = New System.Windows.Forms.CheckBox
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.chkErrorMsg = New System.Windows.Forms.CheckBox
        Me.chkErrorLog = New System.Windows.Forms.CheckBox
        Me.Button5 = New System.Windows.Forms.Button
        Me.chkLogAuto = New System.Windows.Forms.CheckBox
        Me.lblLogFilename = New System.Windows.Forms.Label
        Me.txtLogFilename = New System.Windows.Forms.TextBox
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.gpriGate = New System.Windows.Forms.GroupBox
        Me.lbliGateTotalLimit = New System.Windows.Forms.Label
        Me.txtIGateRate = New System.Windows.Forms.TextBox
        Me.lblRateLimit = New System.Windows.Forms.Label
        Me.txtIGateWxRate = New System.Windows.Forms.TextBox
        Me.txtIGateObjRate = New System.Windows.Forms.TextBox
        Me.txtIGateMsgRate = New System.Windows.Forms.TextBox
        Me.txtIGatePosRate = New System.Windows.Forms.TextBox
        Me.chkIGateWxRF = New System.Windows.Forms.CheckBox
        Me.chkIGateObjRF = New System.Windows.Forms.CheckBox
        Me.chkIGateMsgRF = New System.Windows.Forms.CheckBox
        Me.chkIGatePosRF = New System.Windows.Forms.CheckBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.txtAutoSaveFilename = New System.Windows.Forms.TextBox
        Me.chkStateLoadAuto = New System.Windows.Forms.CheckBox
        Me.lblStateFilename = New System.Windows.Forms.Label
        Me.chkStateSaveAuto = New System.Windows.Forms.CheckBox
        Me.ChkGeoAuto = New System.Windows.Forms.CheckBox
        Me.chkMonAuto = New System.Windows.Forms.CheckBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.grpIncoming = New System.Windows.Forms.GroupBox
        Me.chkCallsignTranslation = New System.Windows.Forms.CheckBox
        Me.cboNetGPSport = New System.Windows.Forms.ComboBox
        Me.cboGPRSport = New System.Windows.Forms.ComboBox
        Me.cboHubPort = New System.Windows.Forms.ComboBox
        Me.chkAutoNetGPSListen = New System.Windows.Forms.CheckBox
        Me.chkAutoGPRSListen = New System.Windows.Forms.CheckBox
        Me.chkAutoHUBlisten = New System.Windows.Forms.CheckBox
        Me.chkHubDumpHistory = New System.Windows.Forms.CheckBox
        Me.gprOutgoing = New System.Windows.Forms.GroupBox
        Me.txtConnectString = New System.Windows.Forms.TextBox
        Me.txtLoginString = New System.Windows.Forms.TextBox
        Me.chkAutoServerConnect = New System.Windows.Forms.CheckBox
        Me.lblOnConnect = New System.Windows.Forms.Label
        Me.lblLoginString = New System.Windows.Forms.Label
        Me.txtOutgoingServer = New System.Windows.Forms.TextBox
        Me.lblOutgoingServer = New System.Windows.Forms.Label
        Me.TabPage7 = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Button13 = New System.Windows.Forms.Button
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.Button12 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lbliGPRSCom = New System.Windows.Forms.Label
        Me.cboIGPRSport = New System.Windows.Forms.ComboBox
        Me.lblrate = New System.Windows.Forms.Label
        Me.lblAPN = New System.Windows.Forms.Label
        Me.lblIPPort = New System.Windows.Forms.Label
        Me.lblIPaddress = New System.Windows.Forms.Label
        Me.lblServer2 = New System.Windows.Forms.Label
        Me.lblServer1 = New System.Windows.Forms.Label
        Me.btnReset = New System.Windows.Forms.Button
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Delay = New System.Windows.Forms.TextBox
        Me.APN = New System.Windows.Forms.TextBox
        Me.Port_2 = New System.Windows.Forms.TextBox
        Me.IP_2 = New System.Windows.Forms.TextBox
        Me.Port_1 = New System.Windows.Forms.TextBox
        Me.IP_1 = New System.Windows.Forms.TextBox
        Me.Button10 = New System.Windows.Forms.Button
        Me.btnConfig = New System.Windows.Forms.Button
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.chkUIShowObjs = New System.Windows.Forms.CheckBox
        Me.chkUIShowMsg = New System.Windows.Forms.CheckBox
        Me.chkUIShowWX = New System.Windows.Forms.CheckBox
        Me.chkUIShowPos = New System.Windows.Forms.CheckBox
        Me.grpXML = New System.Windows.Forms.GroupBox
        Me.Button6 = New System.Windows.Forms.Button
        Me.lblXMLdirectory = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.chkXMLAutoExport = New System.Windows.Forms.CheckBox
        Me.grpPrograms = New System.Windows.Forms.GroupBox
        Me.chkOziDownloadMyPos = New System.Windows.Forms.CheckBox
        Me.chkOziTrail = New System.Windows.Forms.CheckBox
        Me.chkOziOnTop = New System.Windows.Forms.CheckBox
        Me.ChkDecayAuto = New System.Windows.Forms.CheckBox
        Me.chkInterfaceUIViewStartup = New System.Windows.Forms.CheckBox
        Me.chkInterfaceMappointStartup = New System.Windows.Forms.CheckBox
        Me.chkInterfaceOziStartup = New System.Windows.Forms.CheckBox
        Me.grpRINO = New System.Windows.Forms.GroupBox
        Me.cmbRINOcom = New System.Windows.Forms.ComboBox
        Me.chkRINOauto = New System.Windows.Forms.CheckBox
        Me.lblRINOcomport = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chkTNCMonitorOnly = New System.Windows.Forms.CheckBox
        Me.cmbTNCSpeed = New System.Windows.Forms.ComboBox
        Me.cmbTNCcom = New System.Windows.Forms.ComboBox
        Me.chkTNCAuto = New System.Windows.Forms.CheckBox
        Me.chkTNCKiss = New System.Windows.Forms.CheckBox
        Me.lblTNCSpeed = New System.Windows.Forms.Label
        Me.lblTNCComPort = New System.Windows.Forms.Label
        Me.chkAGWPEauto = New System.Windows.Forms.CheckBox
        Me.chkUploadDelay = New System.Windows.Forms.CheckBox
        Me.TabPage8 = New System.Windows.Forms.TabPage
        Me.TabControl2 = New System.Windows.Forms.TabControl
        Me.TabPage14 = New System.Windows.Forms.TabPage
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox12 = New System.Windows.Forms.GroupBox
        Me.lblDigiPath = New System.Windows.Forms.Label
        Me.txtBCNDigi = New System.Windows.Forms.TextBox
        Me.lblAutoTXRate = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.lblSymbol = New System.Windows.Forms.Label
        Me.txtBCNtxRate = New System.Windows.Forms.TextBox
        Me.lblTable = New System.Windows.Forms.Label
        Me.txtBCNsymbol = New System.Windows.Forms.TextBox
        Me.txtBCNtable = New System.Windows.Forms.TextBox
        Me.TabPage10 = New System.Windows.Forms.TabPage
        Me.grpSmartBeacon = New System.Windows.Forms.GroupBox
        Me.lblTurnSeconds = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.txtBCNturntime = New System.Windows.Forms.TextBox
        Me.txtBCNturnslope = New System.Windows.Forms.TextBox
        Me.txtBCNturnangle = New System.Windows.Forms.TextBox
        Me.lblTurnTime = New System.Windows.Forms.Label
        Me.lblTurnSlope = New System.Windows.Forms.Label
        Me.lblMinTurnAngle = New System.Windows.Forms.Label
        Me.chkSmartEnable = New System.Windows.Forms.CheckBox
        Me.lblSlowRate = New System.Windows.Forms.Label
        Me.lblFastSpeed = New System.Windows.Forms.Label
        Me.lblFastRate = New System.Windows.Forms.Label
        Me.txtBCNfastspeed = New System.Windows.Forms.TextBox
        Me.txtBCNfastrate = New System.Windows.Forms.TextBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.lblFastRateSeconds = New System.Windows.Forms.Label
        Me.lblSlowSpeed = New System.Windows.Forms.Label
        Me.lblSlowRateSeconds = New System.Windows.Forms.Label
        Me.txtBCNslowspeed = New System.Windows.Forms.TextBox
        Me.txtBCNslowrate = New System.Windows.Forms.TextBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.TabPage11 = New System.Windows.Forms.TabPage
        Me.grpMICE = New System.Windows.Forms.GroupBox
        Me.lblMICEPath = New System.Windows.Forms.Label
        Me.lblMICEMessage = New System.Windows.Forms.Label
        Me.cboMICEpath = New System.Windows.Forms.ComboBox
        Me.cboMICEmessage = New System.Windows.Forms.ComboBox
        Me.chkMICEprintable = New System.Windows.Forms.CheckBox
        Me.chkMICEEnable = New System.Windows.Forms.CheckBox
        Me.TabPage12 = New System.Windows.Forms.TabPage
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtDefaultLon = New System.Windows.Forms.TextBox
        Me.txtDefaultLat = New System.Windows.Forms.TextBox
        Me.lblLon = New System.Windows.Forms.Label
        Me.lblLat = New System.Windows.Forms.Label
        Me.TabPage13 = New System.Windows.Forms.TabPage
        Me.gprStatus = New System.Windows.Forms.GroupBox
        Me.txtBCNsendevery = New System.Windows.Forms.TextBox
        Me.txtBCNstatus = New System.Windows.Forms.TextBox
        Me.chkBCNSendSeperate = New System.Windows.Forms.CheckBox
        Me.lblSendEvery = New System.Windows.Forms.Label
        Me.lblStatustext = New System.Windows.Forms.Label
        Me.GroupBox11 = New System.Windows.Forms.GroupBox
        Me.chkNMEASend = New System.Windows.Forms.CheckBox
        Me.chkBCNAltDigi = New System.Windows.Forms.CheckBox
        Me.chkBCNSendAlt = New System.Windows.Forms.CheckBox
        Me.chkBCNHMS = New System.Windows.Forms.CheckBox
        Me.chkBcnDHM = New System.Windows.Forms.CheckBox
        Me.chkBCNValid = New System.Windows.Forms.CheckBox
        Me.TabPage9 = New System.Windows.Forms.TabPage
        Me.chkShowInterface = New System.Windows.Forms.CheckBox
        Me.chkShowLogDatabase = New System.Windows.Forms.CheckBox
        Me.chkShowOziAutotrail = New System.Windows.Forms.CheckBox
        Me.chkShowOziDecay = New System.Windows.Forms.CheckBox
        Me.chkShowOziSyncClear = New System.Windows.Forms.CheckBox
        Me.chkShowDatabase = New System.Windows.Forms.CheckBox
        Me.chkShowTranslate = New System.Windows.Forms.CheckBox
        Me.chkShowUploadMonitored = New System.Windows.Forms.CheckBox
        Me.chkShowGeofiltering = New System.Windows.Forms.CheckBox
        Me.chkShowLOG = New System.Windows.Forms.CheckBox
        Me.chkShowRINO = New System.Windows.Forms.CheckBox
        Me.chkShowWx = New System.Windows.Forms.CheckBox
        Me.chkShowGPS = New System.Windows.Forms.CheckBox
        Me.chkShowTNC = New System.Windows.Forms.CheckBox
        Me.chkShowAGWPEUIVIEW = New System.Windows.Forms.CheckBox
        Me.chkShowMapPoint = New System.Windows.Forms.CheckBox
        Me.chkShowOzi = New System.Windows.Forms.CheckBox
        Me.chkShowNetwork = New System.Windows.Forms.CheckBox
        Me.chkShowHelp = New System.Windows.Forms.CheckBox
        Me.chkShowGUI = New System.Windows.Forms.CheckBox
        Me.chkShowServices = New System.Windows.Forms.CheckBox
        Me.chkShowFile = New System.Windows.Forms.CheckBox
        Me.chkShowSetup = New System.Windows.Forms.CheckBox
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.Button14 = New System.Windows.Forms.Button
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.grpGPS.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.grpDatabase.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.gpriGate.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.grpIncoming.SuspendLayout()
        Me.gprOutgoing.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.grpXML.SuspendLayout()
        Me.grpPrograms.SuspendLayout()
        Me.grpRINO.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.grpSmartBeacon.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.grpMICE.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.gprStatus.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(64, 376)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(256, 40)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Save"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(496, 368)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(224, 48)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Close"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(16, 8)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(952, 352)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.grpGPS)
        Me.TabPage1.Controls.Add(Me.txtCallsign)
        Me.TabPage1.Controls.Add(Me.lblCallsign)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(944, 323)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Station"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cboLanguage)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 56)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(296, 80)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lanuage"
        '
        'cboLanguage
        '
        Me.cboLanguage.Items.AddRange(New Object() {"English", "French", "Italian", "German", "Aussie"})
        Me.cboLanguage.Location = New System.Drawing.Point(160, 32)
        Me.cboLanguage.Name = "cboLanguage"
        Me.cboLanguage.Size = New System.Drawing.Size(121, 24)
        Me.cboLanguage.TabIndex = 1
        Me.cboLanguage.Text = "Engligh"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Language"
        '
        'grpGPS
        '
        Me.grpGPS.Controls.Add(Me.chkAutoOziGPS)
        Me.grpGPS.Controls.Add(Me.chkAutoComGPS)
        Me.grpGPS.Controls.Add(Me.CheckBox4)
        Me.grpGPS.Controls.Add(Me.ComboBox2)
        Me.grpGPS.Controls.Add(Me.lblGPSspeed)
        Me.grpGPS.Controls.Add(Me.GPSport)
        Me.grpGPS.Controls.Add(Me.lblGPSport)
        Me.grpGPS.Controls.Add(Me.lblRadioBeacon)
        Me.grpGPS.Controls.Add(Me.lblNetworkBeacon)
        Me.grpGPS.Controls.Add(Me.TextBox2)
        Me.grpGPS.Controls.Add(Me.TextBox1)
        Me.grpGPS.Controls.Add(Me.chkLoopbackPos)
        Me.grpGPS.Controls.Add(Me.chkNMEAauto)
        Me.grpGPS.Controls.Add(Me.Label2)
        Me.grpGPS.Location = New System.Drawing.Point(440, 16)
        Me.grpGPS.Name = "grpGPS"
        Me.grpGPS.Size = New System.Drawing.Size(328, 264)
        Me.grpGPS.TabIndex = 10
        Me.grpGPS.TabStop = False
        Me.grpGPS.Text = "GPS"
        '
        'chkAutoOziGPS
        '
        Me.chkAutoOziGPS.Location = New System.Drawing.Point(152, 200)
        Me.chkAutoOziGPS.Name = "chkAutoOziGPS"
        Me.chkAutoOziGPS.Size = New System.Drawing.Size(168, 24)
        Me.chkAutoOziGPS.TabIndex = 24
        Me.chkAutoOziGPS.Text = "Auto get GPS from Ozi"
        '
        'chkAutoComGPS
        '
        Me.chkAutoComGPS.Location = New System.Drawing.Point(16, 200)
        Me.chkAutoComGPS.Name = "chkAutoComGPS"
        Me.chkAutoComGPS.Size = New System.Drawing.Size(136, 24)
        Me.chkAutoComGPS.TabIndex = 23
        Me.chkAutoComGPS.Text = "AutoGetCOMGPS"
        '
        'CheckBox4
        '
        Me.CheckBox4.Location = New System.Drawing.Point(16, 136)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(144, 24)
        Me.CheckBox4.TabIndex = 22
        Me.CheckBox4.Text = "CheckBox4"
        '
        'ComboBox2
        '
        Me.ComboBox2.Items.AddRange(New Object() {"4800", "9600"})
        Me.ComboBox2.Location = New System.Drawing.Point(256, 24)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(56, 24)
        Me.ComboBox2.TabIndex = 21
        Me.ComboBox2.Text = "4800"
        '
        'lblGPSspeed
        '
        Me.lblGPSspeed.Location = New System.Drawing.Point(144, 24)
        Me.lblGPSspeed.Name = "lblGPSspeed"
        Me.lblGPSspeed.Size = New System.Drawing.Size(104, 23)
        Me.lblGPSspeed.TabIndex = 20
        Me.lblGPSspeed.Tag = "GPS Speed"
        Me.lblGPSspeed.Text = "GPS Speed"
        '
        'GPSport
        '
        Me.GPSport.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.GPSport.Location = New System.Drawing.Point(96, 24)
        Me.GPSport.Name = "GPSport"
        Me.GPSport.Size = New System.Drawing.Size(48, 24)
        Me.GPSport.TabIndex = 19
        Me.GPSport.Text = "1"
        '
        'lblGPSport
        '
        Me.lblGPSport.Location = New System.Drawing.Point(8, 24)
        Me.lblGPSport.Name = "lblGPSport"
        Me.lblGPSport.Size = New System.Drawing.Size(80, 23)
        Me.lblGPSport.TabIndex = 18
        Me.lblGPSport.Text = "GPS Port"
        '
        'lblRadioBeacon
        '
        Me.lblRadioBeacon.Location = New System.Drawing.Point(8, 112)
        Me.lblRadioBeacon.Name = "lblRadioBeacon"
        Me.lblRadioBeacon.Size = New System.Drawing.Size(224, 23)
        Me.lblRadioBeacon.TabIndex = 17
        Me.lblRadioBeacon.Text = "Radio Beacon Rate (Secs)"
        '
        'lblNetworkBeacon
        '
        Me.lblNetworkBeacon.Location = New System.Drawing.Point(8, 88)
        Me.lblNetworkBeacon.Name = "lblNetworkBeacon"
        Me.lblNetworkBeacon.Size = New System.Drawing.Size(208, 23)
        Me.lblNetworkBeacon.TabIndex = 16
        Me.lblNetworkBeacon.Text = "Network Beacon Rate (Secs)"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(256, 112)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(56, 22)
        Me.TextBox2.TabIndex = 15
        Me.TextBox2.Text = "120"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(256, 80)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(56, 22)
        Me.TextBox1.TabIndex = 14
        Me.TextBox1.Text = "120"
        '
        'chkLoopbackPos
        '
        Me.chkLoopbackPos.Location = New System.Drawing.Point(16, 48)
        Me.chkLoopbackPos.Name = "chkLoopbackPos"
        Me.chkLoopbackPos.Size = New System.Drawing.Size(296, 24)
        Me.chkLoopbackPos.TabIndex = 13
        Me.chkLoopbackPos.Text = "Loopback my position reports"
        '
        'chkNMEAauto
        '
        Me.chkNMEAauto.Location = New System.Drawing.Point(200, 160)
        Me.chkNMEAauto.Name = "chkNMEAauto"
        Me.chkNMEAauto.Size = New System.Drawing.Size(112, 24)
        Me.chkNMEAauto.TabIndex = 12
        Me.chkNMEAauto.Text = "AutoNMEA"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 232)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(200, 24)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Only GPS port being used here"
        '
        'txtCallsign
        '
        Me.txtCallsign.Location = New System.Drawing.Point(200, 16)
        Me.txtCallsign.Name = "txtCallsign"
        Me.txtCallsign.Size = New System.Drawing.Size(128, 22)
        Me.txtCallsign.TabIndex = 1
        Me.txtCallsign.Text = "TextBox1"
        '
        'lblCallsign
        '
        Me.lblCallsign.Location = New System.Drawing.Point(8, 16)
        Me.lblCallsign.Name = "lblCallsign"
        Me.lblCallsign.Size = New System.Drawing.Size(184, 24)
        Me.lblCallsign.TabIndex = 0
        Me.lblCallsign.Text = "Station Callsign"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.grpDatabase)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(944, 323)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Database"
        '
        'grpDatabase
        '
        Me.grpDatabase.Controls.Add(Me.Button4)
        Me.grpDatabase.Controls.Add(Me.txtDatabaseFilename)
        Me.grpDatabase.Controls.Add(Me.lblDatabaseFilename)
        Me.grpDatabase.Controls.Add(Me.chkDBConnectAuto)
        Me.grpDatabase.Location = New System.Drawing.Point(24, 16)
        Me.grpDatabase.Name = "grpDatabase"
        Me.grpDatabase.Size = New System.Drawing.Size(240, 200)
        Me.grpDatabase.TabIndex = 4
        Me.grpDatabase.TabStop = False
        Me.grpDatabase.Text = "Database"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(200, 88)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(32, 24)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "..."
        '
        'txtDatabaseFilename
        '
        Me.txtDatabaseFilename.Location = New System.Drawing.Point(8, 88)
        Me.txtDatabaseFilename.Name = "txtDatabaseFilename"
        Me.txtDatabaseFilename.Size = New System.Drawing.Size(176, 22)
        Me.txtDatabaseFilename.TabIndex = 4
        Me.txtDatabaseFilename.Text = "TextBox1"
        '
        'lblDatabaseFilename
        '
        Me.lblDatabaseFilename.Location = New System.Drawing.Point(16, 24)
        Me.lblDatabaseFilename.Name = "lblDatabaseFilename"
        Me.lblDatabaseFilename.Size = New System.Drawing.Size(160, 23)
        Me.lblDatabaseFilename.TabIndex = 3
        Me.lblDatabaseFilename.Text = "Database Filename"
        '
        'chkDBConnectAuto
        '
        Me.chkDBConnectAuto.Location = New System.Drawing.Point(16, 128)
        Me.chkDBConnectAuto.Name = "chkDBConnectAuto"
        Me.chkDBConnectAuto.Size = New System.Drawing.Size(208, 24)
        Me.chkDBConnectAuto.TabIndex = 2
        Me.chkDBConnectAuto.Text = "AutoConnect Database"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.chkErrorMsg)
        Me.TabPage6.Controls.Add(Me.chkErrorLog)
        Me.TabPage6.Controls.Add(Me.Button5)
        Me.TabPage6.Controls.Add(Me.chkLogAuto)
        Me.TabPage6.Controls.Add(Me.lblLogFilename)
        Me.TabPage6.Controls.Add(Me.txtLogFilename)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(944, 323)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Debug"
        '
        'chkErrorMsg
        '
        Me.chkErrorMsg.Location = New System.Drawing.Point(96, 144)
        Me.chkErrorMsg.Name = "chkErrorMsg"
        Me.chkErrorMsg.Size = New System.Drawing.Size(248, 24)
        Me.chkErrorMsg.TabIndex = 5
        Me.chkErrorMsg.Text = "Display Application Errors"
        '
        'chkErrorLog
        '
        Me.chkErrorLog.Location = New System.Drawing.Point(96, 120)
        Me.chkErrorLog.Name = "chkErrorLog"
        Me.chkErrorLog.Size = New System.Drawing.Size(248, 24)
        Me.chkErrorLog.TabIndex = 4
        Me.chkErrorLog.Text = "Log Application Errors"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(304, 16)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(32, 24)
        Me.Button5.TabIndex = 3
        Me.Button5.Text = "..."
        '
        'chkLogAuto
        '
        Me.chkLogAuto.Location = New System.Drawing.Point(16, 40)
        Me.chkLogAuto.Name = "chkLogAuto"
        Me.chkLogAuto.TabIndex = 2
        Me.chkLogAuto.Text = "Auto LOG"
        '
        'lblLogFilename
        '
        Me.lblLogFilename.Location = New System.Drawing.Point(16, 16)
        Me.lblLogFilename.Name = "lblLogFilename"
        Me.lblLogFilename.TabIndex = 1
        Me.lblLogFilename.Text = "Log File Name"
        '
        'txtLogFilename
        '
        Me.txtLogFilename.Location = New System.Drawing.Point(120, 16)
        Me.txtLogFilename.Name = "txtLogFilename"
        Me.txtLogFilename.Size = New System.Drawing.Size(168, 22)
        Me.txtLogFilename.TabIndex = 0
        Me.txtLogFilename.Text = "TextBox5"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox6)
        Me.TabPage4.Controls.Add(Me.gpriGate)
        Me.TabPage4.Controls.Add(Me.Button3)
        Me.TabPage4.Controls.Add(Me.txtAutoSaveFilename)
        Me.TabPage4.Controls.Add(Me.chkStateLoadAuto)
        Me.TabPage4.Controls.Add(Me.lblStateFilename)
        Me.TabPage4.Controls.Add(Me.chkStateSaveAuto)
        Me.TabPage4.Controls.Add(Me.ChkGeoAuto)
        Me.TabPage4.Controls.Add(Me.chkMonAuto)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(944, 323)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Behavior"
        '
        'GroupBox6
        '
        Me.GroupBox6.Location = New System.Drawing.Point(16, 192)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(408, 120)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "GroupBox6"
        '
        'gpriGate
        '
        Me.gpriGate.Controls.Add(Me.lbliGateTotalLimit)
        Me.gpriGate.Controls.Add(Me.txtIGateRate)
        Me.gpriGate.Controls.Add(Me.lblRateLimit)
        Me.gpriGate.Controls.Add(Me.txtIGateWxRate)
        Me.gpriGate.Controls.Add(Me.txtIGateObjRate)
        Me.gpriGate.Controls.Add(Me.txtIGateMsgRate)
        Me.gpriGate.Controls.Add(Me.txtIGatePosRate)
        Me.gpriGate.Controls.Add(Me.chkIGateWxRF)
        Me.gpriGate.Controls.Add(Me.chkIGateObjRF)
        Me.gpriGate.Controls.Add(Me.chkIGateMsgRF)
        Me.gpriGate.Controls.Add(Me.chkIGatePosRF)
        Me.gpriGate.Location = New System.Drawing.Point(448, 8)
        Me.gpriGate.Name = "gpriGate"
        Me.gpriGate.Size = New System.Drawing.Size(320, 256)
        Me.gpriGate.TabIndex = 8
        Me.gpriGate.TabStop = False
        Me.gpriGate.Text = "iGate"
        '
        'lbliGateTotalLimit
        '
        Me.lbliGateTotalLimit.Enabled = False
        Me.lbliGateTotalLimit.Location = New System.Drawing.Point(72, 208)
        Me.lbliGateTotalLimit.Name = "lbliGateTotalLimit"
        Me.lbliGateTotalLimit.Size = New System.Drawing.Size(144, 23)
        Me.lbliGateTotalLimit.TabIndex = 10
        Me.lbliGateTotalLimit.Text = "Overall Limit"
        Me.lbliGateTotalLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtIGateRate
        '
        Me.txtIGateRate.Enabled = False
        Me.txtIGateRate.Location = New System.Drawing.Point(240, 208)
        Me.txtIGateRate.Name = "txtIGateRate"
        Me.txtIGateRate.Size = New System.Drawing.Size(48, 22)
        Me.txtIGateRate.TabIndex = 9
        Me.txtIGateRate.Text = "txtIGateRate"
        '
        'lblRateLimit
        '
        Me.lblRateLimit.Enabled = False
        Me.lblRateLimit.Location = New System.Drawing.Point(224, 24)
        Me.lblRateLimit.Name = "lblRateLimit"
        Me.lblRateLimit.Size = New System.Drawing.Size(72, 24)
        Me.lblRateLimit.TabIndex = 8
        Me.lblRateLimit.Text = "Rate Limit"
        Me.lblRateLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtIGateWxRate
        '
        Me.txtIGateWxRate.Enabled = False
        Me.txtIGateWxRate.Location = New System.Drawing.Point(240, 152)
        Me.txtIGateWxRate.Name = "txtIGateWxRate"
        Me.txtIGateWxRate.Size = New System.Drawing.Size(48, 22)
        Me.txtIGateWxRate.TabIndex = 7
        Me.txtIGateWxRate.Text = "txtIGateWxRate"
        '
        'txtIGateObjRate
        '
        Me.txtIGateObjRate.Enabled = False
        Me.txtIGateObjRate.Location = New System.Drawing.Point(240, 120)
        Me.txtIGateObjRate.Name = "txtIGateObjRate"
        Me.txtIGateObjRate.Size = New System.Drawing.Size(48, 22)
        Me.txtIGateObjRate.TabIndex = 6
        Me.txtIGateObjRate.Text = "txtIGateObjRate"
        '
        'txtIGateMsgRate
        '
        Me.txtIGateMsgRate.Enabled = False
        Me.txtIGateMsgRate.Location = New System.Drawing.Point(240, 88)
        Me.txtIGateMsgRate.Name = "txtIGateMsgRate"
        Me.txtIGateMsgRate.Size = New System.Drawing.Size(48, 22)
        Me.txtIGateMsgRate.TabIndex = 5
        Me.txtIGateMsgRate.Text = "txtIGateMsgRate"
        '
        'txtIGatePosRate
        '
        Me.txtIGatePosRate.Enabled = False
        Me.txtIGatePosRate.Location = New System.Drawing.Point(240, 56)
        Me.txtIGatePosRate.Name = "txtIGatePosRate"
        Me.txtIGatePosRate.Size = New System.Drawing.Size(48, 22)
        Me.txtIGatePosRate.TabIndex = 4
        Me.txtIGatePosRate.Text = "txtIGatePosRate"
        '
        'chkIGateWxRF
        '
        Me.chkIGateWxRF.Location = New System.Drawing.Point(8, 152)
        Me.chkIGateWxRF.Name = "chkIGateWxRF"
        Me.chkIGateWxRF.Size = New System.Drawing.Size(208, 24)
        Me.chkIGateWxRF.TabIndex = 3
        Me.chkIGateWxRF.Text = "iGate WX to RF"
        '
        'chkIGateObjRF
        '
        Me.chkIGateObjRF.Location = New System.Drawing.Point(8, 120)
        Me.chkIGateObjRF.Name = "chkIGateObjRF"
        Me.chkIGateObjRF.Size = New System.Drawing.Size(208, 24)
        Me.chkIGateObjRF.TabIndex = 2
        Me.chkIGateObjRF.Text = "iGate Objects/Items to RF"
        '
        'chkIGateMsgRF
        '
        Me.chkIGateMsgRF.Location = New System.Drawing.Point(8, 88)
        Me.chkIGateMsgRF.Name = "chkIGateMsgRF"
        Me.chkIGateMsgRF.Size = New System.Drawing.Size(208, 24)
        Me.chkIGateMsgRF.TabIndex = 1
        Me.chkIGateMsgRF.Text = "iGate Messages to RF"
        '
        'chkIGatePosRF
        '
        Me.chkIGatePosRF.Location = New System.Drawing.Point(8, 56)
        Me.chkIGatePosRF.Name = "chkIGatePosRF"
        Me.chkIGatePosRF.Size = New System.Drawing.Size(208, 24)
        Me.chkIGatePosRF.TabIndex = 0
        Me.chkIGatePosRF.Text = "iGate Positions to RF"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(368, 112)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(24, 24)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "..."
        '
        'txtAutoSaveFilename
        '
        Me.txtAutoSaveFilename.Location = New System.Drawing.Point(48, 112)
        Me.txtAutoSaveFilename.Name = "txtAutoSaveFilename"
        Me.txtAutoSaveFilename.Size = New System.Drawing.Size(312, 22)
        Me.txtAutoSaveFilename.TabIndex = 6
        Me.txtAutoSaveFilename.Text = "TextBox1"
        '
        'chkStateLoadAuto
        '
        Me.chkStateLoadAuto.Location = New System.Drawing.Point(16, 136)
        Me.chkStateLoadAuto.Name = "chkStateLoadAuto"
        Me.chkStateLoadAuto.Size = New System.Drawing.Size(232, 24)
        Me.chkStateLoadAuto.TabIndex = 5
        Me.chkStateLoadAuto.Text = "Auto Load State"
        '
        'lblStateFilename
        '
        Me.lblStateFilename.Location = New System.Drawing.Point(16, 88)
        Me.lblStateFilename.Name = "lblStateFilename"
        Me.lblStateFilename.Size = New System.Drawing.Size(304, 23)
        Me.lblStateFilename.TabIndex = 4
        Me.lblStateFilename.Text = "Auto Save State Filename"
        '
        'chkStateSaveAuto
        '
        Me.chkStateSaveAuto.Location = New System.Drawing.Point(16, 64)
        Me.chkStateSaveAuto.Name = "chkStateSaveAuto"
        Me.chkStateSaveAuto.Size = New System.Drawing.Size(272, 24)
        Me.chkStateSaveAuto.TabIndex = 3
        Me.chkStateSaveAuto.Text = "Auto Save State"
        '
        'ChkGeoAuto
        '
        Me.ChkGeoAuto.Location = New System.Drawing.Point(16, 40)
        Me.ChkGeoAuto.Name = "ChkGeoAuto"
        Me.ChkGeoAuto.Size = New System.Drawing.Size(272, 24)
        Me.ChkGeoAuto.TabIndex = 1
        Me.ChkGeoAuto.Text = "Auto GeoGraphic Filtering"
        '
        'chkMonAuto
        '
        Me.chkMonAuto.Location = New System.Drawing.Point(16, 16)
        Me.chkMonAuto.Name = "chkMonAuto"
        Me.chkMonAuto.Size = New System.Drawing.Size(264, 16)
        Me.chkMonAuto.TabIndex = 0
        Me.chkMonAuto.Text = "Upload only monitored positions"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.grpIncoming)
        Me.TabPage2.Controls.Add(Me.gprOutgoing)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(944, 323)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Network"
        '
        'grpIncoming
        '
        Me.grpIncoming.Controls.Add(Me.chkCallsignTranslation)
        Me.grpIncoming.Controls.Add(Me.cboNetGPSport)
        Me.grpIncoming.Controls.Add(Me.cboGPRSport)
        Me.grpIncoming.Controls.Add(Me.cboHubPort)
        Me.grpIncoming.Controls.Add(Me.chkAutoNetGPSListen)
        Me.grpIncoming.Controls.Add(Me.chkAutoGPRSListen)
        Me.grpIncoming.Controls.Add(Me.chkAutoHUBlisten)
        Me.grpIncoming.Controls.Add(Me.chkHubDumpHistory)
        Me.grpIncoming.Location = New System.Drawing.Point(344, 8)
        Me.grpIncoming.Name = "grpIncoming"
        Me.grpIncoming.Size = New System.Drawing.Size(384, 232)
        Me.grpIncoming.TabIndex = 11
        Me.grpIncoming.TabStop = False
        Me.grpIncoming.Text = "Incoming"
        '
        'chkCallsignTranslation
        '
        Me.chkCallsignTranslation.Location = New System.Drawing.Point(16, 184)
        Me.chkCallsignTranslation.Name = "chkCallsignTranslation"
        Me.chkCallsignTranslation.Size = New System.Drawing.Size(232, 24)
        Me.chkCallsignTranslation.TabIndex = 17
        Me.chkCallsignTranslation.Text = "Callsign Translation on Startup"
        '
        'cboNetGPSport
        '
        Me.cboNetGPSport.Items.AddRange(New Object() {"80", "81", "443", "8000", "8080"})
        Me.cboNetGPSport.Location = New System.Drawing.Point(256, 152)
        Me.cboNetGPSport.Name = "cboNetGPSport"
        Me.cboNetGPSport.Size = New System.Drawing.Size(121, 24)
        Me.cboNetGPSport.TabIndex = 16
        Me.cboNetGPSport.Text = "80"
        '
        'cboGPRSport
        '
        Me.cboGPRSport.Items.AddRange(New Object() {"23", "5001", "8000", "8001", "10151", "10152", "10153", "10154"})
        Me.cboGPRSport.Location = New System.Drawing.Point(256, 104)
        Me.cboGPRSport.Name = "cboGPRSport"
        Me.cboGPRSport.Size = New System.Drawing.Size(121, 24)
        Me.cboGPRSport.TabIndex = 15
        Me.cboGPRSport.Text = "8001"
        '
        'cboHubPort
        '
        Me.cboHubPort.Items.AddRange(New Object() {"23", "5001", "8000", "8001", "10151", "10152", "10153", "10154"})
        Me.cboHubPort.Location = New System.Drawing.Point(256, 64)
        Me.cboHubPort.Name = "cboHubPort"
        Me.cboHubPort.Size = New System.Drawing.Size(121, 24)
        Me.cboHubPort.TabIndex = 14
        Me.cboHubPort.Text = "10151"
        '
        'chkAutoNetGPSListen
        '
        Me.chkAutoNetGPSListen.Location = New System.Drawing.Point(16, 144)
        Me.chkAutoNetGPSListen.Name = "chkAutoNetGPSListen"
        Me.chkAutoNetGPSListen.Size = New System.Drawing.Size(208, 32)
        Me.chkAutoNetGPSListen.TabIndex = 13
        Me.chkAutoNetGPSListen.Text = "Auto NetGPS listen"
        '
        'chkAutoGPRSListen
        '
        Me.chkAutoGPRSListen.Location = New System.Drawing.Point(16, 104)
        Me.chkAutoGPRSListen.Name = "chkAutoGPRSListen"
        Me.chkAutoGPRSListen.Size = New System.Drawing.Size(208, 32)
        Me.chkAutoGPRSListen.TabIndex = 12
        Me.chkAutoGPRSListen.Text = "Auto GPRS Listen"
        '
        'chkAutoHUBlisten
        '
        Me.chkAutoHUBlisten.Location = New System.Drawing.Point(16, 64)
        Me.chkAutoHUBlisten.Name = "chkAutoHUBlisten"
        Me.chkAutoHUBlisten.Size = New System.Drawing.Size(208, 32)
        Me.chkAutoHUBlisten.TabIndex = 11
        Me.chkAutoHUBlisten.Text = "Auto HUB Listen"
        '
        'chkHubDumpHistory
        '
        Me.chkHubDumpHistory.Location = New System.Drawing.Point(16, 24)
        Me.chkHubDumpHistory.Name = "chkHubDumpHistory"
        Me.chkHubDumpHistory.Size = New System.Drawing.Size(208, 32)
        Me.chkHubDumpHistory.TabIndex = 10
        Me.chkHubDumpHistory.Text = "Dump history on connect"
        '
        'gprOutgoing
        '
        Me.gprOutgoing.Controls.Add(Me.txtConnectString)
        Me.gprOutgoing.Controls.Add(Me.txtLoginString)
        Me.gprOutgoing.Controls.Add(Me.chkAutoServerConnect)
        Me.gprOutgoing.Controls.Add(Me.lblOnConnect)
        Me.gprOutgoing.Controls.Add(Me.lblLoginString)
        Me.gprOutgoing.Controls.Add(Me.txtOutgoingServer)
        Me.gprOutgoing.Controls.Add(Me.lblOutgoingServer)
        Me.gprOutgoing.Location = New System.Drawing.Point(8, 8)
        Me.gprOutgoing.Name = "gprOutgoing"
        Me.gprOutgoing.Size = New System.Drawing.Size(304, 176)
        Me.gprOutgoing.TabIndex = 10
        Me.gprOutgoing.TabStop = False
        Me.gprOutgoing.Text = "Outgoing"
        '
        'txtConnectString
        '
        Me.txtConnectString.Enabled = False
        Me.txtConnectString.Location = New System.Drawing.Point(168, 104)
        Me.txtConnectString.Name = "txtConnectString"
        Me.txtConnectString.Size = New System.Drawing.Size(128, 22)
        Me.txtConnectString.TabIndex = 12
        Me.txtConnectString.Text = "TextBox4"
        '
        'txtLoginString
        '
        Me.txtLoginString.Enabled = False
        Me.txtLoginString.Location = New System.Drawing.Point(168, 72)
        Me.txtLoginString.Name = "txtLoginString"
        Me.txtLoginString.Size = New System.Drawing.Size(128, 22)
        Me.txtLoginString.TabIndex = 11
        Me.txtLoginString.Text = "TextBox1"
        '
        'chkAutoServerConnect
        '
        Me.chkAutoServerConnect.Location = New System.Drawing.Point(8, 144)
        Me.chkAutoServerConnect.Name = "chkAutoServerConnect"
        Me.chkAutoServerConnect.Size = New System.Drawing.Size(176, 16)
        Me.chkAutoServerConnect.TabIndex = 10
        Me.chkAutoServerConnect.Text = "AutoConnect to Server"
        '
        'lblOnConnect
        '
        Me.lblOnConnect.Location = New System.Drawing.Point(8, 104)
        Me.lblOnConnect.Name = "lblOnConnect"
        Me.lblOnConnect.Size = New System.Drawing.Size(176, 23)
        Me.lblOnConnect.TabIndex = 9
        Me.lblOnConnect.Text = "On Connect String"
        '
        'lblLoginString
        '
        Me.lblLoginString.Location = New System.Drawing.Point(8, 72)
        Me.lblLoginString.Name = "lblLoginString"
        Me.lblLoginString.Size = New System.Drawing.Size(176, 23)
        Me.lblLoginString.TabIndex = 8
        Me.lblLoginString.Text = "Login String"
        '
        'txtOutgoingServer
        '
        Me.txtOutgoingServer.Location = New System.Drawing.Point(168, 40)
        Me.txtOutgoingServer.Name = "txtOutgoingServer"
        Me.txtOutgoingServer.Size = New System.Drawing.Size(128, 22)
        Me.txtOutgoingServer.TabIndex = 7
        Me.txtOutgoingServer.Text = "TextBox4"
        '
        'lblOutgoingServer
        '
        Me.lblOutgoingServer.Location = New System.Drawing.Point(8, 36)
        Me.lblOutgoingServer.Name = "lblOutgoingServer"
        Me.lblOutgoingServer.Size = New System.Drawing.Size(176, 23)
        Me.lblOutgoingServer.TabIndex = 6
        Me.lblOutgoingServer.Text = "Outgoing Server"
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.Button14)
        Me.TabPage7.Controls.Add(Me.GroupBox3)
        Me.TabPage7.Controls.Add(Me.Button12)
        Me.TabPage7.Controls.Add(Me.Button7)
        Me.TabPage7.Controls.Add(Me.PictureBox1)
        Me.TabPage7.Controls.Add(Me.lbliGPRSCom)
        Me.TabPage7.Controls.Add(Me.cboIGPRSport)
        Me.TabPage7.Controls.Add(Me.lblrate)
        Me.TabPage7.Controls.Add(Me.lblAPN)
        Me.TabPage7.Controls.Add(Me.lblIPPort)
        Me.TabPage7.Controls.Add(Me.lblIPaddress)
        Me.TabPage7.Controls.Add(Me.lblServer2)
        Me.TabPage7.Controls.Add(Me.lblServer1)
        Me.TabPage7.Controls.Add(Me.btnReset)
        Me.TabPage7.Controls.Add(Me.TextBox4)
        Me.TabPage7.Controls.Add(Me.Delay)
        Me.TabPage7.Controls.Add(Me.APN)
        Me.TabPage7.Controls.Add(Me.Port_2)
        Me.TabPage7.Controls.Add(Me.IP_2)
        Me.TabPage7.Controls.Add(Me.Port_1)
        Me.TabPage7.Controls.Add(Me.IP_1)
        Me.TabPage7.Controls.Add(Me.Button10)
        Me.TabPage7.Controls.Add(Me.btnConfig)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(944, 323)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "iGPRS Hardware Config"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button13)
        Me.GroupBox3.Controls.Add(Me.Button11)
        Me.GroupBox3.Controls.Add(Me.Button9)
        Me.GroupBox3.Controls.Add(Me.Button8)
        Me.GroupBox3.Controls.Add(Me.TreeView1)
        Me.GroupBox3.Location = New System.Drawing.Point(688, 8)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(248, 312)
        Me.GroupBox3.TabIndex = 42
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Configuration Management"
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(20, 280)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(40, 24)
        Me.Button13.TabIndex = 47
        Me.Button13.Text = "Del"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(104, 280)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(32, 24)
        Me.Button11.TabIndex = 46
        Me.Button11.Text = "W"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(200, 280)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(32, 24)
        Me.Button9.TabIndex = 45
        Me.Button9.Text = "+++"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(68, 280)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(32, 24)
        Me.Button8.TabIndex = 44
        Me.Button8.Text = "R"
        '
        'TreeView1
        '
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(8, 16)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(232, 256)
        Me.TreeView1.TabIndex = 43
        '
        'Button12
        '
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.Location = New System.Drawing.Point(552, 160)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(48, 24)
        Me.Button12.TabIndex = 41
        Me.Button12.Text = "<--"
        '
        'Button7
        '
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(552, 120)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(48, 24)
        Me.Button7.TabIndex = 37
        Me.Button7.Text = "-->"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(16, 104)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 177)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 35
        Me.PictureBox1.TabStop = False
        '
        'lbliGPRSCom
        '
        Me.lbliGPRSCom.Location = New System.Drawing.Point(392, 288)
        Me.lbliGPRSCom.Name = "lbliGPRSCom"
        Me.lbliGPRSCom.Size = New System.Drawing.Size(64, 23)
        Me.lbliGPRSCom.TabIndex = 34
        Me.lbliGPRSCom.Text = "Com Port"
        '
        'cboIGPRSport
        '
        Me.cboIGPRSport.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cboIGPRSport.Location = New System.Drawing.Point(456, 288)
        Me.cboIGPRSport.Name = "cboIGPRSport"
        Me.cboIGPRSport.Size = New System.Drawing.Size(48, 24)
        Me.cboIGPRSport.TabIndex = 33
        Me.cboIGPRSport.Text = "1"
        '
        'lblrate
        '
        Me.lblrate.Location = New System.Drawing.Point(256, 72)
        Me.lblrate.Name = "lblrate"
        Me.lblrate.Size = New System.Drawing.Size(40, 23)
        Me.lblrate.TabIndex = 32
        Me.lblrate.Text = "Rate"
        '
        'lblAPN
        '
        Me.lblAPN.Location = New System.Drawing.Point(256, 40)
        Me.lblAPN.Name = "lblAPN"
        Me.lblAPN.Size = New System.Drawing.Size(40, 23)
        Me.lblAPN.TabIndex = 31
        Me.lblAPN.Text = "APN"
        '
        'lblIPPort
        '
        Me.lblIPPort.Location = New System.Drawing.Point(200, 16)
        Me.lblIPPort.Name = "lblIPPort"
        Me.lblIPPort.Size = New System.Drawing.Size(56, 23)
        Me.lblIPPort.TabIndex = 30
        Me.lblIPPort.Text = "Port"
        Me.lblIPPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIPaddress
        '
        Me.lblIPaddress.Location = New System.Drawing.Point(88, 16)
        Me.lblIPaddress.Name = "lblIPaddress"
        Me.lblIPaddress.TabIndex = 29
        Me.lblIPaddress.Text = "IP Address"
        Me.lblIPaddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblServer2
        '
        Me.lblServer2.Location = New System.Drawing.Point(16, 72)
        Me.lblServer2.Name = "lblServer2"
        Me.lblServer2.Size = New System.Drawing.Size(64, 23)
        Me.lblServer2.TabIndex = 28
        Me.lblServer2.Text = "Server #2"
        '
        'lblServer1
        '
        Me.lblServer1.Location = New System.Drawing.Point(16, 40)
        Me.lblServer1.Name = "lblServer1"
        Me.lblServer1.Size = New System.Drawing.Size(64, 23)
        Me.lblServer1.TabIndex = 27
        Me.lblServer1.Text = "Server #1"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(328, 120)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(64, 24)
        Me.btnReset.TabIndex = 25
        Me.btnReset.Text = "RESET"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(16, 288)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(304, 22)
        Me.TextBox4.TabIndex = 24
        Me.TextBox4.Text = "$GPRMC,092204,A,4250.5589,S,14718.5084,E,0.00,89.68,211200,,"
        '
        'Delay
        '
        Me.Delay.Location = New System.Drawing.Point(304, 72)
        Me.Delay.Name = "Delay"
        Me.Delay.Size = New System.Drawing.Size(64, 22)
        Me.Delay.TabIndex = 20
        Me.Delay.Text = "TextBox1"
        '
        'APN
        '
        Me.APN.Location = New System.Drawing.Point(304, 40)
        Me.APN.Name = "APN"
        Me.APN.Size = New System.Drawing.Size(208, 22)
        Me.APN.TabIndex = 19
        Me.APN.Text = "TextBox1"
        '
        'Port_2
        '
        Me.Port_2.Location = New System.Drawing.Point(200, 72)
        Me.Port_2.Name = "Port_2"
        Me.Port_2.Size = New System.Drawing.Size(48, 22)
        Me.Port_2.TabIndex = 17
        Me.Port_2.Text = "TextBox1"
        '
        'IP_2
        '
        Me.IP_2.Location = New System.Drawing.Point(88, 72)
        Me.IP_2.Name = "IP_2"
        Me.IP_2.Size = New System.Drawing.Size(104, 22)
        Me.IP_2.TabIndex = 16
        Me.IP_2.Text = "TextBox1"
        '
        'Port_1
        '
        Me.Port_1.Location = New System.Drawing.Point(200, 40)
        Me.Port_1.Name = "Port_1"
        Me.Port_1.Size = New System.Drawing.Size(48, 22)
        Me.Port_1.TabIndex = 15
        Me.Port_1.Text = "TextBox1"
        '
        'IP_1
        '
        Me.IP_1.Location = New System.Drawing.Point(88, 40)
        Me.IP_1.Name = "IP_1"
        Me.IP_1.Size = New System.Drawing.Size(104, 22)
        Me.IP_1.TabIndex = 14
        Me.IP_1.Text = "TextBox1"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(328, 288)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(48, 24)
        Me.Button10.TabIndex = 21
        Me.Button10.Text = "GPS"
        '
        'btnConfig
        '
        Me.btnConfig.Location = New System.Drawing.Point(240, 120)
        Me.btnConfig.Name = "btnConfig"
        Me.btnConfig.TabIndex = 18
        Me.btnConfig.Text = "Config"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.grpXML)
        Me.TabPage3.Controls.Add(Me.grpPrograms)
        Me.TabPage3.Controls.Add(Me.grpRINO)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Controls.Add(Me.chkAGWPEauto)
        Me.TabPage3.Controls.Add(Me.chkUploadDelay)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(944, 323)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Interfaces"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkUIShowObjs)
        Me.GroupBox5.Controls.Add(Me.chkUIShowMsg)
        Me.GroupBox5.Controls.Add(Me.chkUIShowWX)
        Me.GroupBox5.Controls.Add(Me.chkUIShowPos)
        Me.GroupBox5.Location = New System.Drawing.Point(8, 208)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(296, 104)
        Me.GroupBox5.TabIndex = 13
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "UI"
        '
        'chkUIShowObjs
        '
        Me.chkUIShowObjs.Location = New System.Drawing.Point(152, 40)
        Me.chkUIShowObjs.Name = "chkUIShowObjs"
        Me.chkUIShowObjs.Size = New System.Drawing.Size(128, 24)
        Me.chkUIShowObjs.TabIndex = 3
        Me.chkUIShowObjs.Text = "Show Objs"
        '
        'chkUIShowMsg
        '
        Me.chkUIShowMsg.Location = New System.Drawing.Point(152, 16)
        Me.chkUIShowMsg.Name = "chkUIShowMsg"
        Me.chkUIShowMsg.Size = New System.Drawing.Size(128, 24)
        Me.chkUIShowMsg.TabIndex = 2
        Me.chkUIShowMsg.Text = "Show Msg"
        '
        'chkUIShowWX
        '
        Me.chkUIShowWX.Location = New System.Drawing.Point(16, 40)
        Me.chkUIShowWX.Name = "chkUIShowWX"
        Me.chkUIShowWX.Size = New System.Drawing.Size(136, 24)
        Me.chkUIShowWX.TabIndex = 1
        Me.chkUIShowWX.Text = "Show Wx"
        '
        'chkUIShowPos
        '
        Me.chkUIShowPos.Location = New System.Drawing.Point(16, 16)
        Me.chkUIShowPos.Name = "chkUIShowPos"
        Me.chkUIShowPos.Size = New System.Drawing.Size(136, 24)
        Me.chkUIShowPos.TabIndex = 0
        Me.chkUIShowPos.Text = "Show Pos"
        '
        'grpXML
        '
        Me.grpXML.Controls.Add(Me.Button6)
        Me.grpXML.Controls.Add(Me.lblXMLdirectory)
        Me.grpXML.Controls.Add(Me.TextBox3)
        Me.grpXML.Controls.Add(Me.chkXMLAutoExport)
        Me.grpXML.Enabled = False
        Me.grpXML.Location = New System.Drawing.Point(192, 104)
        Me.grpXML.Name = "grpXML"
        Me.grpXML.Size = New System.Drawing.Size(272, 96)
        Me.grpXML.TabIndex = 12
        Me.grpXML.TabStop = False
        Me.grpXML.Text = "XML"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(224, 56)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(32, 24)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "..."
        '
        'lblXMLdirectory
        '
        Me.lblXMLdirectory.Location = New System.Drawing.Point(16, 56)
        Me.lblXMLdirectory.Name = "lblXMLdirectory"
        Me.lblXMLdirectory.Size = New System.Drawing.Size(136, 23)
        Me.lblXMLdirectory.TabIndex = 2
        Me.lblXMLdirectory.Text = "XML Export Directory"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(152, 56)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(64, 22)
        Me.TextBox3.TabIndex = 1
        Me.TextBox3.Text = "TextBox3"
        '
        'chkXMLAutoExport
        '
        Me.chkXMLAutoExport.Location = New System.Drawing.Point(16, 24)
        Me.chkXMLAutoExport.Name = "chkXMLAutoExport"
        Me.chkXMLAutoExport.Size = New System.Drawing.Size(208, 24)
        Me.chkXMLAutoExport.TabIndex = 0
        Me.chkXMLAutoExport.Text = "Automatic XML export"
        '
        'grpPrograms
        '
        Me.grpPrograms.Controls.Add(Me.chkOziDownloadMyPos)
        Me.grpPrograms.Controls.Add(Me.chkOziTrail)
        Me.grpPrograms.Controls.Add(Me.chkOziOnTop)
        Me.grpPrograms.Controls.Add(Me.ChkDecayAuto)
        Me.grpPrograms.Controls.Add(Me.chkInterfaceUIViewStartup)
        Me.grpPrograms.Controls.Add(Me.chkInterfaceMappointStartup)
        Me.grpPrograms.Controls.Add(Me.chkInterfaceOziStartup)
        Me.grpPrograms.Location = New System.Drawing.Point(552, 16)
        Me.grpPrograms.Name = "grpPrograms"
        Me.grpPrograms.Size = New System.Drawing.Size(320, 232)
        Me.grpPrograms.TabIndex = 11
        Me.grpPrograms.TabStop = False
        Me.grpPrograms.Text = "Programs"
        '
        'chkOziDownloadMyPos
        '
        Me.chkOziDownloadMyPos.Enabled = False
        Me.chkOziDownloadMyPos.Location = New System.Drawing.Point(40, 120)
        Me.chkOziDownloadMyPos.Name = "chkOziDownloadMyPos"
        Me.chkOziDownloadMyPos.Size = New System.Drawing.Size(264, 24)
        Me.chkOziDownloadMyPos.TabIndex = 6
        Me.chkOziDownloadMyPos.Text = "Download My Pos from Ozi"
        '
        'chkOziTrail
        '
        Me.chkOziTrail.Location = New System.Drawing.Point(40, 96)
        Me.chkOziTrail.Name = "chkOziTrail"
        Me.chkOziTrail.Size = New System.Drawing.Size(264, 24)
        Me.chkOziTrail.TabIndex = 5
        Me.chkOziTrail.Text = "Auto Trail moving stations"
        '
        'chkOziOnTop
        '
        Me.chkOziOnTop.Location = New System.Drawing.Point(40, 72)
        Me.chkOziOnTop.Name = "chkOziOnTop"
        Me.chkOziOnTop.Size = New System.Drawing.Size(240, 24)
        Me.chkOziOnTop.TabIndex = 4
        Me.chkOziOnTop.Text = "Keep Ozi On Top"
        '
        'ChkDecayAuto
        '
        Me.ChkDecayAuto.Location = New System.Drawing.Point(40, 48)
        Me.ChkDecayAuto.Name = "ChkDecayAuto"
        Me.ChkDecayAuto.Size = New System.Drawing.Size(240, 24)
        Me.ChkDecayAuto.TabIndex = 3
        Me.ChkDecayAuto.Text = "Decaying Icons"
        '
        'chkInterfaceUIViewStartup
        '
        Me.chkInterfaceUIViewStartup.Location = New System.Drawing.Point(16, 168)
        Me.chkInterfaceUIViewStartup.Name = "chkInterfaceUIViewStartup"
        Me.chkInterfaceUIViewStartup.Size = New System.Drawing.Size(256, 24)
        Me.chkInterfaceUIViewStartup.TabIndex = 2
        Me.chkInterfaceUIViewStartup.Text = "Connect to UI-View on Startup"
        '
        'chkInterfaceMappointStartup
        '
        Me.chkInterfaceMappointStartup.Location = New System.Drawing.Point(16, 144)
        Me.chkInterfaceMappointStartup.Name = "chkInterfaceMappointStartup"
        Me.chkInterfaceMappointStartup.Size = New System.Drawing.Size(272, 24)
        Me.chkInterfaceMappointStartup.TabIndex = 1
        Me.chkInterfaceMappointStartup.Text = "Connect to MapPoint on Startup"
        '
        'chkInterfaceOziStartup
        '
        Me.chkInterfaceOziStartup.Location = New System.Drawing.Point(16, 24)
        Me.chkInterfaceOziStartup.Name = "chkInterfaceOziStartup"
        Me.chkInterfaceOziStartup.Size = New System.Drawing.Size(264, 24)
        Me.chkInterfaceOziStartup.TabIndex = 0
        Me.chkInterfaceOziStartup.Text = "Connect to OziExplorer on Startup"
        '
        'grpRINO
        '
        Me.grpRINO.Controls.Add(Me.cmbRINOcom)
        Me.grpRINO.Controls.Add(Me.chkRINOauto)
        Me.grpRINO.Controls.Add(Me.lblRINOcomport)
        Me.grpRINO.Location = New System.Drawing.Point(192, 16)
        Me.grpRINO.Name = "grpRINO"
        Me.grpRINO.Size = New System.Drawing.Size(272, 80)
        Me.grpRINO.TabIndex = 10
        Me.grpRINO.TabStop = False
        Me.grpRINO.Text = "Rino"
        '
        'cmbRINOcom
        '
        Me.cmbRINOcom.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cmbRINOcom.Location = New System.Drawing.Point(192, 24)
        Me.cmbRINOcom.Name = "cmbRINOcom"
        Me.cmbRINOcom.Size = New System.Drawing.Size(64, 24)
        Me.cmbRINOcom.TabIndex = 9
        Me.cmbRINOcom.Text = "1"
        '
        'chkRINOauto
        '
        Me.chkRINOauto.Location = New System.Drawing.Point(16, 48)
        Me.chkRINOauto.Name = "chkRINOauto"
        Me.chkRINOauto.Size = New System.Drawing.Size(240, 24)
        Me.chkRINOauto.TabIndex = 8
        Me.chkRINOauto.Text = "AutoDownload RINO"
        '
        'lblRINOcomport
        '
        Me.lblRINOcomport.Location = New System.Drawing.Point(16, 24)
        Me.lblRINOcomport.Name = "lblRINOcomport"
        Me.lblRINOcomport.TabIndex = 7
        Me.lblRINOcomport.Text = "RINO Com Port"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkTNCMonitorOnly)
        Me.GroupBox1.Controls.Add(Me.cmbTNCSpeed)
        Me.GroupBox1.Controls.Add(Me.cmbTNCcom)
        Me.GroupBox1.Controls.Add(Me.chkTNCAuto)
        Me.GroupBox1.Controls.Add(Me.chkTNCKiss)
        Me.GroupBox1.Controls.Add(Me.lblTNCSpeed)
        Me.GroupBox1.Controls.Add(Me.lblTNCComPort)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(176, 184)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TNC"
        '
        'chkTNCMonitorOnly
        '
        Me.chkTNCMonitorOnly.Location = New System.Drawing.Point(8, 144)
        Me.chkTNCMonitorOnly.Name = "chkTNCMonitorOnly"
        Me.chkTNCMonitorOnly.Size = New System.Drawing.Size(152, 32)
        Me.chkTNCMonitorOnly.TabIndex = 10
        Me.chkTNCMonitorOnly.Text = "Monitor TNC only"
        '
        'cmbTNCSpeed
        '
        Me.cmbTNCSpeed.Items.AddRange(New Object() {"1200", "4800", "9600", "19200", "38400"})
        Me.cmbTNCSpeed.Location = New System.Drawing.Point(104, 56)
        Me.cmbTNCSpeed.Name = "cmbTNCSpeed"
        Me.cmbTNCSpeed.Size = New System.Drawing.Size(64, 24)
        Me.cmbTNCSpeed.TabIndex = 9
        Me.cmbTNCSpeed.Text = "9600"
        '
        'cmbTNCcom
        '
        Me.cmbTNCcom.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cmbTNCcom.Location = New System.Drawing.Point(104, 24)
        Me.cmbTNCcom.Name = "cmbTNCcom"
        Me.cmbTNCcom.Size = New System.Drawing.Size(64, 24)
        Me.cmbTNCcom.TabIndex = 8
        Me.cmbTNCcom.Text = "1"
        '
        'chkTNCAuto
        '
        Me.chkTNCAuto.Location = New System.Drawing.Point(8, 112)
        Me.chkTNCAuto.Name = "chkTNCAuto"
        Me.chkTNCAuto.Size = New System.Drawing.Size(160, 32)
        Me.chkTNCAuto.TabIndex = 7
        Me.chkTNCAuto.Text = "TNC AutoConnect"
        '
        'chkTNCKiss
        '
        Me.chkTNCKiss.Location = New System.Drawing.Point(8, 88)
        Me.chkTNCKiss.Name = "chkTNCKiss"
        Me.chkTNCKiss.Size = New System.Drawing.Size(152, 24)
        Me.chkTNCKiss.TabIndex = 6
        Me.chkTNCKiss.Text = "TNC KISS Mode"
        '
        'lblTNCSpeed
        '
        Me.lblTNCSpeed.Location = New System.Drawing.Point(8, 56)
        Me.lblTNCSpeed.Name = "lblTNCSpeed"
        Me.lblTNCSpeed.Size = New System.Drawing.Size(88, 32)
        Me.lblTNCSpeed.TabIndex = 5
        Me.lblTNCSpeed.Text = "TNC Speed"
        '
        'lblTNCComPort
        '
        Me.lblTNCComPort.Location = New System.Drawing.Point(8, 24)
        Me.lblTNCComPort.Name = "lblTNCComPort"
        Me.lblTNCComPort.Size = New System.Drawing.Size(100, 32)
        Me.lblTNCComPort.TabIndex = 4
        Me.lblTNCComPort.Text = "TNC COM Port"
        '
        'chkAGWPEauto
        '
        Me.chkAGWPEauto.Location = New System.Drawing.Point(496, 264)
        Me.chkAGWPEauto.Name = "chkAGWPEauto"
        Me.chkAGWPEauto.Size = New System.Drawing.Size(184, 24)
        Me.chkAGWPEauto.TabIndex = 7
        Me.chkAGWPEauto.Text = "AutoConnect to AGWPE"
        '
        'chkUploadDelay
        '
        Me.chkUploadDelay.Enabled = False
        Me.chkUploadDelay.Location = New System.Drawing.Point(488, 296)
        Me.chkUploadDelay.Name = "chkUploadDelay"
        Me.chkUploadDelay.Size = New System.Drawing.Size(272, 24)
        Me.chkUploadDelay.TabIndex = 4
        Me.chkUploadDelay.Text = "Upload only every 30 secs for license"
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.TabControl2)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(944, 323)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Beaconing"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage14)
        Me.TabControl2.Controls.Add(Me.TabPage10)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage12)
        Me.TabControl2.Controls.Add(Me.TabPage13)
        Me.TabControl2.ItemSize = New System.Drawing.Size(0, 21)
        Me.TabControl2.Location = New System.Drawing.Point(16, 16)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(880, 296)
        Me.TabControl2.TabIndex = 21
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.Label3)
        Me.TabPage14.Controls.Add(Me.GroupBox12)
        Me.TabPage14.Location = New System.Drawing.Point(4, 25)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Size = New System.Drawing.Size(872, 267)
        Me.TabPage14.TabIndex = 4
        Me.TabPage14.Text = "Path, Symbol and Rate"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(192, 216)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(376, 23)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Only AutoTX rate used here"
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.lblDigiPath)
        Me.GroupBox12.Controls.Add(Me.txtBCNDigi)
        Me.GroupBox12.Controls.Add(Me.lblAutoTXRate)
        Me.GroupBox12.Controls.Add(Me.Label33)
        Me.GroupBox12.Controls.Add(Me.lblSymbol)
        Me.GroupBox12.Controls.Add(Me.txtBCNtxRate)
        Me.GroupBox12.Controls.Add(Me.lblTable)
        Me.GroupBox12.Controls.Add(Me.txtBCNsymbol)
        Me.GroupBox12.Controls.Add(Me.txtBCNtable)
        Me.GroupBox12.Location = New System.Drawing.Point(192, 40)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(376, 168)
        Me.GroupBox12.TabIndex = 19
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "GroupBox12"
        '
        'lblDigiPath
        '
        Me.lblDigiPath.Location = New System.Drawing.Point(8, 24)
        Me.lblDigiPath.Name = "lblDigiPath"
        Me.lblDigiPath.Size = New System.Drawing.Size(128, 23)
        Me.lblDigiPath.TabIndex = 3
        Me.lblDigiPath.Text = "Digi Path:"
        '
        'txtBCNDigi
        '
        Me.txtBCNDigi.Location = New System.Drawing.Point(200, 24)
        Me.txtBCNDigi.Name = "txtBCNDigi"
        Me.txtBCNDigi.Size = New System.Drawing.Size(168, 22)
        Me.txtBCNDigi.TabIndex = 11
        Me.txtBCNDigi.Text = "WIDE2-2"
        '
        'lblAutoTXRate
        '
        Me.lblAutoTXRate.Location = New System.Drawing.Point(16, 136)
        Me.lblAutoTXRate.Name = "lblAutoTXRate"
        Me.lblAutoTXRate.Size = New System.Drawing.Size(184, 23)
        Me.lblAutoTXRate.TabIndex = 7
        Me.lblAutoTXRate.Text = "Auto Transmit Rate"
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(320, 136)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(40, 23)
        Me.Label33.TabIndex = 15
        Me.Label33.Tag = "Sec"
        Me.Label33.Text = "Sec"
        '
        'lblSymbol
        '
        Me.lblSymbol.Location = New System.Drawing.Point(8, 56)
        Me.lblSymbol.Name = "lblSymbol"
        Me.lblSymbol.Size = New System.Drawing.Size(56, 23)
        Me.lblSymbol.TabIndex = 4
        Me.lblSymbol.Text = "Symbol:"
        Me.lblSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtBCNtxRate
        '
        Me.txtBCNtxRate.Location = New System.Drawing.Point(240, 136)
        Me.txtBCNtxRate.Name = "txtBCNtxRate"
        Me.txtBCNtxRate.Size = New System.Drawing.Size(32, 22)
        Me.txtBCNtxRate.TabIndex = 14
        Me.txtBCNtxRate.Text = "120"
        '
        'lblTable
        '
        Me.lblTable.Location = New System.Drawing.Point(136, 56)
        Me.lblTable.Name = "lblTable"
        Me.lblTable.Size = New System.Drawing.Size(112, 32)
        Me.lblTable.TabIndex = 5
        Me.lblTable.Text = "Table/Overlay :"
        '
        'txtBCNsymbol
        '
        Me.txtBCNsymbol.Location = New System.Drawing.Point(72, 56)
        Me.txtBCNsymbol.Name = "txtBCNsymbol"
        Me.txtBCNsymbol.Size = New System.Drawing.Size(32, 22)
        Me.txtBCNsymbol.TabIndex = 12
        Me.txtBCNsymbol.Text = ">"
        '
        'txtBCNtable
        '
        Me.txtBCNtable.Location = New System.Drawing.Point(288, 48)
        Me.txtBCNtable.Name = "txtBCNtable"
        Me.txtBCNtable.Size = New System.Drawing.Size(16, 22)
        Me.txtBCNtable.TabIndex = 13
        Me.txtBCNtable.Text = "/"
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.grpSmartBeacon)
        Me.TabPage10.Location = New System.Drawing.Point(4, 25)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(872, 267)
        Me.TabPage10.TabIndex = 0
        Me.TabPage10.Text = "Smart Beaconing"
        '
        'grpSmartBeacon
        '
        Me.grpSmartBeacon.Controls.Add(Me.lblTurnSeconds)
        Me.grpSmartBeacon.Controls.Add(Me.Label39)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNturntime)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNturnslope)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNturnangle)
        Me.grpSmartBeacon.Controls.Add(Me.lblTurnTime)
        Me.grpSmartBeacon.Controls.Add(Me.lblTurnSlope)
        Me.grpSmartBeacon.Controls.Add(Me.lblMinTurnAngle)
        Me.grpSmartBeacon.Controls.Add(Me.chkSmartEnable)
        Me.grpSmartBeacon.Controls.Add(Me.lblSlowRate)
        Me.grpSmartBeacon.Controls.Add(Me.lblFastSpeed)
        Me.grpSmartBeacon.Controls.Add(Me.lblFastRate)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNfastspeed)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNfastrate)
        Me.grpSmartBeacon.Controls.Add(Me.Label46)
        Me.grpSmartBeacon.Controls.Add(Me.lblFastRateSeconds)
        Me.grpSmartBeacon.Controls.Add(Me.lblSlowSpeed)
        Me.grpSmartBeacon.Controls.Add(Me.lblSlowRateSeconds)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNslowspeed)
        Me.grpSmartBeacon.Controls.Add(Me.txtBCNslowrate)
        Me.grpSmartBeacon.Controls.Add(Me.Label43)
        Me.grpSmartBeacon.Location = New System.Drawing.Point(108, 9)
        Me.grpSmartBeacon.Name = "grpSmartBeacon"
        Me.grpSmartBeacon.Size = New System.Drawing.Size(524, 184)
        Me.grpSmartBeacon.TabIndex = 20
        Me.grpSmartBeacon.TabStop = False
        Me.grpSmartBeacon.Text = "SmartBeaconing"
        '
        'lblTurnSeconds
        '
        Me.lblTurnSeconds.Location = New System.Drawing.Point(168, 136)
        Me.lblTurnSeconds.Name = "lblTurnSeconds"
        Me.lblTurnSeconds.Size = New System.Drawing.Size(64, 23)
        Me.lblTurnSeconds.TabIndex = 8
        Me.lblTurnSeconds.Text = "Secs"
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(168, 64)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(40, 23)
        Me.Label39.TabIndex = 7
        Me.Label39.Text = "Deg"
        '
        'txtBCNturntime
        '
        Me.txtBCNturntime.Location = New System.Drawing.Point(120, 136)
        Me.txtBCNturntime.Name = "txtBCNturntime"
        Me.txtBCNturntime.Size = New System.Drawing.Size(48, 22)
        Me.txtBCNturntime.TabIndex = 6
        Me.txtBCNturntime.Text = ""
        '
        'txtBCNturnslope
        '
        Me.txtBCNturnslope.Location = New System.Drawing.Point(120, 96)
        Me.txtBCNturnslope.Name = "txtBCNturnslope"
        Me.txtBCNturnslope.Size = New System.Drawing.Size(48, 22)
        Me.txtBCNturnslope.TabIndex = 5
        Me.txtBCNturnslope.Text = ""
        '
        'txtBCNturnangle
        '
        Me.txtBCNturnangle.Location = New System.Drawing.Point(120, 56)
        Me.txtBCNturnangle.Name = "txtBCNturnangle"
        Me.txtBCNturnangle.Size = New System.Drawing.Size(48, 22)
        Me.txtBCNturnangle.TabIndex = 4
        Me.txtBCNturnangle.Text = ""
        '
        'lblTurnTime
        '
        Me.lblTurnTime.Location = New System.Drawing.Point(8, 136)
        Me.lblTurnTime.Name = "lblTurnTime"
        Me.lblTurnTime.Size = New System.Drawing.Size(100, 24)
        Me.lblTurnTime.TabIndex = 3
        Me.lblTurnTime.Text = "Min Turn Time"
        '
        'lblTurnSlope
        '
        Me.lblTurnSlope.Location = New System.Drawing.Point(8, 96)
        Me.lblTurnSlope.Name = "lblTurnSlope"
        Me.lblTurnSlope.Size = New System.Drawing.Size(100, 24)
        Me.lblTurnSlope.TabIndex = 2
        Me.lblTurnSlope.Tag = "Turn Slope"
        Me.lblTurnSlope.Text = "Min Turn Slope"
        '
        'lblMinTurnAngle
        '
        Me.lblMinTurnAngle.Location = New System.Drawing.Point(8, 56)
        Me.lblMinTurnAngle.Name = "lblMinTurnAngle"
        Me.lblMinTurnAngle.Size = New System.Drawing.Size(100, 24)
        Me.lblMinTurnAngle.TabIndex = 1
        Me.lblMinTurnAngle.Text = "Min Turn Angle"
        '
        'chkSmartEnable
        '
        Me.chkSmartEnable.Location = New System.Drawing.Point(8, 24)
        Me.chkSmartEnable.Name = "chkSmartEnable"
        Me.chkSmartEnable.TabIndex = 0
        Me.chkSmartEnable.Text = "Enable"
        '
        'lblSlowRate
        '
        Me.lblSlowRate.Location = New System.Drawing.Point(232, 72)
        Me.lblSlowRate.Name = "lblSlowRate"
        Me.lblSlowRate.Size = New System.Drawing.Size(112, 23)
        Me.lblSlowRate.TabIndex = 21
        Me.lblSlowRate.Text = "Slow Rate"
        '
        'lblFastSpeed
        '
        Me.lblFastSpeed.Location = New System.Drawing.Point(232, 104)
        Me.lblFastSpeed.Name = "lblFastSpeed"
        Me.lblFastSpeed.Size = New System.Drawing.Size(112, 23)
        Me.lblFastSpeed.TabIndex = 26
        Me.lblFastSpeed.Text = "Fast Speed"
        '
        'lblFastRate
        '
        Me.lblFastRate.Location = New System.Drawing.Point(232, 136)
        Me.lblFastRate.Name = "lblFastRate"
        Me.lblFastRate.Size = New System.Drawing.Size(112, 23)
        Me.lblFastRate.TabIndex = 27
        Me.lblFastRate.Text = "Fast Rate"
        '
        'txtBCNfastspeed
        '
        Me.txtBCNfastspeed.Location = New System.Drawing.Point(368, 104)
        Me.txtBCNfastspeed.Name = "txtBCNfastspeed"
        Me.txtBCNfastspeed.Size = New System.Drawing.Size(40, 22)
        Me.txtBCNfastspeed.TabIndex = 28
        Me.txtBCNfastspeed.Text = ""
        '
        'txtBCNfastrate
        '
        Me.txtBCNfastrate.Location = New System.Drawing.Point(368, 136)
        Me.txtBCNfastrate.Name = "txtBCNfastrate"
        Me.txtBCNfastrate.Size = New System.Drawing.Size(40, 22)
        Me.txtBCNfastrate.TabIndex = 29
        Me.txtBCNfastrate.Text = ""
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(416, 104)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(48, 23)
        Me.Label46.TabIndex = 30
        Me.Label46.Text = "MPH"
        '
        'lblFastRateSeconds
        '
        Me.lblFastRateSeconds.Location = New System.Drawing.Point(416, 144)
        Me.lblFastRateSeconds.Name = "lblFastRateSeconds"
        Me.lblFastRateSeconds.Size = New System.Drawing.Size(64, 23)
        Me.lblFastRateSeconds.TabIndex = 31
        Me.lblFastRateSeconds.Text = "Secs"
        '
        'lblSlowSpeed
        '
        Me.lblSlowSpeed.Location = New System.Drawing.Point(232, 40)
        Me.lblSlowSpeed.Name = "lblSlowSpeed"
        Me.lblSlowSpeed.Size = New System.Drawing.Size(112, 23)
        Me.lblSlowSpeed.TabIndex = 20
        Me.lblSlowSpeed.Text = "Slow Speed"
        '
        'lblSlowRateSeconds
        '
        Me.lblSlowRateSeconds.Location = New System.Drawing.Point(416, 72)
        Me.lblSlowRateSeconds.Name = "lblSlowRateSeconds"
        Me.lblSlowRateSeconds.Size = New System.Drawing.Size(64, 23)
        Me.lblSlowRateSeconds.TabIndex = 25
        Me.lblSlowRateSeconds.Text = "Secs"
        '
        'txtBCNslowspeed
        '
        Me.txtBCNslowspeed.Location = New System.Drawing.Point(368, 40)
        Me.txtBCNslowspeed.Name = "txtBCNslowspeed"
        Me.txtBCNslowspeed.Size = New System.Drawing.Size(40, 22)
        Me.txtBCNslowspeed.TabIndex = 22
        Me.txtBCNslowspeed.Text = ""
        '
        'txtBCNslowrate
        '
        Me.txtBCNslowrate.Location = New System.Drawing.Point(368, 72)
        Me.txtBCNslowrate.Name = "txtBCNslowrate"
        Me.txtBCNslowrate.Size = New System.Drawing.Size(40, 22)
        Me.txtBCNslowrate.TabIndex = 23
        Me.txtBCNslowrate.Text = ""
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(416, 40)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(48, 23)
        Me.Label43.TabIndex = 24
        Me.Label43.Text = "MPH"
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.grpMICE)
        Me.TabPage11.Location = New System.Drawing.Point(4, 25)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(872, 267)
        Me.TabPage11.TabIndex = 1
        Me.TabPage11.Text = "Mic-E"
        '
        'grpMICE
        '
        Me.grpMICE.Controls.Add(Me.lblMICEPath)
        Me.grpMICE.Controls.Add(Me.lblMICEMessage)
        Me.grpMICE.Controls.Add(Me.cboMICEpath)
        Me.grpMICE.Controls.Add(Me.cboMICEmessage)
        Me.grpMICE.Controls.Add(Me.chkMICEprintable)
        Me.grpMICE.Controls.Add(Me.chkMICEEnable)
        Me.grpMICE.Location = New System.Drawing.Point(220, 37)
        Me.grpMICE.Name = "grpMICE"
        Me.grpMICE.Size = New System.Drawing.Size(284, 128)
        Me.grpMICE.TabIndex = 20
        Me.grpMICE.TabStop = False
        Me.grpMICE.Text = "MIC-E"
        '
        'lblMICEPath
        '
        Me.lblMICEPath.Location = New System.Drawing.Point(8, 96)
        Me.lblMICEPath.Name = "lblMICEPath"
        Me.lblMICEPath.Size = New System.Drawing.Size(104, 23)
        Me.lblMICEPath.TabIndex = 5
        Me.lblMICEPath.Text = "Path"
        '
        'lblMICEMessage
        '
        Me.lblMICEMessage.Location = New System.Drawing.Point(8, 64)
        Me.lblMICEMessage.Name = "lblMICEMessage"
        Me.lblMICEMessage.Size = New System.Drawing.Size(112, 23)
        Me.lblMICEMessage.TabIndex = 4
        Me.lblMICEMessage.Text = "Message"
        '
        'cboMICEpath
        '
        Me.cboMICEpath.Items.AddRange(New Object() {"Conventional"})
        Me.cboMICEpath.Location = New System.Drawing.Point(152, 96)
        Me.cboMICEpath.Name = "cboMICEpath"
        Me.cboMICEpath.Size = New System.Drawing.Size(121, 24)
        Me.cboMICEpath.TabIndex = 3
        Me.cboMICEpath.Text = "Conventional"
        '
        'cboMICEmessage
        '
        Me.cboMICEmessage.Items.AddRange(New Object() {"Off Duty"})
        Me.cboMICEmessage.Location = New System.Drawing.Point(152, 64)
        Me.cboMICEmessage.Name = "cboMICEmessage"
        Me.cboMICEmessage.Size = New System.Drawing.Size(120, 24)
        Me.cboMICEmessage.TabIndex = 2
        Me.cboMICEmessage.Text = "Off Duty"
        '
        'chkMICEprintable
        '
        Me.chkMICEprintable.Location = New System.Drawing.Point(8, 40)
        Me.chkMICEprintable.Name = "chkMICEprintable"
        Me.chkMICEprintable.Size = New System.Drawing.Size(128, 24)
        Me.chkMICEprintable.TabIndex = 1
        Me.chkMICEprintable.Text = "Force Printable"
        '
        'chkMICEEnable
        '
        Me.chkMICEEnable.Location = New System.Drawing.Point(8, 16)
        Me.chkMICEEnable.Name = "chkMICEEnable"
        Me.chkMICEEnable.TabIndex = 0
        Me.chkMICEEnable.Text = "Enable"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.GroupBox4)
        Me.TabPage12.Location = New System.Drawing.Point(4, 25)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(872, 267)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "Default Position"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtDefaultLon)
        Me.GroupBox4.Controls.Add(Me.txtDefaultLat)
        Me.GroupBox4.Controls.Add(Me.lblLon)
        Me.GroupBox4.Controls.Add(Me.lblLat)
        Me.GroupBox4.Location = New System.Drawing.Point(32, 32)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(256, 128)
        Me.GroupBox4.TabIndex = 21
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "GroupBox4"
        '
        'txtDefaultLon
        '
        Me.txtDefaultLon.Enabled = False
        Me.txtDefaultLon.Location = New System.Drawing.Point(88, 72)
        Me.txtDefaultLon.Name = "txtDefaultLon"
        Me.txtDefaultLon.Size = New System.Drawing.Size(120, 22)
        Me.txtDefaultLon.TabIndex = 19
        Me.txtDefaultLon.Text = "TextBox3"
        '
        'txtDefaultLat
        '
        Me.txtDefaultLat.Enabled = False
        Me.txtDefaultLat.Location = New System.Drawing.Point(88, 32)
        Me.txtDefaultLat.Name = "txtDefaultLat"
        Me.txtDefaultLat.Size = New System.Drawing.Size(120, 22)
        Me.txtDefaultLat.TabIndex = 18
        Me.txtDefaultLat.Text = "TextBox2"
        '
        'lblLon
        '
        Me.lblLon.Location = New System.Drawing.Point(8, 72)
        Me.lblLon.Name = "lblLon"
        Me.lblLon.Size = New System.Drawing.Size(80, 23)
        Me.lblLon.TabIndex = 17
        Me.lblLon.Text = "Default Lon"
        '
        'lblLat
        '
        Me.lblLat.Location = New System.Drawing.Point(8, 32)
        Me.lblLat.Name = "lblLat"
        Me.lblLat.Size = New System.Drawing.Size(72, 23)
        Me.lblLat.TabIndex = 16
        Me.lblLat.Text = "Default Lat"
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.gprStatus)
        Me.TabPage13.Controls.Add(Me.GroupBox11)
        Me.TabPage13.Location = New System.Drawing.Point(4, 25)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(872, 267)
        Me.TabPage13.TabIndex = 3
        Me.TabPage13.Text = "Settings"
        '
        'gprStatus
        '
        Me.gprStatus.Controls.Add(Me.txtBCNsendevery)
        Me.gprStatus.Controls.Add(Me.txtBCNstatus)
        Me.gprStatus.Controls.Add(Me.chkBCNSendSeperate)
        Me.gprStatus.Controls.Add(Me.lblSendEvery)
        Me.gprStatus.Controls.Add(Me.lblStatustext)
        Me.gprStatus.Location = New System.Drawing.Point(320, 16)
        Me.gprStatus.Name = "gprStatus"
        Me.gprStatus.Size = New System.Drawing.Size(296, 88)
        Me.gprStatus.TabIndex = 19
        Me.gprStatus.TabStop = False
        Me.gprStatus.Text = "Status"
        '
        'txtBCNsendevery
        '
        Me.txtBCNsendevery.Location = New System.Drawing.Point(96, 48)
        Me.txtBCNsendevery.Name = "txtBCNsendevery"
        Me.txtBCNsendevery.Size = New System.Drawing.Size(32, 22)
        Me.txtBCNsendevery.TabIndex = 15
        Me.txtBCNsendevery.Text = "3"
        '
        'txtBCNstatus
        '
        Me.txtBCNstatus.Location = New System.Drawing.Point(120, 16)
        Me.txtBCNstatus.Name = "txtBCNstatus"
        Me.txtBCNstatus.Size = New System.Drawing.Size(136, 22)
        Me.txtBCNstatus.TabIndex = 14
        Me.txtBCNstatus.Text = "TextBox9"
        '
        'chkBCNSendSeperate
        '
        Me.chkBCNSendSeperate.Location = New System.Drawing.Point(136, 48)
        Me.chkBCNSendSeperate.Name = "chkBCNSendSeperate"
        Me.chkBCNSendSeperate.Size = New System.Drawing.Size(128, 24)
        Me.chkBCNSendSeperate.TabIndex = 13
        Me.chkBCNSendSeperate.Text = "Send Seperate"
        '
        'lblSendEvery
        '
        Me.lblSendEvery.Location = New System.Drawing.Point(8, 48)
        Me.lblSendEvery.Name = "lblSendEvery"
        Me.lblSendEvery.Size = New System.Drawing.Size(80, 23)
        Me.lblSendEvery.TabIndex = 12
        Me.lblSendEvery.Text = "Send Every:"
        '
        'lblStatustext
        '
        Me.lblStatustext.Location = New System.Drawing.Point(8, 16)
        Me.lblStatustext.Name = "lblStatustext"
        Me.lblStatustext.Size = New System.Drawing.Size(104, 23)
        Me.lblStatustext.TabIndex = 11
        Me.lblStatustext.Text = "Status Text:"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.chkNMEASend)
        Me.GroupBox11.Controls.Add(Me.chkBCNAltDigi)
        Me.GroupBox11.Controls.Add(Me.chkBCNSendAlt)
        Me.GroupBox11.Controls.Add(Me.chkBCNHMS)
        Me.GroupBox11.Controls.Add(Me.chkBcnDHM)
        Me.GroupBox11.Controls.Add(Me.chkBCNValid)
        Me.GroupBox11.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(296, 96)
        Me.GroupBox11.TabIndex = 18
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "GroupBox11"
        '
        'chkNMEASend
        '
        Me.chkNMEASend.Location = New System.Drawing.Point(136, 64)
        Me.chkNMEASend.Name = "chkNMEASend"
        Me.chkNMEASend.TabIndex = 5
        Me.chkNMEASend.Text = "Send NMEA"
        '
        'chkBCNAltDigi
        '
        Me.chkBCNAltDigi.Location = New System.Drawing.Point(136, 40)
        Me.chkBCNAltDigi.Name = "chkBCNAltDigi"
        Me.chkBCNAltDigi.Size = New System.Drawing.Size(144, 24)
        Me.chkBCNAltDigi.TabIndex = 4
        Me.chkBCNAltDigi.Text = "Alternate Digi Paths"
        '
        'chkBCNSendAlt
        '
        Me.chkBCNSendAlt.Location = New System.Drawing.Point(136, 16)
        Me.chkBCNSendAlt.Name = "chkBCNSendAlt"
        Me.chkBCNSendAlt.TabIndex = 3
        Me.chkBCNSendAlt.Text = "Send Altitude"
        '
        'chkBCNHMS
        '
        Me.chkBCNHMS.Location = New System.Drawing.Point(8, 64)
        Me.chkBCNHMS.Name = "chkBCNHMS"
        Me.chkBCNHMS.Size = New System.Drawing.Size(144, 24)
        Me.chkBCNHMS.TabIndex = 2
        Me.chkBCNHMS.Text = "Timestamp HMS"
        '
        'chkBcnDHM
        '
        Me.chkBcnDHM.Location = New System.Drawing.Point(8, 40)
        Me.chkBcnDHM.Name = "chkBcnDHM"
        Me.chkBcnDHM.Size = New System.Drawing.Size(128, 24)
        Me.chkBcnDHM.TabIndex = 1
        Me.chkBcnDHM.Text = "Timestamp DHM"
        '
        'chkBCNValid
        '
        Me.chkBCNValid.Location = New System.Drawing.Point(8, 16)
        Me.chkBCNValid.Name = "chkBCNValid"
        Me.chkBCNValid.Size = New System.Drawing.Size(128, 24)
        Me.chkBCNValid.TabIndex = 0
        Me.chkBCNValid.Text = "Only Send Valid"
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.chkShowInterface)
        Me.TabPage9.Controls.Add(Me.chkShowLogDatabase)
        Me.TabPage9.Controls.Add(Me.chkShowOziAutotrail)
        Me.TabPage9.Controls.Add(Me.chkShowOziDecay)
        Me.TabPage9.Controls.Add(Me.chkShowOziSyncClear)
        Me.TabPage9.Controls.Add(Me.chkShowDatabase)
        Me.TabPage9.Controls.Add(Me.chkShowTranslate)
        Me.TabPage9.Controls.Add(Me.chkShowUploadMonitored)
        Me.TabPage9.Controls.Add(Me.chkShowGeofiltering)
        Me.TabPage9.Controls.Add(Me.chkShowLOG)
        Me.TabPage9.Controls.Add(Me.chkShowRINO)
        Me.TabPage9.Controls.Add(Me.chkShowWx)
        Me.TabPage9.Controls.Add(Me.chkShowGPS)
        Me.TabPage9.Controls.Add(Me.chkShowTNC)
        Me.TabPage9.Controls.Add(Me.chkShowAGWPEUIVIEW)
        Me.TabPage9.Controls.Add(Me.chkShowMapPoint)
        Me.TabPage9.Controls.Add(Me.chkShowOzi)
        Me.TabPage9.Controls.Add(Me.chkShowNetwork)
        Me.TabPage9.Controls.Add(Me.chkShowHelp)
        Me.TabPage9.Controls.Add(Me.chkShowGUI)
        Me.TabPage9.Controls.Add(Me.chkShowServices)
        Me.TabPage9.Controls.Add(Me.chkShowFile)
        Me.TabPage9.Controls.Add(Me.chkShowSetup)
        Me.TabPage9.Location = New System.Drawing.Point(4, 25)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(944, 323)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Menus"
        '
        'chkShowInterface
        '
        Me.chkShowInterface.Location = New System.Drawing.Point(32, 136)
        Me.chkShowInterface.Name = "chkShowInterface"
        Me.chkShowInterface.Size = New System.Drawing.Size(208, 24)
        Me.chkShowInterface.TabIndex = 30
        Me.chkShowInterface.Text = "Show INTERFACES menu"
        '
        'chkShowLogDatabase
        '
        Me.chkShowLogDatabase.Location = New System.Drawing.Point(248, 112)
        Me.chkShowLogDatabase.Name = "chkShowLogDatabase"
        Me.chkShowLogDatabase.Size = New System.Drawing.Size(224, 24)
        Me.chkShowLogDatabase.TabIndex = 29
        Me.chkShowLogDatabase.Text = "Show Log to Database menu"
        '
        'chkShowOziAutotrail
        '
        Me.chkShowOziAutotrail.Location = New System.Drawing.Point(248, 240)
        Me.chkShowOziAutotrail.Name = "chkShowOziAutotrail"
        Me.chkShowOziAutotrail.Size = New System.Drawing.Size(280, 16)
        Me.chkShowOziAutotrail.TabIndex = 28
        Me.chkShowOziAutotrail.Text = "Show Ozi AutoTRAIL menu"
        '
        'chkShowOziDecay
        '
        Me.chkShowOziDecay.Location = New System.Drawing.Point(248, 216)
        Me.chkShowOziDecay.Name = "chkShowOziDecay"
        Me.chkShowOziDecay.Size = New System.Drawing.Size(288, 24)
        Me.chkShowOziDecay.TabIndex = 27
        Me.chkShowOziDecay.Text = "Show Ozi DECAYING Icons Menu"
        '
        'chkShowOziSyncClear
        '
        Me.chkShowOziSyncClear.Location = New System.Drawing.Point(248, 192)
        Me.chkShowOziSyncClear.Name = "chkShowOziSyncClear"
        Me.chkShowOziSyncClear.Size = New System.Drawing.Size(296, 24)
        Me.chkShowOziSyncClear.TabIndex = 26
        Me.chkShowOziSyncClear.Text = "Show OziExplorer SYNC and CLEAR menus"
        '
        'chkShowDatabase
        '
        Me.chkShowDatabase.Location = New System.Drawing.Point(528, 40)
        Me.chkShowDatabase.Name = "chkShowDatabase"
        Me.chkShowDatabase.Size = New System.Drawing.Size(216, 24)
        Me.chkShowDatabase.TabIndex = 25
        Me.chkShowDatabase.Text = "Show Database Playback menu"
        '
        'chkShowTranslate
        '
        Me.chkShowTranslate.Location = New System.Drawing.Point(528, 88)
        Me.chkShowTranslate.Name = "chkShowTranslate"
        Me.chkShowTranslate.Size = New System.Drawing.Size(208, 24)
        Me.chkShowTranslate.TabIndex = 24
        Me.chkShowTranslate.Text = "Show TRANSLATE menu"
        '
        'chkShowUploadMonitored
        '
        Me.chkShowUploadMonitored.Location = New System.Drawing.Point(528, 64)
        Me.chkShowUploadMonitored.Name = "chkShowUploadMonitored"
        Me.chkShowUploadMonitored.Size = New System.Drawing.Size(240, 24)
        Me.chkShowUploadMonitored.TabIndex = 23
        Me.chkShowUploadMonitored.Text = "Show Upload Monitored Only menu"
        '
        'chkShowGeofiltering
        '
        Me.chkShowGeofiltering.Location = New System.Drawing.Point(528, 16)
        Me.chkShowGeofiltering.Name = "chkShowGeofiltering"
        Me.chkShowGeofiltering.Size = New System.Drawing.Size(192, 24)
        Me.chkShowGeofiltering.TabIndex = 22
        Me.chkShowGeofiltering.Text = "Show GeoFiltering menu"
        '
        'chkShowLOG
        '
        Me.chkShowLOG.Location = New System.Drawing.Point(32, 280)
        Me.chkShowLOG.Name = "chkShowLOG"
        Me.chkShowLOG.Size = New System.Drawing.Size(152, 24)
        Me.chkShowLOG.TabIndex = 21
        Me.chkShowLOG.Text = "Show LOG menu"
        '
        'chkShowRINO
        '
        Me.chkShowRINO.Location = New System.Drawing.Point(32, 256)
        Me.chkShowRINO.Name = "chkShowRINO"
        Me.chkShowRINO.Size = New System.Drawing.Size(152, 24)
        Me.chkShowRINO.TabIndex = 20
        Me.chkShowRINO.Text = "Show RINO menu"
        '
        'chkShowWx
        '
        Me.chkShowWx.Location = New System.Drawing.Point(32, 232)
        Me.chkShowWx.Name = "chkShowWx"
        Me.chkShowWx.Size = New System.Drawing.Size(192, 24)
        Me.chkShowWx.TabIndex = 19
        Me.chkShowWx.Text = "Show Wx Menu"
        '
        'chkShowGPS
        '
        Me.chkShowGPS.Location = New System.Drawing.Point(32, 208)
        Me.chkShowGPS.Name = "chkShowGPS"
        Me.chkShowGPS.Size = New System.Drawing.Size(152, 24)
        Me.chkShowGPS.TabIndex = 18
        Me.chkShowGPS.Text = "Show GPS menu"
        '
        'chkShowTNC
        '
        Me.chkShowTNC.Location = New System.Drawing.Point(32, 184)
        Me.chkShowTNC.Name = "chkShowTNC"
        Me.chkShowTNC.Size = New System.Drawing.Size(184, 24)
        Me.chkShowTNC.TabIndex = 17
        Me.chkShowTNC.Text = "Show TNC menu"
        '
        'chkShowAGWPEUIVIEW
        '
        Me.chkShowAGWPEUIVIEW.Location = New System.Drawing.Point(248, 88)
        Me.chkShowAGWPEUIVIEW.Name = "chkShowAGWPEUIVIEW"
        Me.chkShowAGWPEUIVIEW.Size = New System.Drawing.Size(256, 24)
        Me.chkShowAGWPEUIVIEW.TabIndex = 16
        Me.chkShowAGWPEUIVIEW.Text = "Show AGWPE and UIVIew"
        '
        'chkShowMapPoint
        '
        Me.chkShowMapPoint.Location = New System.Drawing.Point(248, 64)
        Me.chkShowMapPoint.Name = "chkShowMapPoint"
        Me.chkShowMapPoint.Size = New System.Drawing.Size(256, 24)
        Me.chkShowMapPoint.TabIndex = 15
        Me.chkShowMapPoint.Text = "Show Connect to MapPoint MENU"
        '
        'chkShowOzi
        '
        Me.chkShowOzi.Location = New System.Drawing.Point(248, 40)
        Me.chkShowOzi.Name = "chkShowOzi"
        Me.chkShowOzi.Size = New System.Drawing.Size(260, 24)
        Me.chkShowOzi.TabIndex = 13
        Me.chkShowOzi.Text = "Show Connect to OziExplorer MENU"
        '
        'chkShowNetwork
        '
        Me.chkShowNetwork.Location = New System.Drawing.Point(248, 16)
        Me.chkShowNetwork.Name = "chkShowNetwork"
        Me.chkShowNetwork.Size = New System.Drawing.Size(224, 24)
        Me.chkShowNetwork.TabIndex = 12
        Me.chkShowNetwork.Text = "Show NETWORK server menus"
        '
        'chkShowHelp
        '
        Me.chkShowHelp.Location = New System.Drawing.Point(32, 112)
        Me.chkShowHelp.Name = "chkShowHelp"
        Me.chkShowHelp.Size = New System.Drawing.Size(152, 24)
        Me.chkShowHelp.TabIndex = 11
        Me.chkShowHelp.Text = "Show HELP menu"
        '
        'chkShowGUI
        '
        Me.chkShowGUI.Location = New System.Drawing.Point(32, 88)
        Me.chkShowGUI.Name = "chkShowGUI"
        Me.chkShowGUI.Size = New System.Drawing.Size(152, 24)
        Me.chkShowGUI.TabIndex = 10
        Me.chkShowGUI.Text = "Show GUI menu"
        '
        'chkShowServices
        '
        Me.chkShowServices.Location = New System.Drawing.Point(32, 64)
        Me.chkShowServices.Name = "chkShowServices"
        Me.chkShowServices.Size = New System.Drawing.Size(176, 24)
        Me.chkShowServices.TabIndex = 9
        Me.chkShowServices.Text = "Show SERVICES menu"
        '
        'chkShowFile
        '
        Me.chkShowFile.Location = New System.Drawing.Point(32, 16)
        Me.chkShowFile.Name = "chkShowFile"
        Me.chkShowFile.Size = New System.Drawing.Size(144, 24)
        Me.chkShowFile.TabIndex = 8
        Me.chkShowFile.Text = "Show FILE menu"
        '
        'chkShowSetup
        '
        Me.chkShowSetup.Location = New System.Drawing.Point(32, 40)
        Me.chkShowSetup.Name = "chkShowSetup"
        Me.chkShowSetup.Size = New System.Drawing.Size(152, 24)
        Me.chkShowSetup.TabIndex = 7
        Me.chkShowSetup.Text = "Show Setup Menu"
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(240, 160)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(72, 24)
        Me.Button14.TabIndex = 43
        Me.Button14.Text = "NewConfig"
        '
        'frmSetup
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(976, 432)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmSetup"
        Me.ShowInTaskbar = False
        Me.Tag = ""
        Me.Text = "NetAPRS Setup Screen"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.grpGPS.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.grpDatabase.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.gpriGate.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.grpIncoming.ResumeLayout(False)
        Me.gprOutgoing.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.grpXML.ResumeLayout(False)
        Me.grpPrograms.ResumeLayout(False)
        Me.grpRINO.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage14.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.grpSmartBeacon.ResumeLayout(False)
        Me.TabPage11.ResumeLayout(False)
        Me.grpMICE.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.gprStatus.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Function cbl(ByVal onestring As String) As Boolean
        Try
            Return CBool(onestring)
        Catch ex As Exception
            Return False

        End Try
        Return False

    End Function


    Private Sub frmSetup_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With setup
            chkAutoNetGPSListen.Checked = cbl(.boolIncomingNetGPSAutoStart)
            chkAutoGPRSListen.Checked = cbl(.boolIncomingGPRSAutoStart)
            chkAutoHUBlisten.Checked = cbl(.boolIncomingServerAutoStart)
            chkHubDumpHistory.Checked = cbl(.boolIncomingServerDumpHistory)
            chkAutoServerConnect.Checked = cbl(.boolOutgoingServerAutoConnect)

            chkTNCMonitorOnly.Checked = cbl(.boolTNCMonitorOnly)
            cboLanguage.Text = .strLanguage


            chkOziTrail.Checked = .boolInterfaceOziAutoTrailMoving


            chkTNCKiss.Checked = cbl(.boolTNCKissMode)
            chkTNCAuto.Checked = cbl(.boolTNCAutoConnect)
            chkAGWPEauto.Checked = cbl(.boolAGWPEAutoConnect)
            chkUploadDelay.Checked = cbl(.boolUploadNonLive)
            chkNMEAauto.Checked = cbl(.boolNMEAAutoStart)
            chkRINOauto.Checked = cbl(.boolRinoAutoStart)

            chkMonAuto.Checked = cbl(.boolMonitorUploadOnly)
            ChkGeoAuto.Checked = cbl(.boolGeoFilterAutoStart)
            ChkDecayAuto.Checked = cbl(.boolInterfaceOziDecayStartup)
            chkStateSaveAuto.Checked = cbl(.boolStateAutosave)
            chkStateLoadAuto.Checked = cbl(.boolStateAutoload)

            chkDBConnectAuto.Checked = cbl(.boolDatabaseAutoStart)
            chkLogAuto.Checked = cbl(.boolDebugLogAutoStart)

            chkInterfaceOziStartup.Checked = cbl(.boolInterfaceOziStartup)
            chkOziOnTop.Checked = cbl(.boolInterfaceOziOntop)
            chkInterfaceMappointStartup.Checked = cbl(.boolInterfaceMapPointStartup)
            chkInterfaceUIViewStartup.Checked = cbl(.boolInterfaceUIViewStartup)
            chkAutoOziGPS.Checked = cbl(.boolInterfaceOziGPS)

            cmbTNCSpeed.Text = .intTNCComSpeed
            cmbTNCcom.Text = .intTNCComPort
            cmbRINOcom.Text = .intRINOComPort

            cboHubPort.Text = .intIncomingHubport
            cboGPRSport.Text = .intIncomingGPRSport
            cboNetGPSport.Text = .intIncomingNetGPSport


            txtCallsign.Text = .strStationCallsign
            txtOutgoingServer.Text = .strOutgoingServer
            txtLoginString.Text = .strOutgoingServerLogin
            txtConnectString.Text = .strOutgoingServerConnectString
            txtDefaultLat.Text = .dblLat
            txtDefaultLon.Text = .dblLon

            txtDatabaseFilename.Text = .strDatabaseFilename
            txtAutoSaveFilename.Text = .strStateFilename
            txtLogFilename.Text = .strDebugLogFilename

            IP_1.Text = .strIGPRSip_1
            IP_2.Text = .strIGPRSip_2
            Port_1.Text = .intIGPRSp_1
            Port_2.Text = .intIGPRSp_2
            APN.Text = .strIGPRSapn
            Delay.Text = .intIGPRSrate
            cboIGPRSport.Text = .intIGPRSport

            chkIGatePosRF.Checked = cbl(.boolIGatePosRf)
            chkIGateMsgRF.Checked = cbl(.booliGateMsgRF)
            chkIGateObjRF.Checked = cbl(.booliGateObjRf)
            chkIGateWxRF.Checked = cbl(.booliGateWxRf)

            txtIGatePosRate.Text = .intIGatePosRate
            txtIGateMsgRate.Text = .intIGateMsgRate
            txtIGateObjRate.Text = .intIGateObjRate
            txtIGateWxRate.Text = .intIGateWxRate
            txtIGateRate.Text = .intIGateRate
            chkCallsignTranslation.Checked = .boolCallsignTranslate


            chkShowFile.Checked = .boolShowFile
            chkShowSetup.Checked = .boolShowSetup
            chkShowServices.Checked = .boolShowServices
            chkShowGUI.Checked = .boolShowGUI
            chkShowHelp.Checked = .boolShowHelp
            chkShowTNC.Checked = .boolShowTNC
            chkShowGPS.Checked = .boolShowGPS
            chkShowWx.Checked = .boolShowWX
            chkShowRINO.Checked = .boolShowRINO
            chkShowLOG.Checked = .boolShowLOG

            chkShowNetwork.Checked = .boolShowNetwork
            chkShowOzi.Checked = .boolShowOzi
            chkShowMapPoint.Checked = .boolShowMapPoint
            chkShowAGWPEUIVIEW.Checked = .boolShowAGWPEUIVIEW
            chkShowOziSyncClear.Checked = .boolShowOziSyncClear
            chkShowOziDecay.Checked = .boolShowOziDecay
            chkShowOziAutotrail.Checked = .boolShowOziAutotrail
            chkShowGeofiltering.Checked = .boolShowGeoFilter
            chkShowDatabase.checked = .boolShowDatabase
            chkShowUploadMonitored.Checked = .boolShowUploadMonitored
            chkShowTranslate.Checked = .boolShowTranslated
            chkShowLogDatabase.Checked = .boolShowLogDatabase
            chkShowInterface.checked = .boolShowInterface


            chkUIShowPos.Checked = .boolUIShowPos
            chkUIShowWX.Checked = .boolUIShowWx
            chkUIShowMsg.Checked = .boolUIShowMsgs
            chkUIShowObjs.Checked = .boolUIShowObjs

            chkErrorLog.Checked = .boolErrorLog
            chkErrorMsg.Checked = .boolErrorMsg



            txtBCNDigi.Text = .txtBCNdigi
            Me.txtBCNsymbol.Text = .txtBCNsymbol
            Me.txtBCNtable.Text = .txtBCNtable
            Me.txtBCNtxRate.Text = .intBCNtxrate

            Me.chkSmartEnable.Checked = .chkSmartEnable
            Me.txtBCNturnangle.Text = .intBCNTurnAngle
            Me.txtBCNturnslope.Text = .intBCNTurnSlope
            Me.txtBCNturntime.Text = .intBCNTurnTIme

            Me.txtBCNslowspeed.Text = .intBCNSlowSpeed
            Me.txtBCNslowrate.Text = .intBCNslowRate
            Me.txtBCNfastspeed.Text = .intBCNfastSpeed
            Me.txtBCNfastrate.Text = .intBCNfastRate

            Me.chkMICEEnable.Checked = .boolBCNMICE
            Me.chkMICEprintable.Checked = .boolBCNMICEPrintable
            Me.cboMICEmessage.SelectedIndex = .intBCNMICEmessage
            Me.cboMICEpath.SelectedIndex = .intBCNmicePATH

            Me.chkBCNValid.Checked = .boolBCNvalid
            Me.chkBcnDHM.Checked = .boolBCNDHM
            Me.chkBCNHMS.Checked = .boolBCNHMS
            Me.chkBCNSendAlt.Checked = .boolBCNSendAlt
            Me.chkNMEASend.Checked = .boolBCNSendNMEA
            Me.chkBCNAltDigi.Checked = .boolBCNAltDigi

            Me.txtBCNstatus.Text = .txtBCNStatus
            Me.txtBCNsendevery.Text = .intBCNSendEvery
            Me.chkBCNSendSeperate.Checked = .boolBCNSendSeperate

            GPSport.Text = .intGPSport


        End With


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        With setup
            .boolIncomingNetGPSAutoStart = chkAutoNetGPSListen.Checked
            .boolIncomingGPRSAutoStart = chkAutoGPRSListen.Checked
            .boolIncomingServerAutoStart = chkAutoHUBlisten.Checked
            .boolIncomingServerDumpHistory = chkHubDumpHistory.Checked
            .boolOutgoingServerAutoConnect = chkAutoServerConnect.Checked

            .strLanguage = cboLanguage.Text

            .boolTNCKissMode = chkTNCKiss.Checked
            .boolTNCAutoConnect = chkTNCAuto.Checked
            .boolAGWPEAutoConnect = chkAGWPEauto.Checked
            .boolUploadNonLive = chkUploadDelay.Checked
            .boolNMEAAutoStart = chkNMEAauto.Checked
            .boolRinoAutoStart = chkRINOauto.Checked

            .boolMonitorUploadOnly = chkMonAuto.Checked
            .boolGeoFilterAutoStart = ChkGeoAuto.Checked
            .boolInterfaceOziDecayStartup = ChkDecayAuto.Checked
            .boolStateAutosave = chkStateSaveAuto.Checked
            .boolStateAutoload = chkStateLoadAuto.Checked

            .boolDatabaseAutoStart = chkDBConnectAuto.Checked
            .boolDebugLogAutoStart = chkLogAuto.Checked

            .boolInterfaceOziStartup = chkInterfaceOziStartup.Checked
            .boolInterfaceOziOntop = chkOziOnTop.Checked
            .boolInterfaceMapPointStartup = chkInterfaceMappointStartup.Checked
            .boolInterfaceUIViewStartup = chkInterfaceUIViewStartup.Checked
            .boolInterfaceOziAutoTrailMoving = chkOziTrail.Checked
            .boolTNCMonitorOnly = chkTNCMonitorOnly.Checked


            .intIncomingHubport = cboHubPort.Text
            .intIncomingGPRSport = cboGPRSport.Text
            .intIncomingNetGPSport = cboNetGPSport.Text


            .strStationCallsign = txtCallsign.Text
            .strOutgoingServer = txtOutgoingServer.Text
            .strOutgoingServerLogin = txtLoginString.Text
            .strOutgoingServerConnectString = txtConnectString.Text
            .dblLat = CDbl(txtDefaultLat.Text)
            .dblLon = CDbl(txtDefaultLon.Text)

            .strDatabaseFilename = txtDatabaseFilename.Text
            .strStateFilename = txtAutoSaveFilename.Text
            .strDebugLogFilename = txtLogFilename.Text


            .intTNCComSpeed = cmbTNCSpeed.Text
            .intTNCComPort = cmbTNCcom.Text
            .intRINOComPort = cmbRINOcom.Text


            .strIGPRSip_1 = IP_1.Text
            .strIGPRSip_2 = IP_2.Text
            .intIGPRSp_1 = Port_1.Text
            .intIGPRSp_2 = Port_2.Text
            .strIGPRSapn = APN.Text
            .intIGPRSrate = Delay.Text
            .intIGPRSport = cboIGPRSport.Text

            .boolIGatePosRf = chkIGatePosRF.Checked
            .booliGateMsgRF = chkIGateMsgRF.Checked
            .booliGateObjRf = chkIGateObjRF.Checked
            .booliGateWxRf = chkIGateWxRF.Checked

            .intIGatePosRate = txtIGatePosRate.Text
            .intIGateMsgRate = txtIGateMsgRate.Text
            .intIGateObjRate = txtIGateObjRate.Text
            .intIGateWxRate = txtIGateWxRate.Text
            .intIGateRate = txtIGateRate.Text

            .boolCallsignTranslate = chkCallsignTranslation.Checked

            .boolInterfaceOziGPS = chkAutoOziGPS.Checked


            .boolShowFile = chkShowFile.Checked
            .boolShowSetup = chkShowSetup.Checked
            .boolShowServices = chkShowServices.Checked
            .boolShowGUI = chkShowGUI.Checked
            .boolShowHelp = chkShowHelp.Checked
            .boolShowTNC = chkShowTNC.Checked
            .boolShowGPS = chkShowGPS.Checked
            .boolShowWX = chkShowWx.Checked
            .boolShowRINO = chkShowRINO.Checked
            .boolShowLOG = chkShowLOG.Checked

            .boolShowNetwork = chkShowNetwork.Checked
            .boolShowOzi = chkShowOzi.Checked
            .boolShowMapPoint = chkShowMapPoint.Checked
            .boolShowAGWPEUIVIEW = chkShowAGWPEUIVIEW.Checked
            .boolShowOziSyncClear = chkShowOziSyncClear.Checked
            .boolShowOziDecay = chkShowOziDecay.Checked
            .boolShowOziAutotrail = chkShowOziAutotrail.Checked
            .boolShowGeoFilter = chkShowGeofiltering.Checked
            .boolShowDatabase = chkShowDatabase.Checked
            .boolShowUploadMonitored = chkShowUploadMonitored.Checked
            .boolShowTranslated = chkShowTranslate.Checked
            .boolShowLogDatabase = chkShowLogDatabase.Checked
            .boolShowInterface = chkShowInterface.checked

            .boolUIShowPos = chkUIShowPos.Checked
            .boolUIShowWx = chkUIShowWX.Checked
            .boolUIShowMsgs = chkUIShowMsg.Checked
            .boolUIShowObjs = chkUIShowObjs.Checked

            .boolErrorLog = chkErrorLog.Checked
            .boolErrorMsg = chkErrorMsg.Checked




            .txtBCNdigi = txtBCNDigi.Text
            .txtBCNsymbol = Me.txtBCNsymbol.Text
            .txtBCNtable = Me.txtBCNtable.Text
            .intBCNtxrate = Me.txtBCNtxRate.Text

            .chkSmartEnable = Me.chkSmartEnable.Checked
            .intBCNTurnAngle = Me.txtBCNturnangle.Text
            .intBCNTurnSlope = Me.txtBCNturnslope.Text
            .intBCNTurnTIme = Me.txtBCNturntime.Text

            .intBCNSlowSpeed = Me.txtBCNslowspeed.Text
            .intBCNslowRate = Me.txtBCNslowrate.Text
            .intBCNfastSpeed = Me.txtBCNfastspeed.Text
            .intBCNfastRate = Me.txtBCNfastrate.Text

            .boolBCNMICE = Me.chkMICEEnable.Checked
            .boolBCNMICEPrintable = Me.chkMICEprintable.Checked
            .intBCNMICEmessage = Me.cboMICEmessage.SelectedIndex
            .intBCNmicePATH = Me.cboMICEpath.SelectedIndex

            .boolBCNvalid = Me.chkBCNValid.Checked
            .boolBCNDHM = Me.chkBcnDHM.Checked
            .boolBCNHMS = Me.chkBCNHMS.Checked
            .boolBCNSendAlt = Me.chkBCNSendAlt.Checked
            .boolBCNSendNMEA = Me.chkNMEASend.Checked
            .boolBCNAltDigi = Me.chkBCNAltDigi.Checked

            .txtBCNStatus = Me.txtBCNstatus.Text
            .intBCNSendEvery = Me.txtBCNsendevery.Text
            .boolBCNSendSeperate = Me.chkBCNSendSeperate.Checked



            .intGPSport = GPSport.Text



        End With
        MasterForm.saveapplicationsettings(setup)



    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        With SaveFileDialog1
            .Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
            .FilterIndex = 1
            .RestoreDirectory = True
            .FileName = txtAutoSaveFilename.Text
            .ShowDialog()
            If .FileName.Length > 0 Then
                txtAutoSaveFilename.Text = .FileName
            End If
        End With
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        With SaveFileDialog1
            .Filter = "txt files (*.mdb)|*.mdb|All files (*.*)|*.*"
            .FilterIndex = 1
            .RestoreDirectory = True
            .FileName = txtDatabaseFilename.Text
            .ShowDialog()
            If .FileName.Length > 0 Then
                txtDatabaseFilename.Text = .FileName
            End If
        End With

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        With SaveFileDialog1
            .Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
            .FilterIndex = 1
            .RestoreDirectory = True
            .FileName = txtLogFilename.Text
            .ShowDialog()
            If .FileName.Length > 0 Then
                txtLogFilename.Text = .FileName
            End If
        End With

    End Sub

    Private Sub chkInterfaceUIViewStartup_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInterfaceUIViewStartup.CheckedChanged

    End Sub

    Private Sub chkInterfaceMappointStartup_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInterfaceMappointStartup.CheckedChanged

    End Sub

    Private Sub btnconfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfig.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = ":::" & Format(i1, "0000000000") & ":" & Format(p1, "00000") & ":" & _
            Format(i2, "0000000000") & ":" & Format(p2, "00000") & ":" & _
            myapn.PadRight(40) & ":" & Format(mydelay, "0000") & ":"
        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 63))), "00000") & ":"



        sendit(temp & vbCrLf)

        '        MsgBox(temp)

    End Sub

    Private Sub sendit(ByVal it As String)
        CommTNC = New SerialNET.Port
        Dim lic = New SerialNET.License
        lic.licenseKey = "ThHGhbBKUCaAOuo3HMLdqsPQK0ZC3OXOTiLF"

        With CommTNC
            .Enabled = False
            .ComPort = cboIGPRSport.Text
            .StopBits = SerialNET.StopBits.One
            .BaudRate = 4800
            .Parity = SerialNET.Parity.No
            .ByteSize = 8
            .Handshake = SerialNET.Handshake.None
            .DTR = True
            .RTS = True
            .Enabled = True

            .Write(it)

            .Enabled = False
        End With
    End Sub

    Private Function iptoi(ByVal ips As String) As Long
        Dim i As Long
        Dim ipsa(4) As String

        ipsa = ips.Split(".")

        i = ipsa(0) * 256 * 256 * 256 + ipsa(1) * 256 * 256 + ipsa(2) * 256 + ipsa(3)

        Return i

    End Function

    Private Function GetAuth(ByVal buffer As String) As Long
        Dim crc32 As Long


        Class_init()


        Dim crc32Result As Long
        crc32Result = &HFFFFFFFF

        Dim i As Integer
        Dim iLookup As Integer

        Dim mybyte As Integer

        'buffer = "darryl@radio-active.net.au"

        For i = 1 To Len(buffer)

            mybyte = Asc(Mid(buffer, i, 1))


            iLookup = (crc32Result And &HFF) Xor mybyte
            'Debug.Print mybyte, iLookup

            crc32Result = ((crc32Result And &HFFFFFF00) \ &H100) _
                And 16777215 ' nasty shr 8 with vb :/
            crc32Result = crc32Result Xor crc32Table(iLookup)

        Next i

        crc32 = Not (crc32Result)

        crc32 = crc32 And &HFFFF

        GetAuth = crc32
        'MsgBox Hex(crc32)

    End Function
    Private Function verify()

    End Function



    Private Sub Class_init()

        ' This is the official polynomial used by CRC32 in PKZip.
        ' Often the polynomial is shown reversed (04C11DB7).
        Dim dwPolynomial As Long
        dwPolynomial = &HEDB88320
        Dim i As Integer, J As Integer

        ReDim crc32Table(256)
        Dim dwCrc As Long

        For i = 0 To 255
            dwCrc = i
            For J = 8 To 1 Step -1
                If (dwCrc And 1) Then
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                    dwCrc = dwCrc Xor dwPolynomial
                Else
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                End If
            Next J
            crc32Table(i) = dwCrc
        Next i

    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click

        sendit(TextBox4.Text & vbCrLf)
    End Sub

    'Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    AxmsCommTNC.PortOpen = True

    'End Sub

    'Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    AxmsCommTNC.PortOpen = False
    'End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click

        sendit(":::RESTART:::" & vbCrLf)

    End Sub


    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub Label30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        With TreeView1
            If Not .SelectedNode Is Nothing Then
                TreeView1.SelectedNode = .SelectedNode.Nodes.Add("New Sub")
            Else
                .Nodes.Add("New Item")
            End If
        End With
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TreeView1.LabelEdit = True
        TreeView1.SelectedNode = TreeView1.Nodes.Add("Root")
    End Sub

    Private Sub LoadTreeViewFromXmlFile(ByVal file_name As _
        String, ByVal trv As TreeView)
        ' Load the XML document.
        Dim xml_doc As New XmlDocument
        xml_doc.Load(file_name)

        ' Add the root node's children to the TreeView.
        trv.Nodes.Clear()
        AddTreeViewChildNodes(trv.Nodes, _
            xml_doc.DocumentElement)
    End Sub
    ' Add the children of this XML node 
    ' to this child nodes collection.
    Private Sub AddTreeViewChildNodes(ByVal parent_nodes As _
        TreeNodeCollection, ByVal xml_node As XmlNode)
        For Each child_node As XmlNode In xml_node.ChildNodes
            ' Make the new TreeView node.
            Dim new_node As TreeNode = _
                                parent_nodes.Add(child_node.Attributes.Item(0).Value)
            new_node.Tag = child_node.Attributes.Item(1).Value
            AddTreeViewChildNodes(new_node.Nodes, child_node)
            If new_node.Nodes.Count = 0 Then _
                new_node.EnsureVisible()


            ' If this is a leaf node, make sure it's visible.
        Next child_node
    End Sub


    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        LoadTreeViewFromXmlFile("c:\testing.xml", TreeView1)

    End Sub

    Private Function iterate(ByVal tw As XmlTextWriter, ByVal tv As TreeNodeCollection)

        Dim tvn As TreeNode
        For Each tvn In tv
            With tvn
                tw.WriteStartElement("Glob")
                tw.WriteAttributeString("Blob", .Text)
                tw.WriteAttributeString("Tag", .Tag)

                If Not .Nodes Is Nothing Then
                    iterate(tw, .Nodes)
                Else
                End If

                tw.WriteEndElement()

            End With
        Next



    End Function



    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Dim xmlTW As XmlTextWriter = Nothing

        Dim junk As XmlTextWriter

        junk = New XmlTextWriter("c:\testing.xml", Nothing)


        With junk


            .WriteStartDocument(False)
            .WriteStartElement("iGPRS")
            iterate(junk, TreeView1.Nodes)


            .WriteEndElement()
            .Close()

        End With

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        TreeView1.SelectedNode.Tag = ":" & IP_1.Text & ":" & Port_1.Text & ":" & IP_2.Text & ":" & Port_2.Text & ":" & _
            APN.Text & ":" & Delay.Text & ":" & cboIGPRSport.Text & ":"

    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs)
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim temp As String
        Dim myarray() As String
        temp = TreeView1.SelectedNode.Tag
        If Len(temp) > 0 Then
            myarray = temp.Split(":")
            IP_1.Text = myarray(1)
            Port_1.Text = myarray(2)
            IP_2.Text = myarray(3)
            Port_2.Text = myarray(4)
            APN.Text = myarray(5)
            Delay.Text = myarray(6)
            cboIGPRSport.Text = myarray(7)
        End If

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click

        Dim n As TreeNode
        For Each n In TreeView1.SelectedNode.Nodes
            n.Remove()
            If TreeView1.SelectedNode.Parent Is Nothing Then
                TreeView1.Nodes.Add(n)
            Else
                TreeView1.SelectedNode.Parent.Nodes.Add(n)
            End If
        Next
        TreeView1.SelectedNode.Remove()
    End Sub

    Private Sub GroupBox5_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox5.Enter

    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = ":::" & Format(i1, "0000000000") & ":" & Format(p1, "00000") & ":" & _
            Format(i2, "0000000000") & ":" & Format(p2, "00000") & ":" & _
            myapn.PadRight(40) & ":" & Format(mydelay, "0000") & ":" & _
            Format(mydelay, "0000") & ":" & Format(0, "0") & ":"

        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 90))), "00000") & ":"



        sendit(temp & vbCrLf)

        MsgBox(temp)

    End Sub

    Private Sub TreeView1_AfterSelect_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect

    End Sub
End Class
