Public Class frmRegister
    Inherits System.Windows.Forms.Form
    Private crc32Table() As Long
    Dim masterform As frmmain

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal mymasterform As frmmain)
        MyBase.New()
        masterform = mymasterform

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Status As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Email As System.Windows.Forms.TextBox
    Friend WithEvents Key As System.Windows.Forms.TextBox
    Friend WithEvents Product As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmRegister))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Status = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Email = New System.Windows.Forms.TextBox
        Me.Key = New System.Windows.Forms.TextBox
        Me.Product = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Email Address"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Registration Key"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Product"
        '
        'Status
        '
        Me.Status.Font = New System.Drawing.Font("Arial", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Status.Location = New System.Drawing.Point(16, 120)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(264, 40)
        Me.Status.TabIndex = 3
        Me.Status.Text = "OK"
        Me.Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 200)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 32)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Apply"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(168, 200)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 32)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Close"
        '
        'Email
        '
        Me.Email.Location = New System.Drawing.Point(136, 16)
        Me.Email.Name = "Email"
        Me.Email.Size = New System.Drawing.Size(144, 22)
        Me.Email.TabIndex = 6
        Me.Email.Text = ""
        '
        'Key
        '
        Me.Key.Location = New System.Drawing.Point(136, 48)
        Me.Key.Name = "Key"
        Me.Key.Size = New System.Drawing.Size(144, 22)
        Me.Key.TabIndex = 7
        Me.Key.Text = "TextBox1"
        '
        'Product
        '
        Me.Product.Location = New System.Drawing.Point(136, 80)
        Me.Product.Name = "Product"
        Me.Product.ReadOnly = True
        Me.Product.Size = New System.Drawing.Size(144, 22)
        Me.Product.TabIndex = 8
        Me.Product.Text = "TextBox1"
        '
        'frmRegister
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(292, 260)
        Me.Controls.Add(Me.Product)
        Me.Controls.Add(Me.Key)
        Me.Controls.Add(Me.Email)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Status)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmRegister"
        Me.Text = "Register"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub Command2_Click()
        Me.Close()

    End Sub

    Private Sub Form_Load()

        Email.Text = GetSetting("OziAPRS", "License", "Email", "Please Enter a Valid Email Address")
        Key.Text = GetSetting("OziAPRS", "License", "Key", "Please Enter a KEY")
        'Mask.Text = Right(Key.Text, 4)

        verify()


    End Sub

    Public Sub closeme()
        Me.Close()


    End Sub

    Private Sub SaveAll()

        SaveSetting("OziAPRS", "License", "Email", Email.Text)
        SaveSetting("OziAPRS", "License", "Key", Key.Text)

    End Sub


    Private Function verify()

        Email.Text = UCase(Email.Text)
        Key.Text = UCase(Key.Text)
        If Len(Key.Text) <> 12 Then
            MsgBox("The KEY entered is not correct")
        End If


        If Check(Email.Text, "SW001", Mid(Key.Text, 1, 4), Key.Text) = True Then
            Product.Text = "SW001"
            Status.Text = "REGISTERED"
            'MsgBox "SAME"
            Exit Function
        End If

        Status.Text = "UNREGISTERED"

    End Function

    Public Function GetEmail()
        GetEmail = Email.Text
    End Function

    Public Function GetKey()
        GetKey = Key.Text
    End Function

    Public Function GetProduct()
        GetProduct = Product.Text
    End Function

    Public Function GetMask()
        GetMask = Mid(Key.Text, 1, 4)
    End Function

    Public Function GetStatus()
        GetStatus = Status.Text
    End Function

    Private Function Check(ByVal EmailAddress As String, ByVal ProductCode As String, ByVal mask As String, ByVal Key As String) As String

        If Hex(GetAuth(EmailAddress & mask & ProductCode)) = Mid(Key, 1, 8) Then
            Check = True
        Else
            Check = False
        End If

    End Function




    Private Function GetAuth(ByVal buffer As String) As Long
        Dim crc32 As Long


        Class_init()


        Dim crc32Result As Long
        crc32Result = &HFFFFFFFF

        Dim i As Integer
        Dim iLookup As Integer

        Dim mybyte As Integer

        'buffer = "darryl@radio-active.net.au"

        For i = 1 To Len(buffer)

            mybyte = Asc(Mid(buffer, i, 1))


            iLookup = (crc32Result And &HFF) Xor mybyte
            'Debug.Print mybyte, iLookup

            crc32Result = ((crc32Result And &HFFFFFF00) \ &H100) _
                And 16777215 ' nasty shr 8 with vb :/
            crc32Result = crc32Result Xor crc32Table(iLookup)

        Next i

        crc32 = Not (crc32Result)

        GetAuth = crc32
        'MsgBox Hex(crc32)

    End Function



    Private Sub Class_init()

        ' This is the official polynomial used by CRC32 in PKZip.
        ' Often the polynomial is shown reversed (04C11DB7).
        Dim dwPolynomial As Long
        dwPolynomial = &HEDB88320
        Dim i As Integer, J As Integer

        ReDim crc32Table(256)
        Dim dwCrc As Long

        For i = 0 To 255
            dwCrc = i
            For J = 8 To 1 Step -1
                If (dwCrc And 1) Then
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                    dwCrc = dwCrc Xor dwPolynomial
                Else
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                End If
            Next J
            crc32Table(i) = dwCrc
        Next i

    End Sub



    Private Sub frmRegister_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        verify()
        SaveAll()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub
End Class
