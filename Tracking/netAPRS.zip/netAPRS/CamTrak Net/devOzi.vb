Public Class devOzi

    Declare Function oziCreateWP Lib "oziapi" (ByRef name As String, ByVal symbol As Int32 _
    , ByVal lat As Double, ByVal lon As Double, ByVal Altitude As Double, ByVal wpDate As Double _
    , ByVal MapDisplayFormat As Int32, ByVal PointerDirection As Int32, ByVal GarminDisplayFormat As Int32 _
    , ByVal ForeColor As Int32, ByVal BackColor As Int32, ByVal ProximityDistance As Int32, ByRef Description As String _
    , ByVal FontSize As Int32, ByVal FontStyle As Int32, ByVal SymbolSize As Int32) As Int32
    Declare Function oziRepositionWP Lib "oziapi" (ByVal Number As Integer, ByVal lat As Double, ByVal lon As Double) As Integer
    Declare Function oziGetOziVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Integer) As Integer
    Declare Function oziGetApiVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Integer) As Integer
    Declare Function oziDeleteWpByName Lib "oziapi" (ByRef pansichar As String) As Integer
    Declare Function oziDeleteWpByNumber Lib "oziapi" (ByRef wpnum As Integer) As Integer
    Declare Function oziGetWpNumberFromName Lib "oziapi" (ByRef pansichar As String) As Integer
    Declare Function oziClearWPs Lib "oziapi" () As Integer
    Declare Function oziRefreshMap Lib "oziapi" () As Integer

    Declare Function oziFindBestMap Lib "oziapi" (ByVal lat As Double, ByVal lon As Double, ByVal subfolders As Integer, ByRef Path As String, ByRef MapFile As String) As Integer
    Declare Function oziFindMapAtPosition Lib "oziapi" (ByVal lat As Double, ByVal lon As Double) As Integer



    Declare Function oziStartMMapi Lib "oziapi" () As Integer
    Declare Function oziStopMM Lib "oziapi" () As Integer

    Declare Function oziSendMMstring Lib "oziapi" (ByRef NmeaString As String) As Integer



    Declare Function oziClearAllTracks Lib "oziapi" () As Integer
    Declare Function oziClearTrack Lib "oziapi" (ByVal TrackNum As Int32) As Int32
    Declare Function oziShowAllTracks Lib "oziapi" () As Integer
    Declare Function oziHideAllTracks Lib "oziapi" () As Integer
    Declare Function oziShowTrack Lib "oziapi" (ByVal TrackNum As Int32) As Integer
    Declare Function oziHideTrack Lib "oziapi" (ByVal TrackNum As Int32) As Integer
    Declare Function oziCreateTrackPoint Lib "oziapi" (ByVal TrackNum As Integer, ByVal Code As Integer, _
    ByVal lat As Double, ByVal lon As Double, ByVal altitude As Double, ByVal tpdate As Double) As Double
    Declare Function oziSetTrackDescription Lib "Oziapi" (ByVal TrackNum As Integer, ByRef TrackDescription As String) As Integer
    Declare Function oziSetTrackType Lib "oziapi" (ByVal TrackNum As Integer, ByVal TrackType As Integer) As Integer

    Declare Function oziGetVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Integer) As Integer
    Declare Function oziGetExePath Lib "oziapi" (ByRef Data As String, ByRef DataLength As Integer) As Integer
    Declare Function oziSetTrackColor Lib "oziapi" (ByVal TrackNo As Integer, ByVal Color As Integer) As Integer

    Declare Function oziMapSingleClickON Lib "oziapi" (ByVal p As delClickCallback) As Integer
    Declare Function oziMapDblClickON Lib "oziapi" (ByVal p As delClickCallback) As Integer

    Declare Function oziObjectClickON Lib "oziapi" (ByVal p As delObjectCallback) As Integer



    Delegate Function delClickCallback(ByRef oType As String, ByVal X As Integer, ByVal Y As Integer, _
              ByVal lat As Double, ByVal lon As Double, _
          ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double) As Integer

    Delegate Function delObjectCallback(ByRef oType As String, _
              ByVal lat As Double, ByVal lon As Double, _
              ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double, ByRef sName As String) As Integer




    Private fpDevGuiMaster As FarPoint.Win.Spread.FpSpread

    '----------------------- Foremost Window API ---------------------
    Public Const HWND_BOTTOM = 1
    Public Const HWND_TOP = 0

    Private Const HWND_TOPMOST As Long = -1
    Private Const HWND_NOTOPMOST As Long = -2
    Private Const SWP_NOMOVE As Long = &H2
    Private Const SWP_NOSIZE As Long = &H1
    Private Const SWP_NOACTIVATE As Long = &H10
    Private Const SWP_SHOWWINDOW As Long = &H40


    Private Const TOPMOST_FLAGS = SWP_NOMOVE Or SWP_NOSIZE

    Public Declare Function SetWindowPos Lib "user32" _
      (ByVal hwnd As Integer, ByVal hWndInsertAfter As Integer, _
       ByVal x As Integer, ByVal Y As Integer, ByVal cx As Integer, _
       ByVal cy As Integer, ByVal wFlags As Integer) As Integer
    '----------------------------------------------------------------

    Dim delMapDoubleClickCallback As delClickCallback
    Dim delExplorerObjectPopupMenu As delObjectCallback

    Dim setup As frmSetup.SetupStructure

    Private masterform As frmmain

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuOziPopup As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuNetAPRS_Label As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Line1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Add As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_StationAdd As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Move As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_line2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_TopLeft As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_BottomRight As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Line3 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Cancel As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuOziPopup = New System.Windows.Forms.ContextMenu
        Me.mnuNetAPRS_Label = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Line1 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Add = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_StationAdd = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Move = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_line2 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_TopLeft = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_BottomRight = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Line3 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Cancel = New System.Windows.Forms.MenuItem
        '
        'mnuOziPopup
        '
        Me.mnuOziPopup.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNetAPRS_Label, Me.mnuOziPopup_Line1, Me.mnuOziPopup_Add, Me.mnuOziPopup_Move, Me.mnuOziPopup_line2, Me.mnuOziPopup_TopLeft, Me.mnuOziPopup_BottomRight, Me.mnuOziPopup_Line3, Me.mnuOziPopup_Cancel})
        '
        'mnuNetAPRS_Label
        '
        Me.mnuNetAPRS_Label.Enabled = False
        Me.mnuNetAPRS_Label.Index = 0
        Me.mnuNetAPRS_Label.Text = "netAPRS"
        '
        'mnuOziPopup_Line1
        '
        Me.mnuOziPopup_Line1.Index = 1
        Me.mnuOziPopup_Line1.Text = "-"
        '
        'mnuOziPopup_Add
        '
        Me.mnuOziPopup_Add.Index = 2
        Me.mnuOziPopup_Add.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuOziPopup_StationAdd})
        Me.mnuOziPopup_Add.Text = "&Add"
        '
        'mnuOziPopup_StationAdd
        '
        Me.mnuOziPopup_StationAdd.Index = 0
        Me.mnuOziPopup_StationAdd.Text = "&Station Add"
        '
        'mnuOziPopup_Move
        '
        Me.mnuOziPopup_Move.Index = 3
        Me.mnuOziPopup_Move.Text = "&Move Station"
        '
        'mnuOziPopup_line2
        '
        Me.mnuOziPopup_line2.Index = 4
        Me.mnuOziPopup_line2.Text = "-"
        '
        'mnuOziPopup_TopLeft
        '
        Me.mnuOziPopup_TopLeft.Index = 5
        Me.mnuOziPopup_TopLeft.Text = "Filter Top Left"
        '
        'mnuOziPopup_BottomRight
        '
        Me.mnuOziPopup_BottomRight.Index = 6
        Me.mnuOziPopup_BottomRight.Text = "Filter Bottom Right"
        '
        'mnuOziPopup_Line3
        '
        Me.mnuOziPopup_Line3.Index = 7
        Me.mnuOziPopup_Line3.Text = "-"
        '
        'mnuOziPopup_Cancel
        '
        Me.mnuOziPopup_Cancel.Index = 8
        Me.mnuOziPopup_Cancel.Text = "&Cancel"
        '
        'oziPopup
        '

    End Sub

#End Region


    Function ConvertStr(ByVal s As String) As String
        Dim p As Integer
        's = StrConv(s, vbUnicode)   'convert to VB format
        p = InStr(s, Chr(0))
        If p > 1 Then
            s = Left(s, p - 1)
        Else
            s = ""
        End If
        ConvertStr = s
    End Function



    Public Function ClearWPs()
        oziClearWPs()
    End Function

    Public Function UploadWPs()
        Dim i As Integer
        With fpDevGuiMaster.ActiveSheet
            For i = 0 To .RowCount - 1
                If .Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text <> "" Then
                    UploadToOzi(i)
                End If
            Next i
        End With


    End Function

    Public Function SyncWPs()
        ClearWPs()
        UploadWPs()
    End Function

    Public Function DecayIcons()
        Dim i As Integer
        Dim colour As Long
        Dim myhex As String
        Dim r, g, b As Integer
        With fpDevGuiMaster.ActiveSheet
            For i = 0 To .RowCount - 1

                If .Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text <> "" Then
                    If Mid(.Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text, 1, 6) <> "FILTER" Then
                        colour = .Cells(i, Crosspoint.DevGuiMasterCols.scColor).Value
                        myhex = Right("000000" & Hex(colour), 6)
                        r = CInt("&H" & Mid(myhex, 5, 2))
                        g = CInt("&H" & Mid(myhex, 3, 2))
                        b = CInt("&H" & Mid(myhex, 1, 2))
                        If True Then
                            If r < 245 Then
                                r = r + 10
                            End If
                            If g < 245 Then
                                g = g + 10
                            End If
                            If b < 245 Then
                                b = b + 10
                            End If
                        Else
                            If r > 100 Then
                                r = r - 10
                            End If
                            If g > 100 Then
                                g = g - 10
                            End If
                            If b > 100 Then
                                b = b - 10
                            End If
                        End If

                        .Cells(i, Crosspoint.DevGuiMasterCols.scColor).Value = RGB(r, g, b)

                        If colour <> .Cells(i, Crosspoint.DevGuiMasterCols.scColor).Value Then
                            UploadToOzi(i)
                        End If

                    End If
                End If
            Next i
        End With

    End Function

    Public Function DeviceOzi(ByVal PortIn As Integer, ByVal Line As String)
        'Useless Function
    End Function


    Public Function TrackInOzi(ByVal line As Integer)
        With fpDevGuiMaster.ActiveSheet
            oziStartMMapi()
            oziSendMMstring(.Cells(line, Crosspoint.DevGuiMasterCols.scGPRMC).Text)
            oziSendMMstring(.Cells(line, Crosspoint.DevGuiMasterCols.scGPRMC).Text)
        End With
    End Function
    Public Function TrailInOzi(ByVal line As Integer)
        Dim TrailNo As Integer
        Dim first As Integer
        Dim callsign As String

        With fpDevGuiMaster.ActiveSheet
            If Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text) = 0 Or _
                Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text) = 0 Then
                Exit Function
            End If

            TrailNo = Val(.Cells(line, Crosspoint.DevGuiMasterCols.scTrailNumber).Text)
            first = 0
            If TrailNo < 1 Then
                TrailNo = FindNewTrailNumber()
                callsign = .Cells(line, Crosspoint.DevGuiMasterCols.scCallsign).Text()
                .Cells(line, Crosspoint.DevGuiMasterCols.scTrailNumber).Text() = TrailNo
                oziClearTrack(TrailNo)
                oziShowTrack(TrailNo)
                oziShowAllTracks()

                oziSetTrackColor(TrailNo, QBColor(TrailNo Mod 16))
                first = 1

            End If

            oziCreateTrackPoint( _
                TrailNo, first, _
                .Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text, _
                .Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text, _
                .Cells(line, Crosspoint.DevGuiMasterCols.scAlt).Text, _
                Now.ToOADate)
            If first = 1 Then
                oziSetTrackDescription(TrailNo, callsign)
            End If
            first = 1

        End With


    End Function

    Public Function FindNewTrailNumber() As Integer
        Dim i, j As Integer
        Dim TrailNo As Integer
        With fpDevGuiMaster.ActiveSheet
            For i = 5 To 75
                For j = 0 To .RowCount - 1
                    If .Cells(j, Crosspoint.DevGuiMasterCols.scTrailNumber).Text() = Format(i) Then
                        GoTo ContinueHere
                    End If
                Next
                Return i
ContinueHere:
            Next
        End With
        Return -1

    End Function


    Public Function UploadToOzi(ByVal line As Integer)

        Dim i As Integer
        Dim OziID As Long

        With fpDevGuiMaster.ActiveSheet

            Try
                If Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text) = 0 Or _
                    Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text) = 0 Then
                    Exit Function
                End If

                Dim direction As Int16

                If Len(.Cells(line, Crosspoint.DevGuiMasterCols.scOziExplorerID).Text) > 0 Then
                    oziDeleteWpByName(.Cells(line, Crosspoint.DevGuiMasterCols.scCallsign).Text)
                End If


                'Exit Function
                OziID = oziCreateWP(.Cells(line, Crosspoint.DevGuiMasterCols.scCallsign).Text, _
                    -1, _
                    CDbl(.Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text), _
                    CDbl(.Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text), _
                    0, _
                    -1, _
                    -1, _
                    direction, _
                    -1, _
                    -1, _
                    .Cells(line, Crosspoint.DevGuiMasterCols.scColor).Text, _
                    0, _
                    vbCrLf & .Cells(line, Crosspoint.DevGuiMasterCols.scDetail).Text, _
                 -1, _
                  -1, _
                 -1)

                .Cells(line, Crosspoint.DevGuiMasterCols.scOziExplorerID).Text = OziID

                oziRefreshMap()


            Catch ex As Exception

                MsgBox(ex.Message)

            End Try



        End With



    End Function

    Function oziExplorerObjectPopupMenu(ByRef oType As String, _
          ByVal lat As Double, ByVal lon As Double, _
          ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double, ByRef sName As String) As Integer

        'MsgBox(oType)
        Static Status As Integer

        'oType = ConvertStr(oType)
        'sName = ConvertStr(sName)
        'if setup.boolinterfaceoziontop = true then 
        'Call SetWindowPos(masterform.hwnd, HWND_TOP, 0, 0, 0, 0, TOPMOST_FLAGS)

        '    'SetFocus

        If oType = "wp_click" Then
            '    MsgBox oType & " " & sName

            Dim points = New Point
            points = Cursor.Position
            masterform.txtPopupCallsign.Text = sName
            masterform.mnuCallsignPopup.MenuItems(0).Text = "Callsign: " & sName
            masterform.mnuCallsignPopup.Show(masterform, New Point(points.x - masterform.Left, points.y - masterform.Top - 100))


        End If

        '    'status = status + 1
        '    'If status = 1 Then
        '    '    frmMain.PopupMenu frmMain.mnuPopUp
        '    'Else
        '    '    status = 0
        '    'End If



    End Function


    Function oziExplorerMapPopupMenu(ByRef oType As String, ByVal X As Integer, ByVal Y As Integer, _
          ByVal lat As Double, ByVal lon As Double, _
          ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double) As Integer

        '    Static Status As Integer

        '    oType = ConvertStr(oType)

        '    MsgBox(oType)

        '    Status = Status + 1
        '    If Status = 1 Then
        '        frmMain.PopupMenu(frmMain.mnuPopup)
        '    Else
        '        Status = 0
        '    End If

    End Function




    Function MapDoubleClickCallback(ByRef oType As String, ByVal X As Integer, ByVal Y As Integer, _
              ByVal lat As Double, ByVal lon As Double, _
          ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double) As Integer

        'MsgBox("Hello")

        '    oType = ConvertStr(oType) 'convert to VB format
        '    UTMzone = ConvertStr(UTMzone) 'convert to VB format

        '    'must do something with it
        '    'here we just show it in an edit box
        '    'MsgBox oType & Format(lat) & " " & Format(lon)


        If lat = 0 And lon = 0 Then
            Exit Function
        End If

        masterform.txtOziLat.Text = lat
        masterform.txtOziLon.Text = lon

        Dim points = New Point
        points = Cursor.Position

        'Beep()


        masterform.mnuPopup.Show(masterform, New Point(points.x - masterform.Left, points.y - masterform.Top - 100))
        'masterform.mnuPopup.Show(masterform, New Point(X - masterform.Left, Y - masterform.Top))
        'masterform.ContextMenu.Show(masterform.mnuPopup, New Point(X, Y))

        'masterform.mnupopup() 'popupmenu(masterform.mnuPopup)
        'treeView1.ContextMenu.Show(treeView1, New Point(e.X, e.Y))

        'popupmenu()


        '    frmMain.PopupMenu(frmMain.mnuPopup)




    End Function


    Public Sub New(ByVal myfpDevGuiMaster As FarPoint.Win.Spread.FpSpread, ByVal rows As Integer, ByRef myMasterForm As frmmain)
        masterform = myMasterForm
        fpDevGuiMaster = myfpDevGuiMaster
        fpDevGuiMaster.ActiveSheet.RowCount = rows


        'NOTE: THis ***MUST*** be seperate or access violations WILL OCCOUR.
        delMapDoubleClickCallback = AddressOf MapDoubleClickCallback
        delExplorerObjectPopupMenu = AddressOf oziExplorerObjectPopupMenu

        'NOTE: DO NOT ATTEMPT TO OPTIMIZE SINCE THE COMPILER FORGETS THE VARIABLE AND
        'GARBAGE COLLECTS WHILST IT IS STILL IN USE. 
        oziMapDblClickON(delMapDoubleClickCallback)
        oziObjectClickON(delExplorerObjectPopupMenu)



        '        If frmMain.OziExplorerRunning = True Then
        'oziMapDblClickON(AddressOf MapDoubleClickCallback)
        'oziObjectClickON(AddressOf oziPopup.)
        '       End If





    End Sub


End Class
