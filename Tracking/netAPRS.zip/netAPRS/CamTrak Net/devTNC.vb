Public Class devTNC

    'Mon on
    'Mcom off
    'Header off

    '    Dim CommTNC As SerialNET.Port
    Dim MasterMenu As frmmain
    Dim kiss As kiss
    Dim setup As frmSetup.SetupStructure
    Dim CommTNC As SerialNET.Port



    Public Sub msCommTNC_OnComm(ByVal line As Byte ())

        Dim theline As String

        Static SerialLine As String
        Dim i As Integer
        For i = 1 To line.Length
            SerialLine = SerialLine & Chr(line(i - 1))
        Next


        '        SerialLine = SerialLine & CommTNC.ByteArrayToString(line)


        If setup.boolTNCKissMode = True Then


            kiss.BufferAdd(SerialLine)
            SerialLine = ""
            While kiss.BufferAvailable
                theline = kiss.BufferDecode
                If Len(theline) > 10 Then
                    MasterMenu.crosspoint.Submit(MasterMenu.portTNC, theline)
                End If
            End While

            Exit Sub
        End If


        While InStr(1, SerialLine, vbCr) > 0 Or InStr(1, SerialLine, vbLf) > 0
            Dim x As Long
            Dim Y As Long
            x = InStr(1, SerialLine, vbCr)
            Y = InStr(1, SerialLine, vbLf)
            If x = 0 Then x = 10000
            If Y = 0 Then Y = 10000
            If x > Y Then
                theline = Left(SerialLine, InStr(1, SerialLine, vbLf) - 1)
                SerialLine = Mid(SerialLine, InStr(1, SerialLine, vbLf) + 1)
            Else
                theline = Left(SerialLine, InStr(1, SerialLine, vbCr) - 1)
                SerialLine = Mid(SerialLine, InStr(1, SerialLine, vbCr) + 1)
            End If
            If Len(theline) > 10 Then
                MasterMenu.crosspoint.Submit(MasterMenu.portTNC, theline)
            End If
        End While



    End Sub



    Public Function devTNC_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)


        Dim iGate As Boolean = False

        If setup.boolIGatePosRf = True And aprsdecoded.isPos Then iGate = True
        If setup.booliGateMsgRF = True And aprsdecoded.isMsg Then iGate = True
        If setup.booliGateWxRf = True And aprsdecoded.isWx Then iGate = True
        If setup.booliGateObjRf = True And aprsdecoded.isObj Then iGate = True

        'TODO: Rate limiting

        'TODO: Send out Serial Port

        If iGate Then
            Debug.WriteLine("INET>TNC: " & Line)
        End If

    End Function



    Public Sub New(ByVal myMasterMenu As frmmain, ByRef mycommtnc As SerialNET.Port, ByVal mysetup As frmSetup.SetupStructure)

        CommTNC = mycommtnc
        MasterMenu = myMasterMenu
        setup = mysetup
        kiss = New kiss


        With CommTNC
            .Enabled = False
            .ComPort = setup.intTNCComPort
            .StopBits = SerialNET.StopBits.One
            .BaudRate = setup.intTNCComSpeed
            .Parity = SerialNET.Parity.No
            .ByteSize = 8
            .Handshake = SerialNET.Handshake.None
            .DTR = True
            .RTS = True
            .Timeout = 0
            .Enabled = True
        End With




        Try
            CommTNC.Write(vbCr)
            CommTNC.Write("mon on" & vbCr)
            CommTNC.Write("mcom off" & vbCr)
            CommTNC.Write("header off" & vbCr)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class

Public Class kiss


    Const FEND = &HC0
    Const FESC = &HDB
    Const TFEND = &HDC
    Const TFESC = &HDD


    Dim PacketBuffer As String
    Dim buffer As String
    Dim CommTNC As SerialNET.Port


    Public Function BufferAdd(ByVal line As String)
        Printline(line)

        buffer = buffer & line

        Printline(buffer)

    End Function

    Public Function BufferAvailable() As Integer
        If InStr(2, buffer, Chr(FEND)) > 0 Then
            BufferAvailable = True
        Else
            BufferAvailable = False
        End If
    End Function

    Public Function BufferDecode() As String

        If BufferAvailable() Then
            ' Then there is something to process
            While Mid(buffer, 2, 1) = Chr(FESC)
                buffer = Mid(buffer, 2)
            End While
            BufferDecode = ProcessData(Mid(buffer, 2, InStr(2, buffer, Chr(FEND)) - 2))
            buffer = Mid(buffer, InStr(2, buffer, Chr(FEND)))
        Else
            BufferDecode = ""

        End If



    End Function

    Public Function ProcessData(ByVal linein As String) As String

        Dim i As Integer
        Dim temp As String

        If Len(linein) < 15 Then
            ProcessData = ""
            Exit Function

        End If


        temp = ""
        If Asc(Mid(linein, 1, 1)) = 0 Then
            linein = Mid(linein, 2)
        End If


        For i = 1 To Len(linein)

            If Mid(linein, i, 1) = Chr(FESC) Then
                i = i + 1
                If Mid(linein, i, 1) = Chr(TFEND) Then
                    temp = temp & Chr(FEND)
                End If
                If Mid(linein, i, 1) = Chr(TFESC) Then
                    temp = temp & Chr(FESC)
                End If

            Else
                If Mid(linein, i, 1) <> Chr(FEND) Then
                    temp = temp & Mid(linein, i, 1)
                End If
            End If



        Next i

        Dim output As String
        output = ""

        output = DecodeCallsign(Mid(temp, 8, 7)) & ">" & DecodeCallsign(Mid(temp, 1, 7)) & ":"


        output = output & GetPayload(temp)


        ProcessData = output
        'Printline (output)

    End Function

    Public Function GetPayload(ByVal temp As String) As String
        Dim i As Integer
        For i = 14 To Len(temp)

            If (Asc(Mid(temp, i, 1)) And &H1) > 0 Then
                GoTo part2
            End If

        Next i


part2:
        Dim temp2 As String

        For i = i + 3 To Len(temp)
            If Asc(Mid(temp, i, 1)) > 27 Then
                temp2 = temp2 & Mid(temp, i, 1)
            End If
        Next i

        GetPayload = temp2

    End Function


    Public Sub Printline(ByVal line As String)
        Dim i As Integer
        Dim temp As String

        temp = ""
        For i = 1 To Len(line)
            'temp = temp & Mid(line, i, 1) & "-" & Hex(Asc(Mid(line, i, 1))) & " "
            temp = temp & "-" & Hex(Asc(Mid(line, i, 1))) & " "

        Next i

        Debug.WriteLine(temp)
        'Debug.Print(temp)
    End Sub



    '/***************************************************************\
    '*                                                               *
    '* asc_frame                                                     *
    '*                                                               *
    '* This function handles a single frame.  It calls functions to  *
    '* translate the AX.25 header and the data field to ASCII.       *
    '*                                                               *
    '* If the frame is empty or too short, it handles that too.      *'
    '*                                                               *
    '\***************************************************************/'
    '
    'void asc_frame(char *buf, int len, FILE *outfile)
    '{
    'char    *p;
    'int i;'
    '
    'if (len == 0)           /* Special handling for empty frames */
    '    fprintf(outfile, "*** Empty Frame ***\n");'
    '
    'else if (len < 15)      /* Special handling for short frames */
    '    {
    '    fprintf(outfile, "*** Short Frame: ");
    '    for (i=0; i<len; i++)
    '    fprintf(outfile, "%02X ", *buf++ & 0xFF);
    '    fprintf(outfile, "\n");
    '    }
    '            /* translate the AX.25 header to ASCII */
    'else if ((p=asc_header(buf, outfile)) == NULL)
    '    return;         /* no data field to log */'
    '
    'else            /* if there's data, output it too */
    '    asc_data(p, len - (p-buf), outfile);
    '}'
    '
    '/*********************************************************\
    '*                                                         *
    '* asc_header                                              *
    '*                                                         *
    '* This function decodes the header of a frame.            *
    '*                                                         *
    '* It outputs an ASCII translation of the header to the    *
    '* specified output file.  If the frame has an associated  *
    '* information field, it returns a pointer to the first    *
    '* byte of the information field.  If not, it returns      *
    '* the NULL pointer.                                       *
    '*                                                         *
    '* The ASCII translation generated resembles the monitor   *
    '* headers generated by the WA8DED TNC firmware.           *
    '*                                                         *
    '\*********************************************************/

    '/* pollcode gives the flags used to represent the various sets of
    '   poll and final flags.  It is indexed by three bits:
    '    pollcode[0x10 bit of ctl][0x80 bit of destcall][0x80 bit of fromcall]'
    '
    '   We use the following codes, following WA8DED:
    '        !   version 1 with poll/final
    '        ^   version 2 command without poll
    '        +   version 2 command with poll
    '        -   version 2 response with final
    '        v   version 2 response without final'
    '
    '0 in the table indicates no character is to be output.
    '*/
    ''
    '
    'char    pollcode[2][2][2] = {   '0',    /* 0 0 0 = V1, no poll/final */
    '                'v',    /* 0 0 1 = V2 resp, no final */
    '                '^',    /* 0 1 0 = V2 cmd, no poll */
    '                0,  /* 0 1 1 = V1, no poll/final */
    '                '!',    /* 1 0 0 = V1, with poll/final */
    '                '-',    /* 1 0 1 = V2 resp, with final */
    '                '+',    /* 1 1 0 = V2 cmd, with poll */
    '                '!',    /* 1 1 1 = V1, with poll/final */
    '                };
    '
    'char    *frameid[] = {"RR", "RNR", "REJ", "???",    /* S frames */
    '        "SABM", "DISC", "DM", "UA", "FRMR"};    /* U frames */'
    '
    'char *asc_header(char *buf, FILE *outfile)
    '{
    'char    *bufp;
    'char    call[10], call2[10];
    'char    ctl;
    'int id = 3;
    'int pollchr;'
    '
    '            /* output the source and destination calls */
    'fprintf(outfile, "fm %s to %s ", getcall(buf+7, call), getcall(buf, call2));'
    '
    'bufp = buf+14;          /* point to CTL or first digipeater */
    '
    '            /* output the digipeater calls, if any */
    'if ((buf[13] & 1) == 0)     /* if there are digipeaters, */
    '    {
    '    fprintf(outfile, "via ");
    '    for (bufp = buf+14; !(*(bufp-1) & 1) && bufp < buf+70; bufp+=7)
    '    fprintf(outfile, (bufp[6] & 0x80) ? "%s* " : "%s ",
    '            getcall(bufp, call));
    '    }

    'ctl = *bufp++;          /* translate the ctl byte */
    'pollchr = pollcode[!!(ctl&0x10)][!!(buf[6]&0x80)][!!(buf[13]&0x80)];

    '    /* now handle each frame type separately */

    'if ((ctl & 1) == 0)     /* if it's an I frame */
    ' '   {
    '    fprintf(outfile, "ctl I%d%d", ((ctl & 0xE0) >> 5), ((ctl & 0x0E) >> 1));
    '    if (pollchr)
    '    fprintf(outfile, "%c", pollchr);    /* output poll/final mark */
    '    fprintf(outfile, " pid %02X\n", *bufp++ & 0xFF);    /* add PID */
    '    return bufp;            /* return pointer to the data */
    '    }
    'else if ((ctl & 3) == 1)    /* if it's an S frame */
    '    {
    '    fprintf(outfile, "ctl %s%d", frameid[(ctl & 0x0C) >> 2],
    '                ((ctl & 0xE0) >> 5));
    '    if (pollchr)
    '    fprintf(outfile, "%c", pollchr);    /* output poll/final mark */
    '    putc('\n', outfile);
    '    return NULL;            /* no data */
    '    }
    'else if ((ctl & 0xEF) == 0x03)  /* if it's a UI frame */
    '    {
    '    fprintf(outfile, "ctl UI");
    '#ifdef WHYDOTHIS
    '    if (pollchr)
    '    fprintf(outfile, "%c", pollchr);    /* output poll/final mark */
    '#End If
    '    fprintf(outfile, " pid %02X\n", *bufp++ & 0xFF);    /* add PID */
    '    return bufp;            /* return pointer to the data */
    '    }
    'else                /* it's some other U frame */
    '    {
    '    switch (ctl & 0xEF)
    '    {
    '    case 0x2F:      /* SABM frame */
    '        id = 4;
    '        break;
    '    case 0x43:      /* DISC frame */
    '        id = 5;
    '        break;
    '    case 0x0F:      /* DM frame */
    '        id = 6;
    '        break;
    '    case 0x63:      /* UA frame */
    '        id = 7;
    '        break;
    '    case 0x87:      /* FRMR frame */
    '        id = 8;
    '        break;
    '    }
    '    fprintf(outfile, "ctl %s", frameid[id]);
    '    if (pollchr)
    '    fprintf(outfile, "%c", pollchr);    /* output poll/final mark */
    '    putc('\n', outfile);
    '    return NULL;            /* no data */
    '    }
    '}

    '/**************************************************************\
    '*                                                              *
    '* getcall                                                      *
    '*                                                              *
    '* This function translates a callsign from the AX.25 format    *
    '* in the frame buffer to ASCII format in the callsign buffer.  *
    '*                                                              *
    '*' Returns the callsign buffer, for convenient use.             *
    '*                                                              *
    '\**************************************************************/
    '
    'char *getcall(char *framebuf, char *callbuf)
    '{
    'int i;
    'int ssid;
    'char    *cbp = callbuf;'
    '
    'for (i=0; i<6; i++)     /* start by filling in the basic characters */
    '    if (*framebuf == 0x40)
    '    framebuf++;
    '    Else
    '    *cbp++ = (char)((*framebuf++ >> 1) & 0x7F); /* unshift to ASCII */'
    '
    '                /* tack on the SSID if it isn't zero */
    'if ((ssid = (*framebuf & 0x1E) >> 1) > 0)
    '    sprintf(cbp, "-%d", ssid);
    'Else
    '    *cbp = '\0';

    'return callbuf;
    '}

    Public Function DecodeCallsign(ByVal Callsign As String) As String
        Dim temp As String
        Dim i As Integer

        If Len(Callsign) < 7 Then
            DecodeCallsign = ""
            Exit Function
        End If

        For i = 1 To 6
            If Chr(Asc(Mid(Callsign, i, 1)) / 2) <> " " Then
                temp = temp & Chr(Asc(Mid(Callsign, i, 1)) / 2)
            End If
        Next i

        'if (Asc(Mid(Callsign, i, 1)) * 2)
        Dim ssid As Long

        ssid = Asc(Mid(Callsign, 7, 1))
        If ssid > 127 Then
            ssid = ssid - 128
        End If

        If ssid > 63 Then
            ssid = ssid - 64
        End If
        If ssid > 31 Then
            ssid = ssid - 32
        End If


        ssid = ssid / 2

        If ssid <> 0 Then
            DecodeCallsign = temp & "-" & Format(ssid)
        Else
            DecodeCallsign = temp
        End If

    End Function


    '/*************************************************************\
    '*                                                             *
    '* asc_data                                                    *
    '*                                                             *
    '* This function takes the data field of a frame, and logs it  *
    '* to the specified file.  It filters all binary characters    *
    '* to dots.  It ends the field with an extra newline.          *
    '*                                                             *
    '\*************************************************************/

    'void asc_data(char *buf, int len, FILE *outfile)
    '{
    'char    *lastp, *p;'
    '
    'lastp = buf+len;
    'for (p = buf; p < lastp; p++)       /* for each character in the buffer */
    '    if ((isascii(*p) && isprint(*p)) || (*p == '\t'))
    ' '   putc(*p, outfile);
    '    else if (*p == '\r')        /* translate CR to CRLF */
    '    putc('\n', outfile);
    '    Else
    '    putc('.', outfile);     /* ugly binary chars mapped to '.' */
    '
    'putc('\n', outfile);        /* terminate the packet */'
    '
    '}





End Class
