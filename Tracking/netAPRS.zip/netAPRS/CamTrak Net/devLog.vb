Public Class devLog

    Dim oFile As System.IO.File
    Dim oWrite As System.IO.StreamWriter

    Public Function DeviceLog(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)

        If Not oWrite Is Nothing Then
            oWrite.WriteLine("Crosspoint::DeviceLog:: PortIn " & Format(PortIn) & " : Line " & Line)
        End If
    End Function
    Public Sub New(ByVal Filename As String)

        oWrite = oFile.AppendText(Filename)


    End Sub

    Public Sub close()
        oWrite.Close()
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
