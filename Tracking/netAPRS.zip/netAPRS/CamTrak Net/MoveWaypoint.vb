Public Class MoveWaypoint
    Inherits System.Windows.Forms.Form

    Dim masterform As frmmain


#Region " Windows Form Designer generated code "

    Public Sub New(ByVal myMasterForm As frmmain)
        MyBase.New()
        masterform = myMasterForm
        InitializeComponent()
        init()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MoveWaypoint))
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(292, 436)
        Me.ListBox1.TabIndex = 0
        '
        'MoveWaypoint
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(292, 448)
        Me.Controls.Add(Me.ListBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MoveWaypoint"
        Me.Text = "MoveWaypoint"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Public Sub init()


    'This call is required by the Windows Form Designer.


    'Add any initialization after the InitializeComponent() call
        Dim i As Integer
        ListBox1.Items.Clear()

        With masterform.FpDevGuiMaster.ActiveSheet
            For i = 0 To .RowCount - 1
                If .Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text <> "" Then
                    ListBox1.Items.Add(.Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text)
                End If
            Next
        End With

    End Sub


    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        Dim s6 As String

        s6 = ListBox1.Items(ListBox1.SelectedIndex) & ">APRS:!" & masterform.double_to_dms(masterform.txtOziLat.Text, 1) & "/" & masterform.double_to_dms(masterform.txtOziLon.Text, 0) & "-"
        'MsgBox(s6)
        masterform.CrosspointSubmitProxy(masterform.portGui, s6)
        'Me.Dispose()

        'masterform.CloseMoveWaypoint()
        '        Me.Close()
        'Me.Dispose()



    End Sub
End Class
