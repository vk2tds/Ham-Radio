Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents tcpARSServer As Dart.PowerTCP.Sockets.Server
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents FpTCPAPRSServerSpread As FarPoint.Win.Spread.FpSpread
    Friend WithEvents FpTCPAPRSServerSpread_Sheet1 As FarPoint.Win.Spread.SheetView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button1 = New System.Windows.Forms.Button
        Me.tcpARSServer = New Dart.PowerTCP.Sockets.Server(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.FpTCPAPRSServerSpread = New FarPoint.Win.Spread.FpSpread
        Me.FpTCPAPRSServerSpread_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.FpTCPAPRSServerSpread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpTCPAPRSServerSpread_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 40)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        '
        'tcpARSServer
        '
        Me.tcpARSServer.Editor = Me.tcpARSServer
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(72, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(912, 400)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.FpTCPAPRSServerSpread)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(904, 371)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'FpTCPAPRSServerSpread
        '
        Me.FpTCPAPRSServerSpread.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FpTCPAPRSServerSpread.Location = New System.Drawing.Point(0, 0)
        Me.FpTCPAPRSServerSpread.Name = "FpTCPAPRSServerSpread"
        Me.FpTCPAPRSServerSpread.Sheets.Add(Me.FpTCPAPRSServerSpread_Sheet1)
        Me.FpTCPAPRSServerSpread.Size = New System.Drawing.Size(904, 371)
        Me.FpTCPAPRSServerSpread.TabIndex = 0
        '
        'FpTCPAPRSServerSpread_Sheet1
        '
        Me.FpTCPAPRSServerSpread_Sheet1.SheetName = "Sheet1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(1032, 456)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.FpTCPAPRSServerSpread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpTCPAPRSServerSpread_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    '    Delegate Sub DeviceDelegate(ByVal PortIn As Integer, ByVal Line As String)

    Private mcolTCPAPRSServer As New Hashtable
    Private lckTCPAPRSServerSpread As New Object
    Private lckMcolTCPAPRSServer As New Object
    Public WeAreClosing As Boolean
    Private tcpAPRSServer_ListeningPort As Integer

    Dim crosspoint As New Crosspoint

    Const tcpAPRSServerConnectionTextCount = 100

    Private tcpAPRSServerConnectionText(tcpAPRSServerConnectionTextCount) As String
    Private tcpAPRSServerConnectionTextStreams(tcpAPRSServerConnectionTextCount) As String




    Public Enum TCPAPRSServerConnections
        LocalPort = 0
        LocalAddress = 1
        RemotePort = 2
        RemoteAddress = 3
        StreamID = 4
        DataLine = 5
        User = 6

        LastRX = 7
        Driver = 8
        DriverID = 9
        Disconnect = 10
    End Enum






    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim NewPort As Integer
        ' Enable the DEBUG device
        NewPort = crosspoint.NewPort(crosspoint.devices.devDEBUG, AddressOf crosspoint.DeviceDebug)
        crosspoint.CrosspointEnable(-1, NewPort, True)

        ' Enable the Logging Device
        NewPort = crosspoint.NewPort(crosspoint.devices.devLOG, AddressOf crosspoint.DeviceLog)
        crosspoint.CrosspointEnable(-1, NewPort, True)



    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        crosspoint.Submit(0, "THIS IS A TEST")

    End Sub

    Private Sub tcpAPRSServer_Start()
        Dim NewPort As Integer

        ' Enable the Logging Device
        NewPort = crosspoint.NewPort(crosspoint.devices.devTCPAPRSSERV, AddressOf tcpAPRSserver_SendOut)
        tcpAPRSServer_ListeningPort = NewPort
        crosspoint.CrosspointEnable(-1, NewPort, True)



    End Sub

    Private Sub tcpAPRSServer_Stop()

    End Sub


    Private Function tcpAPRSserver_SendOut(ByVal PortIn As Integer, ByVal Line As String) As Object
        Dim d As DictionaryEntry
        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs

        If WeAreClosing Then Exit Function

        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                objClient = d.Value
                If objClient.Tcp.Stream.CanWrite = True Then  ' And objClient.Tcp.LocalEndPoint.Port <> 8001 Then
                    objClient.Tcp.Stream.Write(Line.ToString & vbCrLf)
                End If
            Next
        End SyncLock

    End Function

    Private Sub tcpAPRSServer_Listening(ByVal sender As System.Object, ByVal e As Dart.PowerTCP.Sockets.ConnectionEventArgs)

        Dim i As Integer

        Dim found As Boolean = False
        Dim StreamID As String
        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                i = findnewconnectionsrow()
                .Cells(i, TCPAPRSServerConnections.LocalPort).Text = e.Tcp.LocalEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.LocalAddress).Text = e.Tcp.LocalEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.RemotePort).Text = e.Tcp.RemoteEndPoint.Port
                .Cells(i, TCPAPRSServerConnections.RemoteAddress).Text = e.Tcp.RemoteEndPoint.Address.ToString
                .Cells(i, TCPAPRSServerConnections.StreamID).Text = e.Tcp.Socket.Handle.ToString
                StreamID = e.Tcp.Socket.Handle.ToString
                .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
            End With
        End SyncLock
        e.Tcp.SendTimeout = 250

        SyncLock lckMcolTCPAPRSServer
            mcolTCPAPRSServer.Add(StreamID, e)
            For i = 0 To tcpAPRSServerConnectionTextCount - 1
                If tcpAPRSServerConnectionText(i) = "NULL" Then
                    tcpAPRSserverConnectionText(i) = ""
                    tcpAPRSserverConnectionTextStreams(i) = StreamID
                    Exit For
                End If
            Next
        End SyncLock

        'If e.Tcp.LocalEndPoint.Port = 5001 Then
        '    Try
        '        e.Tcp.Stream.Write(MessageQueue.GetLatestPositions())
        '    Catch ex As Exception

        '    End Try
        'End If

        Dim s As String
        Do While (e.Tcp.Connected)
            Try
                s = e.Tcp.Stream.Read(vbCr, 256, found)
            Catch ex As Exception

            End Try
            s = s & ""
            's = s.Trim()
            s = s.Replace(vbCr, "")
            s = s.Replace(vbLf, "")

tryagain:

            SyncLock lckMcolTCPAPRSServer
                tcpAPRSserverConnectionText(GetIndexfromStreamID(StreamID)) &= s & vbCr
            End SyncLock


            s = ""

        Loop

WeAreClosingTheConnectionNow:

        '        UpdateStatus("Disconnected - " & fpspreadtcpAPRSServerConnections.ActiveSheet.Cells(i, TCPAPRSServerConnections.LocalPort).Text)
        SyncLock lckMcolTCPAPRSServer
            ' SyncLock mcolText.SyncRoot
            mcolTCPAPRSServer.Remove(StreamID)

            tcpaprsserverConnectionText(GetIndexfromStreamID(StreamID)) = "NULL"
            tcpaprsserverConnectionTextStreams(GetIndexfromStreamID(StreamID)) = ""
            mcolTCPAPRSServer.Remove(StreamID)
            ' End SyncLock
        End SyncLock


        If WeAreClosing Then Exit Sub

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                For i = 0 To .RowCount - 1
                    If .RowCount > -1 Then
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = StreamID Then
                            Dim j As Integer
                            For j = 0 To .ColumnCount - 2
                                .Cells(i, j).Text = ""
                            Next
                            Exit For
                        End If
                    End If
                Next i
            End With
        End SyncLock

    End Sub

    Private Function GetIndexfromStreamID(ByVal StreamID As String) As Integer
        Dim i As Integer

        For i = 0 To tcpAPRSServerConnectionTextCount - 1
            If tcpaprsserverConnectionTextStreams(i) = StreamID Then
                Return i
            End If
        Next



    End Function


    Private Function findnewconnectionsrow()
        Dim i As Integer
        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                For i = 0 To .RowCount - 1
                    If .Cells(i, TCPAPRSServerConnections.LocalAddress).Text = "" Then
                        Return i
                    End If
                Next
            End With
        End SyncLock
        MsgBox("Please contact Radioactive Networks for more licenses")
        Return 0
    End Function


    Private Sub OnNet960Received(ByVal senderID As String, ByVal Data As String)
        Console.WriteLine("OnNet960Received " & Data)


        Dim temp As String
        Dim strIMEI As String
        Dim i As Integer
        Dim strID As String = ""

        Dim objClient As Dart.PowerTCP.Sockets.ConnectionEventArgs
        Dim d As DictionaryEntry

        If Mid(Data, 1, 9) = "#CONNECT," Then
            strID = Mid(Data, 10)
            strID = Mid(strID, 1, 15)
            GoTo FoundAddress
        End If



        If Mid(Data, 1, 5) = "#MSG," Then
            Data = Mid(Data, 6)
        End If

        If Data.Length > 180 Then
            Data = Mid(Data, InStr(7, Data, ">") - 6)
        End If


        If Data.Length <= 10 Then Exit Sub
        '        UpdateStatus("Line:" & Data)


        If InStr(Data, ">") < 20 And InStr(Data, ">") > 1 Then
            strID = Mid(Data, 1, InStr(Data, ">") - 1)
        End If

FoundAddress:
        Dim strCallsign As String
        strCallsign = strID
        'Dim mymessagequeue As New MessageQueue(fpOutgoingMessageQueue, dgdUsers, dgdVehicles, FpPositions, fpSpreadConnections, Me)

        'UpdateStatus("Callsign:" & strCallsign)


        'Try

        Dim DriverID As Integer

        Dim TempCallsign As String

        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If .RowCount > 0 Then
                    For i = 0 To .RowCount - 1
                        If .Cells(i, TCPAPRSServerConnections.StreamID).Text = senderID Then
                            'UpdateStatus("Found the senderid of :" & senderID)
                            .Cells(i, TCPAPRSServerConnections.DataLine).Text = Data
                            .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign
                            .Cells(i, TCPAPRSServerConnections.LastRX).Text = Now
                            If strID.Length < 2 Then
                                GoTo NoGood
                            End If
                            If InStr(Data, ">") > 0 Then
                                Data = strCallsign & Data.Substring(Data.IndexOf(">"))
                            End If
                            crosspoint.Submit(tcpAPRSServer_ListeningPort, Data.ToString)
                            GoTo resumehere
                        End If
                    Next i


                End If

            End With


        End SyncLock


resumehere:



        SyncLock lckTCPAPRSServerSpread
            With FpTCPAPRSServerSpread.ActiveSheet
                If .RowCount > 0 Then
                    For i = 0 To .RowCount - 1


                        If .Cells(i, TCPAPRSServerConnections.User).Text = strCallsign And Len(.Cells(i, TCPAPRSServerConnections.User).Text) > 0 And Len(strCallsign) > 0 Then
                            If .Cells(i, TCPAPRSServerConnections.StreamID).Text <> senderID Then
                                SyncLock lckMcolTCPAPRSServer
                                    For Each d In mcolTCPAPRSServer

                                        If d.Key = .Cells(i, TCPAPRSServerConnections.StreamID).Text Then
                                            d.Value.tcp.close()
                                        End If
                                    Next
                                End SyncLock
                            End If
                        End If
                    Next i
                End If
            End With
        End SyncLock


        If Len(Data) = 0 Then Exit Sub

        If Mid(Data, 1, 1) = "#" Or Mid(Data, 1, 5) = "$IMEI" Then
            Exit Sub
        End If
        SyncLock lckMcolTCPAPRSServer
            For Each d In mcolTCPAPRSServer
                If d.Key <> senderID Then
                    objClient = d.Value
                    If objClient.Tcp.Stream.CanWrite = True And objClient.Tcp.LocalEndPoint.Port <> 8001 Then
                        If (InStr(Data, ">") > 0 And InStr(Data, ">") <> 0) Then
                            objClient.Tcp.Stream.Write(Data.ToString & vbCrLf)
                        Else
                            objClient.Tcp.Stream.Write(strCallsign & ">APRS:" & Data.ToString & vbCrLf)
                        End If
                    End If
                End If
            Next
        End SyncLock
NoGood:


    End Sub




End Class
