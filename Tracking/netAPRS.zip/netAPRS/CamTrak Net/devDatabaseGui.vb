Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Xml
Imports System.Text
Imports System.Data.Common
Imports System.data.sqlclient

Public Class devDatabaseGui
    Inherits System.Windows.Forms.Form

    Dim DataBaseConnection As IDbConnection
    Dim MasterForm As frmmain

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal myMasterForm As frmmain, ByVal DatabaseFilename As String)


        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        DataBaseConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & DatabaseFilename)  'TODO: What happens if the database is not there?
        MasterForm = mymasterform

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents txtDateTime As System.Windows.Forms.Label
    Friend WithEvents HScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents MonthCalendar2 As System.Windows.Forms.MonthCalendar
    Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblDatabaseStart As System.Windows.Forms.Label
    Friend WithEvents lblDatabaseStop As System.Windows.Forms.Label
    Friend WithEvents cmdGenList As System.Windows.Forms.Button
    Friend WithEvents cmdTrackCall As System.Windows.Forms.Button
    Friend WithEvents cmdTrackAll As System.Windows.Forms.Button
    Friend WithEvents cmdGrabLatestPositions As System.Windows.Forms.Button
    Friend WithEvents lblDatabaseState As System.Windows.Forms.Label
    Friend WithEvents lblTrackStations As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(devDatabaseGui))
        Me.lblDatabaseStart = New System.Windows.Forms.Label
        Me.lblDatabaseStop = New System.Windows.Forms.Label
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.cmdGenList = New System.Windows.Forms.Button
        Me.cmdTrackCall = New System.Windows.Forms.Button
        Me.cmdTrackAll = New System.Windows.Forms.Button
        Me.cmdGrabLatestPositions = New System.Windows.Forms.Button
        Me.txtDateTime = New System.Windows.Forms.Label
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar
        Me.MonthCalendar2 = New System.Windows.Forms.MonthCalendar
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblDatabaseState = New System.Windows.Forms.Label
        Me.lblTrackStations = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'lblDatabaseStart
        '
        Me.lblDatabaseStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatabaseStart.Location = New System.Drawing.Point(16, 48)
        Me.lblDatabaseStart.Name = "lblDatabaseStart"
        Me.lblDatabaseStart.Size = New System.Drawing.Size(240, 23)
        Me.lblDatabaseStart.TabIndex = 2
        Me.lblDatabaseStart.Text = "Start"
        Me.lblDatabaseStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDatabaseStop
        '
        Me.lblDatabaseStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatabaseStop.Location = New System.Drawing.Point(296, 48)
        Me.lblDatabaseStop.Name = "lblDatabaseStop"
        Me.lblDatabaseStop.Size = New System.Drawing.Size(240, 23)
        Me.lblDatabaseStop.TabIndex = 3
        Me.lblDatabaseStop.Text = "Stop"
        Me.lblDatabaseStop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.Location = New System.Drawing.Point(560, 64)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(304, 208)
        Me.CheckedListBox1.TabIndex = 6
        '
        'cmdGenList
        '
        Me.cmdGenList.Location = New System.Drawing.Point(592, 320)
        Me.cmdGenList.Name = "cmdGenList"
        Me.cmdGenList.Size = New System.Drawing.Size(152, 24)
        Me.cmdGenList.TabIndex = 7
        Me.cmdGenList.Text = "Generate List"
        '
        'cmdTrackCall
        '
        Me.cmdTrackCall.Location = New System.Drawing.Point(776, 320)
        Me.cmdTrackCall.Name = "cmdTrackCall"
        Me.cmdTrackCall.TabIndex = 8
        Me.cmdTrackCall.Text = "Track Calls"
        '
        'cmdTrackAll
        '
        Me.cmdTrackAll.Location = New System.Drawing.Point(784, 280)
        Me.cmdTrackAll.Name = "cmdTrackAll"
        Me.cmdTrackAll.TabIndex = 9
        Me.cmdTrackAll.Text = "Track All"
        '
        'cmdGrabLatestPositions
        '
        Me.cmdGrabLatestPositions.Location = New System.Drawing.Point(592, 280)
        Me.cmdGrabLatestPositions.Name = "cmdGrabLatestPositions"
        Me.cmdGrabLatestPositions.Size = New System.Drawing.Size(152, 23)
        Me.cmdGrabLatestPositions.TabIndex = 10
        Me.cmdGrabLatestPositions.Text = "Grab Latest Positions"
        '
        'txtDateTime
        '
        Me.txtDateTime.Location = New System.Drawing.Point(72, 304)
        Me.txtDateTime.Name = "txtDateTime"
        Me.txtDateTime.Size = New System.Drawing.Size(360, 23)
        Me.txtDateTime.TabIndex = 14
        '
        'HScrollBar1
        '
        Me.HScrollBar1.LargeChange = 500
        Me.HScrollBar1.Location = New System.Drawing.Point(8, 280)
        Me.HScrollBar1.Maximum = 32768
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(520, 16)
        Me.HScrollBar1.SmallChange = 10
        Me.HScrollBar1.TabIndex = 13
        '
        'MonthCalendar2
        '
        Me.MonthCalendar2.Location = New System.Drawing.Point(288, 80)
        Me.MonthCalendar2.Name = "MonthCalendar2"
        Me.MonthCalendar2.TabIndex = 12
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(8, 80)
        Me.MonthCalendar1.MaxSelectionCount = 1
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(544, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(8, 344)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'lblDatabaseState
        '
        Me.lblDatabaseState.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatabaseState.Location = New System.Drawing.Point(16, 16)
        Me.lblDatabaseState.Name = "lblDatabaseState"
        Me.lblDatabaseState.Size = New System.Drawing.Size(520, 23)
        Me.lblDatabaseState.TabIndex = 16
        Me.lblDatabaseState.Text = "State of database at a specific time"
        Me.lblDatabaseState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTrackStations
        '
        Me.lblTrackStations.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrackStations.Location = New System.Drawing.Point(560, 16)
        Me.lblTrackStations.Name = "lblTrackStations"
        Me.lblTrackStations.Size = New System.Drawing.Size(288, 23)
        Me.lblTrackStations.TabIndex = 17
        Me.lblTrackStations.Text = "Track Stations"
        Me.lblTrackStations.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(584, 136)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(224, 23)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "this sideNot working yet"
        '
        'devDatabaseGui
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(912, 352)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblTrackStations)
        Me.Controls.Add(Me.lblDatabaseState)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtDateTime)
        Me.Controls.Add(Me.HScrollBar1)
        Me.Controls.Add(Me.MonthCalendar2)
        Me.Controls.Add(Me.MonthCalendar1)
        Me.Controls.Add(Me.cmdGrabLatestPositions)
        Me.Controls.Add(Me.cmdTrackAll)
        Me.Controls.Add(Me.cmdTrackCall)
        Me.Controls.Add(Me.cmdGenList)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.lblDatabaseStop)
        Me.Controls.Add(Me.lblDatabaseStart)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "devDatabaseGui"
        Me.Text = "devDatabaseGui"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Dim myNetAPRS As New netAPRSlib


    Private Sub DatabaseTimeGet(ByVal t1 As Date, ByVal t2 As Date)

        Dim daPosition As OleDbDataAdapter
        Dim cbPosition As OleDbCommandBuilder
        Dim dsPosition As DataSet
        Dim dtPosition As DataTable
        Dim i As Integer

        Dim sqlposstr As String

        sqlposstr = _
        "SELECT DISTINCT tblPositions.Callsign, tblPositions.myDateTime, tblPositions.Lattitude," & _
        "tblPositions.Longitude, tblPositions.Line, tblPositions.Speed, tblPositions.Heading, " & _
        "tblPositions.Altitude FROM tblPositions GROUP BY tblPositions.Callsign, " & _
        "tblPositions.myDateTime, tblPositions.Lattitude, tblPositions.Longitude, " & _
        "tblPositions.Line, tblPositions.Speed, tblPositions.Heading, tblPositions.Altitude " & _
        "HAVING (((tblPositions.myDateTime)>#" & _
        Format(t1, "d/M/yyyy H:mm:ss") & _
        "#)) and (((tblPositions.myDateTime)<#" & _
        Format(t2, "d/M/yyyy H:mm:ss") & _
        "#)) ORDER BY tblPositions.Callsign, tblPositions.myDateTime;"

        '        MsgBox(sqlposstr)

        daPosition = New OleDbDataAdapter(sqlposstr, DataBaseConnection)
        cbPosition = New OleDbCommandBuilder(daPosition)
        dsPosition = New DataSet
        daPosition.Fill(dsPosition, "tblPositions")
        dtPosition = dsPosition.Tables("tblPositions")


        For i = 0 To dtPosition.Rows.Count - 1
            Application.DoEvents()
            MasterForm.crosspoint.Submit _
                (MasterForm.portDatabase, _
                "db_" & dtPosition.Rows(i)("Callsign") & ">APRS:!" & _
                myNetAPRS.double_to_dms(dtPosition.Rows(i)("Lattitude"), 1) & "/" & _
                myNetAPRS.double_to_dms(dtPosition.Rows(i)("Longitude"), 0) & "-")
            Application.DoEvents()
            Application.DoEvents()
            Application.DoEvents()

        Next






        If Not daPosition Is Nothing Then
            daPosition.Dispose()
        End If
        If Not cbPosition Is Nothing Then
            cbPosition.Dispose()
        End If
        If Not dsPosition Is Nothing Then
            dsPosition.Dispose()
        End If
        If Not dtPosition Is Nothing Then
            dtPosition.Dispose()
        End If
    End Sub




    Private Sub HScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar1.Scroll
        Dim t1 As Date
        Dim t2 As Date
        Dim t3 As Date

        Dim diff As Integer

        t1 = MonthCalendar1.SelectionStart
        t2 = MonthCalendar2.SelectionStart.AddDays(1)

        diff = DateDiff(DateInterval.Day, t1, t2)

        t3 = t1.AddDays(HScrollBar1.Value / 32768 * diff)

        txtDateTime.Text = Format(t3) & " to " & Format(t3.AddMinutes(3))

        DatabaseTimeGet(t3, t3.AddMinutes(15))

        'DataBaseTimeGet(t3 + TimeZoneData.Bias / 1440, t4 + TimeZoneData.Bias / 1440)



    End Sub

    Private Sub Splitter1_SplitterMoved(ByVal sender As System.Object, ByVal e As System.Windows.Forms.SplitterEventArgs)

    End Sub

End Class
