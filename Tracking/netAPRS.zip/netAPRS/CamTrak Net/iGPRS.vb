Public Class igprs
    Inherits System.Windows.Forms.Form
    Private crc32Table() As Long

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents IP_1 As System.Windows.Forms.TextBox
    Friend WithEvents Port_1 As System.Windows.Forms.TextBox
    Friend WithEvents IP_2 As System.Windows.Forms.TextBox
    Friend WithEvents Port_2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents APN As System.Windows.Forms.TextBox
    Friend WithEvents Delay As System.Windows.Forms.TextBox
    Friend WithEvents AxMSComm1 As AxMSCommLib.AxMSComm
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents AxMSComm2 As AxMSCommLib.AxMSComm
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(igprs))
        Me.IP_1 = New System.Windows.Forms.TextBox
        Me.Port_1 = New System.Windows.Forms.TextBox
        Me.IP_2 = New System.Windows.Forms.TextBox
        Me.Port_2 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.APN = New System.Windows.Forms.TextBox
        Me.Delay = New System.Windows.Forms.TextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button5 = New System.Windows.Forms.Button
        Me.AxMSComm2 = New AxMSCommLib.AxMSComm
        CType(Me.AxMSComm2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IP_1
        '
        Me.IP_1.Location = New System.Drawing.Point(16, 24)
        Me.IP_1.Name = "IP_1"
        Me.IP_1.Size = New System.Drawing.Size(168, 22)
        Me.IP_1.TabIndex = 0
        Me.IP_1.Text = "TextBox1"
        '
        'Port_1
        '
        Me.Port_1.Location = New System.Drawing.Point(272, 24)
        Me.Port_1.Name = "Port_1"
        Me.Port_1.TabIndex = 1
        Me.Port_1.Text = "TextBox1"
        '
        'IP_2
        '
        Me.IP_2.Location = New System.Drawing.Point(16, 64)
        Me.IP_2.Name = "IP_2"
        Me.IP_2.Size = New System.Drawing.Size(168, 22)
        Me.IP_2.TabIndex = 2
        Me.IP_2.Text = "TextBox1"
        '
        'Port_2
        '
        Me.Port_2.Location = New System.Drawing.Point(256, 64)
        Me.Port_2.Name = "Port_2"
        Me.Port_2.TabIndex = 3
        Me.Port_2.Text = "TextBox1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(312, 168)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Config"
        '
        'APN
        '
        Me.APN.Location = New System.Drawing.Point(16, 104)
        Me.APN.Name = "APN"
        Me.APN.Size = New System.Drawing.Size(200, 22)
        Me.APN.TabIndex = 5
        Me.APN.Text = "TextBox1"
        '
        'Delay
        '
        Me.Delay.Location = New System.Drawing.Point(280, 104)
        Me.Delay.Name = "Delay"
        Me.Delay.Size = New System.Drawing.Size(80, 22)
        Me.Delay.TabIndex = 6
        Me.Delay.Text = "TextBox1"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(344, 208)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(40, 32)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "GPS"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(24, 136)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(80, 40)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Button3"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(16, 200)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(88, 32)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "Button4"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(152, 136)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(304, 22)
        Me.TextBox1.TabIndex = 11
        Me.TextBox1.Text = "$GPRMC,092204,A,4250.5589,S,14718.5084,E,0.00,89.68,211200,,"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(424, 192)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(64, 32)
        Me.Button5.TabIndex = 12
        Me.Button5.Text = "RESET"
        '
        'AxMSComm2
        '
        Me.AxMSComm2.Enabled = True
        Me.AxMSComm2.Location = New System.Drawing.Point(168, 176)
        Me.AxMSComm2.Name = "AxMSComm2"
        Me.AxMSComm2.OcxState = CType(resources.GetObject("AxMSComm2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxMSComm2.Size = New System.Drawing.Size(38, 38)
        Me.AxMSComm2.TabIndex = 13
        '
        'igprs
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(504, 260)
        Me.Controls.Add(Me.AxMSComm2)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Delay)
        Me.Controls.Add(Me.APN)
        Me.Controls.Add(Me.Port_2)
        Me.Controls.Add(Me.IP_2)
        Me.Controls.Add(Me.Port_1)
        Me.Controls.Add(Me.IP_1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "igprs"
        Me.Text = "Form1"
        CType(Me.AxMSComm2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = ":::" & Format(i1, "0000000000") & ":" & Format(p1, "00000") & ":" & _
            Format(i2, "0000000000") & ":" & Format(p2, "00000") & ":" & _
            myapn.PadRight(40) & ":" & Format(mydelay, "0000") & ":"
        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 63))), "00000") & ":"



        AxMSComm1.Output = temp & vbCrLf

        '        MsgBox(temp)

    End Sub

    Private Function iptoi(ByVal ips As String) As Long
        Dim i As Long
        Dim ipsa(4) As String

        ipsa = ips.Split(".")

        i = ipsa(0) * 256 * 256 * 256 + ipsa(1) * 256 * 256 + ipsa(2) * 256 + ipsa(3)

        Return i

    End Function

    Private Function GetAuth(ByVal buffer As String) As Long
        Dim crc32 As Long


        Class_init()


        Dim crc32Result As Long
        crc32Result = &HFFFFFFFF

        Dim i As Integer
        Dim iLookup As Integer

        Dim mybyte As Integer

        'buffer = "darryl@radio-active.net.au"

        For i = 1 To Len(buffer)

            mybyte = Asc(Mid(buffer, i, 1))


            iLookup = (crc32Result And &HFF) Xor mybyte
            'Debug.Print mybyte, iLookup

            crc32Result = ((crc32Result And &HFFFFFF00) \ &H100) _
                And 16777215 ' nasty shr 8 with vb :/
            crc32Result = crc32Result Xor crc32Table(iLookup)

        Next i

        crc32 = Not (crc32Result)

        crc32 = crc32 And &HFFFF

        GetAuth = crc32
        'MsgBox Hex(crc32)

    End Function
    Private Function verify()

    End Function



    Private Sub Class_init()

        ' This is the official polynomial used by CRC32 in PKZip.
        ' Often the polynomial is shown reversed (04C11DB7).
        Dim dwPolynomial As Long
        dwPolynomial = &HEDB88320
        Dim i As Integer, J As Integer

        ReDim crc32Table(256)
        Dim dwCrc As Long

        For i = 0 To 255
            dwCrc = i
            For J = 8 To 1 Step -1
                If (dwCrc And 1) Then
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                    dwCrc = dwCrc Xor dwPolynomial
                Else
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                End If
            Next J
            crc32Table(i) = dwCrc
        Next i

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        AxMSComm1.Output = TextBox1.Text & vbCrLf
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        AxMSComm1.PortOpen = True

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        AxMSComm1.PortOpen = False
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click


        AxMSComm1.Output = ":::RESTART:::" & vbCrLf

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
