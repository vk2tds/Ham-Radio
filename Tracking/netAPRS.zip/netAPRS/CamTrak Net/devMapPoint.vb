
Public Class devMapPoint

    Public objApp As MapPoint.Application
    Public objMap As MapPoint.Map
    Public objLoc As MapPoint.Location
    Public objPushpin As MapPoint.Pushpin


    Dim setup As frmSetup.SetupStructure

    Private masterform As frmmain

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mnuOziPopup As System.Windows.Forms.ContextMenu
    Friend WithEvents mnuNetAPRS_Label As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Line1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Add As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_StationAdd As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Move As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_line2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_TopLeft As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_BottomRight As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Line3 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOziPopup_Cancel As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mnuOziPopup = New System.Windows.Forms.ContextMenu
        Me.mnuNetAPRS_Label = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Line1 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Add = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_StationAdd = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Move = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_line2 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_TopLeft = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_BottomRight = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Line3 = New System.Windows.Forms.MenuItem
        Me.mnuOziPopup_Cancel = New System.Windows.Forms.MenuItem
        '
        'mnuOziPopup
        '
        Me.mnuOziPopup.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNetAPRS_Label, Me.mnuOziPopup_Line1, Me.mnuOziPopup_Add, Me.mnuOziPopup_Move, Me.mnuOziPopup_line2, Me.mnuOziPopup_TopLeft, Me.mnuOziPopup_BottomRight, Me.mnuOziPopup_Line3, Me.mnuOziPopup_Cancel})
        '
        'mnuNetAPRS_Label
        '
        Me.mnuNetAPRS_Label.Enabled = False
        Me.mnuNetAPRS_Label.Index = 0
        Me.mnuNetAPRS_Label.Text = "netAPRS"
        '
        'mnuOziPopup_Line1
        '
        Me.mnuOziPopup_Line1.Index = 1
        Me.mnuOziPopup_Line1.Text = "-"
        '
        'mnuOziPopup_Add
        '
        Me.mnuOziPopup_Add.Index = 2
        Me.mnuOziPopup_Add.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuOziPopup_StationAdd})
        Me.mnuOziPopup_Add.Text = "&Add"
        '
        'mnuOziPopup_StationAdd
        '
        Me.mnuOziPopup_StationAdd.Index = 0
        Me.mnuOziPopup_StationAdd.Text = "&Station Add"
        '
        'mnuOziPopup_Move
        '
        Me.mnuOziPopup_Move.Index = 3
        Me.mnuOziPopup_Move.Text = "&Move Station"
        '
        'mnuOziPopup_line2
        '
        Me.mnuOziPopup_line2.Index = 4
        Me.mnuOziPopup_line2.Text = "-"
        '
        'mnuOziPopup_TopLeft
        '
        Me.mnuOziPopup_TopLeft.Index = 5
        Me.mnuOziPopup_TopLeft.Text = "Filter Top Left"
        '
        'mnuOziPopup_BottomRight
        '
        Me.mnuOziPopup_BottomRight.Index = 6
        Me.mnuOziPopup_BottomRight.Text = "Filter Bottom Right"
        '
        'mnuOziPopup_Line3
        '
        Me.mnuOziPopup_Line3.Index = 7
        Me.mnuOziPopup_Line3.Text = "-"
        '
        'mnuOziPopup_Cancel
        '
        Me.mnuOziPopup_Cancel.Index = 8
        Me.mnuOziPopup_Cancel.Text = "&Cancel"
        '
        'oziPopup
        '

    End Sub

#End Region


    Public Function ClearWPs()
    End Function

    Public Function UploadWPs()
        Dim i As Integer
        With masterform.FpDevGuiMaster.ActiveSheet
            For i = 0 To .RowCount - 1
                If .Cells(i, Crosspoint.DevGuiMasterCols.scCallsign).Text <> "" Then
                    UploadToMapPoint(i)
                End If
            Next i
        End With


    End Function

    Public Function SyncWPs()
        ClearWPs()
        UploadWPs()
    End Function

    Public Function DeviceOzi(ByVal PortIn As Integer, ByVal Line As String)
        'Useless Function
    End Function


    Public Function TrackInOzi(ByVal line As Integer)
        'With fpDevGuiMaster.ActiveSheet
        '    oziSendMMstring(.Cells(line, Crosspoint.DevGuiMasterCols.scGPRMC).Text)
        '    oziSendMMstring(.Cells(line, Crosspoint.DevGuiMasterCols.scGPRMC).Text)
        'End With
    End Function


    Public Function UploadToMapPoint(ByVal line As Integer)

        Dim i As Integer
        Dim OziID As Long

        With masterform.FpDevGuiMaster.ActiveSheet


            If Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text) = 0 Or _
                Val(.Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text) = 0 Then
                Exit Function
            End If

            objMap = objApp.ActiveMap
            objLoc = objMap.GetLocation(.Cells(line, Crosspoint.DevGuiMasterCols.scLat).Text, .Cells(line, Crosspoint.DevGuiMasterCols.scLon).Text, .Cells(line, Crosspoint.DevGuiMasterCols.scAlt).Text)
            objPushpin = objMap.FindPushpin(.Cells(line, Crosspoint.DevGuiMasterCols.scCallsign).Text)        ' .AddPushpin(frmMain.objLoc, name)
            If objPushpin Is Nothing Then
                objPushpin = objMap.AddPushpin(objLoc, .Cells(line, Crosspoint.DevGuiMasterCols.scCallsign).Text)
            Else
                objPushpin.Location = objLoc
            End If
            objPushpin.Note = .Cells(line, Crosspoint.DevGuiMasterCols.scDetail).Text
            objPushpin.Highlight = True
            objPushpin.BalloonState = MapPoint.GeoBalloonState.geoDisplayName  '.Cells(line, Crosspoint.DevGuiMasterCols.scDescription).Text

            If cbl(.Cells(line, Crosspoint.DevGuiMasterCols.scTrack).Text) = True Then  '(we are monitoring)
                objPushpin.GoTo()
            End If


        End With


    End Function

    Public Sub close()
        objMap = Nothing
        objApp = Nothing
        objLoc = Nothing
        objPushpin = Nothing

    End Sub

    Public Sub New(ByRef myMasterForm As frmmain)
        masterform = myMasterForm
        '    fpDevGuiMaster = myfpDevGuiMaster

        Try
            objApp = CreateObject("mappoint.application")
            If Err.Number = 0 Then
                objApp.Visible = True
            End If

        Catch ex As Exception

        End Try






    End Sub

    Public Function cbl(ByVal onestring As String) As Boolean
        Try
            Return CBool(onestring)
        Catch ex As Exception
            Return False

        End Try
        Return False

    End Function

End Class
