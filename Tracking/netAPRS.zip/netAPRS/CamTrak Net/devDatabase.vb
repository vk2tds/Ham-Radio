Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Xml
Imports System.Text
Imports System.Data.Common
Imports System.data.sqlclient

Public Class devDatabase
    Dim daPosition As OleDbDataAdapter
    Dim cbPosition As OleDbCommandBuilder
    Dim dsPosition As DataSet
    Dim dtPosition As DataTable

    Dim daLatestPosition As OleDbDataAdapter
    Dim cbLatestPosition As OleDbCommandBuilder
    Dim dsLatestPosition As DataSet
    Dim dtLatestPosition As DataTable

    Dim setup As frmSetup.SetupStructure

    Private DataBaseConnection As IDbConnection

    Dim sqllatestposstr As String = "SELECT * FROM tblCurrentPositions"
    Dim sqlposstr As String = "SELECT * FROM tblPositions"
    

    'Dim daLatestPosition As OleDbDataAdapter
    'Dim cbLatestPosition As OleDbCommandBuilder
    'Dim dsLatestPosition As DataSet
    'Dim dtLatestPosition As DataTable




    Public Function loaddatabase()

        Try

            daPosition = New OleDbDataAdapter(sqlposstr, DataBaseConnection)
            cbPosition = New OleDbCommandBuilder(daPosition)
            dsPosition = New DataSet
            daPosition.Fill(dsPosition, "tblPositions")
            dtPosition = dsPosition.Tables("tblPositions")

            daLatestPosition = New OleDbDataAdapter(sqllatestposstr, DataBaseConnection)
            cbLatestPosition = New OleDbCommandBuilder(daLatestPosition)
            dsLatestPosition = New DataSet
            daLatestPosition.Fill(dsLatestPosition, "tblCurrentPositions")
            dtLatestPosition = dsLatestPosition.Tables("tblCurrentPositions")

        Catch ex As Exception
            'now record the error
            Dim strErrorMessage As String = ""
            strErrorMessage = "An error was encountered while loading the database " & vbCrLf
            strErrorMessage = strErrorMessage & "Error Message: " & ex.Message & vbCrLf

            'log the error message
            EventLog.WriteEntry("iLog", strErrorMessage, EventLogEntryType.Error)

        End Try


    End Function

    Public Function unloaddatabase()
        Try
            If Not daPosition Is Nothing Then
                daPosition.Dispose()
            End If
            If Not cbPosition Is Nothing Then
                cbPosition.Dispose()
            End If
            If Not dsPosition Is Nothing Then
                dsPosition.Dispose()
            End If
            If Not dtPosition Is Nothing Then
                dtPosition.Dispose()
            End If

            If Not daLatestPosition Is Nothing Then
                daLatestPosition.Dispose()
            End If
            If Not cbLatestPosition Is Nothing Then
                cbLatestPosition.Dispose()
            End If
            If Not dsLatestPosition Is Nothing Then
                dsLatestPosition.Dispose()
            End If
            If Not dtLatestPosition Is Nothing Then
                dtLatestPosition.Dispose()
            End If


        Catch ex As Exception
            'now record the error
            Dim strErrorMessage As String = ""
            strErrorMessage = "An error was encountered while unloading the database " & vbCrLf
            strErrorMessage = strErrorMessage & "Error Message: " & ex.Message & vbCrLf

            'log the error message
            EventLog.WriteEntry("iLog", strErrorMessage, EventLogEntryType.Error)

        End Try


    End Function

    Public Function devDatabase_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)


        Dim drNewPosition As DataRow
        Dim dsChanges As DataSet
        Dim dtLatestPositionsAll As DataTable
        Dim drNewLatestPosition As DataRow
        Dim i As Integer

        loaddatabase()
        drNewPosition = dtPosition.NewRow

        With aprsdecoded
            drNewPosition("Callsign") = .packetSource
            drNewPosition("myDateTime") = Now
            drNewPosition("Lattitude") = .packetLatDouble
            drNewPosition("Longitude") = .packetlonDouble
            drNewPosition("Line") = Mid(.decodedline, 1, 49)
            drNewPosition("Speed") = .packetSpeed
            drNewPosition("Heading") = .packetcourse
            drNewPosition("Altitude") = .packetAltitude
            dtPosition.Rows.Add(drNewPosition)
            dsChanges = dsPosition.GetChanges
            daPosition.Update(dsChanges, "tblPositions")

            dtLatestPositionsAll = dsLatestPosition.Tables("tblCurrentPositions")
            For i = 0 To dtLatestPositionsAll.Rows.Count - 1
                Application.DoEvents()
                If dtLatestPositionsAll.Rows(i)("Callsign") = .packetSource Then
                    dtLatestPositionsAll.Rows(i)("myDateTime") = Now
                    dtLatestPositionsAll.Rows(i)("Lattitude") = .packetLatDouble
                    dtLatestPositionsAll.Rows(i)("Longitude") = .packetlonDouble
                    dtLatestPositionsAll.Rows(i)("Line") = Mid(.decodedline, 1, 49)
                    dtLatestPositionsAll.Rows(i)("Speed") = .packetSpeed
                    dtLatestPositionsAll.Rows(i)("Heading") = .packetcourse
                    dtLatestPositionsAll.Rows(i)("Altitude") = .packetAltitude
                    Try
                        daLatestPosition.Update(dtLatestPositionsAll.GetChanges(DataRowState.Modified))   '(dsChanges, "LatestPositions" )
                        dtLatestPositionsAll.AcceptChanges()
                    Catch ex As Exception
                        If setup.boolErrorLog Then
                            EventLog.WriteEntry("netAPRS", ex.Message, EventLogEntryType.Error)
                        End If
                        If setup.boolErrorMsg Then
                            MsgBox(ex.Message)
                        End If
                    End Try

                    GoTo part2
                End If

            Next

            drNewLatestPosition = dtLatestPositionsAll.NewRow

            drNewLatestPosition("Callsign") = .packetSource
            drNewLatestPosition("myDateTime") = Now
            drNewLatestPosition("Lattitude") = .packetLatDouble
            drNewLatestPosition("Longitude") = .packetlonDouble
            drNewLatestPosition("Line") = Mid(.decodedline, 1, 49)
            drNewLatestPosition("Speed") = .packetSpeed
            drNewLatestPosition("Heading") = .packetcourse
            drNewLatestPosition("Altitude") = .packetAltitude

            dtLatestPositionsAll.Rows.Add(drNewLatestPosition)
            dsChanges = dsLatestPosition.GetChanges
            daLatestPosition.Update(dsChanges, "tblCurrentPositions")

        End With


part2:

        unloaddatabase()

    End Function


    Public Sub New(ByVal DataBaseFileName As String, ByVal mysetup As frmSetup.SetupStructure)

        setup = mysetup
        DataBaseConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & DataBaseFileName)  'TODO: What happens if the database is not there?


    End Sub

    Protected Overrides Sub Finalize()

        MyBase.Finalize()
    End Sub
End Class
