Public Class netAPRSlib


    ' libaprs2 vb v.01b released JAN2003
    '
    'Copyright (c) 2002-2003, Max Kelly (K6MXD) All rights reserved. http://sourceforge.net/projects/libaprs2/
    '
    'Redistribution and use in source and binary forms, with or without modification, are permitted provided
    'that the following conditions are met:
    '
    '* Redistributions of source code must retain the above copyright notice, this list of conditions and the
    'following disclaimer.
    '
    '* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
    'following disclaimer in the documentation and/or other materials provided with the distribution.
    '
    '* Neither the names of K6MXD, Max Kelly, Max Kelly, Inc. nor the names of its contributors may be used to
    'endorse or promote products derived from this software without specific prior written permission.
    '
    'THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    'INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
    'ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    'INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    'GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    'LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
    'OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    '
    'THIS IS BETA-LEVEL SOFTWARE. DO NOT USE IN MISSION CRITICAL APPLICATIONS.
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    ' globals
    Dim aprsline As String
    Dim msgCount As Long
    Dim goodMsgCount As Long
    Dim dataValid As Boolean
    '
    'parser output data
    Dim packetSource As String
    Dim packetDest As String
    '// routing info...
    Dim packetRoute As String
    Dim packetType As String

    Dim packetDateTime As Date


    Dim packetSymbol As String
    Dim packetSymtable As String
    '
    Dim packetLong As Double
    Dim packetLongMin As Double
    Dim packetLongSec As Double
    '
    Dim packetLat As Double
    Dim packetLatMin As Double
    Dim packetLatSec As Double
    Dim packetMessageJobID As String


    Dim packetSpeed As Double
    Dim packetcourse As Double
    Dim packetAltitude As Double

    Dim packetMessageGood As Integer
    Dim packetPositionGood As Integer

    Dim packetWindSpeed As String
    Dim packetWindDirection As String
    Dim packetTemperature As String
    Dim packetWindGust As String
    Dim packetMessageJobResult As String

    Dim packetMessageTo As String
    Dim packetMessageFrom As String
    Dim packetMessageText As String
    Dim packetMessageAck As String
    Dim packetMessageseq As String
    Dim packetMessage As Integer
    Dim packetMessageDateTime As Date
    Dim packetMessageType As MessageType

    Dim packetIsPos As Boolean
    Dim packetIsMsg As Boolean
    Dim packetIsWx As Boolean
    Dim packetIsObj As Boolean

    Dim packetFailure As String

    Dim packetGood As Integer

    Private decodedline As String

    Dim packetPrivateMessageType As Integer

    Public aprsinit As Integer


    Public Structure APRSdecoded
        Dim aprsline As String
        Dim dataValid As Boolean
        '
        'parser output data
        Dim packetSource As String
        Dim packetDest As String
        '// routing info...
        Dim packetRoute As String
        Dim packetType As String
        Dim packetDateTime As Date
        Dim packetSymbol As String
        Dim packetSymtable As String
        Dim packetLong As Double
        Dim packetLongMin As Double
        Dim packetLongSec As Double
        Dim packetLat As Double
        Dim packetLatMin As Double
        Dim packetLatSec As Double
        Dim packetLatDouble As Double
        Dim packetlonDouble As Double
        Dim packetMessageJobID As String
        Dim packetSpeed As Double
        Dim packetcourse As Double
        Dim packetAltitude As Double
        Dim packetMessageGood As Integer
        Dim packetPositionGood As Integer
        Dim packetWindSpeed As String
        Dim packetWindDirection As String
        Dim packetTemperature As String
        Dim packetWindGust As String
        Dim packetMessageJobResult As String
        Dim packetMessageTo As String
        Dim packetMessageFrom As String
        Dim packetMessageText As String
        Dim packetMessageAck As String
        Dim packetMessageseq As String
        Dim packetMessage As Integer
        Dim packetMessageDateTime As Date
        Dim packetMessageType As MessageType
        Dim packetFailure As String
        Dim packetGood As Integer
        Dim decodedline As String
        Dim packetPrivateMessageType As Integer
        Dim aprsinit As Integer
        Dim packetasGPRMC As String
        Dim packetasGPGGA As String
        Dim isPos As Boolean
        Dim isMsg As Boolean
        Dim isWx As Boolean
        Dim isObj As Boolean
    End Structure



    ' private
    Public msgType As New Collection

    Public Enum MessageType
        Null = 33
        Ack = 32
        UnknownMessage = 34
        Version = 35
        UnitPowerUp = 36
        UnitPowerDown = 37
        Login = 52
        Logout = 53
        BinLift = 103
        PhoneCallIn = 74
        PhoneCallOut = 75
        PhoneCallDuraction = 76
        OverSpeed = 84
        Accident = 88
        Emergency = 89
        Police = 90
        Fire = 91
        Ambulance = 92
        PhoneUnlock = 73
        PhoneLock = 72
        GpsRateChange = 82
        FuelPurchase = 60
        P2PMessage = 64
        JobAdd = 98
        JobDelete = 97
        JobDecline = 99
        DelayNotify = 100
        MechanicalProblem = 56
        JobAccept = 102
        JobComplete = 104
        BinLiftSample = 101
        RequestPosAndSpeed = 80
        GotoPosition = 81
        PositionReport = 83
        SMSmessage = 65
        EmailMessage = 66
        UserAdd = 49
        UserGetAll = 48
        UserAuthorized = 54
        FileDataTransfer = 42
        FileDelete = 45
        FileRename = 46
        FileAttrib = 44
        GetAllJobs = 96
        MessageRead = 67
        FileOpen = 41
        FileClose = 43
        FileStatus = 40
        'GetAllJobsAllUsers = 105

    End Enum

    Public ReadOnly Property APRSPacketdecoded()

        Get
            Dim myAPRSdecoded As APRSdecoded

            With myAPRSdecoded
                .aprsline = aprsline
                .dataValid = dataValid
                .packetSource = UCase(Trim(packetSource))
                .packetDest = UCase(Trim(packetDest))
                .packetRoute = UCase(Trim(packetRoute))
                .packetType = packetType
                .packetDateTime = packetDateTime
                .packetSymbol = packetSymbol
                .packetSymtable = packetSymtable
                .packetLong = packetLong
                .packetLong = .packetLong
                .packetLongMin = packetLongMin
                .packetLongSec = packetLongSec
                .packetLat = packetLat
                .packetLatMin = packetLatMin
                .packetLatSec = packetLatSec
                .packetMessageJobID = packetMessageJobID
                Try
                    .packetcourse = CInt(packetcourse)
                    .packetAltitude = CLng(packetAltitude)
                    .packetSpeed = CInt(packetSpeed)
                Catch ex As Exception
                End Try
                .packetMessageGood = packetMessageGood
                .packetPositionGood = packetPositionGood
                .packetWindSpeed = packetWindSpeed
                .packetWindDirection = packetWindDirection
                .packetTemperature = packetTemperature
                .packetWindGust = packetWindGust
                .packetMessageJobResult = packetMessageJobResult
                .packetMessageTo = UCase(Trim(packetMessageTo))
                .packetMessageFrom = UCase(Trim(packetMessageFrom))
                .packetMessageText = packetMessageText
                .packetMessageAck = packetMessageAck
                .packetMessageseq = packetMessageseq
                .packetMessage = packetMessage
                .packetMessageDateTime = CDate(packetMessageDateTime)
                .packetMessageType = CShort(packetMessageType)
                .packetFailure = packetFailure
                .packetGood = packetGood
                .decodedline = decodedline
                .packetPrivateMessageType = packetPrivateMessageType
                .aprsinit = aprsinit
                .packetlonDouble = CDbl(dms_to_double(packetLong, packetLongMin, packetLongSec))
                .packetLatDouble = CDbl(dms_to_double(packetLat, packetLatMin, packetLatSec))


                Dim direction As String
                Dim directionns As String
                Dim directionwe As String
                Dim nmeastring As String
                Dim timedate As Date = Now
                Dim temp As Double
                Dim lat, lon As Double

                NmeaString = "$GPRMC,"
                nmeastring = nmeastring & Format(timedate, "HHmmss") & ".000,A,"
                lat = .packetLatDouble
                If lat < 0 Then
                    directionns = "S"
                Else
                    directionns = "N"
                End If
                lat = Math.Abs(lat)
                NmeaString = NmeaString & Format(Int(lat), "00")
                lat = lat - Int(lat)
                lat = lat * 60
                NmeaString = NmeaString & Format(lat, "00.000")
                NmeaString = NmeaString & "," & directionns & ","
                lon = .packetlonDouble
                If lon < 0 Then
                    directionwe = "W"
                Else
                    directionwe = "E"
                End If
                lon = Math.Abs(lon)
                nmeastring = nmeastring & Format(Int(lon), "000")
                lon = lon - Int(lon)
                lon = lon * 60
                nmeastring = nmeastring & Format(lon, "00.000")
                nmeastring = nmeastring & "," & directionwe
                nmeastring = nmeastring & "," & Format(.packetSpeed) & "," & Format(.packetcourse)
                nmeastring = nmeastring & "," & Format(timedate, "ddMMyy") & ",,"

                .packetasGPRMC = nmeastring

                .isMsg = packetIsMsg
                .isPos = packetIsPos
                .isWx = packetIsWx
                .isObj = packetIsObj


            End With
            Return myAPRSdecoded
        End Get




    End Property



    Public ReadOnly Property APRSisPos()
        Get
            Return packetIsPos
        End Get
    End Property

    Public ReadOnly Property APRSisMsg()
        Get
            Return packetIsMsg
        End Get
    End Property

    Public ReadOnly Property APRSisWx()
        Get
            Return packetIsWx
        End Get
    End Property

    Public ReadOnly Property aprsisObj()
        Get
            Return packetIsObj
        End Get
    End Property




    Public ReadOnly Property APRSPacketSource()
        Get
            Return UCase(Trim(packetSource))
        End Get
    End Property

    Public ReadOnly Property APRSPacketGood()
        Get
            Return packetGood
        End Get
    End Property

    Public ReadOnly Property APRSPacketMessageJobID()
        Get
            Return packetMessageJobID
        End Get
    End Property


    Public ReadOnly Property APRSPacketMessageFrom()
        Get
            Return UCase(Trim(packetMessageFrom))
        End Get
    End Property

    Public ReadOnly Property APRSPacketDateTime()
        Get
            Return packetDateTime
        End Get
    End Property




    Public ReadOnly Property APRSPacketMessage()
        Get
            Return packetMessage
        End Get
    End Property


    Public ReadOnly Property APRSPacketFailure()
        Get
            Return packetFailure
        End Get
    End Property


    Public ReadOnly Property APRSPacketDest()
        Get
            Return UCase(Trim(packetDest))
        End Get
    End Property
    Public ReadOnly Property APRSPacketType()
        Get
            Return packetType
        End Get
    End Property
    Public ReadOnly Property APRSPacketRoute()
        Get
            Return packetRoute
        End Get
    End Property
    Public ReadOnly Property APRSPacketSymbol()
        Get
            Return packetSymbol
        End Get
    End Property
    Public ReadOnly Property APRSPacketSymTable()
        Get
            Return packetSymtable
        End Get
    End Property
    Public ReadOnly Property APRSPacketLong()
        Get
            Return packetLong
        End Get
    End Property
    Public ReadOnly Property APRSPacketLatDouble()
        Get
            Return CDbl(dms_to_double(packetLat, packetLatMin, packetLatSec))
        End Get
    End Property
    Public ReadOnly Property APRSPacketLongDouble()
        Get
            Return CDbl(dms_to_double(packetLong, packetLongMin, packetLongSec))
        End Get
    End Property
    Public ReadOnly Property APRSPacketLongMin()
        Get
            Return packetLongMin
        End Get
    End Property
    Public ReadOnly Property APRSPacketLongSec()
        Get
            Return packetLongSec
        End Get
    End Property
    Public ReadOnly Property APRSPacketLat()
        Get
            Return packetLat
        End Get
    End Property
    Public ReadOnly Property APRSPacketLatMin()
        Get
            Return packetLatMin
        End Get
    End Property
    Public ReadOnly Property APRSPacketLatSec()
        Get
            Return packetLatSec
        End Get
    End Property
    Public ReadOnly Property APRSPacketSpeed()
        Get
            Try
                Return CInt(packetSpeed)

            Catch ex As Exception

                MsgBox(ex.Message)

            End Try
        End Get
    End Property


    Public ReadOnly Property APRSPacketcourse()
        Get
            Return CInt(packetcourse)
        End Get
    End Property
    Public ReadOnly Property APRSPacketAltitude()
        Get
            Return CLng(packetAltitude)
        End Get
    End Property
    Public ReadOnly Property APRSPacketWindSPeed()
        Get
            Return packetWindSpeed
        End Get
    End Property
    Public ReadOnly Property APRSPacketWindDirection()
        Get
            Return packetWindDirection
        End Get
    End Property
    Public ReadOnly Property APRSPacketTemperature()
        Get
            Return packetTemperature
        End Get
    End Property
    Public ReadOnly Property APRSPacketWindGust()
        Get
            Return packetWindGust
        End Get
    End Property

    Public ReadOnly Property APRSPacketMessageType()
        Get
            Return CShort(packetMessageType)
        End Get
    End Property
    Public Property APRSPacketMessageTo()
        Get
            Return UCase(Trim(packetMessageTo))
        End Get
        Set(ByVal Value)
            packetMessageTo = UCase(Value)
        End Set
    End Property
    Public ReadOnly Property APRSPacketMessageText()
        Get
            Return packetMessageText
        End Get
    End Property
    Public ReadOnly Property APRSPacketMessageAck()
        Get
            Return packetMessageAck
        End Get
    End Property
    Public ReadOnly Property APRSPacketMessageDateTime()
        Get
            Return CDate(packetMessageDateTime)
        End Get
    End Property

    Public ReadOnly Property APRSPacketMessageSeq()
        Get
            Return packetMessageseq
        End Get
    End Property

    Public ReadOnly Property APRSPacketMessageJobResult()
        Get
            If packetMessageJobResult = Chr(MessageType.JobAdd) Then
                Return Chr(MessageType.Null)
            Else
                Return packetMessageJobResult
            End If
        End Get
    End Property

    'Public ReadOnly Property APRSprivateMessageType()
    '    Get
    '        Return packetPrivateMessageType
    '    End Get
    'End Property

    Public ReadOnly Property APRSMessageGood()
        Get
            Return packetMessageGood
        End Get
    End Property

    Public ReadOnly Property APRSPositionGood()
        Get
            Return packetPositionGood
        End Get
    End Property







    Public Sub New()
        If aprsinit = 1 Then
            Exit Sub
        End If
        aprsinit = 1

        If (aprs_init()) Then
            ' init success
            '        frmMain.Show
        Else
            MsgBox("failed to init aprs object", vbCritical)
        End If
    End Sub
    '
    Private Function aprs_init() As Boolean

        ' heres a big list of all we know....

        msgType.Add("Current MIC-E", "1c")
        'msgType.Add "Weather Report, no Position", "_"
        'msgType.Add "Status", ">"
        msgType.Add("Position without Timestamp", "!")
        msgType.Add("Position with Timestamp", "=")
        msgType.Add("Stuff", "@")
        msgType.Add("Stuff", "/")
        msgType.Add("Status Report", ">")
        msgType.Add("Message Report", ":")
        msgType.Add("Object", ";")
        msgType.Add("UserDefined", "U")



        msgType.Add("Current D700/D7 Mic-E", "'")
        msgType.Add("MIC-E", "`")

        msgType.Add("NMEA", "$")


        aprs_clear()
        aprs_init = True
    End Function
    '
    Public Function aprs_decode(ByVal myaprsline As String) As Boolean
        aprs_clear()

        decodedline = myaprsline
        'On Error Resume Next
        Dim address As String
        Dim message As String
        ' pointers, kinda
        Dim finger As Integer
        Dim little_finger As Integer



        While Right(myaprsline, 1) = vbCr Or Right(myaprsline, 1) = vbLf
            While Right(myaprsline, 1) = vbCr
                myaprsline = Mid(myaprsline, 1, Len(myaprsline) - 1)
            End While
            While Right(myaprsline, 1) = vbLf
                myaprsline = Mid(myaprsline, 1, Len(myaprsline) - 1)
            End While
        End While




        If Len(myaprsline) > 2 Then
            finger = InStr(1, myaprsline, ":}")
            If finger > 0 Then
                myaprsline = Mid(myaprsline, finger + 2)
            End If
        End If

        ' >2 is larger than a CRLF, it'll try and decode it
        If Len(myaprsline) > 2 Then
            ' its a message i'm trying to decode
            msgCount = msgCount + 1
            dataValid = False
            ' pick into sections
            finger = InStr(myaprsline, ":")
            ' if theres a message and routing section
            If finger > 0 Then
                ' copy
                ' i'm making address seperate because we might want to expose it in the future
                address = Mid(myaprsline, 1, finger - 1)
                ' split src and dest
                little_finger = InStr(address, ">")
                ' a little hack
                If (little_finger < 3) Then
                    aprs_decode = False
                    Exit Function
                End If
                ' we found a ">"
                packetSource = Mid(address, 1, little_finger - 1)
                packetDest = Mid(address, little_finger + 1)
                ' we count on message parsing routines to set dataValid to true
                If (parse_msg(Mid(myaprsline, finger + 1))) Then
                    ' good enough message
                    packetGood = True
                    packetPositionGood = True
                    If packetLat = 0 And packetLong = 0 Then
                        packetPositionGood = False
                    End If
                    goodMsgCount = goodMsgCount + 1
                    aprs_decode = True
                Else
                    aprs_decode = False
                End If

            Else
                ' no address delimiter
                ' clear everything
                aprs_clear()
                aprs_decode = False
            End If
        End If ' longer than 2 chars

    End Function


    Private Function parse_msg(ByVal theMessage As String) As Boolean

        'On Error GoTo error_handler

        '// the message type
        Dim myType As String
        myType = Mid(theMessage, 1, 1)

        '// find in vector
        Try
            packetType = msgType.Item(myType)
        Catch ex As Exception
            packetType = "X"
        End Try

        '       // do message specific parse
        Select Case myType
            Case "!", "="
                parse_msg = parsePosition(theMessage)
            Case "/", "@"
                parse_msg = parsePosition(theMessage)
                '// this is '
            Case ">"
                parse_msg = parseStatus(theMessage)
            Case ":"
                parse_msg = parseMessage(theMessage)
            Case ";"
                parse_msg = parseObject(theMessage)
            Case "U"
                parse_msg = parseUserDefined(theMessage)

            Case "$"
                parse_msg = parseNMEA(theMessage)
            Case "'", "`"
                parse_msg = parseMice(theMessage)
            Case Else
                Debug.WriteLine(theMessage)

                parse_msg = False
        End Select


        Exit Function

error_handler:
        '// we didnt find the type in teh vector
        aprs_error("parsemsg " & Err.Number & Err.Description & theMessage)
    End Function


    Private Sub aprs_error(ByVal error_information As String)

        Debug.WriteLine(error_information)
        '    MsgBox error_information
    End Sub

    Private Sub aprs_clear()
        '// cleans out the packet vars
        dataValid = False
        '// strings
        packetDest = ""
        packetSource = ""
        packetType = ""
        '// chars
        packetSymbol = 0
        packetGood = False
        packetSymtable = ""
        '// string *
        packetRoute = ""
        '// double
        packetLat = 0
        packetLatMin = 0
        packetLatSec = 0
        packetLong = 0
        packetLongMin = 0
        packetLongSec = 0
        packetSpeed = 0
        packetcourse = 0
        packetAltitude = 0
        packetMessageJobID = ""

        decodedline = ""

        packetMessageGood = 0
        packetPositionGood = 0
        'BUG: Need to null out the DateTime to something that is NULL
        'packetMessageDateTime =
        packetMessageType = 0
        packetMessageJobResult = ""
        packetFailure = ""

        packetWindSpeed = ""
        packetWindDirection = ""
        packetTemperature = ""
        packetWindGust = ""
        packetIsPos = False
        packetIsMsg = False
        packetIsWx = False
        packetIsObj = False

    End Sub

    Private Function parseMessage(ByVal theMessage As String) As Boolean

        parseMessage = True
        packetIsMsg = True

    End Function
    Private Function parseUserDefined(ByVal theMessage As String) As Boolean

        If Mid(theMessage, 2, 1) = "I" Then
            packetFailure = packetFailure & "(UI)"

            ' This is VK2TDS Stuff
            packetMessageType = Asc(Mid(theMessage, 3, 1))

            If packetMessageType = MessageType.Ack Then
                packetMessageFrom = Mid(theMessage, 12, 8)
                packetMessageseq = Mid(theMessage, 20, 15)
                packetMessageTo = Mid(theMessage, 4, 8)

                packetMessageGood = True
                packetMessageAck = True
                parseUserDefined = True
                Return True
            End If


            parsePartialThirdMessage(Mid(theMessage, 3))
        End If



        parseUserDefined = True

    End Function
    Private Function parsePartialThirdMessage(ByVal theMessage As String) As Boolean
        Dim finger As Integer

        If theMessage.Length < 32 Then
            packetFailure = packetFailure & "(ShortMessage)"
            Return False
        End If
        packetMessageFrom = Mid(theMessage, 10, 8)
        packetMessageTo = Mid(theMessage, 2, 8)
        packetMessageseq = Mid(theMessage, 18, 15)

        packetMessageText = Mid(theMessage, 33)

        If Asc(Mid(theMessage, 1, 1)) = MessageType.JobDelete Or _
             Asc(Mid(theMessage, 1, 1)) = MessageType.JobAdd Or Asc(Mid(theMessage, 1, 1)) = MessageType.JobDecline Or _
             Asc(Mid(theMessage, 1, 1)) = MessageType.JobAccept Or Asc(Mid(theMessage, 1, 1)) = MessageType.JobComplete Or _
             Asc(Mid(theMessage, 1, 1)) = MessageType.BinLift Then

            packetFailure = packetFailure & "(MessageStuff)"

            packetMessageText = packetMessageText & " "
            finger = InStr(packetMessageText, " ")
            If finger > 0 Then
                packetMessageJobID = Mid(packetMessageText, 1, finger - 1)
                packetMessageText = Mid(packetMessageText, finger + 1)
            Else
                packetMessageJobID = packetMessageText
            End If

            If Asc(Mid(theMessage, 1, 1)) = MessageType.JobAdd Then
                packetMessageJobResult = Mid(packetMessageJobID, 1, 1)
                packetMessageJobID = Mid(packetMessageJobID, 2)
            End If


        End If

        '        If Asc(Mid(theMessage, 1, 1)) = 64 Then
        '
        '       packetMessageJobID = Mid(packetMessageText, 1, 15)
        '      packetMessageText = Mid(packetMessageText, 16)
        '
        '
        '       End If


        If Asc(Mid(theMessage, 1, 1)) = MessageType.PositionReport Then  ' we are a position report
            packetIsPos = True
            packetFailure = packetFailure & "(3rd-POS)"
            packetDateTime = todatetime(Mid(packetMessageText, 1, 14))

            decodeLatLongDecNoPt(Mid(packetMessageText, 15, 9))
            decodeLatLongDecNoPt(Mid(packetMessageText, 24, 8))
            If Len(packetMessageText) >= 34 Then
                packetFailure = packetFailure & "(3rd-CSE)"
                packetcourse = Val(Mid(packetMessageText, 32, 3))
                If Len(packetMessageText) >= 38 Then
                    packetFailure = packetFailure & "(3rd-SPD)"
                    packetSpeed = Val(Mid(packetMessageText, 35, 4)) / 10 / 1.852
                End If
            End If
            packetMessageGood = False


        End If


        packetMessage = True
        packetMessageGood = True
        Return True

    End Function

    Private Function todatetime(ByVal s As String) As Date
        Try

            Return DateSerial(CInt(Mid(s, 1, 4)), _
                CInt(Mid(s, 5, 2)), _
                CInt(Mid(s, 7, 2))) + " " + _
                TimeSerial(CInt(Mid(s, 9, 2)), _
                CInt(Mid(s, 11, 2)), _
                CInt(Mid(s, 13, 2)))
        Catch ex As Exception
            packetFailure = packetFailure & "(BAD toDateTime)"

            Return Now
        End Try

    End Function

    Private Function parsePartialMessage(ByVal theMessage As String) As Boolean
        If InStr(theMessage, ":") < 1 Then Return False
        If InStr(2, theMessage, ":") < 1 Then Return False
        packetMessageTo = Mid(theMessage, 2, InStr(2, theMessage, ":") - 1)
        packetMessageText = Mid(theMessage, InStr(2, theMessage, ":") + 1)

        If Mid(theMessage, 1, 3).ToUpper = "ACK" Then
            packetMessageAck = True
            packetMessageseq = Mid(theMessage, 4)
            packetMessageText = ""
        Else
            packetMessageAck = False
            If InStr(1, theMessage, "}") < 1 Then Return False
            packetMessageseq = Mid(packetMessageText, InStr(1, packetMessageText, "}") + 1)
            packetMessageText = Mid(packetMessageText, 1, InStr(1, packetMessageText, "}"))
        End If

        packetMessageGood = True
        packetMessage = True
        Return True

    End Function



    Private Function parseStatus(ByVal theMessage As String) As Boolean

        parseStatus = True

    End Function

    Private Function parseWeatherUnderscore(ByVal theMessage As String) As Boolean

        If Mid(theMessage, 5, 1) = "/" Then
            packetWindDirection = Mid(theMessage, 2, 3)
            packetWindSpeed = Mid(theMessage, 6, 3)
            If InStr(1, theMessage, "t") > 0 Then
                packetTemperature = Mid(theMessage, InStr(1, theMessage, "t") + 1, 3)
            End If
        End If




    End Function

    Private Function parsePosition(ByVal theMessage As String) As Boolean
        On Error GoTo error_handler
        '// for now, just put it in here
        Dim myLat As String
        Dim myLong As String
        Dim mySymtable As String
        Dim mySymbol As String
        Dim myComment As String
        '// anytime you monkey with the elements, the data is false
        dataValid = False
        ' copying teh data
        If Left(theMessage, 1) = "/" Or Left(theMessage, 1) = "@" Then
            'throw away the timestamp
            ' 11/7/04 Did remove 8 characters on the next line, now only 7.
            theMessage = Mid(theMessage, 1, 1) & Mid(theMessage, 9)
        End If

        If Mid(theMessage, 2, 1) = "/" Or Mid(theMessage, 2, 1) = "\" Then
            ' We are really a compressed packet. Wow. Never seen one of these before. 
            ' Lets look at the spec. 

            packetLat = CompressedToLat(Mid(theMessage, 3, 4))
            packetLong = CompressedToLon(Mid(theMessage, 7, 4))
            packetSymbol = Mid(theMessage, 11, 1)
            If Mid(theMessage, 12, 1) = " " Or Mid(theMessage, 12, 1) = "{" Then
                packetcourse = 0
                packetSpeed = 0
                packetAltitude = 0
            Else
                packetcourse = (Asc(Mid(theMessage, 12, 1)) - 33) * 4
                packetSpeed = Math.Pow(1.08, (Asc(Mid(theMessage, 13, 1)) - 33)) - 1
            End If
            mySymtable = Mid(theMessage, 10, 1)
            dataValid = True
            parsePosition = True
            packetPositionGood = True
            packetIsPos = True
            Return True

        End If

        myLat = Mid(theMessage, 2, 8)
        mySymtable = Mid(theMessage, 10, 1)
        myLong = Mid(theMessage, 11, 9)
        mySymbol = Mid(theMessage, 20, 1)


        '// look for extentions

        '// if everything is good, return
        '// we only care about required parameters on position
        If (Val(myLat) > 0 And Val(myLong) > 0) Then
            '// copy values to publics
            packetLat = decodeLatLongDec(myLat)
            packetSymtable = mySymtable
            packetLong = decodeLatLongDec(myLong)
            packetSymbol = mySymbol
            '// set dataValid
            dataValid = True
            parsePosition = True
            packetPositionGood = True
            packetIsPos = True
        Else
            parsePosition = False
        End If



        If mySymbol = "_" Then
            parseWeatherUnderscore(Mid(theMessage, 20))
        Else
            If Mid(theMessage, 24, 1) = "/" Then
                packetcourse = Val(Mid(theMessage, 21, 3))
                packetSpeed = Val(Mid(theMessage, 25, 3))
            End If
            ' Other types of packets.....



            If Mid(theMessage, 28, 3) = "/A=" Then
                packetAltitude = Val(Mid(theMessage, 31, 6))

            End If

        End If






        '// look for extentions

        '// if everything is good, return
        '// we only care about required parameters on position
        If (Val(myLat) > 0 And Val(myLong) > 0) Then
            '// copy values to publics
            packetLat = decodeLatLongDec(myLat)
            packetSymtable = mySymtable
            packetLong = decodeLatLongDec(myLong)
            packetSymbol = mySymbol
            '// set dataValid
            dataValid = True
            parsePosition = True
            packetIsPos = True
            packetPositionGood = True
        Else
            parsePosition = False
        End If

        Exit Function
error_handler:
        Debug.WriteLine("position error " & Err.Number & Err.Description & Err.Source)
        aprs_error("position error " & Err.Number & Err.Description & Err.Source)

    End Function


    Private Function parseObject(ByVal theMessage As String) As Boolean
        On Error GoTo error_handler
        '// for now, just put it in here
        Dim finger As Integer

        Dim myLat As String
        Dim myLong As String
        Dim mySymtable As String
        Dim mySymbol As String
        Dim myComment As String
        '// anytime you monkey with the elements, the data is false
        dataValid = False
        ' copying teh data
        If Mid(theMessage, 11, 1) = "*" Or Mid(theMessage, 11, 1) = "_" Then
            finger = 19
        End If




        myLat = Mid(theMessage, 0 + finger, 8)
        mySymtable = Mid(theMessage, 8 + finger, 1)
        myLong = Mid(theMessage, 9 + finger, 9)
        mySymbol = Mid(theMessage, 18 + finger, 1)

        '// look for extentions

        '// if everything is good, return
        '// we only care about required parameters on position
        If (Val(myLat) > 0 And Val(myLong) > 0) Then
            '// copy values to publics
            packetSource = Trim(Mid(theMessage, 2, 9))
            packetLat = decodeLatLongDec(myLat)
            packetSymtable = mySymtable
            packetLong = decodeLatLongDec(myLong)
            packetSymbol = mySymbol
            '// set dataValid
            dataValid = True
            parseObject = True
            packetIsObj = True
        Else
            parseObject = False
        End If

        Exit Function
error_handler:
        Debug.WriteLine("position error " & Err.Number & Err.Description & Err.Source)
        aprs_error("position error " & Err.Number & Err.Description & Err.Source)

    End Function



    ' this will set the packet lat long values, this is a change from the initial api
    ' it expects something like: 11811.22W or 9011.22E
    ' as long as the decimal is between min and sec, min is two digits and the cardinall
    ' is at the end, it shoudl work.... enough rules?
    Private Function decodeLatLong(ByVal myData As String) As Double

        If packetLongSec > 60 Or packetLatSec > 60 Then MsgBox("ERROR: Wrong function")

        Dim myFinger As Integer
        myFinger = InStr(1, myData, ".")
        Select Case (Mid(myData, Len(myData), 1))
            ' west is longitude
        Case "W"
                packetLong = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLongMin = Val(Mid(myData, myFinger - 2, 2))
                packetLongSec = Val(Mid(myData, myFinger + 1, 2))
                decodeLatLong = packetLong
                ' south is latitude
            Case "S"
                packetLat = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLatMin = Val(Mid(myData, myFinger - 2, 2))
                packetLatSec = Val(Mid(myData, myFinger + 1, 2))
                decodeLatLong = packetLat
                ' east is longitude
            Case "E"
                packetLong = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLongMin = Val(Mid(myData, myFinger - 2, 2))
                packetLongSec = Val(Mid(myData, myFinger + 1, 2))
                decodeLatLong = packetLong
                ' north is latitude
            Case "N"
                packetLat = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLatMin = Val(Mid(myData, myFinger - 2, 2))
                packetLatSec = Val(Mid(myData, myFinger + 1, 2))
                decodeLatLong = packetLat
                'whatever...
            Case Else
                decodeLatLong = 0
        End Select
    End Function


    ' this will set the packet lat long values, this is a change from the initial api
    ' it expects something like: 11811.22W or 9011.22E
    ' as long as the decimal is between min and sec, min is two digits and the cardinall
    ' is at the end, it shoudl work.... enough rules?
    Private Function decodeLatLongDec(ByVal myData As String) As Double

        Dim myFinger As Integer
        myFinger = InStr(1, myData, ".")
        Select Case (Mid(myData, Len(myData), 1))
            ' west is longitude
        Case "W"
                packetLong = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLongMin = Val(Mid(myData, myFinger - 2, 2))
                packetLongSec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                decodeLatLongDec = packetLong
                ' south is latitude
            Case "S"
                packetLat = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLatMin = Val(Mid(myData, myFinger - 2, 2))
                packetLatSec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                decodeLatLongDec = packetLat
                ' east is longitude
            Case "E"
                packetLong = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLongMin = Val(Mid(myData, myFinger - 2, 2))
                packetLongSec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                decodeLatLongDec = packetLong
                ' north is latitude
            Case "N"
                packetLat = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                packetLatMin = Val(Mid(myData, myFinger - 2, 2))
                packetLatSec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                decodeLatLongDec = packetLat
                'whatever...
            Case Else
                decodeLatLongDec = 0
        End Select
    End Function




    ' this will set the packet lat long values, this is a change from the initial api
    ' it expects something like: 11811.22W or 9011.22E
    ' as long as the decimal is between min and sec, min is two digits and the cardinall
    ' is at the end, it shoudl work.... enough rules?
    Private Function decodeLatLongDecNoPt(ByVal myData As String) As Double
        Try
            If Len(myData) = 0 Then Return 0
            packetFailure = packetFailure & "(DecLLnoDec)"

            Select Case (Mid(myData, Len(myData), 1))
                ' west is longitude
            Case "W"
                    packetLong = -CDbl(Val(Mid(myData, 1, 3)))
                    packetLongMin = Val(Mid(myData, 4, 2))
                    packetLongSec = Val(Mid(myData, 6, 2)) * 60 / 100
                    decodeLatLongDecNoPt = packetLong
                    ' south is latitude
                Case "E"
                    packetLong = CDbl(Val(Mid(myData, 1, 3)))
                    packetLongMin = Val(Mid(myData, 4, 2))
                    packetLongSec = Val(Mid(myData, 6, 2)) * 60 / 100
                    decodeLatLongDecNoPt = packetLong
                    ' north is latitude

                Case "S"
                    packetLat = -CDbl(Val(Mid(myData, 1, 2)))
                    packetLatMin = Val(Mid(myData, 3, 2))
                    packetLatSec = Val(Mid(myData, 5, 2)) * 60 / 100
                    decodeLatLongDecNoPt = packetLat
                    ' east is longitude
                Case "N"
                    packetLat = CDbl(Val(Mid(myData, 1, 2)))
                    packetLatMin = Val(Mid(myData, 3, 2))
                    packetLatSec = Val(Mid(myData, 5, 2)) * 60 / 100
                    decodeLatLongDecNoPt = packetLat
                    'whatever...
                Case Else
                    decodeLatLongDecNoPt = 0
                    packetFailure = packetFailure & "(DecLLnoPt - 0)"
            End Select
        Catch ex As Exception

            MsgBox(ex.Message & " - " & myData)
        End Try

    End Function



    '// TODO clean up, add comment handling, msg bit and all that crap
    '// mic e, ugh.
    Private Function parseMice(ByVal theMessage As String) As Boolean

        Dim myFinger As Integer
        Dim tempLat As String
        Dim msgBits(3) As Boolean
        Dim EorW As String
        Dim NorS As String
        Dim longOffset As Integer
        Dim rawLat, cookedLat As String
        Dim rawLong, cookedLong As String
        Dim myDest As String
        Dim myLat As Double
        Dim myLong As Double
        Dim theVal, i As Integer
        Dim rawMsg As String

        '// anytime you monkey with the elements, the data is false
        dataValid = False

        '// ok, we split out "fake" destination address
        myFinger = InStr(1, packetDest, ",")
        'myFinger = packetDest.find_first_of(',',0);
        '// what? a mic-e packet with only one dest? i think thats invalid.
        If (myFinger = -1) Then
            dataValid = False
            parseMice = dataValid
        End If
        '// take off teh first address, then copy the rest back\]
        If myFinger = 0 Then
            rawLat = packetDest
            myDest = "APRS"
        Else
            rawLat = Mid(packetDest, 1, myFinger - 1)
            myDest = Mid(packetDest, myFinger + 1)
        End If
        packetDest = myDest

        '// now rawLat has the first raw packet.

        '// this is a bear.
        For i = 1 To Len(rawLat)
            '// decode each digit and do stuff..
            theVal = Asc(Mid(rawLat, i, 1))

            Select Case (theVal)
                Case 48 To 57
                    '// first set
                    'replace(templat,
                    tempLat = tempLat & Mid(rawLat, i, 1)
                    Select Case (i)
                        Case 1 To 3
                            msgBits(i) = False
                        Case 4
                            NorS = "S"
                        Case 5
                            longOffset = 0
                        Case 6
                            EorW = "E"
                    End Select

                Case 65 To 74
                    '// second set
                    ' was -32 Now -17 VK2TDS
                    tempLat = tempLat & Chr(theVal - 17)
                    Select Case (i)
                        Case 1 To 3
                            msgBits(i) = True
                    End Select

                Case 75, 76
                    '// third set
                    tempLat = tempLat & " "
                    Select Case (theVal)
                        Case 75
                            msgBits(i) = False
                        Case 76
                            Select Case (i)
                                Case 4
                                    NorS = "S"
                                Case 5
                                    longOffset = 0
                                Case 6
                                    EorW = "E"
                            End Select
                    End Select

                Case 77 To 89
                    '// fourth set
                    tempLat = tempLat & Chr(theVal - 32)
                    Select Case (i)
                        Case 1 To 3
                            msgBits(i) = True
                        Case 4
                            NorS = "N"
                        Case 5
                            longOffset = 100
                        Case 6
                            EorW = "W"
                    End Select

                Case 90
                    '// last set
                    tempLat = tempLat & " "
                    Select Case (i)
                        Case 1 To 3
                            msgBits(i) = True
                        Case 4
                            NorS = "N"
                        Case 5
                            longOffset = 100
                        Case 6
                            EorW = "W"
                    End Select

            End Select
        Next i '// this is the end of that big for loop...

        '//format cooked lat correctly
        '// TODO tempLat could have a buffer overflow.
        tempLat = tempLat & NorS
        cookedLat = Left(tempLat, 4) & "." & Mid(tempLat, 5)

        myLat = decodeLatLongDec(cookedLat)
        '/// latitude decoding is done /////////////////////////////////////////////

        '// ok, now for teh message
        rawLong = Mid(theMessage, 1, 8)
        rawMsg = Mid(theMessage, 10)

        '// now rawLong has the second raw packet.

        '// degree part of longitude
        theVal = longOffset + (Asc(Mid(rawLong, 2, 1)) - 28)
        If (theVal >= 180 And theVal <= 189) Then theVal = theVal - 80
        If (theVal >= 190 And theVal <= 199) Then theVal = theVal - 190
        ' maybe need to do something here....
        cookedLong = CStr(theVal)

        If Len(rawLong) < 4 Then Exit Function


        '// minute part of longitude
        theVal = (Asc(Mid(rawLong, 3, 1)) - 28)
        If (theVal >= 60) Then theVal = theVal - 60
        cookedLong = cookedLong & Format(theVal, "00") & "."

        '// hundreth minute part of latitude
        theVal = (Asc(Mid(rawLong, 4, 1)) - 28)
        cookedLong = cookedLong & CStr(theVal)

        '// finish cooked long
        cookedLong = cookedLong & EorW
        myLong = decodeLatLongDec(cookedLong)

        '// TODO: speed & course
        '// we got lat and long out of it, thats enough.
        '// TODO: convert decode lat long to boolean...

        If Len(rawLong) < 8 Then Exit Function
        packetSpeed = (Asc(Mid(rawLong, 5, 1)) - 28) * 10 + Int((Asc(Mid(rawLong, 6, 1)) - 28) / 10)
        packetcourse = (Asc(Mid(rawLong, 7, 1)) - 28) + ((Asc(Mid(rawLong, 6, 1)) - 28) Mod 10) * 100
        If packetSpeed >= 800 Then
            packetSpeed = packetSpeed - 800
        End If
        If packetcourse >= 400 Then
            packetcourse = packetcourse - 400
        End If

        myFinger = InStr(1, rawMsg, "}")
        If myFinger > 3 Then
            packetAltitude = ((Asc(Mid(rawMsg, myFinger - 3, 1)) - 33) * (91 * 91) + _
                (Asc(Mid(rawMsg, myFinger - 2, 1)) - 33) * (91) + _
                (Asc(Mid(rawMsg, myFinger - 1, 1)) - 33) - 10000) * 3.28083991666667

        End If


        '    rawMsg

        If (myLat <> 0 And myLong <> 0) Then
            '// TODO  also set messages, icon, and comment
            dataValid = True
        End If

        parseMice = dataValid
    End Function

    '// TODO clean up, add comment handling, msg bit and all that crap
    '// mic e, ugh.
    Private Function parseNMEA(ByVal theMessage As String) As Boolean

        Dim myFinger As Integer
        Dim tempLat As String
        Dim msgBits(3) As Boolean
        Dim EorW As String
        Dim NorS As String
        Dim longOffset As Integer
        Dim rawLat, cookedLat As String
        Dim rawLong, cookedLong As String
        Dim myDest As String
        Dim myLat As Double
        Dim myLong As Double
        Dim theVal, i As Integer

        Dim myTemp As String
        On Error Resume Next
        '// anytime you monkey with the elements, the data is false
        dataValid = False

        Select Case (Mid(theMessage, 1, 6))
            Case "$GPRMC"
                myTemp = Mid(theMessage, 8)
                'Get rid of UTC
                myFinger = InStr(1, myTemp, ",")
                myTemp = Mid(myTemp, myFinger + 1)
                If Left(myTemp, 1) <> "A" Then
                    GoTo ExitFunction
                End If
                myTemp = Mid(myTemp, 3)

                ' Lat
                myFinger = InStr(1, myTemp, ",")
                cookedLat = Left(myTemp, myFinger - 1)

                myTemp = Mid(myTemp, myFinger + 1)

                NorS = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)

                myFinger = InStr(1, myTemp, ",")
                cookedLong = Left(myTemp, myFinger - 1)


                myTemp = Mid(myTemp, myFinger + 1)

                EorW = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)


                myFinger = InStr(1, myTemp, ",")
                packetSpeed = Left(myTemp, myFinger - 1)

                myTemp = Mid(myTemp, myFinger + 1)


                myFinger = InStr(2, myTemp, ",")
                packetcourse = Left(myTemp, myFinger - 1)

                myTemp = Mid(myTemp, myFinger + 1)




                myLat = decodeLatLongDec(cookedLat & NorS)
                myLong = decodeLatLongDec(cookedLong & EorW)
                dataValid = True
            Case "$GPGGA"
                myTemp = Mid(theMessage, 8)
                'Get rid of UTC
                myFinger = InStr(1, myTemp, ",")
                myTemp = Mid(myTemp, myFinger + 1)
                '            If Left(myTemp, 1) <> "A" Then
                '                GoTo ExitFunction
                '            End If
                '           myTemp = Mid(myTemp, 3)

                ' Lat
                myFinger = InStr(1, myTemp, ",")
                cookedLat = Left(myTemp, myFinger - 1)

                myTemp = Mid(myTemp, myFinger + 1)

                NorS = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)

                myFinger = InStr(1, myTemp, ",")
                cookedLong = Left(myTemp, myFinger - 1)


                myTemp = Mid(myTemp, myFinger + 1)

                EorW = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)


                myLat = decodeLatLongDec(cookedLat & NorS)
                myLong = decodeLatLongDec(cookedLong & EorW)
                dataValid = True

            Case "$GPGLL"
                myTemp = Mid(theMessage, 8)
                'Get rid of UTC

                ' Lat
                myFinger = InStr(1, myTemp, ",")
                cookedLat = Left(myTemp, myFinger - 1)

                myTemp = Mid(myTemp, myFinger + 1)

                NorS = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)

                myFinger = InStr(1, myTemp, ",")
                cookedLong = Left(myTemp, myFinger - 1)


                myTemp = Mid(myTemp, myFinger + 1)

                EorW = Mid(myTemp, 1, 1)
                myTemp = Mid(myTemp, 3)

                myFinger = InStr(1, myTemp, ",")
                myTemp = Mid(myTemp, myFinger + 1)
                If Left(myTemp, 1) <> "A" Then
                    GoTo ExitFunction
                End If
                myTemp = Mid(myTemp, 3)



                myLat = decodeLatLongDec(cookedLat & NorS)
                myLong = decodeLatLongDec(cookedLong & EorW)
                dataValid = True




        End Select


ExitFunction:
        On Error GoTo 0
        parseNMEA = dataValid
    End Function




    Public Function decimal_to_seconds(ByVal theDecimal As Double) As Integer
        decimal_to_seconds = theDecimal * 60
    End Function


    Public Function double_to_dms(ByVal theCoord As Double, ByVal lat As Integer) As String
        Dim temp As String

        temp = Format(Int(Math.Abs(theCoord)), "000")

        temp = temp & Format((Math.Abs(theCoord) - Int(Math.Abs(theCoord))) * 60, "00.00")
        If lat = 0 Then
            If theCoord > 0 Then
                temp = temp & "E"
            Else
                temp = temp & "W"
            End If

        Else
            If theCoord > 0 Then
                temp = temp & "N"
            Else
                temp = temp & "S"
            End If


            temp = Mid(temp, 2)
        End If


        double_to_dms = temp

    End Function


    Public Function dms_to_double(ByVal theDegree As Double, ByVal theMinute As Double, ByVal theSecond As Double)
        dms_to_double = (Math.Abs(theDegree) + CDbl(theMinute) / 60 + CDbl(theSecond) / 3600) * Math.Sign(theDegree + 0.000001)

    End Function


    Public Function CompressedToLat(ByVal TheString As String) As Double
        Return 90 - ( _
                (Asc(Mid(TheString, 1, 1)) - 33) * 91 * 91 * 91 + _
                (Asc(Mid(TheString, 2, 1)) - 33) * 91 * 91 + _
                (Asc(Mid(TheString, 3, 1)) - 33) * 91 + _
                (Asc(Mid(TheString, 4, 1)) - 33)) _
                 / 380926
    End Function
    Public Function CompressedToLon(ByVal theString As String) As Double
        Return 180 - ( _
            (Asc(Mid(theString, 1, 1)) - 33) * 91 * 91 * 91 + _
            (Asc(Mid(theString, 2, 1)) - 33) * 91 * 91 + _
            (Asc(Mid(theString, 3, 1)) - 33) * 91 + _
            (Asc(Mid(theString, 4, 1)) - 33)) / 190463
    End Function


    Public Function ToDMS(ByVal Combined As Double, ByRef Deg As Integer, ByRef Min As Integer, ByRef Sec As Integer) As Integer

        Deg = Int(Math.Abs(Combined))
        Min = Int((Math.Abs(Combined) - Deg) * 60)
        Sec = Int(Math.Abs(Combined) - Deg - Min / 60) * 3600

        Deg = Deg * Math.Sign(Combined + 0.00001)

        Return True

    End Function


    Public Function removecomma(ByVal withcomma As String) As String

        Dim withoutcomma As String
        Dim i As Integer
        For i = 1 To Len(withcomma)
            If Mid(withcomma, i, 1) = "," Then
                withoutcomma = withoutcomma & "."
            Else
                withoutcomma = withoutcomma & Mid(withcomma, i, 1)
            End If
        Next i
        removecomma = withoutcomma

    End Function




End Class
Public Class DecodeGPS

    Dim GPSlat As Double
    Dim GPSlon As Double
    Dim GPSalt As Double
    Dim GPSspd As Double
    Dim GPShdg As Double
    Dim GPSgood As Integer

    Public ReadOnly Property GetLat()
        Get
            Return GPSlat
        End Get
    End Property

    Public ReadOnly Property GetLon()
        Get
            Return GPSlon
        End Get
    End Property
    Public ReadOnly Property Getalt()
        Get
            Return GPSalt
        End Get
    End Property
    Public ReadOnly Property Getspd()
        Get
            Return GPSspd
        End Get
    End Property
    Public ReadOnly Property Gethdg()
        Get
            Return GPShdg
        End Get
    End Property

    Public ReadOnly Property GetGPSGood()
        Get
            Return GPSgood
        End Get
    End Property


    Public Sub New()
        GPSlat = 0
        GPSlon = 0
        GPSalt = 0
        GPSspd = 0
        GPShdg = 0
        GPSgood = False

    End Sub



    Public Function GPSdecode(ByVal myline As String) As Integer

        Dim split As String() = Nothing

        split = myline.Split(",", 20)

        Select Case split(0)
            Case "$GPGLL"
                '$GPGLL,4250.5589,S,14718.5084,E,092204.999,A*2D
                GPSlat = decodeLatLongDec(split(1) & split(2))
                GPSlon = decodeLatLongDec(split(3) & split(4))

                If Mid(split(6), 1, 1) = "A" Then
                    GPSgood = True
                End If
            Case "$GPRMC"
                '$GPRMC,092204.999,A,4250.5589,S,14718.5084,E,0.00,89.68,211200,,*25
                If Mid(split(2), 1, 1) = "A" Then
                    GPSgood = True
                End If

                GPSlat = decodeLatLongDec(split(3) & split(4))
                GPSlon = decodeLatLongDec(split(5) & split(6))
                GPSspd = split(7)
                GPShdg = split(8)

            Case Else

        End Select



    End Function

    Private Function decodeLatLongDec(ByVal myData As String) As Double

        Dim degree, min, sec As Double

        Dim myFinger As Integer
        myFinger = InStr(1, myData, ".")
        Select Case (Mid(myData, Len(myData), 1))
            ' west is longitude
        Case "W"
                degree = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                Min = Val(Mid(myData, myFinger - 2, 2))
                Sec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                ' south is latitude
            Case "S"
                degree = -CDbl(Val(Mid(myData, 1, myFinger - 3)))
                min = Val(Mid(myData, myFinger - 2, 2))
                sec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                ' east is longitude
            Case "E"
                degree = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                min = Val(Mid(myData, myFinger - 2, 2))
                sec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                ' north is latitude
            Case "N"
                degree = CDbl(Val(Mid(myData, 1, myFinger - 3)))
                min = Val(Mid(myData, myFinger - 2, 2))
                sec = Val(Mid(myData, myFinger + 1, 2)) * 60 / 100
                'whatever...
            Case Else

        End Select
        If degree = 0 Then
            Return 0
        Else
            Return dms_to_double(degree, min, sec)
            GPSgood = True
        End If
    End Function


    Public Function dms_to_double(ByVal theDegree As Double, ByVal theMinute As Double, ByVal theSecond As Double)
        dms_to_double = (Math.Abs(theDegree) + CDbl(theMinute) / 60 + CDbl(theSecond) / 3600) * Math.Sign(theDegree + 0.000001)

    End Function

    Public Function LatLon_to_NorthingEasting(ByVal Lat As Double, ByVal Lon As Double, ByRef Northing As Double, ByRef Easting As Double)
        Northing = Lat / 180 * 40008 / 2
        Easting = Lon / 180 * 40008 / 2 * Math.Cos(Lat * Math.PI / 180)
    End Function

    Public Function Distance(ByVal Northing1 As Double, ByVal Northing2 As Double, ByVal Easting1 As Double, ByVal Easting2 As Double) As Double
        Return Math.Sqrt((Northing2 - Northing1) ^ 2 + (Easting2 - Easting1) ^ 2)
    End Function

End Class
