using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.DirectX.AudioVideoPlayback;

namespace VideoPlayer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem FileOpen;
		private System.Windows.Forms.MenuItem FilePlay;
		private System.Windows.Forms.Panel videoPanel;
		private Video video = null;
		private System.Windows.Forms.MenuItem menuItem2;
		private Timer videoTimer = new Timer();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			videoPanel.SizeChanged +=new EventHandler(videoPanel_SizeChanged);
			videoTimer.Tick += new EventHandler(videoTimer_Tick);
			videoTimer.Interval = 200;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.FileOpen = new System.Windows.Forms.MenuItem();
			this.FilePlay = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.videoPanel = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.FileOpen,
																					  this.FilePlay,
																					  this.menuItem2});
			this.menuItem1.Text = "File";
			// 
			// FileOpen
			// 
			this.FileOpen.Index = 0;
			this.FileOpen.Text = "Open";
			this.FileOpen.Click += new System.EventHandler(this.FileOpen_Click);
			// 
			// FilePlay
			// 
			this.FilePlay.Index = 1;
			this.FilePlay.Text = "Play";
			this.FilePlay.Click += new System.EventHandler(this.FilePlay_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 2;
			this.menuItem2.Text = "Stop";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// videoPanel
			// 
			this.videoPanel.Location = new System.Drawing.Point(10, 9);
			this.videoPanel.Name = "videoPanel";
			this.videoPanel.Size = new System.Drawing.Size(364, 314);
			this.videoPanel.TabIndex = 0;
			this.videoPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.videoPanel_Paint);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
			this.ClientSize = new System.Drawing.Size(384, 329);
			this.Controls.Add(this.videoPanel);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Form1";
			this.SizeChanged += new System.EventHandler(this.OnSize);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void FileOpen_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();

			if (dlg.ShowDialog() == DialogResult.OK)
			{
				if (video != null)
				{
					video.Stop();
					video.Dispose();
					video = null;
				}

				try
				{
					video = new Video(dlg.FileName);		
				}
				catch(Exception)
				{
					MessageBox.Show("Error opening video file");
				}
			}
		}

		private void FilePlay_Click(object sender, System.EventArgs e)
		{
			if (video == null) FileOpen_Click(sender, e);

			if (video != null)
			{
				video.Owner = videoPanel;
				video.Size = videoPanel.Size;
				video.Play();
				videoTimer.Start();
			}
		}

		private void video_Ending(object sender, EventArgs e)
		{

		}

		private void videoPanel_SizeChanged(object sender, EventArgs e)
		{
			videoPanel.Left = videoPanel.Top = 5;
			videoPanel.Width = this.Size.Width - 10;
			videoPanel.Height = this.Size.Height - 10;
		}

		private void videoTimer_Tick(object sender, EventArgs e)
		{
			if (video.CurrentPosition >= video.Duration)
				video.Play();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			if (video != null)
				video.Stop();
			
			videoTimer.Stop();
		}

		private void OnSize(object sender, System.EventArgs e)
		{
			videoPanel.Size = new Size(this.Width, this.Height);

			if (video != null)
				video.Size = videoPanel.Size;
		}

		private void videoPanel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}
	}
}
