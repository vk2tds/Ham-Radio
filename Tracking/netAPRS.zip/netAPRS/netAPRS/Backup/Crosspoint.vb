
Public Class Crosspoint

    Dim PortsList As System.Windows.Forms.ListBox
    Dim fpPortsCrosspoint As FarPoint.Win.Spread.FpSpread
    Dim fpdevGuiMaster As FarPoint.Win.Spread.FpSpread
    Dim fpdevGuiDisplay As FarPoint.Win.Spread.FpSpread
    '    Dim devOzi As devOzi
    Dim MasterForm As Object

    Dim StationInfo As New Hashtable


    Delegate Function DeviceDelegate(ByVal PortIn As Integer, ByVal Line As String, ByVal aprs As netAPRSlib.APRSdecoded)

    Public Enum devices
        devLOOPBACK = 0
        devTNC = 1
        devNETGPS = 2
        devTCPAPRS = 3
        devTCPAPRSSERV = 4
        devTCPXMLSERV = 5
        devLOCAL = 6
        devLOG = 7
        devFILTER = 8
        devDATABASE = 9
        devGPRS = 10
        devDEBUG = 11
        devMonitor = 12
        devGUI = 13
        devWWW = 14
        devAGWPE = 15
        devOzi = 16
        devRINO = 17
        devUIView = 18
        devRealTrack = 19
        devGPS = 20
    End Enum


    Public Function PortsTypeDescription(ByVal dev As devices) As String
        Select Case dev
            Case devices.devLOOPBACK
                Return "devLOOPBACK"
            Case devices.devTNC
                Return "devTNC"
            Case devices.devNETGPS
                Return "devNETGPS"
            Case devices.devTCPAPRS
                Return "devTCPAPRS"
            Case devices.devTCPAPRSSERV
                Return "devTCPAPRSSERV"
            Case devices.devLOCAL
                Return "devLOCAL"
            Case devices.devLOG
                Return "devLOG"
            Case devices.devFILTER
                Return "devFILTER"
            Case devices.devDATABASE
                Return "devDATABASE"
            Case devices.devGPRS
                Return "devGPRS"
            Case devices.devDEBUG
                Return "devDEBUG"
            Case devices.devMonitor
                Return "devMONITOR"
            Case devices.devGUI
                Return "devGUI"
            Case devices.devWWW
                Return "devWWW"
            Case devices.devAGWPE
                Return "devAWGPE"
            Case devices.devOzi
                Return "devOzi"
            Case devices.devRINO
                Return "devRINO"
            Case devices.devUIView
                Return "devUIView"
            Case devices.devRealTrack
                Return "devRealTrack"
            Case devices.devGPS
                Return "devGPS"
            Case Else
                Return "devUNKNOWN"
        End Select

    End Function


    Public Enum DevGuiMasterCols
        scOziExplorerID = 4
        scMonitor = 2
        scTrack = 3
        scCallsign = 1
        scSymbol = 5
        scLat = 6
        scLon = 7
        scAlt = 8
        scSpeed = 9
        scHeading = 10
        scStatus = 11
        scDescription = 12
        scUpdated = 13
        scUpdatedReal = 14
        scDataSource = 15
        scLine = 16
        scDetail = 17
        scColor = 18
        scMapPointID = 19
        scStale = 20
        scTrail = 21
        scTrailNumber = 22
        scGPRMC = 23
    End Enum

    Public Enum DevGuiCols
        Monitor = 0
        Detail = 1
        Callsign = 2
        Lat = 3
        Lon = 4
        Alt = 5
        spd = 6
        heading = 7
        time = 8
        track = 9
        trail = 10

    End Enum




    Public Function DevGuiMasterColsDescription(ByVal dev As DevGuiMasterCols) As String
        Select Case dev
            Case DevGuiMasterCols.scOziExplorerID
                Return "OziExplorer ID"
            Case DevGuiMasterCols.scMonitor
                Return "Monitor"
            Case DevGuiMasterCols.scTrack
                Return "Track"
            Case DevGuiMasterCols.scCallsign
                Return "Callsign"
            Case DevGuiMasterCols.scSymbol
                Return "Symbol"
            Case DevGuiMasterCols.scLat
                Return "Lat"
            Case DevGuiMasterCols.scLon
                Return "Lon"
            Case DevGuiMasterCols.scAlt
                Return "ALT"
            Case DevGuiMasterCols.scSpeed
                Return "Speed"
            Case DevGuiMasterCols.scHeading
                Return "Heading"
            Case DevGuiMasterCols.scStatus
                Return "Status"
            Case DevGuiMasterCols.scDescription
                Return "Description"
            Case DevGuiMasterCols.scUpdated
                Return "Updated"
            Case DevGuiMasterCols.scUpdatedReal
                Return "UpdatedReal"
            Case DevGuiMasterCols.scDataSource
                Return "DataSource"
            Case DevGuiMasterCols.scLine
                Return "Line"
            Case DevGuiMasterCols.scDetail
                Return "Detail"
            Case DevGuiMasterCols.scColor
                Return "Color"
            Case DevGuiMasterCols.scMapPointID
                Return "MapPointID"
            Case Else
                Return "UNKNOWN"
        End Select
    End Function

    Public Structure PortsCrosspointStruct
        Dim Enabled As Boolean
    End Structure

    Public Structure PortsStruct
        Dim objIN As Object
        Dim objOUT As DeviceDelegate
        Dim DevType As devices
        Dim Enabled As Boolean
    End Structure


    Const MaxDevices = 20
    Const MaxPorts = 20

    Dim PortsCrosspoint(MaxPorts, MaxPorts) As PortsCrosspointStruct
    Dim Ports(MaxPorts) As PortsStruct

    Public Function DeviceGUI(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)
        'Dim netAPRSlib As New netAPRSlib

        'netAPRSlib.aprs_decode(Line)
        DeviceGUI_FILL(aprsdecoded) 'netAPRSlib.APRSPacketdecoded)



    End Function



    Public Function DeviceGUI_FILL(ByVal dp As netAPRSlib.APRSdecoded)

        Dim OnRow, onOtherRow As Integer
        If dp.packetGood = False Then
            Return False
        End If

        With MasterForm.setup
            If .boolinterfacegeo = True Then
                If dp.packetLatDouble < .dblGeoFilterLat1 And dp.packetLatDouble > .dblGeoFilterLat2 And _
                dp.packetlonDouble > .dblGeoFilterLon1 And dp.packetlonDouble < .dblGeoFilterLon2 Then
                Else
                    Exit Function

                End If

            End If
        End With

        OnRow = fpdevGuiMaster_DoesCallExistRow(dp.packetSource)
        If OnRow = -1 Then
            OnRow = fpdevGuiMaster_FindEmptyRow()
            If OnRow = -1 Then Return -1
        Else
            If dp.packetLatDouble = 0 And dp.packetlonDouble = 0 Then
                Return -1
            End If
        End If

        With fpdevGuiMaster.ActiveSheet
            .Cells(OnRow, DevGuiMasterCols.scCallsign).Text = dp.packetSource
            .Cells(OnRow, DevGuiMasterCols.scSymbol).Text = dp.packetSymbol
            .Cells(OnRow, DevGuiMasterCols.scLat).Text = dp.packetLatDouble
            .Cells(OnRow, DevGuiMasterCols.scLon).Text = dp.packetlonDouble
            .Cells(OnRow, DevGuiMasterCols.scSymbol).Text = dp.packetSymbol
            .Cells(OnRow, DevGuiMasterCols.scAlt).Text = dp.packetAltitude
            .Cells(OnRow, DevGuiMasterCols.scSpeed).Text = dp.packetSpeed
            .Cells(OnRow, DevGuiMasterCols.scHeading).Text = dp.packetcourse
            '.col = spdColumns.scDescription
            '.Value = Description
            .Cells(OnRow, DevGuiMasterCols.scUpdated).Text = Format(Now)  ' Format(DateTime - (TimeZone / 1440) + (TimeZoneData.Bias / 1440), "General Date") & " Local"
            .Cells(OnRow, DevGuiMasterCols.scUpdatedReal).Text = Now
            '.col = spdColumns.scDataSource
            '.Value = Source
            .Cells(OnRow, DevGuiMasterCols.scLine).Text = dp.decodedline
            '.col = spdColumns.scColor
            '.Value = colo
            '.col = spdColumns.scOziExplorerID

            .Cells(OnRow, DevGuiMasterCols.scGPRMC).Text = dp.packetasGPRMC


            Dim SpeedColours As Boolean = False
            Dim InputLine As String = ""

            Dim weather As String = ""
            Dim MyCol As Integer = 0
            Dim MyTime As String = ""

            If SpeedColours = True Then
                MyCol = RGB(204, 204, 255)
            Else
                MyCol = RGB(255, 255, 0)
            End If

            InputLine = dp.decodedline

            If Len(dp.packetWindSpeed) > 0 Then
                weather = weather & "Wind Speed and Direction :: " & dp.packetWindSpeed & " Knots " & dp.packetWindDirection & " Deg" & vbCrLf
                If Len(dp.packetWindGust) > 0 Then
                    weather = weather & " Gust " & Format(dp.packetWindGust) & " Knots"
                End If
                MyCol = RGB(255, 128, 128)
            End If

            If Val(dp.packetTemperature) <> 0 Then
                weather = weather & " Temperature :: " & dp.packetTemperature & "F or " & Format(CInt(((Val(dp.packetTemperature)) - 32) * 5 / 8)) & "C" & vbCrLf
            End If

            MyTime = "Last Heard: " & Format(Now, "General date")


            If Len(InputLine) > 40 Then
                InputLine = Mid(InputLine, 1, Len(InputLine) / 2) & vbCrLf & "   " & Mid(InputLine, Len(InputLine) / 2 + 1)
            End If

            If dp.packetSpeed > 0 Or dp.packetcourse > 0 Or dp.packetAltitude > 0 Then
                InputLine = InputLine & vbCrLf & "Speed " & Format(dp.packetSpeed) & "Knots " & "(" & Format(Int(dp.packetSpeed * 1.852)) & "KM/H ), Course " & Format(dp.packetcourse, "##0") & " degrees, Altitude " & Format(dp.packetAltitude, "####0") & " feet"
                If SpeedColours = True Then
                    If dp.packetSpeed > 0 And dp.packetSpeed < 10 Then
                        MyCol = RGB(153, 153, 255)
                    ElseIf dp.packetSpeed >= 10 And dp.packetSpeed < 20 Then
                        MyCol = RGB(102, 102, 255)
                    ElseIf dp.packetSpeed >= 20 And dp.packetSpeed < 30 Then
                        MyCol = RGB(51, 51, 255)
                    ElseIf dp.packetSpeed >= 30 And dp.packetSpeed < 40 Then
                        MyCol = RGB(0, 0, 255)
                    ElseIf dp.packetSpeed >= 40 And dp.packetSpeed < 50 Then
                        MyCol = RGB(0, 0, 204)
                    ElseIf dp.packetSpeed >= 50 And dp.packetSpeed < 60 Then
                        MyCol = RGB(0, 0, 153)
                    ElseIf dp.packetSpeed >= 60 Then
                        MyCol = RGB(51, 51, 153)
                    End If
                Else
                    MyCol = RGB(128, 255, 128)
                End If
            End If

            .Cells(OnRow, DevGuiMasterCols.scColor).Text = MyCol
            .Cells(OnRow, DevGuiMasterCols.scDetail).Text = weather & InputLine & vbCrLf & MyTime & vbCrLf







        End With

        onOtherRow = fpdevGui_DoesCallExistRow(dp.packetSource)
        If onOtherRow = -1 Then
            onOtherRow = fpdevGui_FindEmptyRow()
            If onOtherRow = -1 Then Return -1
        End If

        With fpdevGuiDisplay.ActiveSheet
            .Cells(onOtherRow, DevGuiCols.Callsign).Text = dp.packetSource
            .Cells(onOtherRow, DevGuiCols.Lat).Text = dp.packetLatDouble
            .Cells(onOtherRow, DevGuiCols.Lon).Text = dp.packetlonDouble
            .Cells(onOtherRow, DevGuiCols.spd).Text = dp.packetSpeed
            .Cells(onOtherRow, DevGuiCols.heading).Text = dp.packetcourse
            .Cells(onOtherRow, DevGuiCols.Alt).Text = dp.packetAltitude
            .Cells(onOtherRow, DevGuiCols.time).Text = Now

            If .Cells(onOtherRow, DevGuiCols.track).Value = True Then
                MasterForm.devOzi.TrackInOzi(OnRow)
            End If
            If (.Cells(onOtherRow, DevGuiCols.trail).Value = True) Then
                MasterForm.devOzi.TrailInOzi(OnRow)
            Else
                If MasterForm.setup.boolInterfaceOziAutoTrailNow = True = True And _
                    dp.packetSpeed > 0 Then
                    .Cells(onOtherRow, DevGuiCols.trail).Value = True
                    MasterForm.devOzi.TrailInOzi(OnRow)
                End If
            End If
        End With

        If StationInfo.Contains(dp.packetSource) Then
            StationInfo(dp.packetSource).UpdateValues( _
                dp.packetSource, dp.packetcourse, dp.packetSpeed, _
                dp.packetAltitude, Mid(dp.decodedline, 1, 25), _
                Mid(dp.decodedline, 26), True, True)
        End If


        If MasterForm.setup.boolInterfaceMapPOintConnected Then
            MasterForm.devMapPoint.UploadToMapPoint(OnRow)
        End If

        If MasterForm.setup.boolInterfaceOziConnected = True Then
            MasterForm.devOzi.UploadToOzi(OnRow)
        End If


    End Function



    Function fpdevGuiMaster_DoesCallExistRow(ByVal Callsign As String) As Integer
        Dim i As Integer
        Dim myrow, mycol As Integer
        With fpdevGuiMaster.ActiveSheet
            fpdevGuiMaster.Search(0, Callsign, False, True, False, False, 0, DevGuiMasterCols.scCallsign, .RowCount - 1, DevGuiMasterCols.scCallsign, myrow, mycol)
            If mycol > -1 Then
                Return myrow
            End If
            'For i = 0 To .RowCount - 1
            '    If .Cells(i, DevGuiMasterCols.scCallsign).Text = Callsign Then
            '        Return i
            '    End If
            'Next i
        End With
        Return -1

    End Function

    Function fpdevGuiMaster_FindEmptyRow() As Integer
        Dim i As Integer
        With fpdevGuiMaster.ActiveSheet

            For i = 0 To .RowCount - 1
                If Len(.Cells(i, DevGuiMasterCols.scCallsign).Text) = 0 Then
                    Return i
                End If
            Next i
        End With
        Return -1

    End Function


    Function fpdevGui_DoesCallExistRow(ByVal Callsign As String) As Integer
        Dim i As Integer
        With fpdevGuiDisplay.ActiveSheet

            For i = 0 To .RowCount - 1
                If .Cells(i, DevGuiCols.Callsign).Text = Callsign Then
                    Return i
                End If
            Next i
        End With
        Return -1

    End Function

    Function fpdevGui_FindEmptyRow() As Integer
        Dim i As Integer
        With fpdevGuiDisplay.ActiveSheet

            For i = 0 To .RowCount - 1
                If Len(.Cells(i, DevGuiCols.Callsign).Text) = 0 Then
                    Return i
                End If
            Next i
        End With
        Return -1

    End Function


    Public Sub fpdevgui_ButtonClicked(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs)
        Dim i As Integer
        Dim Thecall As String
        Dim frm As frmStationInfo
        If e.Column = DevGuiCols.Detail Then

            Thecall = fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.Callsign).Value()
            If fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.Detail).Value = True Then
                'StationInfo
                frm = New frmStationInfo
                StationInfo.Add(Thecall, frm)
                frm.UpdateValues( _
                    fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.Callsign).Value(), _
                fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.heading).Value(), _
                fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.spd).Value(), _
                fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.Alt).Value(), _
                "", _
                "", _
                fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.track).Value(), _
                fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.trail).Value())

                frm.Show()
            Else
                Try
                    StationInfo(Thecall).close()
                Catch ex As Exception

                End Try
                StationInfo.Remove(Thecall)
            End If
        End If

        If e.Column = DevGuiCols.track Then
            If fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.track).Value = True Then
                devOzi.oziStartMMapi()
                '

            Else
                devOzi.oziStopMM()
            End If


            For i = 0 To fpdevGuiDisplay.ActiveSheet.RowCount - 1
                If i <> e.Row Then
                    fpdevGuiDisplay.ActiveSheet.Cells(i, DevGuiCols.track).Value = False
                End If
            Next
        End If

        If e.Column = DevGuiCols.trail Then
            If fpdevGuiDisplay.ActiveSheet.Cells(e.Row, DevGuiCols.trail).Value = True Then
                devOzi.oziClearTrack(e.Row)
                devOzi.oziShowTrack(e.Row)

            Else
                'devOzi.oziStopMM()
            End If

        End If


        'Crosspoint.devgui_ButtonClicked(sender, e)

        'Dim state As Boolean
        'state = FpPortsCrosspoint.ActiveSheet.Cells(e.Row, e.Column).Value
        'crosspoint.CrosspointEnable(e.Row, e.Column, state)


    End Sub


    Public Function DevGui_ClearOziWPs()
        MasterForm.devOzi.ClearWPs()
    End Function

    Public Function DevGui_UploadOziWPs()
        MasterForm.devOzi.UploadWPs()
    End Function
    Public Function DevGui_SyncOziWPs()
        MasterForm.devOzi.SyncWPs()
    End Function
    Public Function DevGui_DecayIcons()
        MasterForm.devOzi.DecayIcons()
    End Function



    Public Sub DevGui_Init()

        With fpdevGuiMaster.ActiveSheet
            .ColumnCount = 25
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scOziExplorerID).Label = "OziID"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scMonitor).Label = "Mon"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scTrack).Label = "Trk"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scCallsign).Label = "Callsign"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scSymbol).Label = "Symbol"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scLat).Label = "Lat"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scLon).Label = "Lon"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scAlt).Label = "Alt"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scSpeed).Label = "Spd"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scHeading).Label = "Hdg"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scStatus).Label = "Status"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scDescription).Label = "Desc"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scUpdated).Label = "Upd"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scUpdatedReal).Label = "UpdReal"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scDataSource).Label = "Src"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scLine).Label = "Line"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scDetail).Label = "Detail"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scColor).Label = "Colour"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scMapPointID).Label = "MapPointID"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scStale).Label = "Stale"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scTrail).Label = "Trail"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scTrailNumber).Label = "TrailNo"
            .ColumnHeader.Columns.Item(DevGuiMasterCols.scGPRMC).Label = "GPRMC"


        End With

        With fpdevGuiDisplay.ActiveSheet
            .ColumnCount = 11

            .ColumnHeader.Columns.Item(DevGuiCols.Monitor).Label = "Mon"
            .Columns(DevGuiCols.Monitor).CellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
            .Columns(DevGuiCols.Monitor).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

            .ColumnHeader.Columns.Item(DevGuiCols.Detail).Label = "Detail"
            .Columns(DevGuiCols.Detail).CellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
            .Columns(DevGuiCols.Detail).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

            .ColumnHeader.Columns.Item(DevGuiCols.Callsign).Label = "Callsign"
            .ColumnHeader.Columns.Item(DevGuiCols.Lat).Label = "Lat"
            .ColumnHeader.Columns.Item(DevGuiCols.Lon).Label = "Lon"
            .ColumnHeader.Columns.Item(DevGuiCols.spd).Label = "Speed"
            .ColumnHeader.Columns.Item(DevGuiCols.heading).Label = "Hdg"
            .ColumnHeader.Columns.Item(DevGuiCols.Alt).Label = "Alt"
            .ColumnHeader.Columns.Item(DevGuiCols.time).Label = "Time"

            .ColumnHeader.Columns.Item(DevGuiCols.track).Label = "Track"
            .Columns(DevGuiCols.track).CellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
            .Columns(DevGuiCols.track).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

            .ColumnHeader.Columns.Item(DevGuiCols.trail).Label = "Trail"
            .Columns(DevGuiCols.trail).CellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
            .Columns(DevGuiCols.trail).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

        End With



    End Sub





    Public Function DeviceDebug(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)
        Debug.WriteLine("Crosspoint::DeviceDebug:: PortIn " & Format(PortIn) & " : Line " & Line)
    End Function

    Public Sub CrosspointEnable(ByVal Portin As Integer, ByVal PortOut As Integer, ByVal State As Boolean)
        Dim i As Integer
        If Portin = -1 Then
            For i = 0 To MaxPorts - 1
                PortsCrosspoint(i, PortOut).Enabled = State
                fpPortsCrosspoint.ActiveSheet.Cells(i, PortOut).Value = State
            Next
            Return
        End If
        If PortOut = -1 Then
            For i = 0 To MaxPorts - 1
                PortsCrosspoint(Portin, i).Enabled = State
                fpPortsCrosspoint.ActiveSheet.Cells(Portin, i).Value = State
            Next i
            Return
        End If
        PortsCrosspoint(Portin, PortOut).Enabled = State
        fpPortsCrosspoint.ActiveSheet.Cells(Portin, PortOut).Value = State
    End Sub


    Public Sub Submit(ByVal PortIn As Integer, ByVal line As String)

        If Ports(PortIn).Enabled = False Then
            Exit Sub
        End If

        Dim APRSlib As New netAPRSlib

        APRSlib.aprs_decode(line)

        Dim i As Integer

        For i = 0 To MaxPorts - 1
            If PortsCrosspoint(PortIn, i).Enabled Then
                If Not Ports(i).objOUT Is Nothing Then
                    Ports(i).objOUT(PortIn, line, APRSlib.APRSPacketdecoded)
                End If
            End If
        Next

    End Sub

    Public Function nullfunction(ByVal PortIn As Integer, ByVal Line As String, ByVal aprs As netAPRSlib.APRSdecoded)
        ' Null Function - Ignore everything. 
    End Function


    Public Function NewPort(ByVal device As devices, ByVal objOut As DeviceDelegate) As Integer
        Dim i As Integer

        For i = 0 To MaxPorts - 1
            With Ports(i)
                If .Enabled = False Then GoTo Part2
            End With
        Next
        Return -1
Part2:
        With Ports(i)
            .objOUT = objOut
            .DevType = device
            .Enabled = True
            PortsList.Items.Add("::Port " & Format(i) & "::" & PortsTypeDescription(device))
            Return i
        End With
    End Function

    Public Function closePort(ByVal Port As Integer)

        Ports(Port).Enabled = False
        CrosspointEnable(-1, Port, False)
        'TODO: Also remove from list
Part2:
        Return 0
        'With Ports()
        '    .objOUT = objOut
        '    .DevType = device
        '    .Enabled = True
        '    PortsList.Items.Add("::Port " & Format(i) & "::" & PortsTypeDescription(device))
        '    Return i
        'End With
    End Function



    Public Sub New(ByVal myPortsList As System.Windows.Forms.ListBox, ByVal myfpPortsCrosspoint As FarPoint.Win.Spread.FpSpread, ByVal myfpDevGuiMaster As FarPoint.Win.Spread.FpSpread, ByVal myFpDevGuiDisplay As FarPoint.Win.Spread.FpSpread, ByVal myMaster As Windows.Forms.Form)

        MasterForm = myMaster
        PortsList = myPortsList
        fpPortsCrosspoint = myfpPortsCrosspoint
        fpdevGuiMaster = myfpDevGuiMaster
        fpdevGuiDisplay = myFpDevGuiDisplay

        Dim i As Integer
        Dim j As Integer

        For i = 0 To MaxPorts - 1
            Ports(i).Enabled = False
            Ports(i).objIN = Nothing
            Ports(i).objOUT = Nothing
            fpPortsCrosspoint.Sheets(0).Columns(i).Label = Format(i)
            fpPortsCrosspoint.Sheets(0).Rows(i).Label = Format(i)
        Next

        For i = 0 To MaxPorts - 1
            For j = 0 To MaxPorts - 1
                PortsCrosspoint(i, j).Enabled = False
            Next
        Next

    End Sub



End Class
