Public Class devGPS

    Dim MasterMenu As frmmain
    Dim kiss As kiss
    Dim setup As frmSetup.SetupStructure


    Public Function devRINO_SendOut(ByVal PortIn As Integer, ByVal Line As String, ByVal aprsdecoded As netAPRSlib.APRSdecoded)


    End Function

    Public Function process()

        'Dim i As Integer
        'Dim templine As String

        'With MasterMenu.axewaypoint1
        '    .Mode = 0
        '    .Go()
        '    For i = 0 To .WaypointCount - 1
        '        .WaypointIndex = i
        '        templine = .WayName & ">APRS:!" & MasterMenu.double_to_dms(.WayLatitude, 1) & "/" & MasterMenu.double_to_dms(.WayLongitude, 0) & "-"
        '        MasterMenu.crosspoint.Submit(MasterMenu.portRINO, templine)
        '    Next i
        'End With








    End Function


    Public Sub New(ByVal myMasterMenu As frmmain, ByVal mysetup As frmSetup.SetupStructure)

        MasterMenu = myMasterMenu
        setup = mysetup

    End Sub




End Class
