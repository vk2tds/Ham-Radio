Imports System.Xml

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private crc32Table() As Long
    Dim CommTNC As SerialNET.Port


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lbliGPRSCom As System.Windows.Forms.Label
    Friend WithEvents cboIGPRSport As System.Windows.Forms.ComboBox
    Friend WithEvents lblrate As System.Windows.Forms.Label
    Friend WithEvents lblAPN As System.Windows.Forms.Label
    Friend WithEvents lblIPPort As System.Windows.Forms.Label
    Friend WithEvents lblIPaddress As System.Windows.Forms.Label
    Friend WithEvents lblServer2 As System.Windows.Forms.Label
    Friend WithEvents lblServer1 As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Delay As System.Windows.Forms.TextBox
    Friend WithEvents APN As System.Windows.Forms.TextBox
    Friend WithEvents Port_2 As System.Windows.Forms.TextBox
    Friend WithEvents IP_2 As System.Windows.Forms.TextBox
    Friend WithEvents Port_1 As System.Windows.Forms.TextBox
    Friend WithEvents IP_1 As System.Windows.Forms.TextBox
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents btnConfig As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Config As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Button14 = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Button13 = New System.Windows.Forms.Button
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.Button12 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lbliGPRSCom = New System.Windows.Forms.Label
        Me.cboIGPRSport = New System.Windows.Forms.ComboBox
        Me.lblrate = New System.Windows.Forms.Label
        Me.lblAPN = New System.Windows.Forms.Label
        Me.lblIPPort = New System.Windows.Forms.Label
        Me.lblIPaddress = New System.Windows.Forms.Label
        Me.lblServer2 = New System.Windows.Forms.Label
        Me.lblServer1 = New System.Windows.Forms.Label
        Me.btnReset = New System.Windows.Forms.Button
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Delay = New System.Windows.Forms.TextBox
        Me.APN = New System.Windows.Forms.TextBox
        Me.Port_2 = New System.Windows.Forms.TextBox
        Me.IP_2 = New System.Windows.Forms.TextBox
        Me.Port_1 = New System.Windows.Forms.TextBox
        Me.IP_1 = New System.Windows.Forms.TextBox
        Me.Button10 = New System.Windows.Forms.Button
        Me.btnConfig = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Config = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(272, 208)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(72, 24)
        Me.Button14.TabIndex = 66
        Me.Button14.Text = "NewConfig"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button13)
        Me.GroupBox3.Controls.Add(Me.Button11)
        Me.GroupBox3.Controls.Add(Me.Button9)
        Me.GroupBox3.Controls.Add(Me.Button8)
        Me.GroupBox3.Controls.Add(Me.TreeView1)
        Me.GroupBox3.Location = New System.Drawing.Point(720, 56)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(248, 312)
        Me.GroupBox3.TabIndex = 65
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Configuration Management"
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(20, 280)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(40, 24)
        Me.Button13.TabIndex = 47
        Me.Button13.Text = "Del"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(104, 280)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(32, 24)
        Me.Button11.TabIndex = 46
        Me.Button11.Text = "W"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(200, 280)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(32, 24)
        Me.Button9.TabIndex = 45
        Me.Button9.Text = "+++"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(68, 280)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(32, 24)
        Me.Button8.TabIndex = 44
        Me.Button8.Text = "R"
        '
        'TreeView1
        '
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(8, 16)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(232, 256)
        Me.TreeView1.TabIndex = 43
        '
        'Button12
        '
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.Location = New System.Drawing.Point(584, 208)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(48, 24)
        Me.Button12.TabIndex = 64
        Me.Button12.Text = "<--"
        '
        'Button7
        '
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(584, 168)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(48, 24)
        Me.Button7.TabIndex = 63
        Me.Button7.Text = "-->"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(48, 152)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 177)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 62
        Me.PictureBox1.TabStop = False
        '
        'lbliGPRSCom
        '
        Me.lbliGPRSCom.Location = New System.Drawing.Point(424, 336)
        Me.lbliGPRSCom.Name = "lbliGPRSCom"
        Me.lbliGPRSCom.Size = New System.Drawing.Size(64, 23)
        Me.lbliGPRSCom.TabIndex = 61
        Me.lbliGPRSCom.Text = "Com Port"
        '
        'cboIGPRSport
        '
        Me.cboIGPRSport.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cboIGPRSport.Location = New System.Drawing.Point(488, 336)
        Me.cboIGPRSport.Name = "cboIGPRSport"
        Me.cboIGPRSport.Size = New System.Drawing.Size(48, 24)
        Me.cboIGPRSport.TabIndex = 60
        Me.cboIGPRSport.Text = "1"
        '
        'lblrate
        '
        Me.lblrate.Location = New System.Drawing.Point(288, 120)
        Me.lblrate.Name = "lblrate"
        Me.lblrate.Size = New System.Drawing.Size(40, 23)
        Me.lblrate.TabIndex = 59
        Me.lblrate.Text = "Rate"
        '
        'lblAPN
        '
        Me.lblAPN.Location = New System.Drawing.Point(288, 88)
        Me.lblAPN.Name = "lblAPN"
        Me.lblAPN.Size = New System.Drawing.Size(40, 23)
        Me.lblAPN.TabIndex = 58
        Me.lblAPN.Text = "APN"
        '
        'lblIPPort
        '
        Me.lblIPPort.Location = New System.Drawing.Point(232, 64)
        Me.lblIPPort.Name = "lblIPPort"
        Me.lblIPPort.Size = New System.Drawing.Size(56, 23)
        Me.lblIPPort.TabIndex = 57
        Me.lblIPPort.Text = "Port"
        Me.lblIPPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIPaddress
        '
        Me.lblIPaddress.Location = New System.Drawing.Point(120, 64)
        Me.lblIPaddress.Name = "lblIPaddress"
        Me.lblIPaddress.TabIndex = 56
        Me.lblIPaddress.Text = "IP Address"
        Me.lblIPaddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblServer2
        '
        Me.lblServer2.Location = New System.Drawing.Point(48, 120)
        Me.lblServer2.Name = "lblServer2"
        Me.lblServer2.Size = New System.Drawing.Size(64, 23)
        Me.lblServer2.TabIndex = 55
        Me.lblServer2.Text = "Server #2"
        '
        'lblServer1
        '
        Me.lblServer1.Location = New System.Drawing.Point(48, 88)
        Me.lblServer1.Name = "lblServer1"
        Me.lblServer1.Size = New System.Drawing.Size(64, 23)
        Me.lblServer1.TabIndex = 54
        Me.lblServer1.Text = "Server #1"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(360, 168)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(64, 24)
        Me.btnReset.TabIndex = 53
        Me.btnReset.Text = "RESET"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(48, 336)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(304, 22)
        Me.TextBox4.TabIndex = 52
        Me.TextBox4.Text = "$GPRMC,092204,A,4250.5589,S,14718.5084,E,0.00,89.68,211200,,"
        '
        'Delay
        '
        Me.Delay.Location = New System.Drawing.Point(336, 120)
        Me.Delay.Name = "Delay"
        Me.Delay.Size = New System.Drawing.Size(64, 22)
        Me.Delay.TabIndex = 50
        Me.Delay.Text = "TextBox1"
        '
        'APN
        '
        Me.APN.Location = New System.Drawing.Point(336, 88)
        Me.APN.Name = "APN"
        Me.APN.Size = New System.Drawing.Size(208, 22)
        Me.APN.TabIndex = 49
        Me.APN.Text = "TextBox1"
        '
        'Port_2
        '
        Me.Port_2.Location = New System.Drawing.Point(232, 120)
        Me.Port_2.Name = "Port_2"
        Me.Port_2.Size = New System.Drawing.Size(48, 22)
        Me.Port_2.TabIndex = 47
        Me.Port_2.Text = "TextBox1"
        '
        'IP_2
        '
        Me.IP_2.Location = New System.Drawing.Point(120, 120)
        Me.IP_2.Name = "IP_2"
        Me.IP_2.Size = New System.Drawing.Size(104, 22)
        Me.IP_2.TabIndex = 46
        Me.IP_2.Text = "TextBox1"
        '
        'Port_1
        '
        Me.Port_1.Location = New System.Drawing.Point(232, 88)
        Me.Port_1.Name = "Port_1"
        Me.Port_1.Size = New System.Drawing.Size(48, 22)
        Me.Port_1.TabIndex = 45
        Me.Port_1.Text = "TextBox1"
        '
        'IP_1
        '
        Me.IP_1.Location = New System.Drawing.Point(120, 88)
        Me.IP_1.Name = "IP_1"
        Me.IP_1.Size = New System.Drawing.Size(104, 22)
        Me.IP_1.TabIndex = 44
        Me.IP_1.Text = "TextBox1"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(360, 336)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(48, 24)
        Me.Button10.TabIndex = 51
        Me.Button10.Text = "GPS"
        '
        'btnConfig
        '
        Me.btnConfig.Location = New System.Drawing.Point(272, 168)
        Me.btnConfig.Name = "btnConfig"
        Me.btnConfig.TabIndex = 48
        Me.btnConfig.Text = "Config"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(48, 392)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(672, 22)
        Me.TextBox1.TabIndex = 67
        Me.TextBox1.Text = "TextBox1"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(424, 120)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 23)
        Me.Label1.TabIndex = 68
        Me.Label1.Text = "State"
        '
        'Config
        '
        Me.Config.Location = New System.Drawing.Point(472, 120)
        Me.Config.Name = "Config"
        Me.Config.Size = New System.Drawing.Size(72, 22)
        Me.Config.TabIndex = 69
        Me.Config.Text = "TextBox2"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(376, 200)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 32)
        Me.Button1.TabIndex = 70
        Me.Button1.Text = "Mailcall"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(1032, 456)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Config)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lbliGPRSCom)
        Me.Controls.Add(Me.cboIGPRSport)
        Me.Controls.Add(Me.lblrate)
        Me.Controls.Add(Me.lblAPN)
        Me.Controls.Add(Me.lblIPPort)
        Me.Controls.Add(Me.lblIPaddress)
        Me.Controls.Add(Me.lblServer2)
        Me.Controls.Add(Me.lblServer1)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Delay)
        Me.Controls.Add(Me.APN)
        Me.Controls.Add(Me.Port_2)
        Me.Controls.Add(Me.IP_2)
        Me.Controls.Add(Me.Port_1)
        Me.Controls.Add(Me.IP_1)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.btnConfig)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim c As Integer

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        C = Val(config.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = "#S," & Format(i1, "0000000000") & "," _
            & Format(p1, "00000") & "," & _
            Format(i2, "0000000000") & "," & _
            Format(p2, "00000") & "," & _
            myapn.PadRight(40) & "," & _
            Format(mydelay, "0000") & "," & _
            Format(mydelay, "0000") & "," & _
            Format(c, "000") & ","

        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 92))), "00000") & ","



        sendit(temp & vbCrLf)

        TextBox1.Text = temp

    End Sub

    Private Sub btnconfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfig.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = ":::" & Format(i1, "0000000000") & ":" & Format(p1, "00000") & ":" & _
            Format(i2, "0000000000") & ":" & Format(p2, "00000") & ":" & _
            myapn.PadRight(40) & ":" & Format(mydelay, "0000") & ":"
        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 63))), "00000") & ":"



        sendit(temp & vbCrLf)

        '        MsgBox(temp)

    End Sub

    Private Sub sendit(ByVal it As String)
        CommTNC = New SerialNET.Port
        Dim lic = New SerialNET.License
        lic.licenseKey = "ThHGhbBKUCaAOuo3HMLdqsPQK0ZC3OXOTiLF"

        With CommTNC
            .Enabled = False
            .ComPort = cboIGPRSport.Text
            .StopBits = SerialNET.StopBits.One
            .BaudRate = 4800
            .Parity = SerialNET.Parity.No
            .ByteSize = 8
            .Handshake = SerialNET.Handshake.None
            .DTR = True
            .RTS = True
            .Enabled = True

            .Write(it)

            .Enabled = False
        End With
    End Sub

    Private Function iptoi(ByVal ips As String) As Long
        Dim i As Long
        Dim ipsa(4) As String

        ipsa = ips.Split(".")

        i = ipsa(0) * 256 * 256 * 256 + ipsa(1) * 256 * 256 + ipsa(2) * 256 + ipsa(3)

        Return i

    End Function

    Private Function GetAuth(ByVal buffer As String) As Long
        Dim crc32 As Long
        Class_init()

        Dim crc32Result As Long
        crc32Result = &HFFFFFFFF

        Dim i As Integer
        Dim iLookup As Integer

        Dim mybyte As Integer

        For i = 1 To Len(buffer)
            mybyte = Asc(Mid(buffer, i, 1))
            iLookup = (crc32Result And &HFF) Xor mybyte
            crc32Result = ((crc32Result And &HFFFFFF00) \ &H100) _
                And 16777215 ' nasty shr 8 with vb :/
            crc32Result = crc32Result Xor crc32Table(iLookup)
        Next i
        crc32 = Not (crc32Result)
        crc32 = crc32 And &HFFFF
        GetAuth = crc32
    End Function
    Private Function verify()

    End Function



    Private Sub Class_init()

        ' This is the official polynomial used by CRC32 in PKZip.
        ' Often the polynomial is shown reversed (04C11DB7).
        Dim dwPolynomial As Long
        dwPolynomial = &HEDB88320
        Dim i As Integer, J As Integer

        ReDim crc32Table(256)
        Dim dwCrc As Long

        For i = 0 To 255
            dwCrc = i
            For J = 8 To 1 Step -1
                If (dwCrc And 1) Then
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                    dwCrc = dwCrc Xor dwPolynomial
                Else
                    dwCrc = ((dwCrc And &HFFFFFFFE) \ 2&) And &H7FFFFFFF
                End If
            Next J
            crc32Table(i) = dwCrc
        Next i
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click

        sendit(TextBox4.Text & vbCrLf)
    End Sub

    'Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    AxmsCommTNC.PortOpen = True

    'End Sub

    'Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    AxmsCommTNC.PortOpen = False
    'End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click

        sendit(":::RESTART:::" & vbCrLf)

    End Sub


    Private Sub Label30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        With TreeView1
            If Not .SelectedNode Is Nothing Then
                TreeView1.SelectedNode = .SelectedNode.Nodes.Add("New Sub")
            Else
                .Nodes.Add("New Item")
            End If
        End With
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TreeView1.LabelEdit = True
        TreeView1.SelectedNode = TreeView1.Nodes.Add("Root")
    End Sub

    Private Sub LoadTreeViewFromXmlFile(ByVal file_name As _
        String, ByVal trv As TreeView)
        ' Load the XML document.
        Dim xml_doc As New XmlDocument
        xml_doc.Load(file_name)

        ' Add the root node's children to the TreeView.
        trv.Nodes.Clear()
        AddTreeViewChildNodes(trv.Nodes, _
            xml_doc.DocumentElement)
    End Sub
    ' Add the children of this XML node 
    ' to this child nodes collection.
    Private Sub AddTreeViewChildNodes(ByVal parent_nodes As _
        TreeNodeCollection, ByVal xml_node As XmlNode)
        For Each child_node As XmlNode In xml_node.ChildNodes
            ' Make the new TreeView node.
            Dim new_node As TreeNode = _
                                parent_nodes.Add(child_node.Attributes.Item(0).Value)
            new_node.Tag = child_node.Attributes.Item(1).Value
            AddTreeViewChildNodes(new_node.Nodes, child_node)
            If new_node.Nodes.Count = 0 Then _
                new_node.EnsureVisible()


            ' If this is a leaf node, make sure it's visible.
        Next child_node
    End Sub


    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        LoadTreeViewFromXmlFile("c:\testing.xml", TreeView1)

    End Sub

    Private Function iterate(ByVal tw As XmlTextWriter, ByVal tv As TreeNodeCollection)

        Dim tvn As TreeNode
        For Each tvn In tv
            With tvn
                tw.WriteStartElement("Glob")
                tw.WriteAttributeString("Blob", .Text)
                tw.WriteAttributeString("Tag", .Tag)

                If Not .Nodes Is Nothing Then
                    iterate(tw, .Nodes)
                Else
                End If

                tw.WriteEndElement()

            End With
        Next



    End Function



    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Dim xmlTW As XmlTextWriter = Nothing

        Dim junk As XmlTextWriter

        junk = New XmlTextWriter("c:\testing.xml", Nothing)


        With junk


            .WriteStartDocument(False)
            .WriteStartElement("iGPRS")
            iterate(junk, TreeView1.Nodes)


            .WriteEndElement()
            .Close()

        End With

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        TreeView1.SelectedNode.Tag = ":" & IP_1.Text & ":" & Port_1.Text & ":" & IP_2.Text & ":" & Port_2.Text & ":" & _
            APN.Text & ":" & Delay.Text & ":" & cboIGPRSport.Text & ":"

    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs)
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim temp As String
        Dim myarray() As String
        temp = TreeView1.SelectedNode.Tag
        If Len(temp) > 0 Then
            myarray = temp.Split(":")
            IP_1.Text = myarray(1)
            Port_1.Text = myarray(2)
            IP_2.Text = myarray(3)
            Port_2.Text = myarray(4)
            APN.Text = myarray(5)
            Delay.Text = myarray(6)
            cboIGPRSport.Text = myarray(7)
        End If

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click

        Dim n As TreeNode
        For Each n In TreeView1.SelectedNode.Nodes
            n.Remove()
            If TreeView1.SelectedNode.Parent Is Nothing Then
                TreeView1.Nodes.Add(n)
            Else
                TreeView1.SelectedNode.Parent.Nodes.Add(n)
            End If
        Next
        TreeView1.SelectedNode.Remove()
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i1 As Long
        Dim i2 As Long

        Dim c As Integer

        Dim p1 As Integer
        Dim p2 As Integer

        Dim myapn As String
        Dim mydelay As Integer

        Dim temp As String

        i1 = iptoi(IP_1.Text)
        i2 = iptoi(IP_2.Text)

        p1 = Val(Port_1.Text)
        p2 = Val(Port_2.Text)
        c = Val(Config.Text)
        myapn = APN.Text
        mydelay = Delay.Text

        temp = "#S," & Format(i1, "0000000000") & "," _
            & Format(p1, "00000") & "," & _
            Format(i2, "0000000000") & "," & _
            Format(p2, "00000") & "," & _
            myapn.PadRight(40) & "," & _
            Format(mydelay, "0000") & "," & _
            Format(mydelay, "0000") & "," & _
            Format(c, "0") & ","

        temp = temp & Format(CLng(GetAuth(Mid(temp, 1, 90))), "00000") & ","



        sendit(temp & vbCrLf)

        TextBox1.Text = temp


    End Sub
End Class
