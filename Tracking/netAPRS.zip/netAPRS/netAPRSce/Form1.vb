
Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtDetails As System.Windows.Forms.TextBox
    Friend WithEvents StatusBar As System.Windows.Forms.TextBox
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.Button1 = New System.Windows.Forms.Button
        Me.ListView1 = New System.Windows.Forms.ListView
        Me.txtDetails = New System.Windows.Forms.TextBox
        Me.StatusBar = New System.Windows.Forms.TextBox
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(176, 224)
        Me.Button1.Size = New System.Drawing.Size(48, 32)
        Me.Button1.Text = "Button1"
        '
        'ListView1
        '
        Me.ListView1.Location = New System.Drawing.Point(8, 8)
        Me.ListView1.Size = New System.Drawing.Size(216, 192)
        '
        'txtDetails
        '
        Me.txtDetails.Location = New System.Drawing.Point(8, 200)
        Me.txtDetails.Size = New System.Drawing.Size(136, 22)
        Me.txtDetails.Text = "txt"
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(8, 232)
        Me.StatusBar.Size = New System.Drawing.Size(144, 22)
        Me.StatusBar.Text = "TextBox1"
        '
        'Form1
        '
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.txtDetails)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    '    Dim Connect As New ClientSocket
    Dim WithEvents connect As New ClientSocket


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        _processCommand = New EventHandler(AddressOf ProcessSocketCommand)

    End Sub
    Dim _notifycommand As NotifyCommand
    Dim _notifyData As Object
    Private _processCommand As EventHandler

    Private Sub Incoming(ByVal command As NotifyCommand, ByVal data As Object) Handles connect.Notify
        Try
            ' The .Net Compact Framework does not support Control.Invoke
            ' that allows you to pass arguments to the delegate. So save
            ' arguments to class fields and then invoke the delegate.
            SyncLock Me
                ' save arguments to class fields				
                _notifyCommand = command
                _notifyData = data

                ' execute the method on the GUI's thread, this method
                ' uses the _notifyCommand and _notifyData fields
                Invoke(_processCommand)
            End SyncLock
        Catch
        End Try

    End Sub
    ' process socket notification, executes on GUI's thread
    Private Sub ProcessSocketCommand(ByVal sender As Object, ByVal args As EventArgs)
        Dim status As String = ""
        Select Case _notifycommand
            Case NotifyCommand.Connected
                If CBool(_notifyData) = True Then
                    status = "Connected to server"
                    connect.Receive()
                Else
                    status = "Offline"
                End If

            Case NotifyCommand.SentData
                status = "Sent signature"
                'connect.Receive()

            Case NotifyCommand.ReceivedData
                Dim str As String
                str = connect.ReadBuffer

                txtDetails.Text = str

                connect.Receive()

                'If CBool(_notifyData) = True Then
                'status = "Server received signature"
                'Else
                'status = "Server did not receive signature"
                'End If

            Case NotifyCommand.SocketError
                txtDetails.Text = "Socket error" + ControlChars.Cr + ControlChars.Lf + CStr(_notifyData)
                DisconnectFromServer()

        End Select

        ' enable action buttons
        '        UpdateButtons()

        ' update the status bar
        StatusBar.Text = status
    End Sub

    Private Sub DisconnectFromServer()
        statusBar.Text = "Offline"
        connect.Disconnect()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        connect.Connect("203.17.15.167", 10153)

    End Sub
End Class
