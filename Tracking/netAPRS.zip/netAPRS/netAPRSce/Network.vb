'	SignatureData class
'	--
'	Stores the signature information. The width and height specify the size of
'	the signature canvas. The lines property stores a list of line segments. 
'	Each line segment contains an array of points (x and y coordinates).
'
'	The class can flatten itself into a stream of bytes and unflatten, or
'	reconstruct itself, from a stream of bytes. These are used when it needs
'	to be sent over a TCP socket.
'
'
'	Network class
'	--
'	Contains helper methods that read / write data to byte streams and help
'	with the TCP socket message terminator.

Imports System.IO
Imports System.Text
Imports System.Runtime.InteropServices

' Class that contains the signature data. The class knows how 
' to flatten itself to a stream of bytes and reconstruct 
' itself from a stream of bytes.
Public Class SignatureData
	' this identifies this class, used when sent over socket
	' so receiving application can validate the data stream
	Public Const SignatureId As String = "signature"

	Private _width As Integer  ' width of signature canvas
	Private _height As Integer ' height of signature canvas
	Private _lines As ArrayList ' list of line segments

	'
	' Properties
	'

	Public ReadOnly Property Lines() As ArrayList
		Get
			Return _lines
		End Get
	End Property

	Public ReadOnly Property Width() As Integer
		Get
			Return _width
		End Get
	End Property

	Public ReadOnly Property Height() As Integer
		Get
			Return _height
		End Get
	End Property

	' construct an object from stream of bytes
	Public Sub New(ByVal bits() As Byte)
		' index into data stream
		Dim bitsIndex As Integer = 0

		' get signature id
		If Not IsValidStream(bits, bitsIndex) Then
			' this is not what we are expecting
			Throw New Exception("Invalid data stream.")
		End If

		' width and height
		_width = Network.GetInt32(bits, bitsIndex)
		_height = Network.GetInt32(bits, bitsIndex)

		' number of line segments
		Dim linesCount As Int32 = Network.GetInt32(bits, bitsIndex)
		_lines = New ArrayList(linesCount)

		' loop through each line segment and get points
		Dim line As Integer
		For line = 0 To linesCount - 1
			' number of points in this segment
			Dim pointsCount As Int32 = Network.GetInt32(bits, bitsIndex)
			Dim points(pointsCount - 1) As Point

			' get all points in this segment
			Dim point As Integer
			For point = 0 To pointsCount - 1
				points(point).X = Network.GetInt32(bits, bitsIndex)
				points(point).Y = Network.GetInt32(bits, bitsIndex)
			Next point

			' add line segment to list
			_lines.Add(points)
		Next line
	End Sub


	' Flatten object to a stream of bytes.
	Public Shared Function GetBytes(ByVal width As Integer, ByVal height As Integer, ByVal lines As ArrayList) As Byte()
		' hold byte stream
		Dim stream As New MemoryStream

		' signature id
		Network.WriteString(stream, SignatureData.SignatureId)

		' width and height
		Network.WriteInt32(stream, width)
		Network.WriteInt32(stream, height)

		' number of segments
		Network.WriteInt32(stream, lines.Count)

		' each segment
		Dim points As Point()
		For Each points In lines
			' points in the segment
			Network.WriteInt32(stream, points.Length)
			Dim pt As Point
			For Each pt In points
				Network.WriteInt32(stream, pt.X)
				Network.WriteInt32(stream, pt.Y)
			Next pt
		Next points

		Return stream.ToArray()
	End Function


	' Return true if byte array is a valid SignatureData class,
	' otherwise return false.
	Private Function IsValidStream(ByVal bits() As Byte, ByRef bitsIndex As Integer) As Boolean
		Dim valid As Boolean = False

		' see if first value is length of signature id
		Dim idLength As Int32 = Network.GetInt32(bits, bitsIndex)
		If idLength = SignatureData.SignatureId.Length Then
			' get the signature id mark
			Dim id As Byte() = Network.GetBytes(bits, bitsIndex, idLength)

			' see if this is the stream we expect
			If ASCIIEncoding.ASCII.GetString(id, 0, idLength) = SignatureData.SignatureId Then
				valid = True
			End If
		End If

		Return valid
	End Function

End Class



' Network helper functions.
Public Class Network
	' socket message terminator 
	Public Shared ReadOnly Property Terminator() As String
		Get
			Return "<data_end>"
		End Get
	End Property

	' socket message terminator as bytes 
	Public Shared ReadOnly Property TerminatorBytes() As Byte()
		Get
			Return ASCIIEncoding.ASCII.GetBytes(Terminator)
		End Get
	End Property

	  ' all static methods
	  Private Sub New()
	  End Sub

	' Return true if the terminator is located at the
	' end of the byte array, otherwise return false.
	Public Shared Function CheckForTerminator(ByVal data() As Byte) As Boolean
		' return right away if not even long enough to contain terminator
		If data Is Nothing Or data.Length < Terminator.Length Then
			Return False
		End If

		' see if message terminator is at end of stream
		Dim endBuf As String = Encoding.ASCII.GetString(data, CInt(data.Length - Terminator.Length), CInt(Terminator.Length))
		Return Network.Terminator.Equals(endBuf)
	End Function

	' Write int bytes to byte stream.
	Public Shared Sub WriteInt32(ByVal stream As MemoryStream, ByVal data As Int32)
		stream.Write(BitConverter.GetBytes(data), 0, Marshal.SizeOf(data))
	End Sub

	' Write string to byte stream. First write length, followed
	' by string content.
	Public Shared Sub WriteString(ByVal stream As MemoryStream, ByVal data As String)
		' write length of string followed by the string bytes
		WriteInt32(stream, data.Length)
		stream.Write(ASCIIEncoding.ASCII.GetBytes(data), 0, data.Length)
	End Sub

	' Return int from byte stream.
	Public Shared Function GetInt32(ByVal bits() As Byte, ByRef bitsIndex As Integer) As Int32
		Dim data As Int32 = BitConverter.ToInt32(bits, bitsIndex)
		bitsIndex += Marshal.SizeOf(data)
		Return data
	End Function

	' Return specified bytes from byte stream.
	Public Shared Function GetBytes(ByVal bits() As Byte, ByRef bitsIndex As Integer, ByVal length As Integer) As Byte()
		Dim data(length) As Byte
		Buffer.BlockCopy(bits, bitsIndex, data, 0, length)
		bitsIndex += length
		Return data
	End Function

End Class

