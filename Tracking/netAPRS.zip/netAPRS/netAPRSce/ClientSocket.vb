'	NotifyCommand enum
'	--
'	List of socket notification commands.
'
'
'	ClientSocket class
'	--
'	Connects and sends data over TCP sockets. Uses async sockets so a delegate 
'	method is called when the socket command completes. Raises an Notify event 
'	when socket operations complete and passes any associated data with the event.

Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

' Socket notification commands.
Public Enum NotifyCommand
	Connected
	SentData
	ReceivedData
	SocketError
End Enum

' Use async sockets to connect, send and receive data over TCP sockets.
Public Class ClientSocket

	' notification event
	Public Delegate Sub NotifyEventHandler(ByVal command As NotifyCommand, ByVal data As Object)
	Public Event Notify As NotifyEventHandler

	' socket that exchanges information with server
	Private _socket As Socket

	' holds information sent back from server
    Private _readBuffer(256) As Byte

	' used to synchronize the shutdown process, terminate
	' any pending async calls before Disconnect returns
	Private _asyncEvent As ManualResetEvent = New ManualResetEvent(True)
	Private _disconnecting As Boolean = False

    Public ReadOnly Property ReadBuffer()
        Get
            Dim i As Integer
            Dim str As String = ""
            For i = 0 To _readBuffer.Length - 1
                str = str & Chr(_readBuffer(i))
            Next
            Return str
        End Get
    End Property

    ' Returns true if the socket is connected to the server. The property 
    ' Socket.Connected does not always indicate if the socket is currently 
    ' connected, this polls the socket to determine the latest connection state.
    Public ReadOnly Property Connected() As Boolean
        Get
            ' return right away if have not created socket
            If _socket Is Nothing Then
                Return False
            End If

            ' the socket is not connected if the Connected property is false
            If _socket.Connected = False Then
                Return False
            End If

            ' there is no guarantee that the socket is connected even if the
            ' Connected property is true
            Try
                ' poll for error to see if socket is connected
                Return Not _socket.Poll(1, SelectMode.SelectError)
            Catch
                Return False
            End Try
        End Get
    End Property

    Public Sub New()
    End Sub

    ' Connect to the specified address and port number.
    Public Sub Connect(ByVal address As String, ByVal port As Integer)
        ' make sure disconnected
        Disconnect()

        ' connect to the server
        Dim ip As IPAddress = IPAddress.Parse(address)
        Dim endPoint As IPEndPoint = New IPEndPoint(ip, port)
        _socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

        _asyncEvent.Reset()
        _socket.BeginConnect(endPoint, AddressOf ConnectCallback, Nothing)
    End Sub

    ' Disconnect from the server.
    Public Sub Disconnect()
        ' return right away if have not created socket
        If _socket Is Nothing Then
            Return
        End If

        ' set this flag so we don't raise any error notification 
        ' events when disconnecting
        _disconnecting = True

        Try
            ' first, shutdown the socket
            _socket.Shutdown(SocketShutdown.Both)
        Catch
        End Try

        Try
            ' next, close the socket which terminates any pending
            ' async operations
            _socket.Close()

            ' wait for any async operations to complete
            _asyncEvent.WaitOne()
        Catch
        End Try

        _disconnecting = False
    End Sub

    ' Send data to the server.
    Public Sub Send(ByVal data() As Byte)
        ' send the data
        _socket.BeginSend(data, 0, data.Length, _
         SocketFlags.None, Nothing, Nothing)

        ' send the terminator
        _asyncEvent.Reset()
        _socket.BeginSend(Network.TerminatorBytes, 0, _
         Network.TerminatorBytes.Length, SocketFlags.None, _
         AddressOf SendCallback, True)
    End Sub

    ' Read data from server.
    Public Sub Receive()
        _asyncEvent.Reset()
        _socket.BeginReceive(_readBuffer, 0, _readBuffer.Length, _
         SocketFlags.None, AddressOf ReceiveCallback, Nothing)
    End Sub

    ' Raise the specified notification event.
    Private Sub RaiseNotifyEvent(ByVal command As NotifyCommand, ByVal data As Object)
        ' the async operation has completed
        _asyncEvent.Set()

        ' don't raise notification events when disconnecting
        If _disconnecting = False Then
            RaiseEvent Notify(command, data)
        End If
    End Sub

    '
    ' async callbacks
    '

    Public Sub ConnectCallback(ByVal ar As IAsyncResult)
        Try
            _socket.EndConnect(ar)
            RaiseNotifyEvent(NotifyCommand.Connected, Me.Connected)
        Catch ex As Exception
            RaiseNotifyEvent(NotifyCommand.SocketError, ex.Message)
        End Try
    End Sub

    Private Sub SendCallback(ByVal ar As IAsyncResult)
        Try
            _socket.EndSend(ar)
            RaiseNotifyEvent(NotifyCommand.SentData, Nothing)
        Catch ex As Exception
            RaiseNotifyEvent(NotifyCommand.SocketError, ex.Message)
        End Try
    End Sub

    Private Sub ReceiveCallback(ByVal ar As IAsyncResult)
        Try
            _socket.EndReceive(ar)

            ' the server sends an acknowledgment back
            ' that is stored in the read buffer
            If _readBuffer(0) = 1 Then
                RaiseNotifyEvent(NotifyCommand.ReceivedData, True)
            Else
                RaiseNotifyEvent(NotifyCommand.ReceivedData, False)
            End If
        Catch ex As Exception
            RaiseNotifyEvent(NotifyCommand.SocketError, ex.Message)
        End Try
    End Sub

End Class
