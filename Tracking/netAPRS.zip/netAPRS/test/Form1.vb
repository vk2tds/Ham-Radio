Imports System.Xml

Public Class Form1
    Inherits System.Windows.Forms.Form

    Public Structure stru
        Dim one As String
        Dim two As String
        Dim three As String

    End Structure

    Dim struc As stru

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TreeView1
        '
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(24, 24)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(224, 200)
        Me.TreeView1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 240)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 40)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(168, 248)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(64, 48)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Button2"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(72, 296)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(64, 32)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Button3"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(256, 136)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(24, 40)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Button4"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(292, 344)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TreeView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With TreeView1
            If Not .SelectedNode Is Nothing Then
                TreeView1.SelectedNode = .SelectedNode.Nodes.Add("New Sub")
            Else
                .Nodes.Add("New Item")
            End If
        End With
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TreeView1.LabelEdit = True
        TreeView1.SelectedNode = TreeView1.Nodes.Add("Root")
    End Sub

    Private Sub LoadTreeViewFromXmlFile(ByVal file_name As _
        String, ByVal trv As TreeView)
        ' Load the XML document.
        Dim xml_doc As New XmlDocument
        xml_doc.Load(file_name)

        ' Add the root node's children to the TreeView.
        trv.Nodes.Clear()
        AddTreeViewChildNodes(trv.Nodes, _
            xml_doc.DocumentElement)
    End Sub
    ' Add the children of this XML node 
    ' to this child nodes collection.
    Private Sub AddTreeViewChildNodes(ByVal parent_nodes As _
        TreeNodeCollection, ByVal xml_node As XmlNode)
        For Each child_node As XmlNode In xml_node.ChildNodes
            ' Make the new TreeView node.
            Dim new_node As TreeNode = _
                parent_nodes.Add(child_node.Name)

            ' Recursively make this node's descendants.
            AddTreeViewChildNodes(new_node.Nodes, child_node)

            ' If this is a leaf node, make sure it's visible.
            If new_node.Nodes.Count = 0 Then _
                new_node.EnsureVisible()
        Next child_node
    End Sub





    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        LoadTreeViewFromXmlFile("c:\temp.xml", TreeView1)

    End Sub

    Private Function iterate(ByVal tw As XmlTextWriter, ByVal tv As TreeNodeCollection)

        Dim tvn As TreeNode
        For Each tvn In tv
            With tvn
                tw.WriteStartElement("Glob")
                tw.WriteElementString("Blob", .Text)

                If Not .Nodes Is Nothing Then
                    iterate(tw, .Nodes)
                Else
                End If
                If Len(.Tag) > 0 Then
                    tw.WriteElementString("Tag", .Tag)
                End If

                tw.WriteEndElement()

            End With
        Next



    End Function



    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim xmlTW As XmlTextWriter = Nothing

        Dim junk As XmlTextWriter

        junk = New XmlTextWriter("c:\testing.xml", Nothing)


        With junk


            .WriteStartDocument(False)
            .WriteStartElement("iGPRS")
            iterate(junk, TreeView1.Nodes)


            .WriteEndElement()
            .Close()

        End With

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        With struc
            .one = "one"
            .two = "two"
            .three = "three"
        End With

        Dim j As String

        j = j.Join(":", struc)



    End Sub
End Class
