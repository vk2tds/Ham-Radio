//program to transmit data
#include <16F876.h>
#device *=16
#use delay(clock=20000000)
#fuses hs,noprotect,nowdt,nolvp
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)
#byte PORTA=5
#byte PORTB=6
#byte PORTC=7

#byte STATUS=3
#BIT TRMT = 0x98.1



#define STATE_IDLE 0
#define STATE_TO 1
#define STATE_FROM 2
#define STATE_JUNKTO 3
#define STATE_PAYLOAD 4

#define AX25_IDLE 0
#define AX25_FCS 1
#define AX25_RCV 2
#define AX25_STUFFED 3
#define AX25_FCS_MANY 4

#define AX25_POS_DST 0
#define AX25_POS_SRC  1
#define AX25_POS_DIGI  2
#define AX25_POS_PAYLOAD 3
#define AX25_CLOSE  4

char ax25_bit_ctr;
char ax25_ctr;
char ax25_pos_state;
char ax25_num_bits;
short int ax25_got_fcs;
char ax25_state;
char ax25_data_return;
short int ax25_data_available;
short int ax25_third;
short int ax25_third_call;
char ax25;
char ax25_old;
char ax25_i;
char ax25_pos;
char ax25_data;
char ax25_packetlength;
char ax25_to[10];
char ax25_from[10];
char Callsign[10];
char CallsignTo[10];
char Payload[40];
unsigned char c;
char Buffer[40];
char i,j;
char Offset;
char checksum1;
char checksum2;


int k, bt, imbyte;
int fcslo, fcslo1, fcslo2;
int fcshi, fcshi1, fcshi2;




char garmin[68];
char mycall [10];
int32 clng;
int32 b;
int32 mylong;


#separate
void garminmult2 (void)
{

	/*-----------------20/12/2002 11:49AM---------------
	 * Convert the NMEA string for N/S into the correct
	 * an integer coordinate system
	 * --------------------------------------------------*/

	mylong = (((int32)Buffer[7]-'0')*10 + (int32)Buffer[8]-'0') * 6 * 1000;
	mylong += (((int32)Buffer[9]-'0') * 1000) + ((int32)Buffer[10]-'0') * 100 +
 		((int32)Buffer[12]-'0') * 10 + ((int32)Buffer[13] -'0');
	/*-----------------20/12/2002 11:50AM---------------
	 * Then do the huge multiply by about 1988.xxx
	 * --------------------------------------------------*/

	b = mylong * 1024;

	clng = b;
	clng = (clng >> 2) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 2) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 2) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 4) + b;
	clng = (clng >> 4) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	mylong = clng;

	/*-----------------20/12/2002 11:52AM---------------
	 * Correction for SOUTH
	 * --------------------------------------------------*/
	if ( Buffer[15] == 'S'){
		mylong = mylong ^ 0xffffffff;
	}

	/*-----------------20/12/2002 11:52AM---------------
	 * Save the results
	 * --------------------------------------------------*/
	garmin[30] = (int32)mylong >> 24;
	garmin[29] = (int32)(mylong >> 16) & 0xFF;
	garmin[28] = (int32)(mylong >> 8) & 0xFF;
	garmin[27] = 0x00;


}

#separate
void garminmult1 (void)
{



	/*-----------------20/12/2002 11:49AM---------------
	 * Convert the NMEA string for N/S into the correct
	 * an integer coordinate system
	 * --------------------------------------------------*/

	mylong = (
		((int32)Buffer[17]-'0')*100 +
		((int32)Buffer[18]-'0')*10 +
		((int32)Buffer[19]-'0')) * 6 * 1000;
	mylong += (((int32)Buffer[20]-'0') * 1000) + ((int32)Buffer[21]-'0') * 100 +
 		((int32)Buffer[23]-'0') * 10 + ((int32)Buffer[24] -'0');

	/*-----------------20/12/2002 11:50AM---------------
	 * Then do the huge multiply by about 1988.xxx
	 * --------------------------------------------------*/


	b = mylong * 1024;
	clng = b;
	clng = (clng >> 2) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 2) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 3) + b;
	clng = (clng >> 2) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 4) + b;
	clng = (clng >> 4) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	clng = (clng >> 1) + b;
	mylong = clng;

	/*-----------------20/12/2002 11:51AM---------------
	 * Western Hemisphere correction
	 * --------------------------------------------------*/
	if ( Buffer[26] == 'W'){
		mylong = mylong ^ 0xffffffff;
	}

	/*-----------------20/12/2002 11:51AM---------------
	 * Save the results
	 * --------------------------------------------------*/

	garmin[34] = (int32)mylong >> 24;
	garmin[33] = (int32)(mylong >> 16) & 0xFF;
	garmin[32] = (int32)(mylong >> 8) & 0xFF;
	garmin[31] = 0x00;
}


#separate
void garminbin (void)
{

/*-----------------20/12/2002 11:53AM---------------
 * Code for GARMIN binary format version 108?
 * --------------------------------------------------*/

	garmin[0] = 0x10;
	garmin[1] = 0x23;
	garmin[2] = 0x3c; /* Length */
	garmin[3] = 0x00;
	garmin[4] = 0xff; /* WPT class and Colour */
	garmin[5] = 0x00; /* Display the NAME */
	garmin[6] = 0x60; /* Attr*/
	garmin[7] = 161; /* Symbol */
	garmin[8] = 0x00; /* Symboll */
	garmin[9] = 0x00;garmin[10] = 0x00;
	garmin[11] = 0x00;garmin[12] = 0x00;garmin[13] = 0x00;garmin[14] = 0x00;
	garmin[15] = 0xFF;garmin[16] = 0xFF;garmin[17] = 0xFF;garmin[18] = 0xFF;
	garmin[19] = 0xFF;garmin[20] = 0xFF;garmin[21] = 0xFF;garmin[22] = 0xFF;
	garmin[23] = 0xFF;garmin[24] = 0xFF;garmin[25] = 0xFF;garmin[26] = 0xFF;

	/*-----------------20/12/2002 11:54AM---------------
	 * The GARMIN MULT functions have been broken off since
	 * since they would not fit in the same code segment. This
	 * code parses the NMEA string and sends it ot GARMIN{}
	 * --------------------------------------------------*/

	garminmult1();
	garminmult2();

	/*-----------------20/12/2002 11:53AM---------------
	 * The next two lines are for testing....
	 * --------------------------------------------------*/
	/*garmin[27] = 204;garmin[28] = 2;garmin[29] = 206;garmin[30] = 231; */
	/*garmin[31] = 5;garmin[32] = 3;garmin[33] = 67;garmin[34] = 107;*/


	garmin[35] = 0x0;garmin[36] = 0x0;garmin[37] = 1;garmin[38] = 0x0;
	garmin[39] = 0x0;garmin[40] = 0x0;garmin[41] = 1;garmin[42] = 0x0;
	garmin[43] = 0xff;garmin[44] = 0xff;garmin[45] = 0xff;garmin[46] = 0xff;

	garmin[47] = 0x20;garmin[48] = 0x20;
	garmin[49] = 0x20;garmin[50] = 0x20;


	/*-----------------20/12/2002 11:55AM---------------
	 * The next few lines are for testing
	 * --------------------------------------------------*/
	/*
		mycall[0] = 'V';
		mycall[1] = 'K';
		mycall[2] = '2';
		mycall[3] = 'T';
		mycall[4] = 'D';
		mycall[5] = 'S';
		mycall[6] = '-';
		mycall[7] = '1';
		mycall[8] = ' ';
		mycall[9] = 0x00;
	*/

	/*-----------------20/12/2002 11:56AM---------------
	 * copy the data to the WAYPOINT NAME part of the
	 * string and zero terminate the string
	 * --------------------------------------------------*/
	for (i = 0; i < 10; i++){
		if ( Callsign[i] == 0x20){
			garmin[51+i] == 0x00;
		} else {
			garmin[51+i] = Callsign[i]; /*mycall[i];*/
		}
	}
	/*-----------------20/12/2002 11:57AM---------------
	 * and make sure that it is ZERO terminated
	 * --------------------------------------------------*/
	Garmin[60] = 0x00;
	/*-----------------20/12/2002 11:57AM---------------
	 * As per GARMIN spec this is the length of the packet
	 * --------------------------------------------------*/

	garmin[2] = 58;

	/*-----------------20/12/2002 11:57AM---------------
	 * Generate the CHECKSUM of the packet
	 * Add it to the end of the packet
	 * --------------------------------------------------*/
	c = 0x00;
	for (i = 1; i < 51 +9 +1 ; i++){
		c = c + garmin[i];
	}
	c = (256 - c) & 0xff ;
	garmin[61] = c ;

	/*-----------------20/12/2002 11:58AM---------------
	 * Close off the packet
	 * --------------------------------------------------*/
	garmin[62] = 0x10;
	garmin[63] = 0x03;

}






#INT_TIMER2
void int_4800 (void) {
	/*-----------------15/12/2002 3:15PM----------------
	 * get the status of PIN if there is a CD
	 * if there is no CD, then we must put the AX-25 state
	 * machine into idle
	 * --------------------------------------------------*/
	if ( input(PIN_B5)) {
		ax25 = input(PIN_B4);
	} else {
		ax25_old = ax25; /* Cancel out any state changes */
		goto badexit;
	}

	/*-----------------15/12/2002 3:18PM----------------
	 * Has there been a change in the state of the inout pin?
	 * --------------------------------------------------*/

	if (ax25 == ax25_old) {
		/*-----------------15/12/2002 3:19PM----------------
		 * if there has been no change in state, increase the AX25_ctr counter
		 * --------------------------------------------------*/
		ax25_ctr ++;
		/*-----------------15/12/2002 3:21PM----------------
		 * If the ax25 counter says that we have been on this
		 * state too long (over 8*4 + 2) then there is no reason
		 * to continue decoding
		 * --------------------------------------------------*/
		if (ax25_ctr >= 34) goto badexit;
		/*-----------------15/12/2002 3:23PM----------------
		 * No Matter what we need to exit here since there is
		 * nothing to do.
		 * --------------------------------------------------*/
		return;
	}
	else {
		/*-----------------15/12/2002 3:23PM----------------
		 * OK - We have a state change. Lets have some fun.
		 * Firstly, lets cancel the state change
		 * --------------------------------------------------*/
		ax25_old = ax25;
		/*-----------------15/12/2002 3:24PM----------------
		 * Since we are working with the number clocks between
		 * transitions, we need to translate that into bits. The
		 * way we fo that is to take the ax25_ctr and divide it
		 * by 4 after adding two. This places the divide in the
		 * middle of a number, not at the interfaces. Then zero
		 * the counter
		 * --------------------------------------------------*/

		ax25_num_bits = (ax25_ctr +2)/4;
		ax25_ctr = 0;

		if (ax25_num_bits == 7) {
			/*-----------------15/12/2002 3:27PM----------------
			 * We got an FCS... Was it the end or beginning of a packet.
			 * Either way we need to start again, so reset the counters.
			 * --------------------------------------------------*/
			/* ax25_got_fcs = TRUE; */
			ax25_state = AX25_FCS;
			ax25_packetlength = 0;
			ax25_data = 0;
			ax25_bit_ctr = 8;
			ax25_pos_state = AX25_POS_DST;

			return;
		} else if (ax25_num_bits > 7 | ax25_num_bits == 0){
			/*-----------------15/12/2002 3:26PM----------------
			 * If there are more than 7 bits then this is a corrupt
			 * packet since no packet may contain that many continuous
			 * bits. A packet that did would need to be stuffed. so Die.
			 * --------------------------------------------------*/
			goto badexit;
		}



		/*-----------------15/12/2002 3:29PM----------------
		 * Now, we need to take these bits and add them in oposite phase to
		 * the bits that we have already collected. To do that we loop
		 * through the bits.
		 * --------------------------------------------------*/

		for (ax25_i = 0; ax25_i < ax25_num_bits; ax25_i++){
			if (( ax25_state == AX25_FCS) || (ax25_state == AX25_STUFFED) ){
				ax25_state = AX25_RCV;
				continue;
			}
			/*-----------------15/12/2002 3:32PM----------------
			 * Shift and add the data. But we do not add on the first
			 * bit. Cant remember why...
			 * --------------------------------------------------*/
			ax25_data = ax25_data >>1;
			ax25_bit_ctr = ax25_bit_ctr - 1;
			if (ax25_i != 0){
				ax25_data |= 0x80;
			}
			/*-----------------15/12/2002 3:33PM----------------
			 * If the byte is full then return this data to the software
			 * and tell the program that it is there.
			 * --------------------------------------------------*/
			if (ax25_bit_ctr == 0){
				ax25_data_return = ax25_data;
        		ax25_data_available = TRUE;
				ax25_data = 0;
				ax25_bit_ctr = 8;
			}
		}
		if (ax25_num_bits == 6){
			ax25_state = AX25_STUFFED;
		}



	}

	return;
badexit:
		ax25_state = AX25_IDLE;
		ax25_packetlength = 0;
		ax25_data = 0;
		ax25_bit_ctr = 8;
		return;
}

#separate

tx ()
{

	/*-----------------20/12/2002 11:59AM---------------
	 * This is the code to parse the APRS packet into a NMEA
	 * STRING.
	 * --------------------------------------------------*/

	/*-----------------20/12/2002 12:00PM---------------
	 * The first part is to set up the area of BUFFER with
	 * the STRING constants
	 * --------------------------------------------------*/

	Buffer[0] = '$';	Buffer[1] = 'G';	Buffer[2] = 'P';	Buffer[3] = 'W';	Buffer[4] = 'P';
	Buffer[5] = 'L';	Buffer[6] = ',';	Buffer[7] = '0';	Buffer[8] = '0';	Buffer[9] = '0';
	Buffer[10] = '0';	Buffer[11] = '.';	Buffer[12] = '0';	Buffer[13] = '0';	Buffer[14] = ',';
	Buffer[15] = 'N';	Buffer[16] = ',';	Buffer[17] = '0';	Buffer[18] = '0';	Buffer[19] = '0';
	Buffer[20] = '0';	Buffer[21] = '0';	Buffer[22] = '.';	Buffer[23] = '0';	Buffer[24] = '0';
	Buffer[25] = ',';	Buffer[26] = 'W';	Buffer[27] = ',';	Buffer[28] = 'X';	Buffer[29] = 'X';
	Buffer[30] = 'X';	Buffer[31] = 'X';	Buffer[32] = 'X';	Buffer[33] = 'X';	Buffer[34] = 'X';
	Buffer[35] = 'X';	Buffer[36] = 'X';	Buffer[37] = 'X';	Buffer[38] = 0x00;


	/*-----------------20/12/2002 12:02PM---------------
	 * Are we an APRS packet?
	 * And Are we an APRS packet that we can decode?
	 * --------------------------------------------------*/
	if (
		((Payload[0] == '!' | Payload[0] == '=' )& Payload[13] != 'T') |
		((Payload[0] == '/' | Payload[0] == '@' )& Payload[20] != 'T') |
		((Payload[0] == ';' & Payload[18] != '/')) |
		((Payload[0] == ')' | Payload[0] == '\'' | Payload[0] == '`' ))
	 ){
	 	Offset = 0; /* Offset for POS format without TIME */
		switch (Payload[0]){
			case ';':
				Offset = 17;
				for (i = 0; i < 9; i++)
					Buffer[i+28] = Payload[i+1];
				break;
			case ')':
				for (i = 4; (i < 10) & (Payload[i] != '!') & (Payload[i] != '_'); i++){
					;
				}
				for (j = 0; j < i-1; j++)
					Buffer[j+28] = Payload[j+1];
				Offset = i;
				break;
			case '/':
			case '@':
				Offset = 7;
			case '!':
			case '=':
				for (i = 0; (i < 10) && (Callsign[i] != 0); i++)
					Buffer[i+28] = Callsign[i];
				Callsign[i] = 0x00;
				break;
			case '\'':
			case '`':
				for (i = 0; (i < 10) && (Callsign[i] != 0); i++)
					Buffer[i+28] = Callsign[i];
				Callsign[i] = 0x00;
				Offset = 20;
				break;
			default :
				Buffer[0] = 0;
				break;
			}
			Buffer[i + 28] = 0;
			if (Offset != 20){
				for (i = 0; i < 7; i++)
					Buffer[i+7] = Payload[i+1+Offset];
				Buffer[15] = Payload[8+Offset];
				for (i = 0; i < 8; i++)
					Buffer[i+17] = Payload[i+10+Offset];
				Buffer[26] = Payload[18+Offset];
			} else {
				if (CallsignTo[3] < 'P') Buffer[15] = 'S'; else Buffer[15] = 'N';
				if (CallsignTo[5] < 'P') Buffer[26] = 'E'; else Buffer[26] = 'W';
				if (CallsignTo[4] < 'P') Buffer[17] = '0'; else Buffer[17] = '1';
				for (i = 0; i < 6; i++){
					if (CallsignTo[i] >= 'P') CallsignTo[i] -= 0x20;
					if (CallsignTo[i] >= 'A') CallsignTo[i] -= 0x11;
					if (i >= 4)
						Buffer[i+8] = CallsignTo[i];
					else
						Buffer[i+7] = CallsignTo[i];
				}
				buffer[11] = '.';
				Buffer[18] = ((Payload[1] - 28) / 10 ) + '0';
				Buffer[19] = ((Payload[1] - 28) % 10 ) + '0';
				Buffer[20] = ((Payload[2] - 28) / 10 ) + '0';
				Buffer[21] = ((Payload[2] - 28) % 10 ) + '0';
				Buffer[22] = '.';
				Buffer[23] = ((Payload[3] - 28) / 10 ) + '0';
				Buffer[24] = ((Payload[3] - 28) % 10 ) + '0';

				/*-----------------17/12/2002 10:25AM---------------
				 * NEW!!!
				 * --------------------------------------------------*/
				if ( Buffer[9] == '6')
				{
					Buffer[9] = '0';
				}
				if ( Buffer[20] == '6')
				{
					Buffer[20] = '0';
				}
				if ( Buffer[17] == '1' & Buffer[18] == '9')
				{
					Buffer[17]='0';  Buffer[18]='0';
				}
				if ( Buffer[17] == '1' & Buffer[18] == '8')
				{
					Buffer[17]='1';  Buffer[18]='0';
				}
			}

		}

}




#separate

void rx_ax25(void)
{
	int i;
	int temp;
		/*-----------------16/12/2002 8:14PM----------------
		 * If data is available then we process it
		 * --------------------------------------------------*/
		if (ax25_data_available){
			/*-----------------16/12/2002 8:14PM----------------
			 * We then reset the data availability
			 * --------------------------------------------------*/
			ax25_data_available = false;
			/*-----------------16/12/2002 8:15PM----------------
			 * run the state machine for the AX25 packet
			 * --------------------------------------------------*/


			fcslo2 = fcslo1;
			fcslo1 = fcslo;
			fcshi2 = fcshi1;
			fcshi1 = fcshi;


			imbyte = ax25_data_return;
			for ( k = 0; k <8; k++){
				bt=imbyte & 0x01;
				#asm
					BCF 03,0
					RRF fcshi, F
					RRF fcslo, F
				#endasm
				if ((( status & 0x01)^(bt)) == 0x01) {
					fcshi = fcshi ^ 0x84;
					fcslo = fcslo ^ 0x08;
				}
				rotate_right (&imbyte, 1);
			}




			switch ( ax25_pos_state)
			{
				case AX25_POS_DST :
					/*-----------------16/12/2002 8:16PM----------------
					 * this is a DESTINATION field of AX25
					 * --------------------------------------------------*/
					if ( ax25_pos == 7){
						/*-----------------16/12/2002 8:17PM----------------
						 * We are on the SSID. Set the next state after processing
						 * --------------------------------------------------*/
						temp = (ax25_data_return >>1) & 0x0f ;
						if ( temp == 0x00 )
						{
							ax25_to[6] = 0x00;
						} else {
							ax25_to[6] = '-';
							if (temp > 9){
								ax25_to[7] = '1';
								ax25_to[8] = (temp-10) + '0';
								ax25_to[9] = 0x00;
							} else {
								ax25_from[7] = temp + '0';
								ax25_from[8] = 0x00;
							}
						}
						ax25_pos_state = AX25_POS_SRC;
						ax25_pos = 0;
					} else {
						ax25_to[ax25_pos-1] = ax25_data_return >>1;
					}
					break;
				case AX25_POS_SRC :
					/*-----------------16/12/2002 8:16PM----------------
					 * this is the SOURCE field
					 * --------------------------------------------------*/

					if ( ax25_pos == 7){
						/*-----------------16/12/2002 8:17PM----------------
						 * We are on the SSID. Set the next state after processing
						 * --------------------------------------------------*/
						temp = (ax25_data_return >>1) & 0x0f ;
						if ( temp == 0x00 )
						{
							ax25_from[6] = 0x00;
						} else {
							ax25_from[6] = '-';
							if (temp > 9){
								ax25_from[7] = '1';
								ax25_from[8] = (temp-10) + '0';
								ax25_from[9] = 0x00;
							} else {
								ax25_from[7] = temp + '0';
								ax25_from[8] = 0x00;
							}

						}
						if (  (ax25_data_return & 0x01) == 0x01){
							ax25_pos_state = AX25_POS_PAYLOAD;
						} else {
							ax25_pos_state = AX25_POS_DIGI;
						}
						ax25_pos = 0;

					} else {
						ax25_from[ax25_pos-1] = ax25_data_return >>1;
					}
					break;
				case AX25_POS_DIGI :
					if ( (ax25_data_return & 0x01) == 0x01){
						ax25_pos_state = AX25_POS_PAYLOAD;
						ax25_pos = 0;
					} else {
						ax25_pos_state = AX25_POS_DIGI;
					}
					break;
				case AX25_POS_PAYLOAD :
					/*-----------------20/12/2002 3:53PM----------------
					 * This is the third party stuff. The only other thing is that
					 * the ax25_third needs to be reset on FCS
					 * Needs to add FROM callsign :-(
					 * --------------------------------------------------*/
					if ( ax25_pos ==3){
						if ( ax25_data_return == '}'){
							ax25_pos = 0;
							ax25_third = true;
							ax25_third_call = true;
							for (i = 0; i <= 9; i++){
								ax25_from [i] = ' ';
							}
							break;
						}
					}
					if ( ax25_third == TRUE ) {
						/*-----------------28/12/2002 10:33AM---------------
						 * ONLY if we are in 3rd Party Packets
						 * --------------------------------------------------*/

						if ( ax25_data_return == ':'){
							ax25_pos = 2;
							ax25_third = false;
							ax25_third_call = false;
							break;
						}
						if ( ax25_third_call == true){
							/*--------------28/12/2002 10:17AM------------
							 * We need to process the callsigns still, so until
							 * we get * , or > we must stuff the ax25_from array
							 * --------------------------------------------*/
							if ( ax25_data_return == '*' | ax25_data_return == ',' | ax25_data_return == '>' ){
								ax25_from[ax25_pos-1] = 0x00;
								ax25_third_call = false;
								break;
							} else {
								if ( ax25_pos < 11){
									ax25_from[ax25_pos-1] = ax25_data_return;
								}
								break;

							}
						}
					}
					/*-----------------20/12/2002 3:52PM----------------
					 * End of the NEW third party stuff
					 * --------------------------------------------------*/

					/*-----------------28/12/2002 10:52AM---------------
					 * NEW: Stop a buffer overrun...
					 * --------------------------------------------------*/
					if ( ax25_pos < 40 ){
						Payload[ax25_pos-1] = ax25_data_return;
					}
					/*-----------------29/12/2002 4:50PM----------------
					 * NEW - Even if the POS is overrun then still do checksum storage
					 * --------------------------------------------------*/
					checksum2 = checksum1;
					checksum1 = ax25_data_return;


					break;
			}
			ax25_pos ++;


		} else if (ax25_state == AX25_FCS){
			/*ax25_state = AX25_FCS_MANY;*/

/*			while (!TRMT);

			printf (">>%x %x %x %x\n", fcshi2,  Payload[ax25_pos-2] ^ 0xff, fcslo2,  Payload[ax25_pos-3] ^ 0xff);
			printf ("  %x %x %x %x\n", checksum1, checksum2, checksum3, checksum4); */

/*			if (( fcshi2 ==   (Payload[ax25_pos-2] ^ 0xff)) & (fcslo2 ==   (Payload[ax25_pos-3] ^ 0xff))  ){ */
 			if (( fcshi2 ==   (checksum1 ^ 0xff)) & (fcslo2 ==   (checksum2 ^ 0xff))  ){
/*			if ( ax25_pos > 10){        */
				output_bit (PIN_B7, 1);

				while (!TRMT);
				printf ("\n\r%s %s - ", ax25_from, ax25_to);
				/*-----------------29/12/2002 4:45PM----------------
				 * NEW - Added i < 39
				 * --------------------------------------------------*/
/*				for ( i=2; i < ax25_pos-3 & (i < 39); i++)
				{
					while (!TRMT);
					putc (Payload[i]);
				}
				while (!TRMT);
				printf ("\n\r");
*/
/*				printf ("%x %x %x %x ", fcshi2, fcslo2, Payload[ax25_pos-3], Payload[ax25_pos-2]); */

				/*-----------------17/12/2002 10:18AM---------------
				 * Make a full copy of the TO and FROM callsigns. This
				 * is so that they can be overwritten. Should we just
				 * Kill it off anyway?
				 * --------------------------------------------------*/
				for (i = 0; i <= 9; i++){
					Callsign[i] = ax25_from[i];
					CallsignTo[i] = ax25_to[i];
				}
				/*-----------------17/12/2002 10:17AM---------------
				 * The first two characters of the Pauload are the CONTROL
				 * bits and the PID. We dont want them or the FCS at the
				 * end of the packet.
				 * --------------------------------------------------*/
				/*-----------------29/12/2002 4:43PM----------------
				 * NEW - Added i < 37
				 * --------------------------------------------------*/
				for ( i=0; Payload[i+4] != 0 & (i < 37); i++)
				{
					Payload[i] = Payload[i+2];
				}
				tx();
				/*-----------------17/12/2002 10:18AM---------------
				 * TX() just sets the BUFFER. To actually print it requires
				 * some more work - particularly in a multi-processing
				 * environment, where we want to RX and TX at the same time
				 * --------------------------------------------------*/
				if ( Buffer[0] != 0)
				{
					garminbin();
					if (input(PIN_B6)){
						set_uart_speed (9600);
						for (i = 0; i < 64; i++){
							while (!TRMT);
							putc ( garmin[i]);
						}
					} else {
						set_uart_speed (4800);
						while (!TRMT);
						printf ("\n\r%s\n\r",Buffer);
					}
				}

			}
			output_bit (PIN_B7, 0);
			ax25_third = false;
			ax25_third_call = false;
			ax25_pos = 1;
			fcshi = 0xff;
			fcslo = 0xff;
		}
}





main()
{

	set_tris_b(0x70);
	delay_ms(500);

	puts ("PIC16F876 Packet Decoder Copyright Darryl Smith\n");

	disable_interrupts(GLOBAL);
	setup_timer_2 (T2_DIV_BY_16, 65,1); /* should be 130 */
	enable_interrupts(int_timer2);
	enable_interrupts(GLOBAL);




	ax25_got_fcs= FALSE;
	ax25_bit_ctr = 8;
	ax25_ctr = 0;
	ax25_data = 0;
	ax25_state = AX25_IDLE;
	ax25_data_available = FALSE;
	ax25_packetlength = 0;

	fcshi = 0xff;
	fcslo = 0xff;


	set_uart_speed (9600);
	ax25_State = STATE_IDLE;
	while (1 == 1){
		rx_ax25();
	}


}
