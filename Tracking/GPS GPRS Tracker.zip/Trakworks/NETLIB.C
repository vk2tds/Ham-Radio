#class auto

