/* GPS ROAD ANGEL FEATURE? */

#class auto


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------


#define AINBUFSIZE 1023
#define AOUTBUFSIZE 1023
#define BINBUFSIZE 1023
#define BOUTBUFSIZE 1023
#define CINBUFSIZE 1023
#define COUTBUFSIZE 1023
#define DINBUFSIZE 1023
#define DOUTBUFSIZE 1023

#define MAX_SENTENCE 1023


InitSerA(int myspeed)
{
	serAopen(myspeed);	
}
InitSerB(int myspeed)
{
	serBopen(myspeed);	
}
InitSerC(int myspeed)
{
	serCopen(myspeed);	
}
InitSerD(int myspeed)
{
	serAopen(myspeed);	
}


cofunc CofSerA()
{
	char sentence[MAX_SENTENCE];
	int input_char;
	int string_pos;
	char dir_string[2];

	string_pos = 0;
	dir_string[1] = 0;

	while(1)
	{
		waitfordone input_char = cof_serAgetc();
		if(input_char == '\r' || input_char == '\n')
		{
			sentence[string_pos] = 0; //add null
			SerialInput ('A', sentence);
			//printf("%s\n", sentence);
			string_pos = 0;
		}
		else if(input_char > 0)
		{
			sentence[string_pos] = input_char;
			string_pos++;
			if(string_pos == MAX_SENTENCE)
				string_pos = 0;	//reset string if too large
		}
	}
}
		cofunc CofSerB()
{
	char sentence[MAX_SENTENCE];
	int input_char;
	int string_pos;
	char dir_string[2];

	string_pos = 0;
	dir_string[1] = 0;

	while(1)
	{
		waitfordone input_char = cof_serBgetc();
		if(input_char == '\r' || input_char == '\n')
		{
			sentence[string_pos] = 0; //add null
			SerialInput ('B', sentence);
			//printf("%s\n", sentence);
			string_pos = 0;
		}
		else if(input_char > 0)
		{
			sentence[string_pos] = input_char;
			string_pos++;
			if(string_pos == MAX_SENTENCE)
				string_pos = 0;	//reset string if too large
		}
	}
}
cofunc CofSerC()
{
	char sentence[MAX_SENTENCE];
	int input_char;
	int string_pos;
	char dir_string[2];

	string_pos = 0;
	dir_string[1] = 0;

	while(1)
	{
		waitfordone input_char = cof_serCgetc();
		if(input_char == '\r' || input_char == '\n')
		{
			sentence[string_pos] = 0; //add null
			SerialInput ('C', sentence);
			//printf("%s\n", sentence);
			string_pos = 0;
		}
		else if(input_char > 0)
		{
			sentence[string_pos] = input_char;
			string_pos++;
			if(string_pos == MAX_SENTENCE)
				string_pos = 0;	//reset string if too large
		}
	}
}
cofunc CofSerD()
{
	char sentence[MAX_SENTENCE];
	int input_char;
	int string_pos;
	char dir_string[2];

	string_pos = 0;
	dir_string[1] = 0;

	while(1)
	{
		waitfordone input_char = cof_serDgetc();
		if(input_char == '\r' || input_char == '\n')
		{
			sentence[string_pos] = 0; //add null
			SerialInput ('D', sentence);
			//printf("%s\n", sentence);
			string_pos = 0;
		}
		else if(input_char > 0)
		{
			sentence[string_pos] = input_char;
			string_pos++;
			if(string_pos == MAX_SENTENCE)
				string_pos = 0;	//reset string if too large
		}
	}
}


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------











// #USE "GPS.LIB"

// #INCLUDE "NETLIB.C"


char GPSrecord; /* Record GPS data into the buffer */
char TCPconnect; /* Do we want to be connected */
char TCPconnected; /* Are we connected? */

int GPSdelay; /* The delay between position reports */


enum ModemType
{
	GR47,
	M5100
}







ProcessAUX (char *sentence)
{
	
}



ProcessRFID (char *sentence)
{

}


ProcessGPS (char *sentence)
{
//			if(gps_get_position(&current_pos, sentence) == 0)
//			{
//				dir_string[0] = current_pos.lat_direction;
//				printf("Latitude: %d %f' %s\n",
//					current_pos.lat_degrees, current_pos.lat_minutes,
//					dir_string);
//				dir_string[0] = current_pos.lon_direction;
//				printf("Longitude: %d %f' %s\n",
//					current_pos.lon_degrees, current_pos.lon_minutes,
//					dir_string);
//	
//			}
//			if(gps_get_utc(&current_time, sentence) == 0)
//			{
//				printf("UTC: %s %d-%s-%d %02d:%02d:%02d\n",
//					dayname[current_time.tm_wday],
//					current_time.tm_mday,
//					monthname[current_time.tm_mon - 1],
//					1900 + current_time.tm_year,
//					current_time.tm_hour,
//					current_time.tm_min,
//					current_time.tm_sec );
//			}
}


#define AT_GR47 0
#define AT_GR47_DTR 1
#define AT_GR47_AT 2
#define AT_GR47_CGSN 3
#define AT_GR47_CGCONT 4 
#define AT_GR47_E2IPA 5
#define AT_GR47_E2IPO 6
#define AT_GR47_E2IPOCONNECT 7
#define AT_GR47_CONNECT 8
#define AT_GR47_CONNECTED 9
#define AT_MM5100 10
#define AT_MM5100_DTR 11
#define AT_MM5100_AT 12 
#define AT_MM5100_ESN 13
#define AT_MM5100_IPCTRIP 14
#define AT_MM5100_IPCTOS 15 
#define AT_MM5100_CONNECT 16
#define AT_MM5100_CONNECTED 17
#define AT_IGNORE 18



SendAT (char *line)
{
	serCputs (line);
}

ParseIncomingData( char *myData)
{
//	int i;
//	if (sstr (myData, "#STOP,") == myData ){
//		      scpy (DataReturn, "#GOODSTOP,");
//	}
//
//	if (sstr (myData, "#OUT,") != 0 ){
//  / 	pdest = sstr( myData, "#OUT," );
//		i = (pdest - myData) + 1;
//		i = myData [i+4];
//		i = i & 0x0f;
//		if ((i & 0x01)>0 ){io (1,0,1);} else {io (1,0,0);}
//		if ((i & 0x02)>0 ){io (1,1,1);} else {io (1,1,0);}
//		if ((i & 0x04)>0 ){io (1,2,1);} else {io (1,2,0);}
//		if ((i & 0x08)>0 ){io (1,3,1);} else {io (1,3,0);}

// 		prtf ("Out - %x\r\n", i);
//        gpsstate = 1;
//      scpy (DataReturn, "#GOODOUT,");
//    }

//    if (sstr (myData, "#START,") != 0 ){
//        prtf ("Start\r\n");
//        gpsstate = 1;
//        scpy (DataReturn, "#GOODSTART,");
//    }

//    if (sstr (myData, "#POLL,") != 0 ){
//        prtf ("Poll\r\n");
//        scpy (DataReturn, gps);
//    }

//    if (sstr (myData, "#CELL,") != 0 ){
//        prtf ("Cell\r\n");
//        atcrt();
//        err = atsnd("AT*E2EMM=1",myRes,slen("AT*E2EMM=1"),490,&mySize);
//        atdst();
//        for (i = 0; i < 100; i++){
//            myRes[i] = myRes[i+64];
//        }
//        myRes[41] = 0;
//        scpy (DataReturn, "#CE,"); 
//        scat (DataReturn, myRes);   
//    }


//    if (sstr (myData, "#RESTART,") != 0 ){
//        prtf ("Restart initiated\n");
//        uts ("RESTART\n", 8);
//        for (i = 0; i < 10; i++){
//            invert_led();
//            dlyms (3);
//        }
//    }
}




ProcessAT (char *line, char timer)
{
	/* timer = true = boolean */
	static int thisstate;
	static int next_data;
	static int next_timeout;
	static int timeout;

	if (timer){
		if (next_timeout != AT_IGNORE){
			thisstate = next_timeout;
		}
	} else {
		if (next_data != AT_IGNORE){
			thisstate = next_data;
		}
	}
	
	switch (thisstate)
	{
		case AT_MM5100:
			//	drop dtr /* NO MATTER WHAT */

			/* Do we want to be connected? If so start things*/
			if (TCPconnect){
				next_data = AT_IGNORE;
				next_timeout = AT_MM5100_DTR;
				timeout = 2000;
			} else {
				next_data = AT_IGNORE;
				next_timeout = AT_MM5100;
				timeout = 1000;
			}
			break;
		case AT_MM5100_DTR:
			SendAT ("AT\n");			
			next_data = AT_MM5100_ESN;
			next_timeout = AT_MM5100;
			timeout = 3000;
			break;
		case AT_MM5100_ESN:
			if (strstr(line, "OK") != line){
				/* if sentance does not start with OK then */ 
				next_data = AT_IGNORE;
				next_timeout = AT_MM5100;
				timeout = 500;
			} else {
				SendAT ("AT$$NVRESN\n");
				next_data = AT_MM5100_IPCTRIP;
				next_timeout = AT_MM5100;
				timeout = 2000;
				break;
			}
			break;
		case AT_MM5100_IPCTRIP:
			if (strstr(line, "$$NVR:ESN") == line){
				//decode ESN
				next_data = AT_MM5100_IPCTRIP;
				next_timeout = AT_MM5100;
				/* wait for OK */
				timeout = 2000;
			} else if (strstr(line, "OK") == line){
				if (TCPconnect){
					SendAT ("AT$$IPCTRIP  mnmnnjkhj jh j\n");
					next_data = AT_MM5100_IPCTOS;
					next_timeout = AT_MM5100;
					timeout = 2000;
				} else {
					next_data = AT_IGNORE;
					next_timeout = AT_MM5100;
					timeout = 1000;
				}
			} else {
				next_data = AT_MM5100_IPCTRIP;
				next_timeout = AT_MM5100;
				//wait for OK
				timeout = 2000;
			}
			break;
		case AT_MM5100_IPCTOS:
			if (strstr(line, "OK") == line){
					SendAT ("AT$$IPCTOS\n");
					next_data = AT_MM5100_CONNECT;
					next_timeout = AT_MM5100;
					timeout = 2000;
			} else {
				next_data = AT_MM5100_IPCTOS;
				next_timeout = AT_MM5100;
				timeout = 2000;
			}
			break;
		case AT_MM5100_CONNECT:
			if (strstr(line, "OK") == line){
				next_data = AT_IGNORE;
				next_timeout = AT_MM5100;
				timeout = 2000; /* ????????????????????? */
			} else if (strstr(line, "TCP CONNECTED") == line){
				SendAT ("#CONNECT,?????\n");
				next_data = AT_MM5100_CONNECTED;
				next_timeout = AT_MM5100;
				timeout = 2000; /* ?????????????????????? */
			} else {
				/* Ignore and wait for the timeout*/
			}
			break;
		case AT_MM5100_CONNECTED:
			TCPconnected = TRUE;
			if ((!TCPconnect) | (strstr(line, "NO CARRIER") == line) ){
				SendAT ("+++++\n");
				TCPconnected = FALSE;
				next_data = AT_IGNORE;
				next_timeout = AT_MM5100;
				timeout = 1000;
			} else {
				next_data = AT_MM5100;
				next_timeout = AT_MM5100;
				timeout = 0;
				ParseIncomingData (line);
			}
			break;
		}




}



int LedState;


/* ***************************************
     SEMAPHORE - ONLY ONE AT A TIME !!!!!!
   *************************************** */

#define STORAGE_COUNT 100
#define STORAGE_SIZE 80

//char Storage [STORAGE_COUNT * STORAGE_SIZE];
//int StorageTop;
//int StorageBottom;
//int StorageCurrent;
//int StorageCount;
//   
//Storage_Push ()
//{
//
//	if (StorageCount == STORAGE_COUNT){
//		return 0;
//	}
//	StorageCurrent = (StorageCurrent + 1) % STORAGE_COUNT;
//	StorageCount++;
//	strcpy ( Storage [StorageCount], blah);
//}
//Storage_Pop
//{
//	if (StorageCount == 0){
//		return "";
//	}
//	copy out Storage [StorageBottom]
//	StorageCount--;
//	StorageBottom = (StorageBottom +1) % STORAGE_COUNT;	
//	Return the copied ou
//

//}Storage_Get
//{
//
//}

//Storage_Clear()
//{
//	StorageTop = 0;
//	StorageBottom = 0;
//	StorageCurrent = STORAGE_COUNT -1 ;
//	StorageCount = 0;
//}//









//GPSPosition current_pos;
struct tm current_time;



GPSsample()
{
	/* Sample the GPS and TELEMETRY and place them in the buffer for sending */ 	


//typedef struct {
//	int lat_degrees;/
//	int lon_degrees;
//	float lat_minutes;
//	float lon_minutes;
//	char lat_direction;
//	char lon_direction;
//	} GPSPosition;


//	ing working;
//	char TCPstring[20];
//	TCPstring[0] = '%';
//	if (GPSposition.lon_direction == 'W'){
//		working = 180 - GPSposition.lon_degrees;
//	} else {
//		working = 180 + GPSposition.lon_degrees;
//	}
//	TCPstring[1] = '0' + ((working & 0x1F4) >>3);
//	TCPstring[2] = '0' + ((working & 0x07) <<3);
//	working = (int)lon_minutes;
//	TCPstring[3] = '0' + ((working & 0x38) >> 3);

//	current_pos

	


}


int current_telemetry;

cofunc CofTelemetry()
{
	for (;;){
		wfd{ DelayMs (100);};
	}
}


cofunc CofTrack()
{
	for (;;){
		if (GPSrecord){
			GPSsample();
			wfd{ DelaySec (GPSdelay-1);};			
		}
		wfd{ DelaySec(1);};
	}
}




cofunc CofTIMER()
{
	for (;;){
		wfd DelaySec (1);
	}
}


LED( int A, int B)
{
	if (A){
		WrPortI(PEB7R, NULL, 0);     // turn LED DS3 on
	} else {
		WrPortI(PEB7R, NULL, 0xff);  // turn LED DS3 off
	}
	if (B){
		WrPortI(PEB7R, NULL, 0);     // turn LED DS3 on
	} else {
		WrPortI(PEB7R, NULL, 0xff);  // turn LED DS3 off
	}
}









SerialOutput (char Port,char *string)
{
	// A central place to send strings. Note that we disgard any comms
	// strings that will not fit into the buffer. Given the 1k buffer we
	// have set up that should not be a big issue. And 640k is enough for
	// anyone. 	
	switch (Port)
	{
		case 'A': if (serAwrFree() > strlen (string)){ serAputs (string); } break;
		case 'B': if (serBwrFree() > strlen (string)){ serBputs (string); } break;
		case 'C': if (serCwrFree() > strlen (string)){ serCputs (string); } break;
		case 'D': if (serDwrFree() > strlen (string)){ serDputs (string); } break;
	}
}



SerialInput (char Port,char *string)
{
	/* This routine handles incoming Serial from every serial port */
	/* It may seem stupid but it allows us to play around later */
	
	switch (Port)
	{
		case 'A': 	ProcessGPS (string); break;
		case 'B': 	ProcessRFID (string); break;
		case 'C': 	ProcessAUX (string);	break;
		case 'D':	ProcessAT (string, FALSE);	break;
	}
}

int GPSgood;

cofunc CofLED()
{
	static int LED_A; static int LED_B;
	LED_A = 0; LED_B = 0;
	for (;;){
		if (TCPconnect)	{LED_A = 1-LED_A;} 	/* If we want to be connected then FLASH LED */
		else					{LED_A = FALSE;}		/* Else turn the LED off.							*/
		if (TCPconnected)	{LED_A = TRUE;}		/* But if we are connected, over-ride this	*/

		if (GPSgood)		{LED_B = 1-LED_B;}	/* If GPS is good, flash the LED's. 			*/
		else					{LED_B = FALSE;}		/* Else Turn them off								*/
		
		LED ( LED_A, LED_B);
		waitfordone {DelayMs (500);};
	}
}

main ()
{
	/*  1. Convert the I/O ports.  Disable slave port which makes
	 *     Port A an output, and PORT E not have SCS signal.
	 */
	WrPortI(SPCR, & SPCRShadow, 0x84);

	/*  2. Read function shadow and set PE1 and PE7 as normal I/O.
	 *     LED's are conencted to PE1 and PE7, make them outputs.
	 *     Using shadow register preserves function of other Port E bits.
	 */
	WrPortI(PEFR,  & PEFRShadow,  ~((1<<7)|(1<<1)) & PEFRShadow);
	WrPortI(PEDDR, & PEDDRShadow, (1<<7)|(1<<1));

	/*  3. Turn on DS2 (0 -> PE1) and turn off DS3 (1 -> PE7).
	 */
	WrPortI(PEDR, & PEDRShadow, (1<<7));


	InitSerA(4800);	InitSerB(4800);	InitSerC(4800);	InitSerD(4800);
	loopinit();
	for (;;){
		loophead();
		costate {	wfd CofLED();			}
		costate {	wfd CofSerA();			}
		costate {	wfd CofSerB();			}
		costate {	wfd CofSerC();			}
		costate {	wfd CofSerD();			}
		costate {	wfd CofTIMER();		}
		costate {	wfd CofTelemetry();	}
		costate {	wfd CofTrack();		}
	}
}