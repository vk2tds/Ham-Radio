

Public Class OziExplorer



#Region "OziExplorer Declares"

#Region "Moving Map Ozi Callbacks"
    Declare Function oziSendMMpositionOFF Lib "oziapi" () As Integer
    Declare Function oziSendMMpositionON Lib "oziapi" (ByVal p As TMMpositionCallback) As Integer
    Delegate Sub TMMpositionCallback(ByVal Lat As Double, ByVal lon As Double, _
        ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)
#End Region

    Declare Function oziCreateWP Lib "oziapi" (ByRef name As String, ByVal symbol As Int32 _
    , ByVal lat As Double, ByVal lon As Double, ByVal Altitude As Double, ByVal wpDate As Double _
    , ByVal MapDisplayFormat As Int32, ByVal PointerDirection As Int32, ByVal GarminDisplayFormat As Int32 _
    , ByVal ForeColor As Int32, ByVal BackColor As Int32, ByVal ProximityDistance As Int32, ByRef Description As String _
    , ByVal FontSize As Int32, ByVal FontStyle As Int32, ByVal SymbolSize As Int32) As Int32
    Declare Function oziRepositionWP Lib "oziapi" (ByVal Number As Long, ByVal lat As Double, ByVal lon As Double) As Long
    Declare Function oziGetOziVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Long) As Long
    Declare Function oziGetApiVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Long) As Long
    Declare Function oziDeleteWpByName Lib "oziapi" (ByRef pansichar As String) As Long
    Declare Function oziDeleteWpByNumber Lib "oziapi" (ByRef wpnum As Int32) As Long
    Declare Function oziGetWpNumberFromName Lib "oziapi" (ByRef pansichar As String) As Long
    Declare Function oziClearWPs Lib "oziapi" () As Long
    Declare Function oziGetVersion Lib "oziapi" (ByRef Data As String, ByRef DataLength As Long) As Long
    Declare Function oziMapDblClickON Lib "oziapi" (ByVal p As delClickCallback) As Integer
    Dim delMapDoubleClickCallback As delClickCallback
    Delegate Function delClickCallback(ByRef oType As String, ByVal X As Integer, ByVal Y As Integer, _
          ByVal lat As Double, ByVal lon As Double, _
      ByRef UTMzone As String, ByVal easting As Double, ByVal northing As Double) As Integer
    'Declare Function oziSendMMpositionOFF Lib "oziapi" () As Integer
    'Declare Function oziSendMMpositionON Lib "oziapi" (ByVal p As TMMpositionCallback) As Integer
    'Delegate Sub TMMpositionCallback(ByVal Lat As Double, ByVal lon As Double, _
    '    ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)
    Declare Function oziClearAllTracks Lib "oziapi" () As Integer
    Declare Function oziClearTrack Lib "oziapi" (ByVal TrackNum As Int32) As Int32
    Declare Function oziShowAllTracks Lib "oziapi" () As Integer
    Declare Function oziHideAllTracks Lib "oziapi" () As Integer
    Declare Function oziShowTrack Lib "oziapi" (ByVal TrackNum As Int32) As Integer
    Declare Function oziHideTrack Lib "oziapi" (ByVal TrackNum As Int32) As Integer
    Declare Function oziCreateTrackPoint Lib "oziapi" (ByVal TrackNum As Integer, ByVal Code As Integer, _
    ByVal lat As Double, ByVal lon As Double, ByVal altitude As Double, ByVal tpdate As Double) As Double
    Declare Function oziSetTrackDescription Lib "Oziapi" (ByVal TrackNum As Integer, ByRef TrackDescription As String) As Integer
    Declare Function oziSetTrackType Lib "oziapi" (ByVal TrackNum As Integer, ByVal TrackType As Integer) As Integer

    Declare Function oziGetMapFilePath Lib "oziapi" (ByRef MapFilePath As String) As Integer
    Declare Function oziFindBestMap Lib "oziapi" (ByVal lat As Double, ByVal lon As Double, _
        ByVal SubFolders As Integer, ByRef MapPath As String, ByRef MapFile As String) As Integer
    Declare Function oziLoadMap Lib "oziapi" (ByRef MapName As String) As Integer
    Declare Function oziCenterMapAtPosition Lib "oziapi" (ByVal lat As Double, ByVal lon As Double) As Integer
    Declare Function oziRefreshMap Lib "oziapi" () As Integer
    Declare Function oziCloseProgram Lib "oziapi" () As Integer
    Declare Function oziSaveMapFlag Lib "oziapi" (ByVal Saved As Boolean) As Integer
    Declare Function oziCloseApi Lib "oziapi" () As Integer

    Public Sub RefreshMap()
        Dim i As Integer
        i = oziRefreshMap()
    End Sub

#End Region

    Public Declare Function GetTickCount Lib "kernel32" () As Integer

    Dim _TrailMode As Boolean = False
    Dim _BaseMode As Boolean = False
    Dim _DescLine As String = "TeamTrack"
    Dim _AutoStartOziExplorer As Boolean = True
    Dim _Running As Boolean = False
    Dim _MapTrack As Boolean = False

#Region "Mode Properties"


    Public Property TrailMode() As Boolean
        Get
            Return _TrailMode
        End Get
        Set(ByVal value As Boolean)
            _TrailMode = value
        End Set
    End Property
    Public Property BaseMode() As Boolean
        Get
            Return _BaseMode
        End Get
        Set(ByVal value As Boolean)
            _BaseMode = value
        End Set
    End Property
    Public Property Descline() As String
        Get
            Return _DescLine
        End Get
        Set(ByVal value As String)
            _DescLine = value
        End Set
    End Property
    Public Property AutoStartOziExplorer() As Boolean
        Get
            Return _AutoStartOziExplorer
        End Get
        Set(ByVal value As Boolean)
            _AutoStartOziExplorer = value
        End Set
    End Property
    Public Property Running() As Boolean
        Get
            Return _Running
        End Get
        Set(ByVal value As Boolean)
            _Running = value
        End Set
    End Property
    Public Property MapTrack() As Boolean
        Get
            Return _MapTrack
        End Get
        Set(ByVal value As Boolean)
            _MapTrack = value
        End Set
    End Property
#End Region

    Public Sub New()

    End Sub


    
    Private Function GetDescLine(ByVal dr As DataRow) As String

        Dim Descline As String = _DescLine

        For i As Integer = 0 To dr.ItemArray.GetLength(0) - 1
            Descline = Descline.Replace("[" & dr.Table.Columns(i).ColumnName & "]", dr.Item(i).ToString)
        Next

        Descline = Descline.Replace("[CR]", vbCrLf)
        Return Descline
    End Function

    Private Function SetTrail(ByVal dr As DataRow) As Integer

        If Val(dr("ozi_Trail").ToString) > 0 Then
            Return dr("ozi_Trail")
        End If

        For i As Integer = 2 To 70
            For Each ddr As DataRow In dr.Table.Rows
                If Val(ddr("ozi_Trail").ToString) = i Then GoTo nexti
            Next
            dr("ozi_Trail") = i
            Return i
nexti:
        Next
        Return 0
    End Function


    Public Sub FindBestMap(ByVal lat As Double, ByVal lon As Double)
        Dim MapFilePath As String = "12345678901234567890123456789012345678901234567890123456789012345678901234567890"
        Dim MapFile As String = "12345678901234567890123456789012345678901234567890123456789012345678901234567890"
        Dim ReturnValue As Integer


        If CheckIfOziRunning() = False Then
            If _AutoStartOziExplorer = True Then
                StartUpOzi()
                If CheckIfOziRunning() = False Then
                    Exit Sub
                End If
            End If
        End If




        ReturnValue = oziGetMapFilePath(MapFilePath)
        ReturnValue = oziFindBestMap(lat, lon, 1, MapFilePath, MapFile)
        ReturnValue = oziLoadMap(MapFile)
        ReturnValue = oziCenterMapAtPosition(lat, lon)

    End Sub


    Public Function CheckIfOziRunning() As Integer
        Dim Data As String = "1234567890123456789012345678901234567890"
        Dim DataLength As Long
        oziGetOziVersion(Data, DataLength)
        If DataLength > 0 Then
            Try
                Data = Data.Substring(0, DataLength).Trim
            Catch ex As Exception
                MsgBox(Data & " " & Format(DataLength))
            End Try
        End If
        If Len(Data) > 2 Then
            'delTMMpositionCallback = AddressOf positionCallback
            'oziSendMMpositionON(delTMMpositionCallback)

            Return True
        Else
            Return False
        End If
    End Function



    Public Sub StartUpOzi()
        If CheckIfOziRunning() = False Then

            Try
                Shell("c:\Program Files\OziExplorer\oziexp.exe", AppWinStyle.NormalNoFocus, False, -1)
            Catch ex As Exception
            End Try
            Try
                Shell("c:\oziexplorer\oziexp.exe", AppWinStyle.NormalNoFocus, False, -1)
            Catch ex As Exception
            End Try
        End If

        For i As Integer = 1 To 15
            'Application.DoEvents()
            DelayTime(1)
            If CheckIfOziRunning() = True Then
                _Running = True
                GoTo ResumeHere
            End If
        Next
        _Running = False

ResumeHere:

    End Sub





#Region "Support Functions"
    Private Function revRGB(ByVal inRGB As Long) As Long
        Return (inRGB And &HFF00) Or ((inRGB And &HFF) << 16) Or ((inRGB And &HFF0000) >> 16)

    End Function

    Private Sub DelayTime(ByRef SecToDelay As Single)
        Dim MarkTime As Single
        MarkTime = GetTickCount
        Do While GetTickCount < MarkTime + SecToDelay * 1000 'Convert into Seconds
            System.Windows.Forms.Application.DoEvents()
            System.Threading.Thread.Sleep(100)

        Loop
    End Sub


#End Region

#Region "Finalize"
    Protected Overrides Sub Finalize()
        Try
            Dim i As Long = oziCloseApi()
        Catch ex As Exception

        End Try
        MyBase.Finalize()
    End Sub
#End Region


    Public Enum IconType
        GreenM
        OrangeP
        RedU
        BlueP
        GrayX
    End Enum

    Public ReadOnly Property GetColorEnum(ByVal Speed As Integer, ByVal Age As TimeSpan, ByVal EngineOn As Boolean) As IconType
        Get
            If Age.TotalMinutes > 1440 Then
                Return IconType.GrayX
            End If
            If EngineOn Then
                Return IconType.BlueP
            End If
            ' We are in EngineOn!!!
            If Speed < 5 And Age.TotalMinutes < 30 Then
                Return IconType.OrangeP
            End If
            If Age.TotalMinutes >= 30 Then
                Return IconType.RedU
            End If
            If Age.TotalMinutes < 5 Then
                Return IconType.GreenM
            End If
            Return IconType.RedU
        End Get
    End Property

    Public ReadOnly Property GetColor(ByVal Speed As Integer, ByVal Age As TimeSpan) As System.Drawing.Color
        Get
            Dim Moving As Boolean = True
            If Speed < 5 Then Moving = False
            If Age.TotalMinutes < 5 Then
                If Moving Then
                    Return System.Drawing.Color.Yellow
                End If
                Return System.Drawing.Color.LightGreen
            End If
            If Age.TotalMinutes < 30 Then
                Return System.Drawing.Color.Lime
            End If
            If Age.TotalMinutes < 1440 Then
                Return System.Drawing.Color.LightBlue
            End If
            Return System.Drawing.Color.LightGray
        End Get
    End Property


End Class

