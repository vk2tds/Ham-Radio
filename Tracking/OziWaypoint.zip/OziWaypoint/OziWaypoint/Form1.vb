Public Class Form1

    Declare Function oziCreateWP Lib "oziapi" (ByRef name As String, ByVal symbol As Int32 _
    , ByVal lat As Double, ByVal lon As Double, ByVal Altitude As Double, ByVal wpDate As Double _
    , ByVal MapDisplayFormat As Int32, ByVal PointerDirection As Int32, ByVal GarminDisplayFormat As Int32 _
    , ByVal ForeColor As Int32, ByVal BackColor As Int32, ByVal ProximityDistance As Int32, ByRef Description As String _
    , ByVal FontSize As Int32, ByVal FontStyle As Int32, ByVal SymbolSize As Int32) As Int32
    Declare Function oziRefreshMap Lib "oziapi" () As Integer

#Region "Moving Map Ozi Callbacks"
    Declare Function oziSendMMpositionOFF Lib "oziapi" () As Integer
    Declare Function oziSendMMpositionON Lib "oziapi" (ByVal p As TMMpositionCallback) As Integer
    Delegate Sub TMMpositionCallback(ByVal Lat As Double, ByVal lon As Double, _
        ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)
#End Region


    Declare Function oziCloseApi Lib "oziapi" () As Integer

    Dim Callback As TMMpositionCallback ' Must be Global!!!

    Private Sub Form1_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        oziCloseApi()
    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress

        Dim w As Integer
        w = WhichOne(e.KeyChar)
        If w = 0 Then Exit Sub

        'MsgBox(Format(w))


        Dim ret As Integer



        ret = oziCreateWP(GetAnotherOne(w), GetOne(w), _lat, _lon, _alt, -1, -1, -1, -1, -1, -1, 0, "OziWaypoint", -1, -1, -1)

        ret = oziRefreshMap
        'MsgBox(ret)

    End Sub

    Private Function WhichOne(ByVal c As Char) As Integer
        If c = decode(ComboBox1.Text) Then Return 1
        If c = decode(ComboBox3.Text) Then Return 2
        If c = decode(ComboBox5.Text) Then Return 3
        If c = decode(ComboBox7.Text) Then Return 4
        If c = decode(ComboBox9.Text) Then Return 5
        If c = decode(ComboBox11.Text) Then Return 6
        If c = decode(ComboBox13.Text) Then Return 7
        If c = decode(ComboBox15.Text) Then Return 8
        If c = decode(ComboBox17.Text) Then Return 9
        If c = decode(ComboBox19.Text) Then Return 10
        Return 0
    End Function

    Private Function GetOne(ByVal i As Integer) As Integer
        If i = 1 Then Return Val(ComboBox2.SelectedIndex + 1)
        If i = 2 Then Return Val(ComboBox4.SelectedIndex + 1)
        If i = 3 Then Return Val(ComboBox6.SelectedIndex + 1)
        If i = 4 Then Return Val(ComboBox8.SelectedIndex + 1)
        If i = 5 Then Return Val(ComboBox10.SelectedIndex + 1)
        If i = 6 Then Return Val(ComboBox12.SelectedIndex + 1)
        If i = 7 Then Return Val(ComboBox14.SelectedIndex + 1)
        If i = 8 Then Return Val(ComboBox16.SelectedIndex + 1)
        If i = 9 Then Return Val(ComboBox18.SelectedIndex + 1)
        If i = 10 Then Return Val(ComboBox20.SelectedIndex + 1)

    End Function

    Private Function GetAnotherOne(ByVal i As Integer) As String
        If i = 1 Then Return Text1.Text
        If i = 2 Then Return Text2.Text
        If i = 3 Then Return Text3.Text
        If i = 4 Then Return Text4.Text
        If i = 5 Then Return Text5.Text
        If i = 6 Then Return Text6.Text
        If i = 7 Then Return Text7.Text
        If i = 8 Then Return Text8.Text
        If i = 9 Then Return Text9.Text
        If i = 10 Then Return Text10.Text
        Return ""
    End Function

    Private Function decode(ByVal s As String) As Char
        If Len(s) = 2 Then
            Return Chr(Val(Mid(s, 2)))
        End If
        Return Mid(s, 1, 1)
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        ComboBox2.Items.Clear()
        ComboBox4.Items.Clear()
        ComboBox6.Items.Clear()
        ComboBox8.Items.Clear()
        ComboBox10.Items.Clear()
        ComboBox12.Items.Clear()
        ComboBox14.Items.Clear()
        ComboBox16.Items.Clear()
        ComboBox18.Items.Clear()
        ComboBox20.Items.Clear()


        For i As Integer = 1 To 32
            ComboBox2.Items.Add("Icon " & Format(i))
            ComboBox4.Items.Add("Icon " & Format(i))
            ComboBox6.Items.Add("Icon " & Format(i))
            ComboBox8.Items.Add("Icon " & Format(i))
            ComboBox10.Items.Add("Icon " & Format(i))
            ComboBox12.Items.Add("Icon " & Format(i))
            ComboBox14.Items.Add("Icon " & Format(i))
            ComboBox16.Items.Add("Icon " & Format(i))
            ComboBox18.Items.Add("Icon " & Format(i))
            ComboBox20.Items.Add("Icon " & Format(i))
        Next

        ComboBox3.Items.Clear()
        ComboBox5.Items.Clear()
        ComboBox7.Items.Clear()
        ComboBox9.Items.Clear()
        ComboBox11.Items.Clear()
        ComboBox13.Items.Clear()
        ComboBox15.Items.Clear()
        ComboBox17.Items.Clear()
        ComboBox19.Items.Clear()

        For i As Integer = 0 To ComboBox1.Items.Count - 1
            ComboBox3.Items.Add(ComboBox1.Items(i))
            ComboBox5.Items.Add(ComboBox1.Items(i))
            ComboBox7.Items.Add(ComboBox1.Items(i))
            ComboBox9.Items.Add(ComboBox1.Items(i))
            ComboBox11.Items.Add(ComboBox1.Items(i))
            ComboBox13.Items.Add(ComboBox1.Items(i))
            ComboBox15.Items.Add(ComboBox1.Items(i))
            ComboBox17.Items.Add(ComboBox1.Items(i))
            ComboBox19.Items.Add(ComboBox1.Items(i))

        Next

        ComboBox1.SelectedIndex = Val(My.Settings.Key1)
        ComboBox3.SelectedIndex = Val(My.Settings.Key2)
        ComboBox5.SelectedIndex = Val(My.Settings.Key3)
        ComboBox7.SelectedIndex = Val(My.Settings.Key4)
        ComboBox9.SelectedIndex = Val(My.Settings.Key5)
        ComboBox11.SelectedIndex = Val(My.Settings.Key6)
        ComboBox13.SelectedIndex = Val(My.Settings.Key7)
        ComboBox15.SelectedIndex = Val(My.Settings.Key8)
        ComboBox17.SelectedIndex = Val(My.Settings.Key9)
        ComboBox19.SelectedIndex = Val(My.Settings.Key10)

        ComboBox2.SelectedIndex = Val(My.Settings.Icon1)
        ComboBox4.SelectedIndex = Val(My.Settings.Icon2)
        ComboBox6.SelectedIndex = Val(My.Settings.Icon3)
        ComboBox8.SelectedIndex = Val(My.Settings.Icon4)
        ComboBox10.SelectedIndex = Val(My.Settings.Icon5)
        ComboBox12.SelectedIndex = Val(My.Settings.Icon6)
        ComboBox14.SelectedIndex = Val(My.Settings.Icon7)
        ComboBox16.SelectedIndex = Val(My.Settings.Icon8)
        ComboBox18.SelectedIndex = Val(My.Settings.Icon9)
        ComboBox20.SelectedIndex = Val(My.Settings.Icon10)

        Text1.Text = My.Settings.Text1
        Text2.Text = My.Settings.Text2
        Text3.Text = My.Settings.Text3
        Text4.Text = My.Settings.Text4
        Text5.Text = My.Settings.Text5
        Text6.Text = My.Settings.Text6
        Text7.Text = My.Settings.Text7
        Text8.Text = My.Settings.Text8
        Text9.Text = My.Settings.Text9
        Text10.Text = My.Settings.Text10

        Callback = AddressOf PositionCallback
        oziSendMMpositionON(Callback)


    End Sub

    Dim _lat As Double
    Dim _lon As Double
    Dim _alt As Double
    Public Sub PositionCallback(ByVal Lat As Double, ByVal lon As Double, _
            ByVal Speed As Double, ByVal COurse As Double, ByVal magvar As Double, ByVal altitude As Double)

        _lat = Lat
        _lon = lon
        _alt = altitude

    End Sub

    Private Sub Function1ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Function1ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(1))
        Form1_KeyPress(Nothing, e1)
    End Sub

    Private Sub F2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F2ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(2))
        Form1_KeyPress(Nothing, e1)
    End Sub

    Private Sub F3ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F3ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(3))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F4ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F4ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(4))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F5ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F5ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(5))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F6ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F6ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(6))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F7ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F7ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(7))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F8ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F8ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(8))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F9ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F9ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(9))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F10ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F10ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(10))
        Form1_KeyPress(Nothing, e1)

    End Sub
    Private Sub F12ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F12ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(11))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub F11ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles F11ToolStripMenuItem.Click
        Dim e1 As New System.Windows.Forms.KeyPressEventArgs(Chr(12))
        Form1_KeyPress(Nothing, e1)

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Form1_KeyPress(sender, e)
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Protected Overrides Sub Finalize()
        Try
            Dim i As Long = oziCloseApi()
        Catch ex As Exception

        End Try
        MyBase.Finalize()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        With My.Settings

            .Key1 = ComboBox1.SelectedIndex ' = Val(My.Settings.Key1)
            .Key2 = ComboBox3.SelectedIndex ' = Val(My.Settings.Key2)
            .Key3 = ComboBox5.SelectedIndex ' = Val(My.Settings.Key3)
            .Key4 = ComboBox7.SelectedIndex ' = Val(My.Settings.Key4)
            .Key5 = ComboBox9.SelectedIndex ' = Val(My.Settings.Key5)
            .Key6 = ComboBox11.SelectedIndex ' = Val(My.Settings.Key6)
            .Key7 = ComboBox13.SelectedIndex ' = Val(My.Settings.Key7)
            .Key8 = ComboBox15.SelectedIndex ' = Val(My.Settings.Key8)
            .Key9 = ComboBox17.SelectedIndex ' = Val(My.Settings.Key9)
            .Key10 = ComboBox19.SelectedIndex ' = Val(My.Settings.Key10)

            .Icon1 = ComboBox2.SelectedIndex ' = Val(My.Settings.Icon1)
            .Icon2 = ComboBox4.SelectedIndex ' = Val(My.Settings.Icon2))
            .Icon3 = ComboBox6.SelectedIndex ' = Val(My.Settings.Icon3))
            .Icon4 = ComboBox8.SelectedIndex ' = Val(My.Settings.Icon4)
            .Icon5 = ComboBox10.SelectedIndex ' = Val(My.Settings.Icon5)
            .Icon6 = ComboBox12.SelectedIndex ' = Val(My.Settings.Icon6)
            .Icon7 = ComboBox14.SelectedIndex ' = Val(My.Settings.Icon7)
            .Icon8 = ComboBox16.SelectedIndex ' = Val(My.Settings.Icon8)
            .Icon9 = ComboBox18.SelectedIndex ' = Val(My.Settings.Icon9)
            .Icon10 = ComboBox20.SelectedIndex ' = Val(My.Settings.Icon10)

            .Text1 = Text1.Text
            .Text2 = Text2.Text
            .Text3 = Text3.Text
            .Text4 = Text4.Text
            .Text5 = Text5.Text
            .Text6 = Text6.Text
            .Text7 = Text7.Text
            .Text8 = Text8.Text
            .Text9 = Text9.Text
            .Text10 = Text10.Text

            .Save()
        End With
        Timer1.Interval = 5000
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox4.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox5.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox6_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox6.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox7_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox7.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox8_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox8.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox9_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox9.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox10_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox10.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox11_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox11.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox12_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox12.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox13_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox13.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox14_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox14.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox15_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox15.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox16_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox16.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox17_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox17.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox18_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox18.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox19_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox19.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub ComboBox20_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox20.SelectedIndexChanged
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        Timer1.Interval = 5000
        Me.ActiveControl = TextBox1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim size2 As New Size(Me.Size.Width, 26)
        Me.Size = size2

        Me.Top = 0
        Me.Left = 0

        'Size.Height(32)

    End Sub
End Class