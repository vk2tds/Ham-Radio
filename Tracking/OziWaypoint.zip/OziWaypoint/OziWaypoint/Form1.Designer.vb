<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FILEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.KeysToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Function1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.ComboBox4 = New System.Windows.Forms.ComboBox
        Me.ComboBox5 = New System.Windows.Forms.ComboBox
        Me.ComboBox6 = New System.Windows.Forms.ComboBox
        Me.ComboBox7 = New System.Windows.Forms.ComboBox
        Me.ComboBox8 = New System.Windows.Forms.ComboBox
        Me.ComboBox9 = New System.Windows.Forms.ComboBox
        Me.ComboBox10 = New System.Windows.Forms.ComboBox
        Me.ComboBox11 = New System.Windows.Forms.ComboBox
        Me.ComboBox12 = New System.Windows.Forms.ComboBox
        Me.ComboBox13 = New System.Windows.Forms.ComboBox
        Me.ComboBox14 = New System.Windows.Forms.ComboBox
        Me.ComboBox15 = New System.Windows.Forms.ComboBox
        Me.ComboBox16 = New System.Windows.Forms.ComboBox
        Me.ComboBox17 = New System.Windows.Forms.ComboBox
        Me.ComboBox18 = New System.Windows.Forms.ComboBox
        Me.ComboBox19 = New System.Windows.Forms.ComboBox
        Me.ComboBox20 = New System.Windows.Forms.ComboBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Text1 = New System.Windows.Forms.TextBox
        Me.Text2 = New System.Windows.Forms.TextBox
        Me.Text3 = New System.Windows.Forms.TextBox
        Me.Text4 = New System.Windows.Forms.TextBox
        Me.Text5 = New System.Windows.Forms.TextBox
        Me.Text10 = New System.Windows.Forms.TextBox
        Me.Text9 = New System.Windows.Forms.TextBox
        Me.Text8 = New System.Windows.Forms.TextBox
        Me.Text7 = New System.Windows.Forms.TextBox
        Me.Text6 = New System.Windows.Forms.TextBox
        Me.F11ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.F12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Button1 = New System.Windows.Forms.Button
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FILEToolStripMenuItem, Me.KeysToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(400, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FILEToolStripMenuItem
        '
        Me.FILEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem})
        Me.FILEToolStripMenuItem.Name = "FILEToolStripMenuItem"
        Me.FILEToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FILEToolStripMenuItem.Text = "&File"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'KeysToolStripMenuItem
        '
        Me.KeysToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Function1ToolStripMenuItem, Me.F2ToolStripMenuItem, Me.F3ToolStripMenuItem, Me.F4ToolStripMenuItem, Me.F5ToolStripMenuItem, Me.F6ToolStripMenuItem, Me.F7ToolStripMenuItem, Me.F8ToolStripMenuItem, Me.F9ToolStripMenuItem, Me.F10ToolStripMenuItem, Me.F11ToolStripMenuItem, Me.F12ToolStripMenuItem})
        Me.KeysToolStripMenuItem.Name = "KeysToolStripMenuItem"
        Me.KeysToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12
        Me.KeysToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.KeysToolStripMenuItem.Text = "&Keys"
        Me.KeysToolStripMenuItem.Visible = False
        '
        'Function1ToolStripMenuItem
        '
        Me.Function1ToolStripMenuItem.Name = "Function1ToolStripMenuItem"
        Me.Function1ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.Function1ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.Function1ToolStripMenuItem.Text = "F1"
        '
        'F2ToolStripMenuItem
        '
        Me.F2ToolStripMenuItem.Name = "F2ToolStripMenuItem"
        Me.F2ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.F2ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F2ToolStripMenuItem.Text = "F2"
        '
        'F3ToolStripMenuItem
        '
        Me.F3ToolStripMenuItem.Name = "F3ToolStripMenuItem"
        Me.F3ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3
        Me.F3ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F3ToolStripMenuItem.Text = "F3"
        '
        'F4ToolStripMenuItem
        '
        Me.F4ToolStripMenuItem.Name = "F4ToolStripMenuItem"
        Me.F4ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4
        Me.F4ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F4ToolStripMenuItem.Text = "F4"
        '
        'F5ToolStripMenuItem
        '
        Me.F5ToolStripMenuItem.Name = "F5ToolStripMenuItem"
        Me.F5ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.F5ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F5ToolStripMenuItem.Text = "F5"
        '
        'F6ToolStripMenuItem
        '
        Me.F6ToolStripMenuItem.Name = "F6ToolStripMenuItem"
        Me.F6ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6
        Me.F6ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F6ToolStripMenuItem.Text = "F6"
        '
        'F7ToolStripMenuItem
        '
        Me.F7ToolStripMenuItem.Name = "F7ToolStripMenuItem"
        Me.F7ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7
        Me.F7ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F7ToolStripMenuItem.Text = "F7"
        '
        'F8ToolStripMenuItem
        '
        Me.F8ToolStripMenuItem.Name = "F8ToolStripMenuItem"
        Me.F8ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8
        Me.F8ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F8ToolStripMenuItem.Text = "F8"
        '
        'F9ToolStripMenuItem
        '
        Me.F9ToolStripMenuItem.Name = "F9ToolStripMenuItem"
        Me.F9ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9
        Me.F9ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F9ToolStripMenuItem.Text = "F9"
        '
        'F10ToolStripMenuItem
        '
        Me.F10ToolStripMenuItem.Name = "F10ToolStripMenuItem"
        Me.F10ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10
        Me.F10ToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.F10ToolStripMenuItem.Text = "F10"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox1.Location = New System.Drawing.Point(12, 59)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(139, 59)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 2
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(12, 86)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 4
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox4.Location = New System.Drawing.Point(139, 86)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 3
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(12, 113)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 6
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox6.Location = New System.Drawing.Point(139, 113)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox6.TabIndex = 5
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(12, 140)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox7.TabIndex = 8
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox8.Location = New System.Drawing.Point(139, 140)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox8.TabIndex = 7
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(12, 167)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox9.TabIndex = 10
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox10.Location = New System.Drawing.Point(139, 167)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox10.TabIndex = 9
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(12, 194)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox11.TabIndex = 12
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox12.Location = New System.Drawing.Point(139, 194)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox12.TabIndex = 11
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(12, 221)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox13.TabIndex = 14
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox14.Location = New System.Drawing.Point(139, 221)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox14.TabIndex = 13
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(12, 248)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox15.TabIndex = 16
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox16.Location = New System.Drawing.Point(139, 248)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox16.TabIndex = 15
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(12, 275)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox17.TabIndex = 18
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox18.Location = New System.Drawing.Point(139, 275)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox18.TabIndex = 17
        '
        'ComboBox19
        '
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(12, 302)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox19.TabIndex = 20
        '
        'ComboBox20
        '
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})
        Me.ComboBox20.Location = New System.Drawing.Point(139, 302)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox20.TabIndex = 19
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 33)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(248, 20)
        Me.TextBox1.TabIndex = 21
        '
        'Timer1
        '
        '
        'Text1
        '
        Me.Text1.Location = New System.Drawing.Point(266, 59)
        Me.Text1.Name = "Text1"
        Me.Text1.Size = New System.Drawing.Size(121, 20)
        Me.Text1.TabIndex = 22
        '
        'Text2
        '
        Me.Text2.Location = New System.Drawing.Point(266, 86)
        Me.Text2.Name = "Text2"
        Me.Text2.Size = New System.Drawing.Size(121, 20)
        Me.Text2.TabIndex = 23
        '
        'Text3
        '
        Me.Text3.Location = New System.Drawing.Point(266, 114)
        Me.Text3.Name = "Text3"
        Me.Text3.Size = New System.Drawing.Size(121, 20)
        Me.Text3.TabIndex = 24
        '
        'Text4
        '
        Me.Text4.Location = New System.Drawing.Point(266, 141)
        Me.Text4.Name = "Text4"
        Me.Text4.Size = New System.Drawing.Size(121, 20)
        Me.Text4.TabIndex = 25
        '
        'Text5
        '
        Me.Text5.Location = New System.Drawing.Point(266, 167)
        Me.Text5.Name = "Text5"
        Me.Text5.Size = New System.Drawing.Size(121, 20)
        Me.Text5.TabIndex = 26
        '
        'Text10
        '
        Me.Text10.Location = New System.Drawing.Point(266, 301)
        Me.Text10.Name = "Text10"
        Me.Text10.Size = New System.Drawing.Size(121, 20)
        Me.Text10.TabIndex = 31
        '
        'Text9
        '
        Me.Text9.Location = New System.Drawing.Point(266, 275)
        Me.Text9.Name = "Text9"
        Me.Text9.Size = New System.Drawing.Size(121, 20)
        Me.Text9.TabIndex = 30
        '
        'Text8
        '
        Me.Text8.Location = New System.Drawing.Point(266, 248)
        Me.Text8.Name = "Text8"
        Me.Text8.Size = New System.Drawing.Size(121, 20)
        Me.Text8.TabIndex = 29
        '
        'Text7
        '
        Me.Text7.Location = New System.Drawing.Point(266, 220)
        Me.Text7.Name = "Text7"
        Me.Text7.Size = New System.Drawing.Size(121, 20)
        Me.Text7.TabIndex = 28
        '
        'Text6
        '
        Me.Text6.Location = New System.Drawing.Point(266, 193)
        Me.Text6.Name = "Text6"
        Me.Text6.Size = New System.Drawing.Size(121, 20)
        Me.Text6.TabIndex = 27
        '
        'F11ToolStripMenuItem
        '
        Me.F11ToolStripMenuItem.Name = "F11ToolStripMenuItem"
        Me.F11ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F11
        Me.F11ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.F11ToolStripMenuItem.Text = "F11"
        '
        'F12ToolStripMenuItem
        '
        Me.F12ToolStripMenuItem.Name = "F12ToolStripMenuItem"
        Me.F12ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12
        Me.F12ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.F12ToolStripMenuItem.Text = "F12"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(266, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(121, 20)
        Me.Button1.TabIndex = 32
        Me.Button1.Text = "Make Small"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 338)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Text10)
        Me.Controls.Add(Me.Text9)
        Me.Controls.Add(Me.Text8)
        Me.Controls.Add(Me.Text7)
        Me.Controls.Add(Me.Text6)
        Me.Controls.Add(Me.Text5)
        Me.Controls.Add(Me.Text4)
        Me.Controls.Add(Me.Text3)
        Me.Controls.Add(Me.Text2)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ComboBox19)
        Me.Controls.Add(Me.ComboBox20)
        Me.Controls.Add(Me.ComboBox17)
        Me.Controls.Add(Me.ComboBox18)
        Me.Controls.Add(Me.ComboBox15)
        Me.Controls.Add(Me.ComboBox16)
        Me.Controls.Add(Me.ComboBox13)
        Me.Controls.Add(Me.ComboBox14)
        Me.Controls.Add(Me.ComboBox11)
        Me.Controls.Add(Me.ComboBox12)
        Me.Controls.Add(Me.ComboBox9)
        Me.Controls.Add(Me.ComboBox10)
        Me.Controls.Add(Me.ComboBox7)
        Me.Controls.Add(Me.ComboBox8)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox6)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "OziWaypoint"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FILEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeysToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Function1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F7ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F8ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F9ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F10ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox15 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox16 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox17 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox18 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox19 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox20 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Text1 As System.Windows.Forms.TextBox
    Friend WithEvents Text2 As System.Windows.Forms.TextBox
    Friend WithEvents Text3 As System.Windows.Forms.TextBox
    Friend WithEvents Text4 As System.Windows.Forms.TextBox
    Friend WithEvents Text5 As System.Windows.Forms.TextBox
    Friend WithEvents Text10 As System.Windows.Forms.TextBox
    Friend WithEvents Text9 As System.Windows.Forms.TextBox
    Friend WithEvents Text8 As System.Windows.Forms.TextBox
    Friend WithEvents Text7 As System.Windows.Forms.TextBox
    Friend WithEvents Text6 As System.Windows.Forms.TextBox
    Friend WithEvents F11ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents F12ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
